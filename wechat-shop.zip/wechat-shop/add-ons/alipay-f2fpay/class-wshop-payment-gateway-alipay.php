<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

class WShop_Payment_Gateway_Alipay_F2FPay extends Abstract_WShop_Payment_Gateway{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Payment_Gateway_Alipay_F2FPay
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Payment_Gateway_Alipay_F2FPay
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='alipay_f2fpay';
        $this->group = 'alipay_f2fpay';
        $this->title=__('Alipay',WSHOP);
        $this->icon=WSHOP_URL.'/assets/image/alipay-l.png';
        $this->icon_small=WSHOP_URL.'/assets/image/alipay.png';
        
        $this->init_form_fields ();
        $this->enabled ='yes'==$this->get_option('enabled');
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields() {
        $this->form_fields = array (
            'enabled' => array (
                'title' => __ ( 'Enable/Disable', WSHOP ),
                'type' => 'checkbox',
                'label' => __ ( 'Enable alipay payment', WSHOP ),
                'default' => 'yes'
            ),
            'appid' => array (
                'title' => __ ( 'APP ID', WSHOP ),
                'type' => 'text',
                'description' => '<a href="https://www.wpweixin.net/blog/2140.html" target="_blank">帮助文档</a>',
                'required' => true,
                'css' => 'width:400px'
            ),
            'private_key' => array (
                'title' => __ ( 'Private.key', WSHOP ),
                'type' => 'textarea',
                'css' => 'width:400px',
                'required' => true,
                'desc_tip' => false,
                'description'=>'此处填写的是应用私钥',
            ),
            'public_key' => array (
                'title' => __ ( 'Public.key', WSHOP ),
                'type' => 'textarea',
                'css' => 'width:400px',
                'description'=>'此处填写的是<span style="color:red;">支付宝公钥</span>(非应用公钥)',
                'required' => true,
                'desc_tip' => false
            )
        );
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Payment_Gateway::process_payment()
     */
    public function process_payment($order)
    {
        $api = WShop_Add_On_Alipay_F2FPay::instance();
        
        return WShop_Error::success(WShop::instance()->ajax_url(array(
            'action'=>"wshop_{$api->id}",
            'tab'=>'pay',
            'order_id'=>$order->id
        ),true,true));
    }
    
    public function query_order_transaction($transaction_id, $order){
        if($transaction_id){
            return $transaction_id;
        }
        $parameter = array (
            'app_id' =>$this->get_option('appid'),
            'method'=>'alipay.trade.query',
            'charset'=>'utf-8',
            'sign_type'=>'RSA2',
            'timestamp'=>date_i18n('Y-m-d H:i:s'),
            'version'=>'1.0',
            'biz_content'=>json_encode(array(
                'out_trade_no'=>$order->sn
            ))
        );
        
        try {
            $parameter['sign'] = WShop_Add_On_Alipay_F2FPay::instance()->generate_sign($parameter,$this->get_option('private_key'));
            $response = WShop_Helper_Http::http_post('https://openapi.alipay.com/gateway.do',$parameter,false,null,true);
            $response = iconv("GB2312","UTF-8",$response);
            $response = json_decode($response,true);
            if(!$response||!is_array($response)){
                $response=array();
            }
            
            if(isset($response['trade_status'])&&in_array($response['trade_status'], array('TRADE_SUCCESS','TRADE_FINISHED'))){
               return $response['trade_no'];
            }
        }catch (Exception $e){
            
        }
        
        return $transaction_id;
    }
}
?>