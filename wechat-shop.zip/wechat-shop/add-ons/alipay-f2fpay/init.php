<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
require_once 'abstract-xh-add-ons-api.php';
require_once 'class-wshop-payment-gateway-alipay.php';	

/**
 * @author rain
 *
 */
class WShop_Add_On_Alipay_F2FPay extends Abstract_WShop_Add_Ons_Alipay_F2FPay_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Alipay_F2FPay
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Alipay_F2FPay
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        $this->id='wshop_add_ons_alipay_f2fpay';
        $this->title='支付宝 - 当面付';
        $this->description='支付宝 - 当面付，支持扫码支付，移动端调用支付宝app';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url("admin.php?page=wshop_page_default&section=menu_default_checkout&sub=alipay_f2fpay")
            )
        );
    }

    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        $this->m2();
    }

    /**
     * 监听支付成功回调
     * @since 1.0.0
     */
    public function on_after_init(){
        
        if(
            isset($_POST['notify_type'])
            &&$_POST['notify_type']=='trade_status_sync'
            &&isset($_POST['notify_time'])
            &&isset($_POST['notify_id'])
            &&isset($_POST['sign_type'])
            &&$_POST['sign_type']=='RSA2'
            &&isset($_POST['trade_no'])
            &&isset($_POST['app_id'])
            &&isset($_POST['out_trade_no'])
        ){
            
            $request =stripslashes_deep($_POST) ;
            
            $request = apply_filters('wshop_payment_gateway_alipay_f2fpay_notify',$request);
            
            $out_trade_no = $request['out_trade_no'];
            $transaction_id = $request['trade_no'];
            $trade_status = $request['trade_status'];
            $order = WShop::instance()->payment->get_order('sn', $out_trade_no);
            if(!$order){
                //可能是其他支付方式的回调
                return;
            }
            $api = WShop_Payment_Gateway_Alipay_F2FPay::instance();
            $public_key  = $api->get_option('public_key');
            $sign = $request["sign"];
            $notify_id = $request['notify_id'];
            $partner = $api->get_option('appid');
            $public_key  = $api->get_option('public_key');
            
            if(!$this->validate_sign($request, $public_key)){
                WShop_Log::error('invalid sign:'.print_r($request,true));
                return;
            }
             
            try {
                if ($trade_status == 'TRADE_FINISHED' || $trade_status == 'TRADE_SUCCESS') {
                    $error =$order->complete_payment($transaction_id);
                    if(!WShop_Error::is_valid($error)){
                        WShop_Log::error('complete_payment fail:'.$error->errmsg);
                        echo 'faild!';
                        exit;
                    }
                }
            } catch (Exception $e) {
                WShop_Log::error($e);
                echo 'faild';
                exit;
            }
            
            echo 'success';
            exit;
        }
        
    }
  
    /**
     * 执行支付相关操作
     * @since 1.0.0
     */
    public function do_ajax(){
        $action ="wshop_{$this->id}";
    
        
        switch (isset($_REQUEST['tab'])?$_REQUEST['tab']:null){
            case 'pay':
                $datas=WShop_Async::instance()->shortcode_atts(array(
                    'notice_str'=>null,
                    'action'=>$action,
                    $action=>null,
                    'tab'=>null,
                    'order_id'=>0
                ), stripslashes_deep($_REQUEST));
               
                if(!WShop::instance()->WP->ajax_validate($datas, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
                    WShop::instance()->WP->wp_die(WShop_Error::err_code(701));
                    exit;
                }
               
                if(WShop_Helper_Uri::is_wechat_app()){
                    require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/alipay-f2fpay/in-wechat-warning.php');
                    exit;
                }
                
                if(!isset($_REQUEST['skip_qq_vd'])){
                    if(strripos(strtolower($_SERVER['HTTP_USER_AGENT']),'qq')!==false){
                        require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/alipay-f2fpay/in-qq-warning.php');
                        exit;
                    }
                }
                
                if(WShop_Helper_Uri::is_app_client()){
                    require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/alipay-f2fpay/wap.php');
                    exit;
                }
                
                require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/alipay-f2fpay/qrcode.php');
                exit;
        }
    }
    
    public function validate_sign(array $params,$publickey){
        $sign = $params['sign'];
        $signType = $params['sign_type'];
        unset($params['sign_type']);
        unset($params['sign']);
        
        $args = '';
        $i = 0;
        ksort($params);
        reset($params);
        foreach ($params as $k => $v) {
            if (!is_null($v)&&$v!=='') {
                if ($i == 0) {
                    $args .= "{$k}={$v}";
                } else {
                    $args .= "&{$k}={$v}" ;
                }
                $i++;
            }
        }
        unset ($k, $v);
        if(strpos($publickey, '-----BEGIN PUBLIC KEY-----')===false)
        $publickey = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($publickey, 64, "\n", true) . "\n-----END PUBLIC KEY-----";
     
        return (bool)openssl_verify($args, base64_decode($sign), $publickey, version_compare(PHP_VERSION,'5.4.0', '<') ? SHA256 : OPENSSL_ALGO_SHA256); 
    }
    
    public function generate_sign(array $params,$private_key) {
        ksort($params);
        reset($params);
        
        $args = '';
        $i = 0;
        foreach ($params as $k => $v) {
            if (!is_null($v)&&$v!=='') {
                if ($i == 0) {
                    $args .= "{$k}={$v}";
                } else {
                    $args .= "&{$k}={$v}" ;
                }
                $i++;
            }
        }
        unset ($k, $v);
        
        if(strpos($private_key, '-----BEGIN RSA PRIVATE KEY-----')===false)
            $private_key = "-----BEGIN RSA PRIVATE KEY-----\n" . wordwrap($private_key, 64, "\n", true) . "\n-----END RSA PRIVATE KEY-----";
        
        openssl_sign($args, $sign, $private_key, version_compare(PHP_VERSION,'5.4.0', '<') ? SHA256 : OPENSSL_ALGO_SHA256); //OPENSSL_ALGO_SHA256是php5.4.8以上版本才支持
        
        return base64_encode($sign);
    }
}

return WShop_Add_On_Alipay_F2FPay::instance();
?>