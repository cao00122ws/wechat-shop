<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
$api = WShop_Add_On_Alipay_F2FPay::instance();
?>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?php echo __('Alipay',WSHOP)?></title>
</head>
<body style="padding:0;margin:0;">
<?php 
if(WShop_Helper_Uri::is_ios()){
    ?>
	<img alt="<?php echo __('Alipay',WSHOP)?>" src="<?php print $api->domain_url?>/images/ios.png" style="max-width: 100%;">
	<?php 
}else{
	?>
	<img alt="<?php echo __('Alipay',WSHOP)?>" src="<?php print $api->domain_url?>/images/android.jpg" style="max-width: 100%;">
	<?php 
}
?>
</body>
</html>