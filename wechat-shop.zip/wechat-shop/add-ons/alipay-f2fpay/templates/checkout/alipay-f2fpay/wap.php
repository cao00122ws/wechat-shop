<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

$order = WShop::instance()->payment->get_order('id', $_GET['order_id']);
if(!$order){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404));
    exit;
}
if($order->is_paid()){
    wp_redirect($order->get_received_url());
    exit;
}
if(!$order->can_pay()){
    WShop::instance()->WP->wp_die(WShop_Error::error_custom(__('Current order is paid or expired!',WSHOP)));
    exit;
}

$api = WShop_Payment_Gateway_Alipay_F2FPay::instance();
$appid =$api->get_option('appid');
$private_key =$api->get_option('private_key');

//创建订单支付编号
$sn = $order->generate_sn();
if($sn instanceof WShop_Error){
    WShop::instance()->WP->wp_die($sn);
    exit;
}

$exchange_rate = round(floatval(WShop_Settings_Default_Basic_Default::instance()->get_option('exchange_rate')),3);
if($exchange_rate<=0){
    $exchange_rate = 1;
}

$parameter = array (
    'app_id' =>$appid,
    'method'=>'alipay.trade.precreate',
    'charset'=>'utf-8',
    'sign_type'=>'RSA2',
    'timestamp'=>date_i18n('Y-m-d H:i:s'),
    'version'=>'1.0',
    'notify_url'=>home_url('/'),
    'biz_content'=>json_encode(array(
        'out_trade_no'=>$sn,
        'total_amount'=>round($order->get_total_amount()*$exchange_rate,2),
        'subject'=> mb_strimwidth($order->get_title(), 0, 32,'...','utf-8')
    ))
);

try {

    $parameter['sign'] = WShop_Add_On_Alipay_F2FPay::instance()->generate_sign($parameter,$private_key);
    $response = WShop_Helper_Http::http_post('https://openapi.alipay.com/gateway.do',$parameter,false,null,true);
    $response = iconv("GB2312","UTF-8",$response);
    $response = json_decode($response,true);
    if(!$response||!is_array($response)){
        $response=array();
    }
    
    if(!isset($response['alipay_trade_precreate_response']['code'])||$response['alipay_trade_precreate_response']['code']!=10000){
        throw new Exception(print_r($response,true));
    }
    if ( ! $guessurl = site_url() ){
        $guessurl = wp_guess_url();
    }
    ?>
   <html>
	<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="">
    <meta name="description" content="">   
    <title>支付宝收银台</title>
    <style>
 *{margin:0;padding:0;}
  body{padding-top: 50px; background: #f2f2f4;}
 .clearfix:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }
.clearfix { display: inline-block; }
* html .clearfix { height: 1%; }
.clearfix { display: block; }
  .xh-title{height:35px;line-height:35px;text-align:center;font-size:30px;margin-bottom:20px;font-weight:300;}
  .qrbox{max-width: 900px;margin: 0 auto;background:#f9f9f9;padding:35px 20px 20px 50px;}
  
  .qrbox .left{width: 95%;        
     display: block;
    margin: 0px auto;}
  .qrbox .left .qrcon{
    border-radius: 10px;
    background: #fff;
    overflow: visible;
    text-align: center;
    padding-top:25px;
    color: #555;
    box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .05);
    vertical-align: top;
    -webkit-transition: all .2s linear;
    transition: all .2s linear;
  }
    .qrbox .left .qrcon .logo{width: 100%;}
    .qrbox .left .qrcon .title{font-size: 16px;margin: 10px auto;width: 100%;height:30px;line-height:30px;overflow:hidden;text-overflow :ellipsis }
    .qrbox .left .qrcon .price{font-size: 22px;margin: 0px auto;width: 100%;}
    .qrbox .left .qrcon .bottom{border-radius: 0 0 10px 10px;
    width: 100%;
    background: #32343d;
    color: #f2f2f2;padding:15px 0px;text-align: center;font-size: 14px;}
   .qrbox .sys{width: 60%;float: right;text-align: center;padding-top:20px;font-size: 12px;color: #ccc}
   .qrbox img{max-width: 100%;}
   @media (max-width : 767px){
.qrbox{padding:20px;}
    .qrbox .left{width: 95%;float: none;}   
    .qrbox .sys{display: none;}
   }
   
   @media (max-width : 320px){
   body{padding-top:35px;}
  }
  @media ( min-width: 321px) and ( max-width:375px ){
body{padding-top:35px;}
  }
    </style>
    </head>
    
    <body >
   	
      <div class="qrbox clearfix">
      <div class="left">
         <div class="qrcon">
          
           <h5><img src="<?php print WSHOP_URL;?>/assets/image/alipay/logo.png" style="height:40px;" alt=""></h5>
             <div class="title"><?php print $order->get_title();?></div>
         	 <div class="price">￥<?php echo $order->get_total_amount(false);?></div>
         	 <br/>
         	  <div id="btn-refresh" style="display:none;"><a href="">已支付？点击此处刷新！</a></div>
         	  <br/>
         	  <br/>
         	  <script src="<?php echo $guessurl.'/wp-includes/js/jquery/jquery.js'; ?>"></script>
             <script type="text/javascript">
                 (function($){
              		window.view={
              			query:function () {
              		        $.ajax({
              		            type: "POST",
              		            url: '<?php print WShop::instance()->ajax_url(array(
              		                'action'=>'wshop_checkout_v2',
              		                'order_id'=>$order->id,
              		                'tab'=>'is_paid'
              		            ),true,true);?>',
              		            timeout:6000,
              		            cache:false,
              		            dataType:'json',
              		            success:function(e){
              		                if (e && e.data.paid) {
              			                $('#weixin-notice').css('color','green').text('已支付成功，跳转中...');
              		                    location.href = e.data.received_url;
              		                    return;
              		                }
              		                $('#btn-refresh').css('display','block');
              		                setTimeout(function(){window.view.query();}, 1500);
              		            },
              		            error:function(){
             		            	 $('#btn-refresh').css('display','block');
              		            	 setTimeout(function(){window.view.query();}, 1500);
              		            }
              		        });
              		    }
              		};
          		
         		 	window.view.query();
          		})(jQuery);
          		setTimeout(function(){
          			location.href='<?php echo esc_url($response['alipay_trade_precreate_response']['qr_code'])?>';
              	},1000);
             	
             	
             </script>
         </div>
         </div>
      </div>
     
    </body>
    </html>
    <?php 
} catch (Exception $e) {
    WShop_Log::error($e);
    WShop::instance()->WP->wp_die($e);
    exit;
}