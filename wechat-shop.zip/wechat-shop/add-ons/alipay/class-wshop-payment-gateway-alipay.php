<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

class WShop_Payment_Gateway_Alipay extends Abstract_WShop_Payment_Gateway{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Payment_Gateway_Alipay
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Payment_Gateway_Alipay
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='alipay';
        $this->group = 'alipay';
        $this->title=__('Alipay',WSHOP);
        $this->icon=WSHOP_URL.'/assets/image/alipay-l.png';
        $this->icon_small=WSHOP_URL.'/assets/image/alipay.png';
        
        $this->init_form_fields ();
        $this->enabled ='yes'==$this->get_option('enabled');
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields() {
        $this->form_fields = array (
            'enabled' => array (
                'title' => __ ( 'Enable/Disable', WSHOP ),
                'type' => 'checkbox',
                'label' => __ ( 'Enable alipay payment', WSHOP ),
                'default' => 'yes'
            ),
            'appid' => array (
                'title' => __ ( 'PID', WSHOP ),
                'type' => 'text',
                'description' => '<a href="https://www.wpweixin.net/blog/1444.html" target="_blank">帮助文档</a>',
                'required' => true,
                'css' => 'width:400px'
            ),
            'appsecret' => array (
                'title' => __ ( 'MD5 KEY', WSHOP ),
                'type' => 'text',
                'css' => 'width:400px',
                'required' => true,
                'desc_tip' => false
            )
        );
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Payment_Gateway::process_payment()
     */
    public function process_payment($order)
    {
        $api = WShop_Add_On_Alipay::instance();
        
        return WShop_Error::success(WShop::instance()->ajax_url(array(
            'action'=>"wshop_{$api->id}",
            'tab'=>'pay',
            'order_id'=>$order->id
        ),true,true));
    }
    
    public function query_order_transaction($transaction_id,$order){
        if($transaction_id){
            return $transaction_id;
        }
        
        $appid = $this->get_option('appid');
        $parameter = array (
            'service' => 'single_trade_query',
            'partner' =>$appid,
            'out_trade_no'=>$order->sn,
            '_input_charset' => 'utf-8'
        );
        
        ksort($parameter);
        reset($parameter);
        
        $parameter['sign'] = WShop_Add_On_Alipay::instance()->generate_sign($parameter,$this->get_option('appsecret') );
        $parameter['sign_type'] = 'MD5';
        
        try {
            $response = WShop_Helper_Http::http_get('https://mapi.alipay.com/gateway.do?'.http_build_query($parameter),true);
            $response = WShop_Helper_String::xml_to_obj($response);
             
            if($response
                &&isset($response['is_success'])&&$response['is_success']=='T'
                &&isset($response['response']['trade']['trade_status'])&&$response['response']['trade']['trade_status']=='TRADE_SUCCESS'){
                    return $response['response']['trade']['trade_no'];
            }
        } catch (Exception $e) {
            
        }
        
        return $transaction_id;
    }
}
?>