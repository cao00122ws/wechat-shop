<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
require_once 'abstract-xh-add-ons-api.php';
require_once 'class-wshop-payment-gateway-alipay.php';	   
/**
 * @author rain
 *
 */
class WShop_Add_On_Alipay extends Abstract_WShop_Add_Ons_Alipay_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Alipay
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Alipay
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        $this->id='wshop_add_ons_alipay';
        $this->title=__('Alipay',WSHOP);
        $this->description='支付宝网关，同时支持电脑和手机网站支付，自适应平台，手机浏览器自动唤醒app支付';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url("admin.php?page=wshop_page_default&section=menu_default_checkout&sub=alipay")
            )
        );
    }

    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        $this->m2();
    }

    /**
     * 监听支付成功回调
     * @since 1.0.0
     */
    public function on_after_init(){       
        if(
            //isset($_POST['buyer_id'])//wp版本，没有buyer_id参数
            isset($_POST['notify_id'])
            &&isset($_POST['sign_type'])
            &&isset($_POST['sign'])
            &&isset($_POST['seller_id'])
            &&isset($_POST['out_trade_no'])
            &&isset($_POST['trade_status'])
            &&isset($_POST['trade_no'])
        ){
            $api = WShop_Payment_Gateway_Alipay::instance();
            $request =stripslashes_deep($_POST) ;
            
            $request = apply_filters('wshop_payment_gateway_alipay_notify',$request);
            
            $out_trade_no = $request['out_trade_no'];
            $transaction_id = $request['trade_no'];
            $trade_status = $request['trade_status'];
            $order = WShop::instance()->payment->get_order('sn', $out_trade_no);
            if(!$order){
                //可能是其他支付方式的回调
                return;
            }
            
            $sign = $request["sign"];
            $notify_id = $request['notify_id'];
            $partner = $api->get_option('appid');
            $secret  = $api->get_option('appsecret');
            
            if($sign!==$this->generate_sign($request, $secret)){
                WShop_Log::error('invalid sign:'.print_r($request,true));
                return;
            }
             
            try {
                $response = WShop_Helper_Http::http_get("http://notify.alipay.com/trade/notify_query.do?partner={$partner}&notify_id={$notify_id}",true);
                if(!preg_match("/true$/i", $response)){
                    WShop_Log::error('invalid order status'.$response);
                    echo 'faild';
                    exit;
                }
            
               
                
                if ($trade_status == 'TRADE_FINISHED' || $trade_status == 'TRADE_SUCCESS') {
                    
            
                    $error =$order->complete_payment($transaction_id);
                    if(!WShop_Error::is_valid($error)){
                        WShop_Log::error('complete_payment fail:'.$error->errmsg);
                        echo 'faild!';
                        exit;
                    }
                }
            } catch (Exception $e) {
                WShop_Log::error($e);
                echo 'faild';
                exit;
            }
            
            echo 'success';
            exit;
        }
        
        if(
            //isset($_GET['buyer_id'])//wp版本，没有buyer_id参数
            isset($_GET['notify_id'])
            &&isset($_GET['sign_type'])
            &&isset($_GET['sign'])
            &&isset($_GET['seller_id'])
            &&isset($_GET['out_trade_no'])
            &&isset($_GET['trade_status'])
            &&isset($_GET['trade_no'])
            ){
                $request = array();
                $url = WShop_Helper_Uri::get_uri_without_params(WShop_Helper_Uri::get_location_uri(),$request,true);
                $api = WShop_Payment_Gateway_Alipay::instance();
                $secret  = $api->get_option('appsecret');

                $order = WShop::instance()->payment->get_order('sn', $_GET['out_trade_no']);
                if(!$order){
                    return;
                }
                
                $sign =$_GET['sign'];
                if($sign!==$this->generate_sign($request, $secret)){
                    WShop_Log::error('invalid sign:'.print_r($request,true));
                    return;
                }
                
                $trade_status = $_GET['trade_status'];
                $transaction_id = $_GET['trade_no'];
                
                if ($trade_status == 'TRADE_FINISHED' || $trade_status == 'TRADE_SUCCESS') {
                    $error =$order->complete_payment($transaction_id);
                    if(!WShop_Error::is_valid($error)){
                        WShop::instance()->WP->wp_die($error);
                        exit;
                    }
                }
                
                wp_redirect($order->get_received_url());
                exit;
         }
    }
  
    /**
     * 执行支付相关操作
     * @since 1.0.0
     */
    public function do_ajax(){
        $action ="wshop_{$this->id}";
    
        
        switch (isset($_REQUEST['tab'])?$_REQUEST['tab']:null){
            case 'pay':
                $datas=WShop_Async::instance()->shortcode_atts(array(
                    'notice_str'=>null,
                    'action'=>$action,
                    $action=>null,
                    'tab'=>null,
                    'order_id'=>0
                ), stripslashes_deep($_REQUEST));
               
                if(!WShop::instance()->WP->ajax_validate($datas, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
                    WShop::instance()->WP->wp_die(WShop_Error::err_code(701));
                    exit;
                }
               
                if(WShop_Helper_Uri::is_wechat_app()){
                    require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/alipay/in-wechat-warning.php');
                    exit;
                }
                
                if(!isset($_REQUEST['skip_qq_vd'])){
                    if(strripos(strtolower($_SERVER['HTTP_USER_AGENT']),'qq')!==false){
                        require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/alipay/in-qq-warning.php');
                        exit;
                    }
                }
                
                $order = WShop::instance()->payment->get_order('id', $_GET['order_id']);
                if(!$order){
                    WShop::instance()->WP->wp_die(WShop_Error::err_code(404));
                    exit;
                }
                if($order->is_paid()){
                    wp_redirect($order->get_received_url());
                    exit;
                }
                if(!$order->can_pay()){
                    WShop::instance()->WP->wp_die(WShop_Error::error_custom(__('Current order is paid or expired!',WSHOP)));
                    exit;
                }
                
                $api = WShop_Payment_Gateway_Alipay::instance();
                $appid =$api->get_option('appid');
                $appsecret=$api->get_option('appsecret');
                
                //创建订单支付编号
                $sn = $order->generate_sn();
                if($sn instanceof WShop_Error){
                    WShop::instance()->WP->wp_die($sn);
                    exit;
                }
                
                $exchange_rate = round(floatval(WShop_Settings_Default_Basic_Default::instance()->get_option('exchange_rate')),3);
                if($exchange_rate<=0){
                    $exchange_rate = 1;
                }
                
                $parameter = array (
                    'partner' =>$appid,
                    'seller_id' =>$appid,
                    'payment_type'=>'1',
                    'notify_url' => home_url('/'),
                    'return_url' => home_url('/'),
                    'out_trade_no' => $sn,
                    'subject' => mb_strimwidth($order->get_title(), 0, 32,'...','utf-8'),
                    '_input_charset' => 'utf-8',
                    'total_fee'=>round($order->get_total_amount()*$exchange_rate,2)
                );
                
                //parameter不能有空值
                if(WShop_Helper_Uri::is_app_client()){
                    $parameter['service']='alipay.wap.create.direct.pay.by.user';
                    $parameter['app_pay']='Y';
                }else{
                    $parameter['service']='create_direct_pay_by_user';
                }
                
                ksort($parameter);
                reset($parameter);
                
                $parameter['sign'] = $this->generate_sign($parameter,$appsecret );
                $parameter['sign_type'] = 'MD5';
              
                wp_redirect('https://mapi.alipay.com/gateway.do?'.http_build_query($parameter));
                exit;
        }
    }
    
    public function generate_sign(array $parameter,$appsecret){
        ksort($parameter);
        reset($parameter);
        
        $builder = '';
        $index=0;
        foreach ($parameter as $key=>$val){
            if($key==='sign'||$key==='sign_type'||$val===''||is_array($val)){
                continue;
            }
            
            if($index++!=0){
                $builder.='&';
            }
            $builder.="{$key}={$val}";
        }
     
        return md5($builder .$appsecret );
    }
}

return WShop_Add_On_Alipay::instance();
?>