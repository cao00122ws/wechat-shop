<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
$url = WShop_Helper_Uri::get_new_uri( WShop_Helper_Uri::get_location_uri(),array('skip_qq_vd'=>1));
$api = WShop_Add_On_Alipay::instance();
if ( ! $guessurl = site_url() ){
    $guessurl = wp_guess_url();
}
?>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?php echo __('Alipay',WSHOP)?></title>
<script src="https://open.mobile.qq.com/sdk/qqapi.js?_bid=152"></script>
 <script src="<?php echo $guessurl.'/wp-includes/js/jquery/jquery.js'; ?>"></script>
<script type="text/javascript">
jQuery(function($){
	if(mqq&& mqq.QQVersion!='0'){
		var html='';
		if(mqq.android){
			html='<img alt="<?php echo __('Alipay',WSHOP)?>" src="<?php print $api->domain_url?>/images/android.jpg" style="max-width: 100%;">';
		}else{
			html='<img alt="<?php echo __('Alipay',WSHOP)?>" src="<?php print $api->domain_url?>/images/ios.png" style="max-width: 100%;">';
		}
		$('#wp-content').html(html);
	}else{
		location.href='<?php echo $url?>';
	}
});
</script>
</head>
<body style="padding:0;margin:0;" id="wp-content">
</body>
</html>