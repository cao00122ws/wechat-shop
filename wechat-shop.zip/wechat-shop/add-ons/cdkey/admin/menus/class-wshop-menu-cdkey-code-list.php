<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WShop_Cdkey_Code_List {

	public function view() {
		global $wpdb;
		$api = WShop_Add_On_Cdkey::instance();
		?>
		<div class="wrap">
		<h2><?php echo sprintf(__( '%s codes', WSHOP ),$api->post_type_display);?></h2>
   		<?php
   		$table = new WShop_Cdkey_List_Table();
   		$table->process_action();
   		$table->views();
   		$table->prepare_items();
   		?>
    	<form method="post" id="form-wshop-order">
    	   <input type="hidden" name="page" value="<?php echo WShop_Admin::instance()->get_current_page()->get_page_id()?>"/>
           <input type="hidden" name="section" value="<?php echo WShop_Admin::instance()->get_current_menu()->id?>"/>
           <input type="hidden" name="tab" value="<?php echo WShop_Admin::instance()->get_current_submenu()->id?>"/>
       		<div class="order-list" id="wshop-order-list">
       		<?php $table->display(); ?>
       		</div>
    	</form>
    	<script type="text/javascript">
			(function($){
				window.wshop_view ={
					delete:function(id){
						if(confirm('<?php echo __('Are you sure?',WSHOP)?>')){
							$('#wpbody-content').loading();
							$.ajax({
								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'cdkey_item_delete'),true,true)?>',
								type:'post',
								timeout:60*1000,
								async:true,
								cache:false,
								data:{
									id:id
								},
								dataType:'json',
								complete:function(){
									$('#wpbody-content').loading('hide');
								},
								success:function(e){
									if(e.errcode!=0){
										alert(e.errmsg);
										return;
									}
									
									location.reload();
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo sprintf(__( 'System error while remove %s codes!', WSHOP),$api->post_type_display); ?>');
								}
							});
						}
					}
				};
		})(jQuery);
	</script>
	</div>
	<?php
	}
}

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class WShop_Cdkey_List_Table extends WP_List_Table {
    private $status;
    private $post;
    private $code,$expired,$email;
    /**
     * @param WShop_Menu_Order_Default_Settings $api
     * @param array $args
     * @since 1.0.0
     */
    public function __construct( $args = array() ) {
        parent::__construct( $args );
        $this->email = isset($_REQUEST['email'])?$_REQUEST['email']:null;
        $post =get_post(isset($_REQUEST['post'])?$_REQUEST['post']:null);
        $this->expired = isset($_REQUEST['expired'])&&$_REQUEST['expired']!==''?intval($_REQUEST['expired']):null;
        $this->post = $post&&$post->post_type==WShop_Add_On_Cdkey::instance()->get_option('post_type')?$post:null;
        
        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable ,'amount');
        
        $this->status = isset($_REQUEST['status'])?$_REQUEST['status']:null;
        if(!$this->status||!in_array($this->status, $this->get_all_order_status())){
            $this->status='';
        }
        
        $this->code  = isset($_REQUEST['code'])?$_REQUEST['code']:null;
    }
    
    public function process_action(){
        $bulk_action = $this->current_action();
        if(empty($bulk_action)){
            return;
        }
        
        check_admin_referer( 'bulk-' . $this->_args['plural'] );
        $cdkey_ids   = isset($_POST['cdkey_ids'])?$_POST['cdkey_ids']:null;;
        if(!$cdkey_ids||!is_array($cdkey_ids)){
            return;
        }
       
        foreach ($cdkey_ids as $order_id){
            $error =WShop_Cdkey_Helper::update_cdkey_item($order_id, $bulk_action);
            if(!WShop_Error::is_valid($error)){
                ?><div class="notice notice-error is-dismissible"><p><?php echo $error->errmsg;?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
                return;
            }
       }
    }
    
    public function get_all_order_status(){
        return array(
            WShop_Cdkey_Item::STATUS_PUBLISH,
            WShop_Cdkey_Item::STATUS_SOLD,
            WShop_Cdkey_Item::STATUS_SHOPPING
        );
    }
    
    function get_sortable_columns() {
        return array(
            'code' => array( 'id', false )
        );
    }

    function get_views() {
        global $wpdb;
        $now = current_time( 'timestamp');
        $result =$wpdb->get_row(
           "select sum(if(o.`status` in ('P','D'),1,0)) as alls,
                   sum(if(o.`status`='P',1,0)) as unsold,
                   sum(if(o.`status`='S',1,0)) as hold,
                   sum(if(o.`status`='D',1,0)) as sold
            from `{$wpdb->prefix}wshop_cdkey_item` o
            inner join {$wpdb->prefix}posts p on p.ID = o.cdkey_id
            where p.post_status='publish';");
         
        $form_count= array(
            '' => array(
                'title'=>__('All',WSHOP),
                'count'=>intval( $result->alls )
            ),
            WShop_Cdkey_Item::STATUS_PUBLISH    => array(
                'title'=>__('Unsold',WSHOP),
                'count'=>intval( $result->unsold )
            ),
            WShop_Cdkey_Item::STATUS_SHOPPING    => array(
                'title'=>__('Hold',WSHOP),
                'count'=>intval( $result->hold )
            ),
            WShop_Cdkey_Item::STATUS_SOLD    => array(
                'title'=>__('Sold',WSHOP),
                'count'=>intval( $result->sold )
            )
        );
    
        $current =null;
        $index=0;
        foreach ($form_count as $key=>$val){
            if($index++==0){
                $current=$key;
            }
    
            if($this->status==$key){
                $current=$key;
                break;
            }
        }
    
        $page_now = WShop_Admin::instance()->get_current_admin_url();
        $views=array();
        foreach ($form_count as $key=>$data){
            $now = $current==$key?"current":"";
            $views[$key] ="<a class=\"{$now}\" href=\"{$page_now}&status={$key}\">{$data['title']} <span class=\"count\">(<span>{$data['count']}</span>)</span></a>";
        }
         
        return $views;
    }

    
    function prepare_items() {
        $sort_column  = empty( $_REQUEST['orderby'] ) ? null : $_REQUEST['orderby'];
        $sort_columns = array_keys( $this->get_sortable_columns() );

        if (!$sort_column|| ! in_array( strtolower( $sort_column ), $sort_columns ) ) {
            $sort_column = 'id';
        }

        $sort = isset($_REQUEST['order']) ? $_REQUEST['order']:null;
        if(!in_array($sort, array('asc','desc'))){
            $sort ='desc';
        }

        $status =empty($this->status)?" and o.status in ('P','D') ":" and o.status='{$this->status}'";
        $post_id = !$this->post?"":" and o.cdkey_id={$this->post->ID} ";
        $now =  current_time( 'timestamp');
        $email_sql = '';
        if(!empty($this->email)){
            if(is_email($this->email)){
                $email_sql =" and o.email='{$this->email}' ";
            }else if(is_numeric($this->email)){
                $email_sql =" and o.purchase_order_id='{$this->email}' ";
            }
        }
        $expired = is_null($this->expired)?"":($this->expired?" and o.expire_date<$now ":" and (o.expire_date is null or o.expire_date>$now)");
        global $wpdb;
        $sql=  "select count(o.id) as qty
                from `{$wpdb->prefix}wshop_cdkey_item` o
                inner join `{$wpdb->prefix}posts` c on c.ID = o.cdkey_id
                where (%s='' or o.code=%s)
                      and c.post_status='publish'
                      $email_sql
                      $expired
                      $post_id
                      $status;";
        
        $query = $wpdb->get_row($wpdb->prepare($sql, $this->code,md5($this->code)));

        $total = intval($query->qty);
        $per_page = 50;
        
        $total_page = intval(ceil($total/($per_page*1.0)));
        $this->set_pagination_args( array(
            'total_items' => $total,
            'total_pages' => $total_page,
            'per_page' => $per_page,
            'status'=>$this->status,
            'post'=>$this->post?$this->post->ID:null,
            'code'=>$this->code,
            'expired'=>$this->expired,
            'email'=>$this->email
        ));

        $pageIndex =$this->get_pagenum();
        $start = ($pageIndex-1)*$per_page;
        $end = $per_page;

        $sql = "select o.*,
                       c.post_title as cdkey_title
                from `{$wpdb->prefix}wshop_cdkey_item` o
                inner join `{$wpdb->prefix}posts` c on c.ID = o.cdkey_id
                where (%s='' or o.code=%s)
                      and c.post_status='publish'
                      $email_sql
                      $expired
                      $post_id
                      $status
                order by o.$sort_column $sort
                limit $start,$end;";
     
        $this->items = $wpdb->get_results($wpdb->prepare($sql, $this->code,md5($this->code)));   
    }
    
    function extra_tablenav( $which ) {
       if($which!='top'){
           return;
       }
       ?>
      
		<style type="text/css">.select2-container {width: 200px !important;}</style>
       <select class="wshop-search" data-type='<?php echo WShop_Add_On_Cdkey::instance()->get_option('post_type')?>' name="post" data-sortable="true" data-placeholder="<?php echo sprintf(__( 'Search for a %s(ID/post_title)&hellip;', WSHOP),WShop_Add_On_Cdkey::instance()->post_type_display); ?>" data-allow_clear="true">
			<?php 
			if($this->post){
			    ?>
			    <option value="<?php echo $this->post->ID?>">
			    	<?php echo $this->post->post_title;?>
			    </option>
			    <?php 
			}
			?>
		</select>
        <input type="search" id="search-code" name="code" style="height:32px;" value="<?php echo esc_attr($this->code)?>" placeholder="<?php echo sprintf(__('%s code',WSHOP),WShop_Add_On_Cdkey::instance()->post_type_display)?>"/>
        <input type="search" id="search-email" name="email" style="height:32px;" value="<?php echo esc_attr($this->email)?>" placeholder="<?php echo __('Buyer email or Order ID',WSHOP)?>"/>
        <select id="search-expired" name="expired">
        	<option value="">选择是否过期</option>
        	<option value="1" <?php echo $this->expired=='1'?'selected':''?>>已过期</option>
        	<option value="0" <?php echo $this->expired=='0'?'selected':''?>>未过期</option>
        </select>
		<input type="submit" class="button" style="line-height: 32px;height:32px;" value="<?php echo __('Filter',WSHOP)?>">
       <?php 
    }
    
    function get_bulk_actions() {
        return array(
            'cdkey_item_delete' => esc_html__( 'Delete permanently', WSHOP ),
        );
    }

    function get_columns() {
        $api = WShop_Add_On_Cdkey::instance();
        return array(
            'cb'                    => '<input type="checkbox" />',
            'code'                  => __( 'Code', WSHOP ),
            'cdkey_title'           =>$api->post_type_display,
            'expire_date'          =>__('Expire date',WSHOP),
            'created_time'          =>__('Created time',WSHOP),
            'purchase'              =>__('Order info',WSHOP)
        );
    }

    public function single_row( $item ) {
        echo '<tr id="form-tr-'.$item->id .'">';
        $this->single_row_columns( $item );
        echo '</tr>';
    }

    function single_row_columns( $item ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();

        foreach ( $columns as $column_name => $column_display_name ) {
            $classes = "$column_name column-$column_name";
            if ( $primary === $column_name ) {
                $classes .= ' has-row-actions column-primary';
            }

            if ( in_array( $column_name, $hidden ) ) {
                $classes .= ' hidden';
            }

            $data = 'data-colname="' . wp_strip_all_tags( $column_display_name ) . '"';

            $attributes = "class='$classes' $data";

            if ( 'cb' === $column_name ) {
                echo '<th scope="row" class="check-column">';
                echo $this->column_cb( $item );
                echo '</th>';
            }  elseif ( method_exists( $this, '_column_' . $column_name ) ) {
                echo call_user_func(
                    array( $this, '_column_' . $column_name ),
                    $item,
                    $classes,
                    $data,
                    $primary
                    );
            } elseif ( method_exists( $this, 'column_' . $column_name ) ) {
                echo "<td $attributes>";
                echo call_user_func( array( $this, 'column_' . $column_name ), $item );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            } else {
                echo "<td $attributes>";
                echo $this->column_default( $item, $column_name );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            }
        }
    }

	function column_cb( $form ) {
		$form_id = $form->id;
		?>
		<label class="screen-reader-text" for="cb-select-<?php echo esc_attr( $form_id ); ?>"><?php echo sprintf(__( 'Select %s' ),WShop_Add_On_Cdkey::instance()->post_type_display); ?></label>
		<input type="checkbox" class="wshop_list_checkbox" name="cdkey_ids[]" value="<?php echo esc_attr( $form_id ); ?>" />
		<?php
	}

	public function column_cdkey_title($item){
	    ?>
        <a target="_blank" href="<?php echo get_edit_post_link($item->cdkey_id)?>"><?php echo $item->cdkey_title?></a>
        <?php 
    }
    public function column_expire_date($item){
        if(!$item->expire_date){
            echo '--';
            return;
        }
        
        $now =current_time( 'timestamp');
        ?>
        <time style="<?php echo ($item->expire_date<$now?'color:red':'')?>"><?php echo date('Y-m-d H:i',$item->expire_date)?></time>
        <?php 
    }
	public function column_created_time($item){
	    ?>
        <time><?php echo date('Y-m-d H:i',$item->created_time)?></time>
        <?php 
    }
    
    public function column_purchase($item){
        if($item->status!=WShop_Cdkey_Item::STATUS_SOLD){
            return;
        }
        ?>
        <dl>
        <?php 
            if($item->purchase_customer_id){
                $customer = get_user_by('id', $item->purchase_customer_id);
                if($customer){
                    ?><dt><?php echo __('User:',WSHOP)?> <a target="_blank" href="<?php echo get_edit_user_link($customer->ID)?>"><?php echo $customer->user_login?></a></dt> <?php 
                }
            }
            
            if($item->purchase_order_id){
                $order = new WShop_Order($item->purchase_order_id);
                ?><dt><b>OID:</b><?php echo $item->purchase_order_id;?></dt><?php
                if(!empty($order->sn)){
                    ?><dt><b>SN:</b><?php echo $order->sn;?></dt><?php
                }
                if(!empty($order->transaction_id)){
                    ?><dt><b>TRANSACTION ID:</b><?php echo $order->transaction_id;?></dt><?php
                }
            }
            
            if($item->purchase_time){
                ?><dt><?php echo __('Time:',WSHOP)?> <time><?php echo date('Y-m-d H:i',$item->purchase_time);?></time></dt> <?php
             }
        ?>
        </dl>

        <?php 
    }
	
    public function column_code($item){
        echo apply_filters('wshop_cdkey_code_admin_view', '<a href="javascript:void(0);" class="row-title"><strong>'. $item->_code.'</strong></a>',$item);
        ?>
         <div class="row-actions">
         	 <span class="delete"><a href="javascript:void(0);" onclick="window.wshop_view.delete(<?php echo $item->id;?>);"><?php echo __('Delete',WSHOP)?></a></span>
         </div>
        <?php 
    }
    
	function no_items() {
		echo sprintf(__( "You don't have any %s codes!", WSHOP ),WShop_Add_On_Cdkey::instance()->post_type_display) ;
	}
}
