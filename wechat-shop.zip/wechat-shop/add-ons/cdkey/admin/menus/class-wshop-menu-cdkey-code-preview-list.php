<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WShop_Cdkey_Code_Preview_List {
	public function view($post) {
	    global $wpdb;
	    $api = WShop_Add_On_Cdkey::instance();
	    $upload =$wpdb->get_row(
           "select u.*
            from {$wpdb->prefix}wshop_cdkey_item_upload u
            where u.cdkey_id={$post->ID}
                    and u.status='".WShop_Cdkey_Item_Upload::STATUS_PRE."'
            order by u.id desc
            limit 1;");
	   
		if(!$upload){
		    WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
            return;
		}
		?>
		<div class="wrap">
		<h2><?php echo sprintf(__( '%s:%s codes uploaded preview', WSHOP ),$post->post_title,$api->post_type_display);?></h2>
   		<?php
        $api =WShop_Add_On_Cdkey::instance();
   		$table = new WShop_Cdkey_List_Table($upload,$post);
   		$table->process_action();
   		$table->views();
   		$table->prepare_items();
   		?>
    	<form method="get" id="form-wshop-order">
    	   <input type="hidden" name="page" value="<?php echo WShop_Admin::instance()->get_current_page()->get_page_id()?>"/>
           <input type="hidden" name="section" value="<?php echo WShop_Admin::instance()->get_current_menu()->id?>"/>
           <input type="hidden" name="tab" value="<?php echo WShop_Admin::instance()->get_current_submenu()->id?>"/>
       		<div class="order-list" id="wshop-order-list">
       		<?php $table->display(); ?>
       		</div>
    	</form>
    	
    	<p class="submit" style="float:left;">
    		<input type="button" onclick="window.wshop_view.cancel(<?php echo $upload->id;?>);" value="<?php echo __('Cancel',WSHOP)?>" class="button">
			<input type="button" onclick="window.wshop_view.confirm(<?php echo $upload->id;?>);" value="<?php echo __('Confirm',WSHOP)?>" class="button-primary">
		 </p>
		 
    	<script type="text/javascript">
			(function($){
				window.wshop_view ={
					cancel:function(uid){
						if(confirm('<?php echo __('Are you sure?',WSHOP)?>')){
							$('#wpbody-content').loading();
							$.ajax({
								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'upload_cancel'),true,true)?>',
								type:'post',
								timeout:60*1000,
								async:true,
								cache:false,
								data:{
									upload_id:uid
								},
								dataType:'json',
								complete:function(){
									$('#wpbody-content').loading('hide');
								},
								success:function(e){
									if(e.errcode!=0){
										alert(e.errmsg);
										return;
									}
									
									location.href="<?php echo get_edit_post_link($post->ID,null)?>";
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo esc_attr( 'System error while cancel upload!', WSHOP); ?>');
								}
							});
						}
					},
					confirm:function(uid){
						$('#wpbody-content').loading();
						$.ajax({
							url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'upload_confirm'),true,true)?>',
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:{
								upload_id:uid
							},
							dataType:'json',
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert(e.errmsg);
									return;
								}
								
								location.href="<?php echo get_edit_post_link($post->ID,null)?>";
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo esc_attr( 'System error while confirm upload!', WSHOP); ?>');
							}
						});
					},
					delete:function(id){
						if(confirm('<?php echo __('Are you sure?',WSHOP)?>')){
							$('#wpbody-content').loading();
							$.ajax({
								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'cdkey_item_delete'),true,true)?>',
								type:'post',
								timeout:60*1000,
								async:true,
								cache:false,
								data:{
									id:id
								},
								dataType:'json',
								complete:function(){
									$('#wpbody-content').loading('hide');
								},
								success:function(e){
									if(e.errcode!=0){
										alert(e.errmsg);
										return;
									}
									
									location.reload();
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo sprintf(__( 'System error while remove %s codes!', WSHOP),$api->post_type_display); ?>');
								}
							});
						}
						
					}
				};
		})(jQuery);
	</script>
	</div>
	<?php
	}
}

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class WShop_Cdkey_List_Table extends WP_List_Table {

    /**
     * @var WShop_Menu_Order_Default_Settings
     * @since 1.0.0
     */
    public $post;
    public $upload;
    /**
     * @param WShop_Menu_Order_Default_Settings $api
     * @param array $args
     * @since 1.0.0
     */
    public function __construct($upload,$post, $args = array() ) {
        parent::__construct( $args );
        
        $this->post = $post;
        $this->upload = $upload;
      
        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable ,'code');
    }
    
    public function process_action(){
        $bulk_action = $this->current_action();
        if(empty($bulk_action)){
            return;
        }
         
        check_admin_referer( 'bulk-' . $this->_args['plural'] );
         
        $cdkey_ids   = isset($_POST['cdkey_ids'])?$_POST['cdkey_ids']:null;;
        if(!$cdkey_ids||!is_array($cdkey_ids)){
            return;
        }
     
        foreach ($cdkey_ids as $order_id){
            $error =WShop_Cdkey_Helper::update_cdkey_item($order_id, $bulk_action);
            if(!WShop_Error::is_valid($error)){
                ?><div class="notice notice-error is-dismissible"><p><?php echo $error->errmsg;?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
                return;
            }
       }
    }
    
    function get_sortable_columns() {
        return array(
            'code' => array( 'id', false )
        );
    }

    function prepare_items() {
        
        $sort_column  = empty( $_REQUEST['orderby'] ) ? null : $_REQUEST['orderby'];
        $sort_columns = array_keys( $this->get_sortable_columns() );

        if (!$sort_column|| ! in_array( strtolower( $sort_column ), $sort_columns ) ) {
            $sort_column = 'id';
        }

        $sort = isset($_REQUEST['order']) ? $_REQUEST['order']:null;
        if(!in_array($sort, array('asc','desc'))){
            $sort ='desc';
        }

        global $wpdb;
        $sql=  "select count(o.id) as qty
                from `{$wpdb->prefix}wshop_cdkey_item` o
                where o.upload_id={$this->upload->id} and o.status='".WShop_Cdkey_Item::STATUS_PRE."';";
        
        $query = $wpdb->get_row($sql);

        $total = intval($query->qty);
        $per_page = 50;
       
        $total_page = intval(ceil($total/($per_page*1.0)));
        
        $this->set_pagination_args( array(
            'total_items' => $total,
            'total_pages' => $total_page,
            'per_page' => $per_page,
            'view'=>'preview',
            'post'=>$this->post->ID
        ));

        $pageIndex =$this->get_pagenum();
        $start = ($pageIndex-1)*$per_page;
        $end = $per_page;

        $sql ="select o.*
               from `{$wpdb->prefix}wshop_cdkey_item` o
               where o.upload_id={$this->upload->id}
                      and o.status='".WShop_Cdkey_Item::STATUS_PRE."'
               order by o.$sort_column $sort
               limit $start,$end;";
     
        $this->items = $wpdb->get_results($sql);   
    }
  
    
    function get_bulk_actions() {
        return array(
            'cdkey_item_delete' => esc_html__( 'Delete permanently', WSHOP )
        );
    }

    function get_columns() {
        return array(
            'cb'                    => '<input type="checkbox" />',
            'code'                  => __( 'Code', WSHOP ),
            'created_time'          =>__('Created time',WSHOP)
        );
    }

    public function single_row( $item ) {
        echo '<tr id="form-tr-'.$item->id .'">';
        $this->single_row_columns( $item );
        echo '</tr>';
    }

    function single_row_columns( $item ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();

        foreach ( $columns as $column_name => $column_display_name ) {
            $classes = "$column_name column-$column_name";
            if ( $primary === $column_name ) {
                $classes .= ' has-row-actions column-primary';
            }

            if ( in_array( $column_name, $hidden ) ) {
                $classes .= ' hidden';
            }

            $data = 'data-colname="' . wp_strip_all_tags( $column_display_name ) . '"';

            $attributes = "class='$classes' $data";

            if ( 'cb' === $column_name ) {
                echo '<th scope="row" class="check-column">';
                echo $this->column_cb( $item );
                echo '</th>';
            }  elseif ( method_exists( $this, '_column_' . $column_name ) ) {
                echo call_user_func(
                    array( $this, '_column_' . $column_name ),
                    $item,
                    $classes,
                    $data,
                    $primary
                    );
            } elseif ( method_exists( $this, 'column_' . $column_name ) ) {
                echo "<td $attributes>";
                echo call_user_func( array( $this, 'column_' . $column_name ), $item );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            } else {
                echo "<td $attributes>";
                echo $this->column_default( $item, $column_name );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            }
        }
    }

	function column_cb( $item ) {
		?>
		<label class="screen-reader-text" for="cb-select-<?php echo esc_attr( $item->id ); ?>"><?php echo sprintf(__( 'Select %s' ),WShop_Add_On_Cdkey::instance()->post_type_display); ?></label>
		<input type="checkbox" class="wshop_list_checkbox" name="cdkey_ids[]" value="<?php echo esc_attr( $item->id ); ?>" />
		<?php
	}
	
	public function column_created_time($item){
	    ?>
        <time><?php echo date('Y-m-d H:i',$item->created_time)?></time>
        <?php 
    }
	
	public function column_code($item){
	    echo apply_filters('wshop_cdkey_code_admin_view', '<a href="javascript:void(0);" class="row-title"><strong>'. $item->_code.'</strong></a>',$item);
        ?>
         <div class="row-actions">
         	 <span class="delete"><a href="javascript:void(0);" onclick="window.wshop_view.delete(<?php echo $item->id;?>);"><?php echo __('Delete',WSHOP)?></a></span>
         </div>
        <?php 
    }
    
	function no_items() {
		echo sprintf(__( "You don't have any %s codes!", WSHOP ),WShop_Add_On_Cdkey::instance()->post_type_display) ;
	}
}
