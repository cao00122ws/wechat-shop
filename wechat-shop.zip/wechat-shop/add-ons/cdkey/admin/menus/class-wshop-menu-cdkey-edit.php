<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
   
class WShop_Menu_Cdkey_Edit_Page extends Abstract_WShop_Settings_Page{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='add_ons_page_cdkey_edit';
        $this->title=sprintf(__('%s codes',WSHOP),WShop_Add_On_Cdkey::instance()->post_type_display);
    }
    
    /* (non-PHPdoc)
     * @see Abstract_WShop_Settings_Menu::menus()
     */
    public function menus(){
        return apply_filters("wshop_admin_page_{$this->id}",array(
            WShop_Menu_Cdkey_Edit::instance()
        ));
    }
}

/**
 * @since 1.0.0
 * @author ranj
 */
class WShop_Menu_Cdkey_Edit extends Abstract_WShop_Settings_Menu{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='add_ons_menu_cdkey_edit';
        $this->title=sprintf(__('%s codes',WSHOP),WShop_Add_On_Cdkey::instance()->post_type_display);
    }

    /* (non-PHPdoc)
     * @see Abstract_WShop_Settings_Menu::menus()
     */
    public function menus(){
        return apply_filters("wshop_admin_menu_{$this->id}", array(
            WShop_Menu_Cdkey_Edit_Settings::instance()
        ));
    }
}
    
class WShop_Menu_Cdkey_Edit_Settings extends Abstract_WShop_Settings {
    /**
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    private function __construct(){
        $this->id='add_ons_modal_cdkey_edit_settings';
        $this->title=sprintf(__('%s codes',WSHOP),WShop_Add_On_Cdkey::instance()->post_type_display);
    }

    public function admin_form_start(){}
     
    public function admin_options(){
       
        $view = isset($_GET['view'])?$_GET['view']:null; 
        global $wpdb;
        switch ($view){
            case 'preview':
                $id  = isset($_GET['post'])?$_GET['post']:null;
                $post = get_post($id);
                if(!$post){
                    WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
                    return;
                }
                require_once 'class-wshop-menu-cdkey-code-preview-list.php';
                $api = new WShop_Cdkey_Code_Preview_List();
                $api->view($post);
                return;
            default:
                require_once 'class-wshop-menu-cdkey-code-list.php';
                $api = new WShop_Cdkey_Code_List();
                $api->view();
                return;
        }
	}
	
    public function admin_form_end(){} 
}


?>