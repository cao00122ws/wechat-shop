<?php 
class WShop_Cdkey extends WShop_Post_Object{
    const POST_T='wshop_cdkey';
    
    const KEY_CDKEY_EMAIL ='CDKEY_EMAIL';
    public function __construct($id_or_obj=null){
        parent::__construct($id_or_obj);
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_cdkey';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_cdkey_properties', array(
            'post_ID'=>null,
            'minnum_purchase'=>null,
            'maxnum_purchase'=>null,
            'purchase_start'=>null,
            'purchase_end'=>null
        ));
    }

}

class WShop_Cdkey_Fields extends Abstract_XH_WShop_Fields{
    
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Cdkey_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="cdkey";
        $this->title =WShop_Add_On_Cdkey::instance()->post_type_display;
    }

    public function admin_init(){
        parent::admin_init();
      
        add_action('post_edit_form_tag',array($this,'post_edit_form_tag'),10,1);
        //add_action('dbx_post_advanced', array($this,'pre_post_edit'),10,1);
        foreach ($this->get_post_types() as $post_type=>$label){
            add_filter( "manage_{$post_type}_posts_columns", array($this,'manage_posts_columns'),11 ,1);
            add_action( "manage_{$post_type}_posts_custom_column", array( $this, 'manage_posts_custom_column' ),11, 2 );
        }
    }

    
    public function post_edit_form_tag($post){
        if(in_array($post->post_type, array_keys($this->get_post_types()))){
            echo ' enctype="multipart/form-data" ';
        }
    }
    
    public function manage_posts_columns($existing_columns){
        if(!$existing_columns){$existing_columns=array();}

        $has = false;
        $new_columns = array();
        foreach ($existing_columns as $key=>$v){
            $new_columns[$key]=$v;
            if($key=='title'){
               // $new_columns['cdkey_minnum_purchase']=__('Min number purchase',WSHOP);
                //$new_columns['cdkey_maxnum_purchase']=__('Max number purchase',WSHOP);
                //$new_columns['cdkey_purchase_start']=__('Purchase start',WSHOP);
                //$new_columns['cdkey_purchase_end']=__('Purchase end',WSHOP);
                $new_columns['cdkey_codes']=__('Codes',WSHOP);
                $new_columns['cdkey_shortcode']=__('Short code',WSHOP);
                $has=true;
            }
        }

        return $new_columns;
    }

    public function manage_posts_custom_column($column,$post_ID){
        global $current_cdkey;
        if(!$current_cdkey||$current_cdkey->post_ID!=$post_ID){
             $current_cdkey = new WShop_Cdkey($post_ID);
        }
        $cdkey=$current_cdkey;
        if(!$cdkey->is_load()){
            return;
        }
        if($column=='cdkey_shortcode'){
           ?><code>[wshop_cdkey post_id="<?php echo $post_ID?>"]</code><?php 
        }
        if($column=='cdkey_minnum_purchase'){
            echo WShop_Helper_String::is_null_or_empty($cdkey->minnum_purchase)?"--":$cdkey->minnum_purchase;
        }
        
        if($column=='cdkey_maxnum_purchase'){
            echo WShop_Helper_String::is_null_or_empty($cdkey->maxnum_purchase)?"--":$cdkey->maxnum_purchase;
        }
        
        if($column=='cdkey_purchase_start'){
            echo $cdkey->purchase_start?date('Y-m-d H:i',$cdkey->purchase_start):"--";
        }
        
        if($column=='cdkey_purchase_end'){
            echo $cdkey->purchase_end?date('Y-m-d H:i',$cdkey->purchase_end):"--";
        }
        
        if($column=='cdkey_codes'){
            global $wpdb;
            $query = $wpdb->get_row(
                "select sum(if(i.status='D',1,0)) as sold,
                count(i.id) as total
                from {$wpdb->prefix}wshop_cdkey_item i
                where i.cdkey_id={$post_ID} ;");
            ?><a href="<?php echo admin_url("admin.php?page=wshop_add_ons_page_cdkey_edit&post=".$post_ID)?>"><?php echo __('All:',WSHOP).intval($query->total)?>,<?php echo __('Sold:',WSHOP).intval($query->sold)?></a><?php
            
        }
    }
    
    public function set_purchase_start_val($post,$product,$key,$val){
        return !$val?"":date('Y-m-d H:i',$val);
    }
    
    public function set_purchase_end_val($post,$product,$key,$val){
        return !$val?"":date('Y-m-d H:i',$val);
    }
    public function validate_minnum_purchase_field($key){
        $field = $this->get_field_key ( $key );
        if(!isset($_POST[$field])){
            return null;
        }
        return $_POST[$field]===''?null:intval($_POST[$field]);
    }
    
    public function validate_maxnum_purchase_field($key){
        $field = $this->get_field_key ( $key );
        if(!isset($_POST[$field])){
            return null;
        }
        return $_POST[$field]===''?null:intval($_POST[$field]);
    }
    public function validate_purchase_start_field($key){
        $field = $this->get_field_key ( $key );
        if(!isset($_POST[$field])){
            return null;
        }
        return $_POST[$field]===''?null:strtotime($_POST[$field]);
    }
    
    public function validate_purchase_end_field($key){
         $field = $this->get_field_key ( $key );
        if(!isset($_POST[$field])){
            return null;
        }
        return $_POST[$field]===''?null:strtotime($_POST[$field]);
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
     public function init_form_fields(){
        global $post;
        $this->form_fields = apply_filters('wshop_cdkey_fields', array(
            'cdkey'=>array(
                'title'=>WShop_Add_On_Cdkey::instance()->post_type_display,
                'type'=>'custom',
                'func'=>function( $key,$api,$data){
                    global $post;
                    $field = $api->get_field_key ( $key );
                    global $wpdb;
                    $now = current_time( 'timestamp');
                    $query = $wpdb->get_row(
                        "select sum(if(i.status='D',1,0)) as sold,
                                count(i.id) as total,
                                sum(if(i.expire_date is not null and i.expire_date<$now,1,0)) as expired
                         from {$wpdb->prefix}wshop_cdkey_item i
                         where i.cdkey_id={$post->ID} ;");
                    ?>
                    <tr valign="top" class="">
                    	<th scope="row" class="titledesc">
                    		<label><?php echo WShop_Add_On_Cdkey::instance()->post_type_display?><a href="<?php echo admin_url("admin.php?page=wshop_add_ons_page_cdkey_edit&post=".$post->ID)?>">(<?php echo __('All:',WSHOP).intval($query->total)?>,<?php echo __('Sold:',WSHOP).intval($query->sold)?>,<?php echo __('Expired:',WSHOP).intval($query->expired)?>)</a></label>
            			</th>
                    	<td class="forminp">
                    		<fieldset>
                    			<legend class="screen-reader-text">
                    				<span><?php echo WShop_Add_On_Cdkey::instance()->post_type_display?></span>
                    			</legend>
                    			<div class="setting-row">
                        			<label>到期时间<span class="wshop_field_required">*</span></label><br />
                        			<input type="text" id="<?php echo esc_attr( $field );?>_expired" class="regular-text" placeholder="可选" name="<?php echo esc_attr( $field );?>_expired" />
                        		</div>
                        		<br/>
                    			<textarea class="input-text regular-input" rows="3" name="<?php echo esc_attr( $field );?>" id="<?php echo esc_attr( $field );?>" placeholder="<?php echo "code1\ncode2\ncode3\n...";?>" style="min-width:400px;width:100%;"></textarea>
                    			<br/>
                    			<?php echo __('or',WSHOP)?>
                    			<br/>
                    			<input type="file" name="<?php echo esc_attr( $field );?>_file" style="width:180px;" accept=".csv,text/plain"/>(*.txt,*.csv)
                    			<?php do_action('wshop_cdkey_field_upload',$key,$api,$data);?>
            					<p class="description"></p>
            					
                        		<script type="text/javascript">
                        			(function($){
                        				$("#<?php echo esc_attr( $field );?>_expired").focus(function() {
                                  			WdatePicker({
                                  				dateFmt: 'yyyy-MM-dd HH:mm',
                                  				minDate:'<?php echo date_i18n('Y-m-d H:i')?>'
                                  			});
                                  		});
                        			})(jQuery);
                        		</script>
            				</fieldset>
                    	</td>
                    </tr>
                    <?php 
                },
                'validate'=>function($key,$api){
                    $field = $api->get_field_key ( $key );
                   
                    $expire_date = isset($_REQUEST["{$field}_expired"])&&!is_null($_REQUEST["{$field}_expired"])&&$_REQUEST["{$field}_expired"]!==''?strtotime(stripslashes($_REQUEST["{$field}_expired"])):0;
        
                    //文本框输入授权码
                    $upload_cdkey = array();
                    if(isset($_POST[$field])&&!empty($_POST[$field])){
                        foreach (explode("\r\n", stripslashes($_POST[$field])) as $code){
                            if(empty($code)){
                                continue;
                            }
                    
                            if(in_array($code, $upload_cdkey)){
                                continue;
                            }
                    
                            $upload_cdkey[]=array(
                                'code'=>$code,
                                'expire_date'=>$expire_date,
                                'metas'=>array(
                                    'type'=>'text'
                                )
                            );
                        }
                    }
                    
                    //上传文件授权码
                    if(isset($_FILES["{$field}_file"])&&!empty($_FILES["{$field}_file"]["name"])){
                        if(isset($_FILES["{$field}_file"]['error'])&&$_FILES["{$field}_file"]['error']){
                            $api->errors[]="upload file error:".$_FILES["{$field}_file"]['error'];
                            return null;
                        }
                    
                        if(!in_array($_FILES["{$field}_file"]["type"], array(
                            'application/vnd.ms-excel',
                            'text/plain'
                        ))){
                            $api->errors[]=__("upload file error:invalid file type!",WSHOP);
                            return null;
                        }
                    
                        $file_name = $_FILES["{$field}_file"]["name"];
                        $p_index = strripos($file_name, '.');
                        if($p_index===false){
                            $api->errors[]=__("upload file error:file name is invalid!",WSHOP);
                            return null;
                        }
                    
                        $ext = strtolower(substr($file_name, $p_index+1));
                    
                    
                        switch ($ext){
                            case 'txt':
                                $content = @file_get_contents($_FILES["{$field}_file"]["tmp_name"]);
                                @unlink($_FILES["{$field}_file"]["tmp_name"]);
                                foreach (explode("\r\n", $content) as $code){
                                    if(empty($code)){
                                        continue;
                                    }
                    
                                    if(in_array($code, $upload_cdkey)){
                                        continue;
                                    }
                    
                                    $upload_cdkey[]=array(
                                        'code'=>$code,
                                        'expire_date'=>$expire_date,
                                        'metas'=>array(
                                            'type'=>'text'
                                        )
                                    );
                                }
                                 
                                break;
                            case 'csv':
                                if(!class_exists('SplFileObject')){
                                    $api->errors[]=__("upload file error:php class 'SplFileObject' not found(connect developer)!",WSHOP);
                                    return null;
                                }
                    
                                $spl_object = new SplFileObject($_FILES["{$field}_file"]["tmp_name"], 'rb');
                                $spl_object->seek(0);
                                while (!$spl_object->eof()) {
                                    $codes =$spl_object->fgetcsv();
                                    $spl_object->next();// 下一行
                    
                                    if(count($codes)==0){
                                        continue;
                                    }
                    
                                    $code=$codes[0];
                                    if(empty($code)||in_array($code, $upload_cdkey)){
                                        continue;
                                    }
                    
                                    $upload_cdkey[]=array(
                                        'code'=>$code,
                                        'expire_date'=>$expire_date,
                                        'metas'=>array()
                                    );
                                }
                                 
                                @unlink($_FILES["{$field}_file"]["tmp_name"]);
                    
                                break;
                            default:
                                @unlink($_FILES["{$field}_file"]["tmp_name"]);
                                $api->errors[]=__("upload file error:file name is invalid!",WSHOP);
                                return null;
                        }
                    }
                    
                    $upload_cdkey = apply_filters('wshop_cdkey_upload_codes', $upload_cdkey,$key,$api,$expire_date);
                    if(!empty($api->errors)){
                       return null;
                    }
                    global $wpdb;
                    //清楚上次上传未确定的代码
                    $wpdb->query("delete from {$wpdb->prefix}wshop_cdkey_item_upload where status in ('".WShop_Cdkey_Item_Upload::STATUS_INACTIVE."','".WShop_Cdkey_Item_Upload::STATUS_PRE."')");
                    if(!empty($wpdb->last_error)){
                        $api->errors[]=$wpdb->last_error;
                        return null;
                    }
                    
                    $wpdb->query("delete from {$wpdb->prefix}wshop_cdkey_item where status ='".WShop_Cdkey_Item::STATUS_PRE."'");
                    if(!empty($wpdb->last_error)){
                        $api->errors[]=$wpdb->last_error;
                        return null;
                    }
                    
                    /**
                     * @var WShop_Cdkey_Item[]
                     */
                    $cdkey_items = array();
                    
                    /**
                     *
                     * @var WShop_Cdkey_Item_Upload
                     */
                    
                    if(count($upload_cdkey)<=0){return null;}
                    global $post;
                    global $wpdb;
                    $upload = new WShop_Cdkey_Item_Upload(array(
                        'user_ID'=>get_current_user_id(),
                        'cdkey_id'=>$post->ID,
                        'created_time'=>current_time( 'timestamp' ),
                        'status'=>WShop_Cdkey_Item_Upload::STATUS_PRE
                    ));
                
                    $error = $upload->insert();
                
                    if(!WShop_Error::is_valid($error)){
                        $api->errors[]=$error->errmsg;
                        return null;
                    }
                
                    $update_id = $upload->id;
                    if(!$update_id){
                        $api->errors[]=WShop_Error::error_unknow(500)->errmsg;
                        return null;
                    }
                
                    foreach ($upload_cdkey as $_item){
                        $code = isset($_item['code'])?$_item['code']:null;
                        $metas = isset($_item['metas'])&&is_array($_item['metas'])?$_item['metas']:array();
                        $expire_date = isset($_item['expire_date'])?$_item['expire_date']:null;
                        $code_key = md5($code);
                        
                        $data = $wpdb->get_row($wpdb->prepare(
                           "select id
                            from {$wpdb->prefix}wshop_cdkey_item
                            where code=%s
                            limit 1;", $code_key));
                
                        if($data){
                            $api->errors[]=sprintf(__("%s code is already exists:%s",WSHOP),WShop_Add_On_Cdkey::instance()->post_type_display,$code);
                            return null;
                        }
            
                        $cdkey_item = new WShop_Cdkey_Item(array(
                            'code'=>$code_key,
                            '_code'=>$code,
                            'expire_date'=>$expire_date,
                            'metas'=>$metas,
                            'cdkey_id'=>$post->ID,
                            'status'=>WShop_Cdkey_Item::STATUS_PRE,
                            'upload_id'=>$update_id,
                            'created_time'=>current_time( 'timestamp' ),
                        ));
            
                        $error =$cdkey_item->insert();
                        if(!WShop_Error::is_valid($error)){
                            $api->errors[]=$error->errmsg;
                            return null;
                        }
            
                        $cdkey_items[]=$cdkey_item;
                    }
                
                    $updated_qty =$wpdb->query(
                        "update {$wpdb->prefix}wshop_cdkey_item i
                         inner join {$wpdb->prefix}wshop_cdkey_item_upload u on u.id = i.upload_id
                         set i.status='".WShop_Cdkey_Item::STATUS_PUBLISH."',
                             u.status ='".WShop_Cdkey_Item_Upload::STATUS_PUBLISH."'
                         where i.status='".WShop_Cdkey_Item::STATUS_PRE."'
                                and u.status ='".WShop_Cdkey_Item_Upload::STATUS_PRE."'
                                and i.upload_id={$update_id}
                                and i.cdkey_id={$post->ID};");
                
                    if(!empty($wpdb->last_error)){
                        $api->errors[]=$wpdb->last_error;
                        return null;
                    }
                
                    foreach ($cdkey_items as $cdkey_item){
                        $cdkey_item->refresh_cache();
                    }
                
                    $upload->refresh_cache();
                    return $cdkey_items;
                }
            ),
            'minnum_purchase'=>array(
                'title'=>__('Min number purchase',WSHOP),
                'type'=>'text',
                'default'=>null,
                'css'=>'width:100%;'
            ),
            'maxnum_purchase'=>array(
                'title'=>__('Max number purchase',WSHOP),
                'type'=>'text',
                'default'=>null,
                'css'=>'width:100%;'
            ),
            'purchase_start'=>array(
                'title'=>__('Purchase start',WSHOP),
                'type'=>'datetime',
                'css'=>'width:100%;'
            ),
            'purchase_end'=>array(
                'title'=>__('Purchase end',WSHOP),
                'type'=>'datetime',
                'css'=>'width:100%;'
            )
        ),$post);
    }

    public function get_post_types()
    {
        return array(
            WShop_Add_On_Cdkey::instance()->get_option('post_type')=>WShop_Add_On_Cdkey::instance()->post_type_display
        );
    }

    public function get_object($post){
        return new WShop_Cdkey($post->ID);
    }

}

class WShop_Cdkey_Item extends WShop_Object{
    //待上架的数据
    const STATUS_PRE='A';
    
    //已上架，未销售的数据
    const STATUS_PUBLISH='P';
    
    //已预订，未付款(已启用)
    const STATUS_SHOPPING='S';
    
    //已售出的数据
    const STATUS_SOLD='D';
    
    public function __construct($obj=null){
        parent::__construct($obj);
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::is_auto_increment()
     */
    public function is_auto_increment()
    {
        // TODO Auto-generated method stub
        return true;
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_primary_key()
     */
    public function get_primary_key()
    {
        // TODO Auto-generated method stub
        return 'id';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_cdkey_item';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_cdkey_item_properties', array(
            'id'=>0,
            'code'=>null,
            '_code'=>null,
            'cdkey_id'=>0,
            'upload_id'=>0,
            'metas'=>array(),
            'expire_date'=>null,
            'status'=>self::STATUS_PRE,
            'created_time'=>current_time( 'timestamp' ),
            'email'=>null,
            'purchase_customer_id'=>null,
            'purchase_order_item_id'=>null,
            'purchase_order_id'=>null,
            'purchase_time'=>null
        ));
    }

}
class WShop_Cdkey_Item_Upload extends WShop_Object{
    //未确认上传的数据
    const STATUS_PRE='A';
    
    //已确认上传的数据
    const STATUS_PUBLISH='P';
    
    //已取消上传的数据
    const STATUS_INACTIVE='I';
    public function __construct($obj=null){
        parent::__construct($obj);
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::is_auto_increment()
     */
    public function is_auto_increment()
    {
        // TODO Auto-generated method stub
        return true;
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_primary_key()
     */
    public function get_primary_key()
    {
        // TODO Auto-generated method stub
        return 'id';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_cdkey_item_upload';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    { 
        return apply_filters('wshop_cdkey_item_upload', array(
            'id'=>0,
            'user_ID'=>0,
            'cdkey_id'=>0,
            'created_time'=>current_time( 'timestamp' ),
            'status'=>self::STATUS_PRE
        ));
    }

}
class WShop_Cdkey_Model extends Abstract_WShop_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        $collate=$this->get_collate();
        global $wpdb;
        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_cdkey` (
    		`post_ID` INT(11) NOT NULL,
        	`minnum_purchase` INT(11) NULL DEFAULT NULL,
        	`maxnum_purchase` INT(11) NULL DEFAULT NULL,
        	`purchase_start` BIGINT(20) NULL DEFAULT NULL,
        	`purchase_end` BIGINT(20) NULL DEFAULT NULL,
        	PRIMARY KEY (`post_ID`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        //上传记录
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_cdkey_item_upload` (
            `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
        	`user_ID` BIGINT(20) NOT NULL,
        	`cdkey_id` BIGINT(20) NOT NULL,
        	`created_time` BIGINT(20) NOT NULL DEFAULT '0',
        	`status` VARCHAR(1) NOT NULL,
        	PRIMARY KEY (`id`)
        )
        $collate;");
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_cdkey_item` (
            `id` BIGINT(20) NOT NULL AUTO_INCREMENT,
	        `code` VARCHAR(128) NOT NULL,
	        `_code` TEXT NULL DEFAULT NULL,
        	`cdkey_id` INT(11) NOT NULL,
        	`metas` TEXT NULL DEFAULT NULL,
        	`upload_id` BIGINT(20) NOT NULL,
        	`expire_date` BIGINT(20) NULL DEFAULT NULL,
        	`status` VARCHAR(1) NOT NULL,
        	`created_time` BIGINT(20) NOT NULL,
        	`email` VARCHAR(128) NULL DEFAULT NULL,
        	`purchase_customer_id` BIGINT(20) NULL DEFAULT NULL,
        	`purchase_order_item_id` BIGINT(20) NULL DEFAULT NULL,
        	`purchase_order_id` BIGINT(20) NULL DEFAULT NULL,
        	`purchase_time` BIGINT(20) NULL DEFAULT NULL,
        	PRIMARY KEY (`id`),
        	INDEX `email` (`email`),
        	UNIQUE INDEX `code` (`code`)
        )
        $collate;");
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_cdkey_item'
            and table_schema ='".DB_NAME."'
				 and column_name ='email'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_cdkey_item` add column `email` VARCHAR(128) NULL DEFAULT NULL;");
        }
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_cdkey_item'
                 and table_schema ='".DB_NAME."'
				 and column_name ='metas'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_cdkey_item` add column `metas` TEXT NULL DEFAULT NULL;");
        }
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_cdkey_item'
            and table_schema ='".DB_NAME."'
				 and column_name ='expire_date'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_cdkey_item` add column `expire_date` BIGINT(20) NULL DEFAULT NULL;");
        }
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_cdkey_item'
            and table_schema ='".DB_NAME."'
				 and column_name ='_code'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_cdkey_item` add column `_code` TEXT NULL DEFAULT NULL;");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
            
            //移植老数据到新的字段去
            $wpdb->query(
                "update {$wpdb->prefix}wshop_cdkey_item c
                set c._code = c.code,c.code=MD5(c.code);");
            
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
    }
}

class WShop_Cdkey_Helper{
     
    public static function update_cdkey_item($id,$action){  
        $cdkey = new WShop_Cdkey_Item($id);
        if(!$cdkey->is_load()){
            return WShop_Error::err_code(404);
        }
       
        try {
            global $wpdb;
            switch ($action){
                
                case 'cdkey_item_delete':
                    $wshop_cdkey_item = new WShop_Cdkey_Item($cdkey->id);
                    if(!$wshop_cdkey_item->is_load()){
                        throw new Exception(sprintf(__('%s item is not found!',WSHOP),WShop_Add_On_Cdkey::instance()->post_type_display));
                    }
                    
                    $result = $wshop_cdkey_item->remove();
                    if(!WShop_Error::is_valid($result)){
                        throw new Exception($result->errmsg);
                    }
                    break;
               
            }
        } catch (Exception $e) {
            return WShop_Error::error_custom($e->getMessage());
        }
         
        return WShop_Error::success();
    }
}
?>