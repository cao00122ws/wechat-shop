<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
require_once 'includes/class-wshop-cdkey.php'; 
require_once 'abstract-xh-add-ons-api.php';
/**
 * @author rain
 *
 */
class WShop_Add_On_Cdkey extends Abstract_WShop_Add_Ons_Cdkey_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Cdkey
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    public $post_type_display;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Cdkey
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        
        $this->id='wshop_add_ons_cdkey';
       
        $this->version='1.0.1';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->plugin_uri='https://www.wpweixin.net/product/1465.html';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
     
        $this->init_form_fields();
        
        $this->post_type_display = $this->get_option('post_type_display',__('Cdkey',WSHOP));
       
        $this->title=__('Cdkey',WSHOP);
        $this->description='卡密销售插件，支持text和CSV导入卡密，支持再次导入补货';
    }

    public function register_fields(){
        WShop_Cdkey_Fields::instance();
    }
    
    public function wshop_admin_menu_menu_default_modal($menus){
        $menus[]=$this;
        return $menus;
    }
    /**
     * @since 1.0.0
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields(){
        $this->form_fields =array(
            'cdkey_type_enabled'=>array(
                'title'=>__('Enable inner cdkey type',WSHOP),
                'type'=>'checkbox',
                'default'=>'yes',
                'description'=>'启用插件自带的cdkey类型，如果您的系统自带cdkey类型，此处不必勾选。在"绑定内容类型"处指定您的类型'
            ),
            'post_type_display'=>array(
                'title'=>__('Cdkey alias',WSHOP),
                'type'=>'text',
                'default'=>__('Cdkey',WSHOP)
            ),
            'post_type'=>array(
                'title'=>__('Bind post type',WSHOP),
                'type'=>'select',
                'func'=>true,
                'default'=>WShop_Cdkey::POST_T,
                'options'=>array($this,'get_post_type_options')
            ),
            'subtitle_form'=>array(
                'title'=>__('Checkout page settings',WSHOP),
                'type'=>'subtitle'
            ),
            'page_checkout'=>array(
                'title'=>__('Checkout page',WSHOP),
                'description'=>null,
                'type'=>'select',
                'func'=>true,
                'default'=>null,
                'options'=>array($this,'get_page_options')
            )
            ,
            'title'=>array(
                'title'=>__('Title',WSHOP),
                'type'=>'text',
                'default'=>'迅虎自动发卡'
            ),
            'description'=>array(
                'title'=>__('Description',WSHOP),
                'type'=>'textarea',
                'default'=>'迅虎wordpress卡密,邀请码,优惠码销售插件'
            ),
            'enable_email'=>array(
                'title'=>__('Have email receiver',WSHOP),
                'type'=>'checkbox',
                'default'=>'yes',
                'description'=>''
            ),
            'subtitle_form'=>array(
                'title'=>__('Checkout success page settings',WSHOP),
                'type'=>'subtitle'
            ),
            'page_checkout_success'=>array(
                'title'=>__('Checkout success page',WSHOP),
                'description'=>null,
                'type'=>'select',
                'func'=>true,
                'default'=>null,
                'options'=>array($this,'get_page_options')
            )
        );
    }
    
    public function get_post_type_options(){
        $options = parent::get_post_type_options();
        $options[WShop_Cdkey::POST_T]=$this->post_type_display;
        return $options;
    }
    
    public function on_install(){
        $api = new WShop_Cdkey_Model();
        $api->init(); 
        $this->init_page_checkout();
        $this->init_page_checkout_success();
    }
    
    public function wshop_checkout_tab_cdkey($request){
        $action = isset($request['action'])?$request['action']:null;
        $datas=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null,
            'section'=>null,//支付方式：付费下载 ， 快速支付等
            'hash'=>null
        ), $request);
        
        if(!WShop::instance()->WP->ajax_validate($datas, $datas['hash'])){
            echo WShop_Error::err_code(701)->to_json();
            exit;
        }
         
        if(!is_user_logged_in()&&!WShop::instance()->WP->is_enable_guest_purchase()){
            echo WShop_Error::err_code(501)->to_json();
            exit;
        }
        
        if(!isset($request['section'])||empty($request['section'])){
            echo WShop_Error::err_code(600)->to_json();
            exit;
        }
        
        $cart = WShop_Shopping_Cart::empty_cart(false);
        if($cart instanceof WShop_Error){
            echo $cart->to_json();
            exit;
        }
        
        $qty = isset($request['qty'])?absint($request['qty']):1;
        if($qty<1){$qty=1;}
        
        $product_id = isset($request['post_id'])?intval($request['post_id']):null;
        
        $email = isset($request['email'])?sanitize_email($request['email']):null;
        if('yes'==WShop_Add_On_Cdkey::instance()->get_option('enable_email')){
            if(empty($email)){
                echo WShop_Error::error_custom('请填入接收卡密的电子邮件!')->to_json();
                exit;
            }
        }
        
        if(!empty($email)&&!is_email($email)){
            echo  WShop_Error::error_custom('接收卡密的电子邮件格式错误!')->to_json();
            exit;
        }
        
        $cart = $cart->__add_to_cart($product_id,$qty);
        if($cart instanceof WShop_Error){
            echo $cart->to_json();
            exit;
        }
        
         
        $coupon_code = isset($request['coupon_code'])?$request['coupon_code']:null;
        $coupon_api = WShop::instance()->get_installed_addon('wshop_add_ons_coupon');
        if(!empty($coupon_code)&&$coupon_api){
            //此处优惠券只能使用一个
            $coupon = $coupon_api->add_coupon_to_cart($cart,$coupon_code,true,false);
            if($coupon instanceof WShop_Error){
                echo $coupon->to_json();
                exit;
            }
        }
        
        $cart->__set_payment_method(isset($request['payment_method'])?$request['payment_method']:null);
        $cart->__set_metas(array(
            'section'=>$request['section'],
            'location'=>isset($request['location'])?$request['location']:null,
            WShop_Cdkey::KEY_CDKEY_EMAIL=>$email
        ));
        
        $order = $cart->create_order();
        if($order instanceof WShop_Error){
            echo $order->to_json();
            exit;
        }
         
        echo WShop_Error::success(array(
            'redirect_url'=>$order->get_pay_url()
        ))->to_json();
        exit;
    }
    
    public function get_page_checkout_uri($params = array()){
        $page_id =  $this->get_option('page_checkout',0);
        return WShop_Helper_Uri::get_new_uri(get_page_link($page_id),$params);
    }
    
    private function init_page_checkout(){
        $page_id =intval($this->get_option('page_checkout',0));
        $page=null;
        if($page_id>0){
            return true;
        }
    
        $page_id =wp_insert_post(array(
            'post_type'=>'page',
            'post_name'=>'cdkey-checkout',
            'post_title'=>__('WShop - CDKey checkout',WSHOP),
            'post_content'=>'[wshop_cdkey_checkout]',
            'post_status'=>'publish',
            'meta_input'=>array(
                '_wp_page_template'=>'cdkey/purchase.php'
            )
        ),true);
    
        if(is_wp_error($page_id)){
            WShop_Log::error($page_id);
            throw new Exception($page_id->get_error_message());
        }
    
        $this->update_option('page_checkout', $page_id,true);
        return true;
    }
    
    private function init_page_checkout_success(){
        $page_id =intval($this->get_option('page_checkout_success',0));
        $page=null;
        if($page_id>0){
            return true;
        }
    
        $page_id =wp_insert_post(array(
            'post_type'=>'page',
            'post_name'=>'cdkey-checkout-success',
            'post_title'=>__('WShop - CDKey checkout success',WSHOP),
            'post_content'=>'[wshop_cdkey_checkout_success]',
            'post_status'=>'publish',
            'meta_input'=>array(
                '_wp_page_template'=>'cdkey/purchase.php'
            )
        ),true);
    
        if(is_wp_error($page_id)){
            WShop_Log::error($page_id);
            throw new Exception($page_id->get_error_message());
        }
    
        $this->update_option('page_checkout_success', $page_id,true);
        return true;
    }
    
    public function wshop_page_templates($ms){
       $ms[$this->domain_dir]['cdkey/purchase.php']=__('WShop - CDKey',WSHOP);
        return $ms;
    }
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_load()
     */
    public function on_load(){  
        $this->m1();

        WShop_Async::instance()->async('wshop_cdkey', array($this,'wshop_cdkey'));
        
        add_filter('wshop_page_templates', array($this,'wshop_page_templates'),10,1);
    }
    
    public function add_shortcodes($shortcodes){
        $shortcodes['wshop_cdkey_checkout']=function($atts = array(),$content =null){
            if(isset($_REQUEST['action'])&&$_REQUEST['action']=='search'){
                return WShop::instance()->WP->requires(WShop_Add_On_Cdkey::instance()->domain_dir, 'cdkey/search-content.php',array(
                    'atts'=>$atts,
                    'content'=>$content
                ));
            }else{
                return WShop::instance()->WP->requires(WShop_Add_On_Cdkey::instance()->domain_dir, 'cdkey/purchase-content.php',array(
                    'atts'=>$atts,
                    'content'=>$content
                ));
            }
        };
        
        $shortcodes['wshop_cdkey_checkout_success']=function($atts = array(),$content =null){
            return WShop::instance()->WP->requires(WShop_Add_On_Cdkey::instance()->domain_dir, 'cdkey/purchase-success.php',array(
                'atts'=>$atts,
                'content'=>$content
            ));
        };
        
        return $shortcodes;
    }

    public function wshop_cdkey($atts = array(),$content = null){
        return WShop_Async::instance()->async_call('wshop_cdkey', function(&$atts,&$content){
            if(isset($atts['cdkey_id'])&&$atts['cdkey_id']){
                $atts['post_id']=$atts['cdkey_id'];
                unset($atts['cdkey_id']);
            }
            if(!isset( $atts['post_id'])||empty( $atts['post_id'])){
                if(method_exists(WShop::instance()->WP, 'get_default_post')){
                    $default_post = WShop::instance()->WP->get_default_post();
                    $atts['post_id']=$default_post?$default_post->ID:0;
                }else{
                    global $wp_query,$post;
                    $default_post=$wp_query?$wp_query->post:null;
                    if(!$default_post&&$post){
                        $default_post = $post;
                    }
                    $atts['post_id']=$default_post?$default_post->ID:0;
                }
            }
    
            if(!isset($atts['location'])||empty($atts['location'])){
                $atts['location'] =  WShop_Helper_Uri::get_location_uri();
            }
    
        },function(&$atts,&$content){
            $content = empty($content)?__('Pay now',WSHOP):$content;
            return WShop::instance()->WP->requires(WShop_Add_On_Cdkey::instance()->domain_dir, 'cdkey/button-purchase.php',array(
                'content'=>$content,
                'atts'=>$atts
            ));
        },
        array(
            'cdkey_id'=>0,
            'style'=>null,
            'post_id'=>0,
            'class'=>'xh-btn xh-btn-danger xh-btn-lg',
            'location'=>null
        ),
        $atts,
        $content);
    }
    
    public function wshop_admin_pages ($m){
        require_once 'admin/menus/class-wshop-menu-cdkey-edit.php';
        $m[25] =WShop_Menu_Cdkey_Edit_Page::instance();
        return $m;
    }
    
    /**
     * 
     * @param WShop_Error $success
     * @param WShop_Shopping_Cart $cart
     * @param WShop_Product $product
     */
    public function wshop_cart_item_validate($success,$cart,$product,$qty){
        if(!WShop_Error::is_valid($success)||$product->get('post_type')!=$this->get_option('post_type')){
            return $success;
        }
       
        return $this->validate_cdkey_on_purchase($product->post_ID, $qty);
    }
  
    public function create_order_cdkey($func,$cart,$request){
        return array(function($cart,$request){
            $qty = isset($request['qty'])?absint($request['qty']):1;
            if($qty<1){$qty=1;}
            
            $product_id = isset($request['post_id'])?intval($request['post_id']):null;
            
            $email = isset($request['email'])?sanitize_email($request['email']):null;
            if('yes'==WShop_Add_On_Cdkey::instance()->get_option('enable_email')){
                if(empty($email)){
                    return WShop_Error::error_custom('请填入接收卡密的电子邮件!');
                }
            }
            
            if(!empty($email)&&!is_email($email)){
                return WShop_Error::error_custom('接收卡密的电子邮件格式错误!');
            }
            
            $cart->__empty_cart();
         
           try {
               $cart->__add_to_cart($product_id,$qty);
           } catch (Exception $e) {
               $code =$e->getCode();
               return new WShop_Error($code==0?-1:$code,$e->getMessage());
           }
           
            $coupon_code = isset($request['coupon_code'])?$request['coupon_code']:null;
            $coupon_api = WShop::instance()->get_installed_addon('wshop_add_ons_coupon');
            if(!empty($coupon_code)&&$coupon_api){
                //此处优惠券只能使用一个
                $coupon = $coupon_api->add_coupon_to_cart($cart,$coupon_code,true,false);
                if($coupon instanceof WShop_Error){
                    return $coupon;
                }
            }
            $cart->__set_payment_method($request['payment_method']);
            $cart->__set_metas(array(
                'location'=>isset($request['location'])?$request['location']:null,
                WShop_Cdkey::KEY_CDKEY_EMAIL=>$email
            ));
            
            return $cart;
        });
    }
    
    /**
     * 
     * @param string $email
     * @param WShop_Order $order
     */
    public function wshop_order_email_receiver($email,$order){
        if(isset($order->metas[WShop_Cdkey::KEY_CDKEY_EMAIL])){
            $email = $order->metas[WShop_Cdkey::KEY_CDKEY_EMAIL];
            if(is_email($email))
            return $email;
        }
        
        return $email;
    }
    
    public function wshop_order_email_sections($order){        
        echo WShop::instance()->WP->requires(
            $this->domain_dir,
            "cdkey/order-received-section.php",
            array('order'=>$order)
        );
    }
    
  
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        $this->m2();
        
        add_action('template_redirect', function(){
            if(isset($_REQUEST['export'])
                &&isset($_REQUEST['tid'])
                &&isset($_REQUEST['action'])
                &&isset($_REQUEST['hash'])
                &&isset($_REQUEST['notice_str'])
                &&in_array($_REQUEST['export'], array('txt','csv'))
                &&$_REQUEST['action']=='wshop_order_cdkeys_export'
                &&!empty($_REQUEST['tid'])){
            
                    if(!WShop::instance()->WP->ajax_validate(array(
                        'tid'=>$_REQUEST['tid'],
                        'notice_str'=>$_REQUEST['notice_str'],
                        'action'=>$_REQUEST['action'],
                        'export'=>$_REQUEST['export'],
                    ), $_REQUEST['hash'])){
                        return;
                    }
                    
                    global $wpdb;
                    $codes =  $wpdb->get_results($wpdb->prepare(
                        "select ci.*
                        from {$wpdb->prefix}wshop_order o
                        inner join {$wpdb->prefix}wshop_order_item oi on oi.order_id = o.id
                        inner join {$wpdb->prefix}wshop_cdkey_item ci on ci.purchase_order_item_id = oi.id
                        where o.transaction_id=%s
                        and o.status in ('complete','processing')", $_REQUEST['tid']));
                    if(!$codes){
                        return;
                    }
            
                    if($_REQUEST['export']=='txt'){
                        $txt = '';
                        foreach ($codes as $item){
                            $txt.=$item->_code."\r\n";
                        }
                         
                        echo $txt;
                        header('Content-type: application/octet-stream');
                        header('Content-Disposition: attachment; filename="'.$_REQUEST['tid'].'.txt"');
                        header("Content-Length: ". strlen($txt));
                        exit;
                    }
                    if($_REQUEST['export']=='csv'){
                        $dir = '/uploads/'.date_i18n('Y/m/d').'/';
                        if(!WShop_Install::instance()->load_writeable_dir(WP_CONTENT_DIR.$dir,true)){
                            wp_die(sprintf(__('Create file dir failed when export post data(%s)!',WSHOP),WP_CONTENT_DIR.$dir));
                            exit;
                        }
                         
                        $filename = $_REQUEST['tid'].'.csv';
                        $fp = fopen(WP_CONTENT_DIR. $dir.$filename, 'w');
                        if(!$fp){
                            wp_die(sprintf(__('Create file failed when export post data(%s)!',WSHOP),WP_CONTENT_DIR. $dir.$filename));
                            exit;
                        }
                         
                        try {
                            foreach ($codes as $item){
                                fputcsv($fp, array($item->_code)); 
                            }
                            
                        } catch (Exception $e) {
                            if($fp){
                                fclose($fp);
                            }
                            wp_die($e->getMessage());
                            exit;
                        }
                         
                        fclose($fp);
                         
                        $file_size =filesize(WP_CONTENT_DIR. $dir.$filename);
                        if($file_size>1024*1024*3){
                            wp_die('导出文件过大，请手动<a href="'.WP_CONTENT_URL. $dir.$filename.'">下载</a>');
                            exit;
                        }
                        
                        header('Content-type: application/octet-stream');
                        header('Content-Disposition: attachment; filename="'.$filename.'"');
                        header("Content-Length: ". $file_size);
                        readfile(WP_CONTENT_DIR. $dir.$filename);
                        exit;
                    }
            }
        });
    }
   
    /**
     * 
     * @param string $url
     * @param WShop_Order $order
     */
    public function wshop_order_received_url($url,$order){
        $params = WShop::instance()->generate_request_params(array(
            'id'=>$order->id
        ));
        return $this->get_page_checkout_success_url($params);
    }
    
    public function get_page_checkout_url($request = array()){
        $page_id = $this->get_option('page_checkout');
        $url = $page_id?get_permalink($page_id):null;
        if(!$url){
            return null;
        }
    
        return WShop_Helper_Uri::get_new_uri($url,$request);
    }
    
    public function get_page_checkout_success_url($request = array()){
        $page_id = $this->get_option('page_checkout_success');
        $url = $page_id?get_permalink($page_id):null;
        if(!$url){
            return null;
        }
    
        return WShop_Helper_Uri::get_new_uri($url,$request);
    }
    
    public function get_cdkey_purchase_result($request = array()){
        $url = WShop::instance()->WP->get_checkout_uri('cdkey-purchase-result');
      
        if(count($request)>0){
           $params = array();
           $url = WShop_Helper_Uri::get_uri_without_params($url,$params);
           $url .="?".http_build_query(array_merge($params,$request));
        }
       
        return apply_filters( 'wshop_cdkey_purchase_result_url', $url,$this);
    }

    public function get_order_cdkeys_export_url($order_transaction_id,$type){
        return home_url('/')."?".http_build_query(WShop::instance()->generate_request_params(array(
            'tid'=>$order_transaction_id,
            'export'=>$type,
            'action'=>'wshop_order_cdkeys_export'
        )));
    }
    
    public function register_post_types(){
        if('yes'!=$this->get_option('cdkey_type_enabled')){return;}
        register_post_type( WShop_Cdkey::POST_T,
            array(
                'labels' => array(
                    'name' => $this->post_type_display,
                    'singular_name' =>$this->post_type_display,
                    'add_new' => __('Add New',WSHOP),
                    'add_new_item' =>sprintf(__('Add New %s',WSHOP),$this->post_type_display),
                    'edit' =>  __('Edit',WSHOP),
                    'edit_item' => sprintf(__('Edit %s',WSHOP),$this->post_type_display),
                    'new_item' => sprintf(__('New %s',WSHOP),$this->post_type_display),
                    'view' => __('View',WSHOP),
                    'view_item' => sprintf(__('View %s',WSHOP),$this->post_type_display),
                    'search_items' => sprintf(__('Search %s',WSHOP),$this->post_type_display),
                    'not_found' => sprintf(__('No %s found',WSHOP),$this->post_type_display),
                    'not_found_in_trash' =>sprintf( __('No %s found in trash',WSHOP),$this->post_type_display),
                    'parent' => sprintf(__('Parent %s',WSHOP),$this->post_type_display)
                ),
                //决定自定义文章类型在管理后台和前端的可见性
                'public' => true,
                'wshop_ignore'=>true,
                'wshop_include'=>true,
                'menu_position' => 55.5,
                'exclude_from_search '=>true,
                'publicly_queryable'=>true,
                'hierarchical'=>false,
                'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'excerpt','page-attributes' ),
                //创建自定义分类。在这里没有定义
                //'taxonomies' => array( ),
                //启用自定义文章类型的存档功能
                'has_archive' => true
            ));
    }
    
    public function free_cdkey_orders($cdkey_id){
        //此方法
    }
    
 
    /**
     * 
     * @param array $args
     * @param WShop_Order $order
     * @param string $transaction_id
     * @return array
     */
    public function wshop_order_complete_payment_args($args,$order,$transaction_id){
        $args['executed']['cdkey'][]=function($order,$is_update){
            if(!$is_update){
                return;
            }
            
            $order_items = $order->get_order_items();
            if(!$order_items||count($order_items)==0){
                return;
            }
            $email = isset($order->metas[WShop_Cdkey::KEY_CDKEY_EMAIL])&&is_email($order->metas[WShop_Cdkey::KEY_CDKEY_EMAIL])?$order->metas[WShop_Cdkey::KEY_CDKEY_EMAIL]:null;
            $now= current_time( 'timestamp');
            
            global $wpdb;
            foreach ($order_items as $order_item){
                $result = $wpdb->query(
                             "update {$wpdb->prefix}wshop_cdkey_item c
                              set c.purchase_customer_id='{$order->customer_id}',
                                  c.purchase_order_item_id ={$order_item->id},
                                  c.purchase_order_id ={$order->id},
                                  c.purchase_time=$now,
                                  c.email='$email',
                                  c.status='".WShop_Cdkey_Item::STATUS_SOLD."'
                              where c.status='".WShop_Cdkey_Item::STATUS_PUBLISH."'
                                    and c.cdkey_id={$order_item->post_ID}
                                    and (c.expire_date is null or c.expire_date=0 or c.expire_date>$now) 
                              order by c.id asc
                              limit {$order_item->qty};");
                if(!empty($wpdb->last_error)){
                    WShop_Log::error($wpdb->last_error);
                }
                if(!$result){
                    WShop_Log::error(  $wpdb->last_query);
                }
                $wpdb->last_error=null;
            }
        };

        return $args;
    }
   
    public function validate_cdkey_on_purchase($post_ID,$qty){
        $cdkey = new WShop_Cdkey($post_ID);
        if(!$cdkey->is_load()){
            return WShop_Error::error_unknow();
        }
        $now= current_time( 'timestamp');
        global $wpdb;
        $query =$wpdb->get_row(
           "select count(ci.id) as qty
            from {$wpdb->prefix}wshop_cdkey_item ci
            where ci.cdkey_id={$post_ID}
                  and (ci.expire_date is null or ci.expire_date=0 or ci.expire_date>$now) 
                  and ci.status='".WShop_Cdkey_Item::STATUS_PUBLISH."'");
        $unsold_qty = intval($query->qty);
        
        $start = current_time( 'timestamp')-15*60;
        $unpaid_order = $wpdb->get_row(
        		"select sum(oi.qty) as qty
        		from {$wpdb->prefix}wshop_order o
        		inner join {$wpdb->prefix}wshop_order_item oi on oi.order_id = o.id
        		where o.status='pending'
		        		and o.order_date>={$start}
		        		and oi.post_ID ={$post_ID};");
        
        $unpaid_order_qty = $unpaid_order?absint($unpaid_order->qty):0;
        $unsold_qty = $unsold_qty-$unpaid_order_qty<0?0:($unsold_qty-$unpaid_order_qty);
        if($qty>$unsold_qty){
            return WShop_Error::error_custom(sprintf(__('Sorry!"%s" is inventory shortage.',WSHOP),$cdkey->post_title));
        }
        
        if(!WShop_Helper_String::is_null_or_empty($cdkey->minnum_purchase)){
            if($qty<intval($cdkey->minnum_purchase)){
                return WShop_Error::error_custom(sprintf(__('Sorry!Minimum quantity purchased is %s ("%s").',WSHOP),$cdkey->minnum_purchase,$cdkey->post_title));
            }
        }
        
        if(!WShop_Helper_String::is_null_or_empty($cdkey->maxnum_purchase)){
            if($qty>intval($cdkey->maxnum_purchase)){
                return WShop_Error::error_custom(sprintf(__('Sorry!Maxmum quantity purchased is %s ("%s").',WSHOP),$cdkey->maxnum_purchase,$cdkey->post_title));
            }
        }
        
        if(!WShop_Helper_String::is_null_or_empty($cdkey->purchase_start)){
            if(current_time( 'timestamp' )<intval($cdkey->purchase_start)){
                return WShop_Error::error_custom(sprintf(__('Sorry!%s is not online.',WSHOP),$cdkey->post_title));
            }
        }
        
        if(!WShop_Helper_String::is_null_or_empty($cdkey->purchase_end)){
            if(current_time( 'timestamp' )>intval($cdkey->purchase_end)){
                return WShop_Error::error_custom(sprintf(__('Sorry!%s is not online.',WSHOP),$cdkey->post_title));
            }
        }
        
        return WShop_Error::success();
    }
    
    
    /**
     * 执行支付相关操作
     * @since 1.0.0
     */
    public function do_ajax(){
        $action ="wshop_{$this->id}";
        $datas=WShop_Async::instance()->shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));
        
        if(isset($_REQUEST['location'])){
            $datas['location'] = stripslashes($_REQUEST['location']);
        }
        
        if(!WShop::instance()->WP->ajax_validate($datas,$datas['hash'],true)){
            echo WShop_Error::err_code(701)->to_json();
            exit;
        }
        
        switch ($datas['tab']){
            case 'cdkey_item_delete':
                global $current_user;
                $roles = $current_user?$current_user->roles:null;
                if(!$roles||!is_array($roles)||!in_array('administrator', $roles)){
                    echo WShop_Error::err_code(501)->to_json();
                    exit;
                }
                 
                $error =WShop_Cdkey_Helper::update_cdkey_item(isset($_REQUEST['id'])?sanitize_key($_REQUEST['id']):null, $datas['tab']);
                echo $error->to_json();
                exit;
            case 'upload_cancel':
                global $current_user;
                $roles = $current_user?$current_user->roles:null;
                if(!$roles||!is_array($roles)||!in_array('administrator', $roles)){
                    echo WShop_Error::err_code(501)->to_json();
                    exit;
                }
                 
                $upload_id = isset($_REQUEST['upload_id'])?$_REQUEST['upload_id']:null;
                $upload = new WShop_Cdkey_Item_Upload($upload_id);
                if(!$upload->is_load()){
                    echo WShop_Error::err_code(404)->to_json();
                    exit;
                }
        
                global $wpdb;
                $result = $upload->update(array(
                    'status'=>'I'
                ));
        
                echo $result->to_json();
                exit;
            case 'upload_confirm':
                global $current_user;
                $roles = $current_user?$current_user->roles:null;
                if(!$roles||!is_array($roles)||!in_array('administrator', $roles)){
                    echo WShop_Error::err_code(501)->to_json();
                    exit;
                }
                 
                
                $upload_id = isset($_REQUEST['upload_id'])?$_REQUEST['upload_id']:null;
                $upload = new WShop_Cdkey_Item_Upload($upload_id);
                if(!$upload->is_load()){
                    echo WShop_Error::err_code(404)->to_json();
                    exit;
                }
        
                global $wpdb;
                $sql ="update {$wpdb->prefix}wshop_cdkey_item_upload u
                        inner join {$wpdb->prefix}wshop_cdkey_item i on i.upload_id = u.id
                        set u.status='P',
                            i.status='P'
                        where u.id={$upload->id}
                             and i.status='".WShop_Cdkey_Item::STATUS_PRE."'
                             and u.status='".WShop_Cdkey_Item_Upload::STATUS_PRE."';";
        
                $wpdb->query($sql);
        
                if(!empty($wpdb->last_error)){
                    WShop_Log::error($wpdb->last_error);
                    echo WShop_Error::error_custom($wpdb->last_error)->to_json();
                    exit;
                }
        
                $upload->refresh_cache();
                $upload_items = $wpdb->get_results("select * from {$wpdb->prefix}wshop_cdkey_item where upload_id = $upload_id");
                if($upload_items){
                    foreach ($upload_items as $upload_item){
                        $upload_item = new WShop_Cdkey_Item($upload_item);
                        $upload_item->refresh_cache();
                    }
                }
        
                echo WShop_Error::success()->to_json();
                exit;
        }
    }
}

return WShop_Add_On_Cdkey::instance();
?>