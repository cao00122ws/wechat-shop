<?php 
if (! defined('ABSPATH')) {
    exit();
}

$request = WShop_Temp_Helper::clear('atts','templates');

$data = $request['atts'];
$content = $request['content'];

$context = isset($data['context'])?$data['context']:null;
if(empty($context)){
    $context = WShop_Helper::generate_unique_id();
}
$style = isset($data['style'])?$data['style']:null;
$class = isset($data['class'])?$data['class']:'xh-btn xh-btn-danger xh-btn-lg';
$location = isset($data['location'])&&!empty($data['location'])?esc_url_raw($data['location']):WShop_Helper_Uri::get_location_uri();

$post_id = $data['post_id'];
$request = array(
    'cid'=>$post_id,
    'location'=>$data['location'],
    'notice_str'=>str_shuffle(time())
);
$request['hash'] = WShop_Helper::generate_hash($request, WShop::instance()->get_hash_key());
$url = WShop_Add_On_Cdkey::instance()->get_page_checkout_uri($request);
?>
<a href="<?php echo $url;?>" class="<?php echo $class;?>" style="<?php echo $style;?>"><?php echo do_shortcode($content);?></a>