<?php 
if (! defined('ABSPATH')) {
    exit();
}

$context = WShop_Helper::generate_unique_id();
$api =WShop_Add_On_Cdkey::instance();

$cdkey_id = null;
$callback = home_url('/');
if(isset($_REQUEST['id'])){
   $cdkey_id=absint($_REQUEST['id']);
}
if(isset($_REQUEST['cid'])){
    $cdkey_id=absint($_REQUEST['cid']);
}
?>
<style type="text/css">body{background: #f8f8f8;}</style>

 <div class="xh-layout-sm xh-posr">
	<span class="topbt"><a href="<?php echo esc_url($callback)?>">返回</a> <a href="<?php echo $api->get_page_checkout_uri(array('action'=>'search'))?>"><?php echo $api->get_option('post_type_display')?>查询</a></span>
       <div class="title xh-text-center"><?php echo $api->get_option('title')?></div>
       <p class="xh-text-center gray"><?php echo $api->get_option('description')?></p>
        
       <div class="xh-form" style="padding-top:15px;padding-bottom:15px">
           	<p class="clearfix xh-text-center paylist">
           	<?php 
        	$gateways = WShop::instance()->payment->get_payment_gateways();
        	$index=0;
        	foreach ($gateways as $sort=> $gateway){
        	    ?><label style="margin-right:15px;"><input class="wshop-form-cdkey-<?php echo $context;?>-payment-method" type="radio" <?php echo $index++==0?'checked':'';?> name="payment-method-<?php echo $context?>" value="<?php echo esc_attr($gateway->id)?>" > <img src="<?php echo esc_attr($gateway->icon)?>" alt="<?php echo esc_attr($gateway->title);?>"></label><?php 
        	}
        	?>
            </p>
            <script type="text/javascript">
            	(function($){
            		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
						data.payment_method = $('.wshop-form-cdkey-<?php echo $context;?>-payment-method:checked').val();
                	});
            	})(jQuery);
            </script>
            <?php 
            $cdkeys=array();
            $args = array(
                'post_type'=>WShop_Add_On_Cdkey::instance()->get_option('post_type'),
                'no_found_rows'=>true,
                'posts_per_page'=>-1,
                'orderby'=>'menu_order',
                'order'=>'asc'
            );
            if($cdkey_id){
                $args['p']=$cdkey_id;
            }
            $wp_query = new WP_Query($args);
  
            global $wpdb;
            $now = current_time( 'timestamp');
            
            ?>
            <div class="xh-form-group">
            	<label><?php echo $api->get_option('post_type_display')?>: 
            	<?php 
            	   if($wp_query->post_count===1){
            	       while ($wp_query->have_posts()){
            	           $wp_query->the_post();
            	            
            	           $product = new WShop_Product(get_the_ID());
            	           if(!$product->is_load()){
            	               continue;
            	           }
            	            
            	           $cdkeys[]=array(
            	               'ID'=>get_the_ID(),
            	               'post_title'=>get_the_title(),
            	               'sale_price'=>$product->get_single_price(false)
            	           );
            	           
            	           $query = $wpdb->get_row(
            	              "select count(ci.id) as qty
            	               from {$wpdb->prefix}wshop_cdkey_item ci
            	               where ci.cdkey_id={$product->post_ID}
                	               and (ci.expire_date is null or ci.expire_date=0 or ci.expire_date>$now)
                	               and ci.status ='".WShop_Cdkey_Item::STATUS_PUBLISH."'");
            	           
            	           $inventory = intval($query->qty);
            	           $start = current_time( 'timestamp')-15*60;
            	           $unpaid_order = $wpdb->get_row(
            	           		"select sum(oi.qty) as qty
								 from {$wpdb->prefix}wshop_order o
								 inner join {$wpdb->prefix}wshop_order_item oi on oi.order_id = o.id
							     where o.status='pending'
									   and o.order_date>={$start}
									   and oi.post_ID ={$product->post_ID};");
            	           $unpaid_order_qty = $unpaid_order?absint($unpaid_order->qty):0;
            	           $inventory = $inventory-$unpaid_order_qty<0?0:($inventory-$unpaid_order_qty);
            	          ?><span> <?php the_title()?>&nbsp;&nbsp;(库存:<?php echo $inventory?>)</span><?php 
            	       }
            	       
            	       wp_reset_postdata();
            	       $wp_query->rewind_posts();
            	   }
            	?>
            	</label>
            	<select class="form-control" id="wshop-form-cdkey-<?php echo $context;?>-product" style="<?php echo $wp_query->post_count===1?'display:none':'';?>">
            	<?php 
            	
            	while ($wp_query->have_posts()){
            	    $wp_query->the_post();
            	  
            	    $product = new WShop_Product(get_the_ID());
            	    if(!$product->is_load()){
            	        continue;
            	    }
            	    
            	    $cdkeys[]=array(
            	        'ID'=>get_the_ID(),
            	        'post_title'=>get_the_title(),
            	        'sale_price'=>$product->get_single_price(false)
            	    );
            	   
            	    $query = $wpdb->get_row(
            	        "select count(ci.id) as qty
            	         from {$wpdb->prefix}wshop_cdkey_item ci
            	         where ci.cdkey_id={$product->post_ID}
            	               and (ci.expire_date is null or ci.expire_date=0 or ci.expire_date>$now)
            	               and ci.status ='".WShop_Cdkey_Item::STATUS_PUBLISH."'");

            	    $inventory = intval($query->qty);
            	    
            	    ?><option value="<?php echo esc_attr(get_the_ID())?>"><?php the_title()?>&nbsp;&nbsp;(库存:<?php echo $inventory?>)</option><?php
            	}
            	wp_reset_postdata();
            	?>
           		</select>
            </div>
         	 <?php 
             	 
            
            $coupon_api = WShop::instance()->get_installed_addon('wshop_add_ons_coupon');
            if($coupon_api){
                ?>
                <div class="xh-form-group">  
                    <label>优惠券:</label>           
                    <input id="wshop-form-cdkey-<?php echo $context;?>-coupon"  type="text" class="form-control" placeholder="请填入优惠券，可空" />
                </div>
                <script type="text/javascript">
                	(function($){
                		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
    						data.coupon_code = $.trim($('#wshop-form-cdkey-<?php echo $context;?>-coupon').val());
                    	});
                	})(jQuery);
                </script>
                <?php 
            }
           ?>
            
            <div class="xh-form-group">
            	<label>购买数量:</label>
                <input type="tel" class="form-control" id="wshop-form-cdkey-<?php echo $context;?>-qty" value="1"/>
            </div>
            <script type="text/javascript">
            	(function($){
                	window.products = <?php echo json_encode($cdkeys)?>;
            		$(document).bind('wshop_<?php echo $context;?>_init_amount_before',function(e,m){
						var product_id = $('#wshop-form-cdkey-<?php echo $context;?>-product').val();
						var product = null;
						 for(var i=0;i<window.products.length;i++){
								if(window.products[i].ID==product_id){
									product=window.products[i];
									break;
								}
						 }
						if(!product){return;}
						
						var val = $.trim($('#wshop-form-cdkey-<?php echo $context;?>-qty').val());
						var qty = parseInt(val);
						if(isNaN(qty)||qty<1){
							qty = 1;
						}
						
						m.total_amount+=parseFloat(product.sale_price*qty);
						
						if(val.length==0){return;}
						$('#wshop-form-cdkey-<?php echo $context;?>-qty').val(qty);
            		});
            		$('#wshop-form-cdkey-<?php echo $context;?>-qty').keyup(function(){
            			$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
                	});
            		$('#wshop-form-cdkey-<?php echo $context;?>-product').change(function(){
            			$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
                	});
                	
            		(function($){
                		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
                    		var val = $.trim($('#wshop-form-cdkey-<?php echo $context;?>-qty').val());
                    		
                			var qty = parseInt(val);
                			
    						if(isNaN(qty)||qty<1){
    							qty = 1;
    						}

    						data.qty = qty;
    						data.post_id = $('#wshop-form-cdkey-<?php echo $context;?>-product').val();

    						if(val.length==0){return;}
    						$('#wshop-form-cdkey-<?php echo $context;?>-qty').val(qty);
                    	});
                	})(jQuery);
            	})(jQuery);
            </script>
            <?php 
                if('yes'==$api->get_option('enable_email')){
                    ?>
                    <div class="xh-form-group">  
                        <label>电子邮件:</label>
                        <?php global $current_user;?>             
                            <input id="wshop-form-cdkey-<?php echo $context;?>-email" value="<?php echo $current_user?esc_attr($current_user->user_email):null;?>" type="email" class="form-control" placeholder="请填入接收卡密的电子邮件" />
                        </div>
                        <script type="text/javascript">
                        	(function($){
                        		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
            						data.email = $.trim($('#wshop-form-cdkey-<?php echo $context;?>-email').val());
                            	});
                        	})(jQuery);
                        </script>
                    <?php 
                }
            ?>
            
            <?php do_action('wshop_cdkey_checkout',$context);?>
         
            <div class="xh-form-group">
           		<?php 
           		echo WShop::instance()->WP->requires(WSHOP_DIR, '__purchase.php',array(
           		    'content'=>__('Pay Now',WSHOP),
           		    'class'=>'xh-btn xh-btn-primary xh-btn-block xh-btn-lg',
           		    'location'=>WShop_Helper_Uri::get_location_uri(),
           		    'context'=>$context,
           		    'tab'=>'cdkey',
           		    'section'=>'cdkey',
           		    'modal'=>'shopping'
           		));
                ?>
                <script type="text/javascript">
					(function($){
						$(document).bind('wshop_<?php echo $context?>_show_amount',function(e,view){
		    				var total =view.total_amount;
		    				if(total>0){
		    					$('#btn-pay-button-<?php echo $context?>').html(view.symbol+total.toFixed(2)+' 确认支付');
		    				}else{
		    					$('#btn-pay-button-<?php echo $context?>').html('确认支付');
			    			}
		    			});
					})(jQuery);
                </script>
                <?php 

                echo WShop::instance()->WP->requires(WSHOP_DIR, 'page/checkout-order-pay-total-amount.php',array(
                    'context'=>$context
                ));
                ?>
            </div>
       </div>
    </div>