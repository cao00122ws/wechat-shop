<?php 
if (! defined('ABSPATH')) {
    exit();
}

$order_id = null;
$api =WShop_Add_On_Cdkey::instance();
$transaction_id='';
if(isset($_REQUEST['id'])&&isset($_REQUEST['hash'])){
    if(!WShop::instance()->WP->ajax_validate(shortcode_atts(array(
        'hash'=>null,
        'id'=>null,
        'notice_str'=>null
    ), stripslashes_deep($_REQUEST)), $_REQUEST['hash'])){
        WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
        return ;
    }
    $order = new WShop_Order($_REQUEST['id']);
    $transaction_id =$order->is_load()?$order->transaction_id:null;
	 $order_id = $order->is_load()?$order->id:null;
}

if( isset($_REQUEST['tid'])){
    $transaction_id = trim(stripslashes($_REQUEST['tid']));
}
if(!$order){
    wp_die('未找到订单信息！');
}
$TOTAL_PURCHASE_QTY = 0;
if($transaction_id){
    global $wpdb;
    $codes =  $wpdb->get_results($wpdb->prepare(
        "select ci.*,
                o.order_date
        from {$wpdb->prefix}wshop_order o
        inner join {$wpdb->prefix}wshop_order_item oi on oi.order_id = o.id
        inner join {$wpdb->prefix}wshop_cdkey_item ci on ci.purchase_order_item_id = oi.id
        where o.transaction_id=%s
              and o.status in ('complete','processing')
              and ci.status='".WShop_Cdkey_Item::STATUS_SOLD."'", $transaction_id));
    
    $query = $wpdb->get_row($wpdb->prepare(
       "select sum(oi.qty) as total
        from {$wpdb->prefix}wshop_order o
        inner join  {$wpdb->prefix}wshop_order_item oi on oi.order_id = o.id
        where o.transaction_id=%s
              and o.status in ('complete','processing')", $transaction_id));
    $TOTAL_PURCHASE_QTY = intval($query->total);
}


?>
<style type="text/css">body{background: #f8f8f8;}</style>

 <div class="xh-layout-sm xh-posr">
	<span class="topbt"><a href="<?php echo $api->get_page_checkout_uri();?>"><?php echo $api->get_option('post_type_display')?>购买</a> <a href="<?php echo $api->get_page_checkout_uri(array('action'=>'search'));?>"><?php echo $api->get_option('post_type_display')?>查询</a></span>
     <div class="title xh-text-center">提取<?php echo $api->get_option('post_type_display')?></div>
         <p class="xh-text-center gray">请确认已复制或下载<?php echo $api->get_option('post_type_display')?>后(合计:<?php echo $TOTAL_PURCHASE_QTY?>个)，关闭本页面(如果<?php echo $api->get_option('post_type_display')?>个数不符，请联系管理员补单<?php echo empty($order_id)?'':"，附：订单号：{$order_id}"?>)</p>
         <form method="post" action="">
    		<div class="xh-form" style="padding-top:20px;">
                <?php 
                if($order->is_canceled()){
                    ?>您的订单已取消或已过期...<?php
                }else if($order->is_paid()){
                    if($codes&&count($codes)>0){
                        ?><textarea class="form-control" style="min-height:200px;min-width:200px;"><?php foreach ($codes as $item){
                                $order_date = date('Y.m.d H:i',$item->order_date);
                              echo esc_textarea("{$item->_code}  订单编号：{$item->purchase_order_id} --- {$order_date}\r\n");
                          }?></textarea>
                          <div style="float:right;"><a href="<?php echo $api->get_order_cdkeys_export_url($transaction_id,'csv')?>" class="xh-btn xh-btn-sm xh-btn-default">导出(.csv)</a> <a href="<?php echo $api->get_order_cdkeys_export_url($transaction_id,'txt')?>" class="xh-btn xh-btn-sm xh-btn-default">导出(.txt)</a></div>
                          <?php    
                    }else{
                        if(!empty($transaction_id)){
                        ?>未查询到任何信息...<?php 
                        }
                    }
                }else{
                    ?>您的订单还未支付...<?php
                }?>
        	</div>
    	</form>  
</div>