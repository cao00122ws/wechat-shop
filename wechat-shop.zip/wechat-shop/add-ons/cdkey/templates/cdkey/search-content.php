<?php 
if (! defined('ABSPATH')) {
    exit();
}

$context = WShop_Helper::generate_unique_id();
$api =WShop_Add_On_Cdkey::instance();
$transaction_id= isset($_REQUEST['tid'])?trim(stripslashes($_REQUEST['tid'])):null;
$codes=null;
if($transaction_id){
    global $wpdb;
   
    $codes =  $wpdb->get_results($wpdb->prepare(
        "select ci.*,
            o.order_date
        from {$wpdb->prefix}wshop_order o
        inner join {$wpdb->prefix}wshop_order_item oi on oi.order_id = o.id
        inner join {$wpdb->prefix}wshop_cdkey_item ci on ci.purchase_order_item_id = oi.id
        where o.transaction_id=%s
        and o.status in ('complete','processing')
        ", $transaction_id));
}

?>
<style type="text/css">body{background: #f8f8f8;}</style>

 <div class="xh-layout-sm xh-posr">
	<span class="topbt"><a href="<?php echo $api->get_page_checkout_uri();?>"><?php echo $api->get_option('post_type_display')?>详情</a> <a href="<?php echo $api->get_page_checkout_uri()?>"><?php echo $api->get_option('post_type_display')?>购买</a></span>
      <div class="title xh-text-center"><?php echo $api->get_option('title')?></div>
       <p class="xh-text-center gray"><?php echo $api->get_option('description')?></p>
     <form method="post" action="">
		<div class="xh-form"  style="padding-top:20px;">
		
        <div class="xh-form-group">
            <label>支付宝订单号/微信商户单号：</label>
            <input type="text" placeholder="请输入支付宝订单号/微信商户单号" class="form-control" value="<?php echo esc_attr($transaction_id)?>" name="tid" />
            <span class="xh-help-block"></span>
        </div>
            
        <div class="clearfix">
           <button class="xh-btn xh-btn-primary xh-btn-block xh-btn-lg" type="submit">查询<?php echo WShop_Add_On_Cdkey::instance()->post_type_display?></button>    
        </div>
        <div class="block20"></div>
        <?php 
            if($codes&&count($codes)>0){
                ?><textarea class="form-control" style="min-height:200px;min-width:200px;"><?php foreach ($codes as $item){
                        $order_date = date('Y.m.d H:i',$item->order_date);
                      echo esc_textarea("{$item->_code}  订单编号：{$item->purchase_order_id} --- {$order_date}\r\n");
                  }?></textarea>
                  <div style="float:right;"><a href="<?php echo $api->get_order_cdkeys_export_url($transaction_id,'csv')?>" class="xh-btn xh-btn-sm xh-btn-default">导出(.csv)</a> <a href="<?php echo $api->get_order_cdkeys_export_url($transaction_id,'txt')?>" class="xh-btn xh-btn-sm xh-btn-default">导出(.txt)</a></div>
                  <?php    
            }else{
                if(!empty($transaction_id)){
                ?>未查询到任何信息...<?php 
                }
            }?>
	</div>
	</form>  
</div>