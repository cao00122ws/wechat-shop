<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
?>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title><?php echo __('Alipay',WSHOP)?></title>
<body style="padding:0;margin:0;">
<?php 
if(WShop_Helper_Uri::is_ios()){
    ?>
	<img alt="<?php echo __('Alipay',WSHOP)?>" src="<?php print $this->domain_url?>/images/ios.png" style="max-width: 100%;">
	<?php 
}else{
	?>
	<img alt="<?php echo __('Alipay',WSHOP)?>" src="<?php print $this->domain_url?>/images/android.jpg" style="max-width: 100%;">
	<?php 
}
?>
</body>
</html>