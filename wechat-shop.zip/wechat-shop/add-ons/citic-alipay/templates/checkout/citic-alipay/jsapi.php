<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
  
$order_id =isset($_GET['order_id'])?$_GET['order_id']:'';
$order = WShop::instance()->payment->get_order('id', $order_id);
if(!$order){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404));
    exit;
}

if(!$order->can_pay()){
    WShop::instance()->WP->wp_die(WShop_Error::error_custom(__('Current order is paid or expired!',WSHOP)));
    exit;
}

try {    
    $api = WShop_Add_On_Citic_Alipay::instance();
    $payment_gateway = WShop_Payment_Gateway_Citic_Alipay::instance();
    $appid = $payment_gateway->get_option('appid');
    $appsecret = $payment_gateway->get_option('appsecret');
    
    //创建订单支付编号
    $sn = $order->generate_sn();
    if($sn instanceof WShop_Error){
       throw new Exception($sn->errmsg);
    }
    
    $startTime = date_i18n('YmdHis' );
    $expiredTime = date('YmdHis',current_time( 'timestamp' )+10*60);
    //若过期时间不对，请检查时区
    $exchange_rate = round(floatval(WShop_Settings_Default_Basic_Default::instance()->get_option('exchange_rate')),3);
    if($exchange_rate<=0){
        $exchange_rate = 1;
    }

    $request = array(
        'service'=>'pay.alipay.native',
        'mch_id'=>$appid,
        'out_trade_no'=>$sn,
        'body'=>mb_strimwidth($order->get_title(), 0, 32,'...','utf-8'),
        'total_fee'=> round($order->get_total_amount()*100*$exchange_rate),
        'mch_create_ip'=>WShop::instance()->WP->get_client_ip(),
        'notify_url'=>home_url('/'),
        'time_start'=>$startTime,
        'time_expire'=>$expiredTime,
        'nonce_str'=>str_shuffle(time())
    );
    
    $response=$api->post_xml('https://pay.swiftpass.cn/pay/gateway',$request,$appsecret);
    wp_redirect($response['code_url']);
    exit;  
} catch (Exception $e) {
    WShop_Log::error($e);
    WShop::instance()->WP->wp_die($e);
    exit;
}
?>