<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

class WShop_Payment_Gateway_Citic_Wechat extends Abstract_WShop_Payment_Gateway{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Payment_Gateway_Citic_Wechat
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Payment_Gateway_Citic_Wechat
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='citic_wechat';
        $this->group = 'wechat';
        $this->title=__('Wechat Pay',WSHOP);
        $this->icon=WSHOP_URL.'/assets/image/wechat-l.png';
        $this->icon_small=WSHOP_URL.'/assets/image/wechat.png';
        
        $this->init_form_fields ();
        $this->enabled ='yes'==$this->get_option('enabled');
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields() {
        $this->form_fields = array (
            'enabled' => array (
                'title' => __ ( 'Enable/Disable', WSHOP ),
                'type' => 'checkbox',
                'label' => __ ( 'Enable wechat payment', WSHOP ),
                'default' => 'yes'
            ),
            'appid' => array (
                'title' => __ ( 'Merchant ID', WSHOP ),
                'type' => 'text',
                'required' => true,
                'css' => 'width:400px'
            ),
            'appsecret' => array (
                'title' => __ ( 'Secret(KEY)', WSHOP ),
                'type' => 'text',
                'css' => 'width:400px',
                'required' => true,
                'desc_tip' => false
            ),
            'subtitle'=>array(
                'title'=>__('H5 In-App Web-based Payment',WSHOP),
                'type'=>'subtitle'
            ),
            'enable_mp' => array (
                'title' => __ ( 'Support H5 In-App Web-based Payment', WSHOP ),
                'type' => 'checkbox'
            ),
            'sub_appid'=>array (
                'title' => __ ( 'Sub appid', WSHOP ),
                'type' => 'text',
                'required' => true,
                'css' => 'width:400px'
            ),
            'sub_appsecret'=>array (
                'title' => __ ( 'Sub appsecret', WSHOP ),
                'type' => 'text',
                'required' => true,
                'css' => 'width:400px'
            )
        );
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Payment_Gateway::process_payment()
     */
    public function process_payment($order)
    {
        $api = WShop_Add_On_Citic_Wechat::instance();
        
        return WShop_Error::success(WShop::instance()->ajax_url(array(
            'action'=>"wshop_{$api->id}",
            'tab'=>'pay',
            'order_id'=>$order->id
        ),true,true));
    }
}
?>