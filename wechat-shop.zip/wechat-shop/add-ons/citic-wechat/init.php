<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'class-wshop-payment-gateway-citic-wechat.php';	   
/**
 * @author rain
 *
 */
class WShop_Add_On_Citic_Wechat extends Abstract_WShop_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Citic_Wechat
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Citic_Wechat
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wshop_add_ons_citic_wechat';
        $this->title=__('Wechat Pay(CITIC)',WSHOP);
        $this->description='中信银行全付通专用微信收款';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url("admin.php?page=wshop_page_default&section=menu_default_checkout&sub=citic_wechat")
            )
        );
    }

    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        add_filter('wshop_admin_menu_menu_default_checkout', function($menu){
            $menu[]= WShop_Payment_Gateway_Citic_Wechat::instance();
            return $menu;
        },10,1);
        
        add_filter('wshop_payments', function($payment_gateways){
            $payment_gateways[] =WShop_Payment_Gateway_Citic_Wechat::instance();
            return $payment_gateways;
        },10,1);
    }

    /**
     * 监听支付成功回调
     * @since 1.0.0
     */
    public function on_after_init(){ 
        $xml =isset($GLOBALS['HTTP_RAW_POST_DATA'])?$GLOBALS['HTTP_RAW_POST_DATA']:'';
        if(empty($xml)){
            $xml = file_get_contents("php://input");
        }
        
        if(empty($xml)){
            return;
        }
        //排除非xmlpost提交
        $xml = trim($xml);
        if(substr($xml, 0,4) !='<xml'){
            return;
        }
        
        //排除非微信回调
        if(strpos($xml, 'transaction_id')===false
           ||strpos($xml, 'trade_type')===false
           ||strpos($xml, 'mch_id')===false){
            return;
        }
        
        $response =WShop_Helper_String::xml_to_obj($xml);
        if(!$response){
            return;
        }
        
        if(!isset($response['status'])
            ||!isset($response['result_code'])
            ||!isset($response['sign'])
            ||!isset($response['mch_id'])
            ||!isset($response['transaction_id'])
            ){
            return;
        }
        
        try {
            $api = WShop_Payment_Gateway_Citic_Wechat::instance();
            $this->validate_callback_data($response,$api->get_option('appsecret'));
        } catch (Exception $e) {
            WShop_Log::error("invalid wechat callback,detail errors:".$e->getMessage().".".print_r($response,true));
            return;
        }
        
        try {
            $order = WShop::instance()->payment->get_order('sn', $response['out_trade_no']);
            if(!$order){
                WShop_Log::error("invalid wechat callback,detail errors:".$e->getMessage().".".print_r($response,true));
                echo 'faild';
                exit;
            }
    
            $error =$order->complete_payment($response['transaction_id']);
            if(!WShop_Error::is_valid($error)){
                WShop_Log::error('invalid wechat callback,detail errors:'.$error->errmsg.".".print_r($response,true));
                echo 'faild!';
                exit;
            }
        } catch (Exception $e) {
            WShop_Log::error('invalid wechat callback,detail errors:'.$e->getMessage().".".print_r($response,true));
            echo 'faild!';
            exit;
        }
        
        echo 'success';
        exit;
    }
       
    /**
     * 执行支付相关操作
     * @since 1.0.0
     */
    public function do_ajax(){
        $action ="wshop_{$this->id}";
    
        
        switch (isset($_REQUEST['tab'])?$_REQUEST['tab']:null){
            case 'pay':

                $datas=WShop_Async::instance()->shortcode_atts(array(
                    'notice_str'=>null,
                    'action'=>$action,
                    $action=>null,
                    'tab'=>null,
                    'order_id'=>0
                ), stripslashes_deep($_REQUEST));
               
                if(!WShop::instance()->WP->ajax_validate($datas, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
                    WShop::instance()->WP->wp_die(WShop_Error::err_code(701));
                    exit;
                }
               
                $api = WShop_Payment_Gateway_Citic_Wechat::instance();
              
                if(WShop_Helper_Uri::is_wechat_app()){
                    if('yes'==$api->get_option('enable_mp')){
                        require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/citic-wechat/jsapi.php');
                        exit;
                    }
                }
                
                require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/citic-wechat/qrcode.php');
                exit;
        }
    }
    
    public function validate_callback_data($response,$mchkey){
        $sign = $this->generate_sign($response,$mchkey);
        if($sign!=$response['sign']){
            throw new Exception('invalid sign');
        }
    
        if("{$response['status']}"!=='0'){
            throw new Exception("connect failed!errmsg:{$response['message']}");
        }
    
        if("{$response['result_code']}"!=='0'){
            throw new Exception("request failed!errcode:{$response['err_code']},errmsg:{$response['err_msg']}");
        }
         
        return $response;
    }
    /**
     * 微信签名
     * @param array $parameter
     * @param string $mchkey
     * @return string
     */
    public function generate_sign(array $parameter,$mchkey){
        ksort($parameter);
        reset($parameter);
       
        $builder = '';
        $index=0;
        foreach ($parameter as $key=>$val){
            if($key==='sign'||$val===''||is_array($val)){
                continue;
            }
        
            if($index++!=0){
                $builder.='&';
            }
            $builder.="{$key}={$val}";
        }
        
        return strtoupper(md5($builder . "&key=".$mchkey));
    }
    
    /**
     * post 请求微信数据
     * @param unknown $url
     * @param array $request
     * @param string $mchkey
     * @throws Exception
     * @return string
     */
    public function post_xml($url,array $request,$mchkey){
        $request['sign'] =$this->generate_sign($request, $mchkey);
      
        $response = WShop_Helper_Http::http_post($url,WShop_Helper_String::obj_to_xml($request));
        if(!$response){
            throw new Exception($response);
        }
        
        $data = WShop_Helper_String::xml_to_obj($response);
        if(!$data){
            throw new Exception($response);
        }
        
        return $this->validate_callback_data($data, $mchkey);
    }
    
}

return WShop_Add_On_Citic_Wechat::instance();
?>