<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
      
$order_id =isset($_GET['order_id'])?$_GET['order_id']:'';
$order = WShop::instance()->payment->get_order('id', $order_id);
if(!$order){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404));
    exit;
}

if(!$order->can_pay()){
    WShop::instance()->WP->wp_die(WShop_Error::error_custom(__('Current order is paid or expired!',WSHOP)));
    exit;
}

try {    
    $api = WShop_Add_On_Citic_Wechat::instance();
    $payment_gateway = WShop_Payment_Gateway_Citic_Wechat::instance();
    $appid = $payment_gateway->get_option('appid');
    $appsecret = $payment_gateway->get_option('appsecret');
    
    $sub_appid = $payment_gateway->get_option('sub_appid');
    $sub_appsecret = $payment_gateway->get_option('sub_appsecret');
    
    //创建订单支付编号
    $sn = $order->generate_sn();
    if($sn instanceof WShop_Error){
       throw new Exception($sn->errmsg);
    }
    
    $startTime = date_i18n('YmdHis' );
    $expiredTime = date('YmdHis',current_time( 'timestamp' )+10*60);
    //若过期时间不对，请检查时区
    $exchange_rate = round(floatval(WShop_Settings_Default_Basic_Default::instance()->get_option('exchange_rate')),3);
    if($exchange_rate<=0){
        $exchange_rate = 1;
    }

    require_once WSHOP_DIR.'/includes/class-xh-wechat-api.php';
    $wechat_api = new WShop_Wechat_Api($sub_appid, $sub_appsecret);
    $sub_openid = $wechat_api->get_openid();
    if(empty($sub_openid)){
        throw new Exception(__('Wechat authorize failed!',WSHOP));
    }
    
    $request = array(
        'service'=>'pay.weixin.jspay',
        'mch_id'=>$appid,
        'out_trade_no'=>$sn,
        'is_raw'=>1,
        'sub_appid'=>$sub_appid,
        'sub_openid'=>$sub_openid,
        'body'=>mb_strimwidth($order->get_title(), 0, 32,'...','utf-8'),
        'total_fee'=> round($order->get_total_amount()*100*$exchange_rate),
        'mch_create_ip'=>WShop::instance()->WP->get_client_ip(),
        'notify_url'=>home_url('/'),
        'time_start'=>$startTime,
        'time_expire'=>$expiredTime,
        'nonce_str'=>str_shuffle(time())
    );
  
    $response=$api->post_xml('https://pay.swiftpass.cn/pay/gateway',$request,$appsecret);
    $info = shortcode_atts(array(
        'appId'=>null,
        'timeStamp'=>null,
        'nonceStr'=>null,
        'package'=>null,
        'signType'=>null,
        'paySign'=>null,
    ), json_decode($response['pay_info'],true) );
    foreach ($info as $key=>$val){
        $info[$key] ="$val";
    }
    $back_url = $order->get_back_url();
    ?>
	<!DOCTYPE html>
	<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="">
    <meta name="description" content="">   
    <title>微信支付收银台</title>
    <style>
 *{margin:0;padding:0;}
  body{padding-top: 50px; background: #f2f2f4;}
 .clearfix:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }
.clearfix { display: inline-block; }
* html .clearfix { height: 1%; }
.clearfix { display: block; }
  .xh-title{height:35px;line-height:35px;text-align:center;font-size:30px;margin-bottom:20px;font-weight:300;}
  .qrbox{max-width: 900px;margin: 0 auto;background:#f9f9f9;padding:35px 20px 20px 50px;}
  
  .qrbox .left{width: 95%;        
     display: block;
    margin: 0px auto;}
  .qrbox .left .qrcon{
    border-radius: 10px;
    background: #fff;
    overflow: visible;
    text-align: center;
    padding-top:25px;
    color: #555;
    box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .05);
    vertical-align: top;
    -webkit-transition: all .2s linear;
    transition: all .2s linear;
  }
    .qrbox .left .qrcon .logo{width: 100%;}
    .qrbox .left .qrcon .title{font-size: 16px;margin: 10px auto;width: 100%;height:30px;line-height:30px;overflow:hidden;text-overflow :ellipsis }
    .qrbox .left .qrcon .price{font-size: 22px;margin: 0px auto;width: 100%;}
    .qrbox .left .qrcon .bottom{border-radius: 0 0 10px 10px;
    width: 100%;
    background: #32343d;
    color: #f2f2f2;padding:15px 0px;text-align: center;font-size: 14px;}
   .qrbox .sys{width: 60%;float: right;text-align: center;padding-top:20px;font-size: 12px;color: #ccc}
   .qrbox img{max-width: 100%;}
   @media (max-width : 767px){
.qrbox{padding:20px;}
    .qrbox .left{width: 95%;float: none;}   
    .qrbox .sys{display: none;}
   }
   
   @media (max-width : 320px){
   body{padding-top:35px;}
  }
  @media ( min-width: 321px) and ( max-width:375px ){
body{padding-top:35px;}
  }
    </style>
    </head>
    
    <body >
   	
      <div class="qrbox clearfix">
      <div class="left">
         <div class="qrcon">
          
           <h5><img src="<?php print WSHOP_URL;?>/assets/image/wechat/logo.png" style="height:40px;" alt=""></h5>
             <div class="title"><?php print $order->get_title();?></div>
         	 <div class="price">￥<?php echo $order->get_total_amount(false);?></div>
             <script type="text/javascript">
             	function wechat_jsapi_pay(){
             		WeixinJSBridge.invoke('getBrandWCPayRequest',<?php echo json_encode($info)?>,function(res){
             			if (res.err_msg != "get_brand_wcpay_request:ok"&&res.err_msg != "get_brand_wcpay_request:cancel") {
        					alert(JSON.stringify(res));
        					location.href='<?php print esc_url_raw($back_url);?>';
        					return;
        				}

        				location.href='<?php print $order->get_received_url();?>';
                	});
                }
             	
             	if (typeof WeixinJSBridge == "undefined"){
            	    if( document.addEventListener ){
            	        document.addEventListener('WeixinJSBridgeReady', wechat_jsapi_pay, false);
            	    }else if (document.attachEvent){
            	        document.attachEvent('WeixinJSBridgeReady', wechat_jsapi_pay); 
            	        document.attachEvent('onWeixinJSBridgeReady', wechat_jsapi_pay);
            	    }
            	}else{
            	    wechat_jsapi_pay();
            	}
             </script>
         </div>
         </div>
      </div>
     
    </body>
	<?php    
} catch (Exception $e) {
    WShop_Log::error($e);
    WShop::instance()->WP->wp_die($e);
    exit;
}
?>