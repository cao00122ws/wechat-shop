<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
  
$order_id =isset($_GET['order_id'])?$_GET['order_id']:'';
$order = WShop::instance()->payment->get_order('id', $order_id);
if(!$order){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404));
    exit;
}

if(!$order->can_pay()){
    WShop::instance()->WP->wp_die(WShop_Error::error_custom(__('Current order is paid or expired!',WSHOP)));
    exit;
}

try {    
    $api = WShop_Add_On_Citic_Wechat::instance();
    $payment_gateway = WShop_Payment_Gateway_Citic_Wechat::instance();
    $appid = $payment_gateway->get_option('appid');
    $appsecret = $payment_gateway->get_option('appsecret');
    
    //创建订单支付编号
    $sn = $order->generate_sn();
    if($sn instanceof WShop_Error){
       throw new Exception($sn->errmsg);
    }
    
    $startTime = date_i18n('YmdHis' );
    $expiredTime = date('YmdHis',current_time( 'timestamp' )+10*60);
    //若过期时间不对，请检查时区
    $exchange_rate = round(floatval(WShop_Settings_Default_Basic_Default::instance()->get_option('exchange_rate')),3);
    if($exchange_rate<=0){
        $exchange_rate = 1;
    }

    $request = array(
        'service'=>'pay.weixin.native',
        'mch_id'=>$appid,
        'out_trade_no'=>$sn,
        'body'=>mb_strimwidth($order->get_title(), 0, 32,'...','utf-8'),
        'total_fee'=> round($order->get_total_amount()*100*$exchange_rate),
        'mch_create_ip'=>WShop::instance()->WP->get_client_ip(),
        'notify_url'=>home_url('/'),
        'time_start'=>$startTime,
        'time_expire'=>$expiredTime,
        'nonce_str'=>str_shuffle(time())
    );
  
    $response=$api->post_xml('https://pay.swiftpass.cn/pay/gateway',$request,$appsecret);
    if ( ! $guessurl = site_url() ){
        $guessurl = wp_guess_url();
    }
    ?>
	<!DOCTYPE html>
	<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="keywords" content="">
    <meta name="description" content="">   
    <title>微信支付收银台</title>
    <style>
 *{margin:0;padding:0;}
  body{padding-top: 50px; background: #f2f2f4;}
 .clearfix:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }
.clearfix { display: inline-block; }
* html .clearfix { height: 1%; }
.clearfix { display: block; }
  .xh-title{height:35px;line-height:35px;text-align:center;font-size:30px;margin-bottom:20px;font-weight:300;}
  .qrbox{max-width: 900px;margin: 0 auto;background:#f9f9f9;padding:35px 20px 20px 50px;border:1px solid #ddd;border-top:3px solid #44b549;}
  
  .qrbox .left{width: 40%;
    float: left;    
     display: block;
    margin: 0px auto;}
  .qrbox .left .qrcon{
    border-radius: 10px;
    background: #fff;
    overflow: visible;
    text-align: center;
    padding-top:25px;
    color: #555;
    box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .05);
    vertical-align: top;
    -webkit-transition: all .2s linear;
    transition: all .2s linear;
  }
    .qrbox .left .qrcon .logo{width: 100%;}
    .qrbox .left .qrcon .title{font-size: 16px;margin: 10px auto;width: 100%;}
    .qrbox .left .qrcon .price{font-size: 22px;margin: 0px auto;width: 100%;}
    .qrbox .left .qrcon .bottom{border-radius: 0 0 10px 10px;
    width: 100%;
    background: #32343d;
    color: #f2f2f2;padding:15px 0px;text-align: center;font-size: 14px;}
   .qrbox .sys{width: 60%;float: right;text-align: center;padding-top:20px;font-size: 12px;color: #ccc}
   .qrbox img{max-width: 100%;}
   @media (max-width : 767px){
.qrbox{padding:20px;}
    .qrbox .left{width: 90%;float: none;}   
    .qrbox .sys{display: none;}
   }
   
   @media (max-width : 320px){
   body{padding-top:35px;}
  }
  @media ( min-width: 321px) and ( max-width:375px ){
body{padding-top:35px;}
  }
    </style>
    </head>
    
    <body >
    <div class="xh-title">微信支付收银台</div>
      <div class="qrbox clearfix">
      <div class="left">
             <div class="qrcon">
               <h5><img src="<?php print WSHOP_URL;?>/assets/image/wechat/logo.png" style="height:40px;" alt=""></h5>
                 <div class="title"><?php print $order->get_title();?></div>
             	 <div class="price"><?php echo $order->get_total_amount(true);?></div>
                 <div align="center"><img src="<?php print $response['code_img_url']?>" style="width: 250px;height: 250px;" alt=""></div>
                 <div class="bottom">
             		 <?php 
                     if(WShop_Helper_Uri::is_app_client()){
                         ?>步骤1：长按二维码保存到手机相册<br/>步骤2：微信扫一扫选择相册(右上角)完成扫描
                         <?php 
                     }else{
                         ?>
                         	请使用微信扫一扫<br/>
            				扫描二维码支付
                         <?php 
                     }
                     ?>
                 </div>
             </div>
             
      </div>
         <div class="sys"><img src="<?php print WSHOP_URL;?>/assets/image/wechat/wechat-sys.png" alt=""></div>
      </div>
     <script src="<?php echo $guessurl.'/wp-includes/js/jquery/jquery.js'; ?>"></script>
     <script type="text/javascript">
         (function($){
        		window.view={
        			query:function () {
        		        $.ajax({
        		            type: "POST",
        		            url: '<?php print WShop::instance()->ajax_url(array(
        		                'action'=>'wshop_checkout_v2',
        		                'order_id'=>$order->id,
        		                'tab'=>'is_paid'
        		            ),true,true);?>',
        		            timeout:6000,
        		            cache:false,
        		            dataType:'json',
        		            success:function(e){
        		            	if (e && e.data.paid) {
        			                $('#weixin-notice').css('color','green').text('已支付成功，跳转中...');
        		                    location.href = e.data.received_url;
        		                    return;
        		                }
        		                
        		                setTimeout(function(){window.view.query();}, 2000);
        		            },
        		            error:function(){
        		            	 setTimeout(function(){window.view.query();}, 2000);
        		            }
        		        });
        		    }
        		};
        		
       		 	window.view.query();
        	})(jQuery);
        	</script>
    </body>
	<?php    
} catch (Exception $e) {
    WShop_Log::error($e);
    WShop::instance()->WP->wp_die($e);
    exit;
}
?>