<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WShop_Coupon_Edit_Detail{
    /**
     * @var WShop_Coupon
     */
    private $coupon;
    
    public function __construct($id=0){
        $this->coupon = new WShop_Coupon($id);
    }
   
	public function view() {
	    $api = WShop_Add_On_Coupon::instance();
        ?>
         <h1 class="wp-heading-inline"><?php echo __('Edit coupon',WSHOP)?></h1>
           <div id="form-msg" style="display:none;"></div>     
           <a href="<?php echo WShop_Admin::instance()->get_current_admin_url(array('view'=>'edit'))?>" class="page-title-action"><?php echo __('Add coupon',WSHOP)?></a>
                <hr class="wp-header-end">
                
                <form name="post" action="post.php" method="post" id="post">
                
                <div id="poststuff">
                <div id="post-body" class="metabox-holder columns-2">
                   <div id="post-body-content">
                        <div id="titlediv">
                            <div id="titlewrap">
                            	<label class="screen-reader-text" id="title-prompt-text" for="title"><?php echo __('Coupon code:',WSHOP)?></label>
                            	<input type="text" id="form-coupon-code" placeholder="<?php echo __('Coupon code',WSHOP)?>" class="wshop-title" value="<?php echo esc_attr($this->coupon->code)?>" spellcheck="true" autocomplete="off">
                            </div>
                        	<div class="inside"></div>
                     	</div>	
                        <textarea id="form-coupon-description" class="wshop-coupon-description" cols="5" rows="2" placeholder="<?php echo __('Description',WSHOP)?>"><?php echo esc_textarea($this->coupon->description)?></textarea>
                    </div>
                    
                <div id="postbox-container-1" class="postbox-container">
                <div id="side-sortables" class="meta-box-sortables ui-sortable">
                
                    <div id="submitdiv" class="postbox ">
          
                        <h2 class="hndle ui-sortable-handle"><span><?php echo __('Publish',WSHOP)?></span></h2>
                        <div class="inside">
                        <div class="submitbox" id="submitpost">
                        
                        <div id="minor-publishing">
                        
                        
                        <div id="minor-publishing-actions">
                        <div id="save-action">
                        </div>
                        <div class="clear"></div>
                    </div>
                
                    <div id="misc-publishing-actions">
                    
                        <div class="misc-pub-section misc-pub-post-status">
                        	<?php echo __('Status:',WSHOP)?> <span id="post-status-display">
                        	<?php switch ($this->coupon->status){
                        	    case WShop_Coupon::STATUS_PUBLISH:
                        	        echo __('Published',WSHOP);
                        	        break;
                        	    case WShop_Coupon::STATUS_INAVTICE:
                        	        echo __('Deleted',WSHOP);
                        	        break;
                        	    default:
                        	        echo $this->coupon->status;
                        	}?></span>
                        </div>
                        
                        <div class="misc-pub-section curtime misc-pub-curtime">
                        	<span id="timestamp"><?php echo __('Created at:',WSHOP). date('Y-m-d H:i',$this->coupon->created_date)?></span>
                        </div>
                    
                    </div>
                    <div class="clear"></div>
                </div>
                
                <div id="major-publishing-actions">
                <div id="publishing-action">
                	<span class="spinner"></span>
            		<input name="save" type="button" class="button button-primary button-large" id="form-publish" value="<?php echo __('Update',WSHOP)?>">
                </div>
                <div class="clear"></div>
                </div>
                </div>
                
                </div>
                </div>
                </div>
                </div>
                
                
                <div id="postbox-container-2" class="postbox-container">
                <div id="normal-sortables" class="meta-box-sortables ui-sortable">
                <div id="wshop-coupon-data" class="postbox ">
                <h2 class="hndle ui-sortable-handle"><span><?php echo __('Coupon data',WSHOP)?></span></h2>
                	<div class="inside">
                
                		<div id="coupon_options" class="panel-wrap coupon_data">
                
                			<div class="wc-tabs-back"></div>
                
                			<ul class="coupon_data_tabs wc-tabs" style="">
                				<li class="general_options general_tab general_coupon_data active">
        							<a href="#general_coupon_data"><span><?php echo __('General',WSHOP)?></span></a>
        						</li>
                    			<li class="usage_restriction_options usage_restriction_tab">
        							<a href="#usage_restriction_coupon_data"><span><?php echo __('Usage restriction',WSHOP)?></span></a>
        						</li>
        						<li class="usage_limit_options usage_limit_tab">
        							<a href="#usage_limit_coupon_data"><span><?php echo __('Usage limits',WSHOP)?></span></a>
        						</li>			
        					</ul>
        					
                			<div id="general_coupon_data" class="panel wshop_options_panel" style="display: block;">
                			<p class="form-field discount_type_field ">
                        		<label><?php echo __('Discount type',WSHOP)?></label>
                        		
                        		<select id="form-discount-type" class="select short" >
                        			<?php foreach (WShop_Coupon::get_coupon_types() as $key=>$val){
                        			    ?><option value="<?php echo $key?>" <?php echo $key==$this->coupon->discount_type?"selected":""?>><?php echo $val;?></option><?php 
                        			}?>
                        		</select> 
                			</p>
                		
                    		<p class="form-field coupon_amount_field ">
                        		<label><?php echo __('Coupon amount',WSHOP)?></label>
                        		<span class="wshop-help-tip"></span>
                        		<input type="text" class="short" id="form-coupon-amount" value="<?php echo esc_attr($this->coupon->amount)?>" placeholder="0.00">
                    		</p>
                    		<p class="form-field expiry_date_field ">
                        		<label><?php echo __('Coupon expiry date',WSHOP)?></label>
                        		<input type="text" class="short" id="form-coupon-expire-date" value="<?php echo $this->coupon->expire_date? date('Y-m-d H:i',$this->coupon->expire_date):"";?>"  placeholder="<?php echo __('Unlimit',WSHOP)?>"/> 
                    		</p>
                    		<script type="text/javascript">
                           		(function($){
                              		$(function(){
                              			$("#form-coupon-expire-date").focus(function() {
                                  			WdatePicker({
                                  				dateFmt: 'yyyy-MM-dd HH:mm'
                                  			});
                                  		});
                                  	});
                               	})(jQuery);
                    	   </script>
                		</div>
                		
                			<div id="usage_restriction_coupon_data" class="panel wshop_options_panel" style="display: none;">
                				<div class="options_group">
                					<p class="form-field minimum_amount_field">
                					
                						<label><?php echo __('Minimum spend',WSHOP)?></label>
                						<span class="wshop-help-tip"></span>
                						<input type="text" class="short" id="form-coupon-minnum-spend" value="<?php echo $this->coupon->minnum_spend&&$this->coupon->minnum_spend>0?esc_attr($this->coupon->minnum_spend):"";?>" placeholder="<?php echo __('No minimum',WSHOP)?>" />
                						<br/><span class="description"><?php echo __('This field allows you to set the minimum spend (subtotal, including taxes) allowed to use the coupon.',WSHOP)?></span>  
                					</p>
                					
                					<p class="form-field maximum_amount_field" >
                						<label><?php echo __('Maxmum spend',WSHOP)?></label>
                							<span class="wshop-help-tip"></span>
                							<input type="text" class="short" id="form-coupon-maxnum-spend" value="<?php echo $this->coupon->maxnum_spend&&$this->coupon->maxnum_spend>0?esc_attr($this->coupon->maxnum_spend):"";?>" placeholder="<?php echo __('No maximum',WSHOP)?>" />
                							<br/><span class="description"><?php echo __('This field allows you to set the maximum spend (subtotal, including taxes) allowed when using the coupon.',WSHOP)?></span> 
                					</p>
                					
                					<p class="form-field individual_use_field ">
                						<label ><?php echo __('Individual use only',WSHOP)?></label>
                						<input type="checkbox" class="checkbox" id="form-coupon-individual-use-only" <?php echo $this->coupon->individual_use_only?"checked":""?> value="yes"> 
                						<br/><span class="description"><?php echo __('Check this box if the coupon cannot be used in conjunction with other coupons.',WSHOP)?></span>
                					</p>
                				</div>
                					
                		</div>
                			
                			
                		<div id="usage_limit_coupon_data" class="panel wshop_options_panel" style="display: none;">
                			
                			<div class="options_group">
                			
                    			<p class="form-field usage_limit_field ">
                    				<label for="usage_limit"><?php echo __('Usage limit per coupon',WSHOP)?></label>
                    				<span class="wshop-help-tip"></span>
                    				<input type="number" class="short" id="form-coupon-usage-limit" value="<?php echo $this->coupon->usage_limit&&$this->coupon->usage_limit>0?esc_attr($this->coupon->usage_limit):"";?>" placeholder="<?php echo __('Unlimited usage',WSHOP)?>" step="1" min="0"> 
                    			</p>
                    		
                				<p class="form-field usage_limit_per_user_field ">
                            		<label for="usage_limit_per_user"><?php echo __('Usage limit per user',WSHOP)?></label>
                            		<span class="wshop-help-tip"></span>
                            		<input type="number" class="short" id="form-coupon-usage-limit-per-user" value="<?php echo $this->coupon->usage_limit_per_user&&$this->coupon->usage_limit_per_user>0? esc_attr($this->coupon->usage_limit_per_user):"";?>" placeholder="<?php echo __('Unlimited usage',WSHOP)?>" step="1" min="0"> 
                        		</p>
                			</div>
                		</div>
                		<div class="clear"></div>
                		</div>
                	</div>
                </div>
                </div>
                <div id="advanced-sortables" class="meta-box-sortables ui-sortable"></div></div>
                </div><!-- /post-body -->
                <br class="clear">
                </div><!-- /poststuff -->
                </form>
                
            <script type="text/javascript">
				(function($){
					$('.coupon_data_tabs li a').click(function(){
						$('.coupon_data_tabs li.active').removeClass('active');
						$(this).parent('.coupon_data_tabs li').addClass('active');
						$('.panel.wshop_options_panel').css({display:'none'});
						$($(this).attr('href')).css({display:'block'});
						return false;
					});

					$('#form-publish').click(function(){
						var data ={
							id	:'<?php echo $this->coupon->id?>',
							code:$.trim($('#form-coupon-code').val()),
							description:$.trim($('#form-coupon-description').val()),
							discount_type:$.trim($('#form-discount-type').val()),
							amount:$.trim($('#form-coupon-amount').val()),
							expire_date:$.trim($('#form-coupon-expire-date').val()),
							minnum_spend:$.trim($('#form-coupon-minnum-spend').val()),
							maxnum_spend:$.trim($('#form-coupon-maxnum-spend').val()),
							individual_use_only:$('#form-coupon-individual-use-only:checked').length>0?1:0,
							usage_limit:$.trim($('#form-coupon-usage-limit').val()),
							usage_limit_per_user:$.trim($('#form-coupon-usage-limit-per-user').val()),		
						};

						$.ajax({
							url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'save_or_update'),true,true)?>',
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:data,
							dataType:'json',
							beforeSend:function(){
								$('#wpbody-content').loading();
							},
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert( e.errmsg );
									return;
								}

								location.href='<?php echo WShop_Admin::instance()->get_current_admin_url()?>';
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo __( 'Ajax error while adding coupon', WSHOP); ?>' );
							}
						});
					});
				})(jQuery);
			</script>    
		<?php
	}
}
