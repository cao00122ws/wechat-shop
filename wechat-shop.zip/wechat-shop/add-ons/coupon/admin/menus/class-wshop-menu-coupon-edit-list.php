<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WShop_Coupon_Edit_List {

	public function view() {
		global $wpdb;
		$api =WShop_Add_On_Coupon::instance();
		?>
		
		<div class="wrap">
		<h2>
			<?php esc_html_e( 'Coupon', WSHOP );?>
			<a class="add-new-h2" href="<?php echo WShop_Admin::instance()->get_current_admin_url(array(
			    'view'=>'edit'
			))?>"><?php echo esc_html__( 'Add New', WSHOP )?> </a>
		</h2>
		<style type="text/css">
		  .column-description{max-width:20%;}
		</style>
   		<?php
   
   		$table = new WShop_Coupon_List_Table($this);
   		$table->process_action();
   		$table->views();
   		$table->prepare_items();
   		?>
   		
    	<form method="get" id="form-wshop-order">
    	   <input type="hidden" name="page" value="<?php echo WShop_Admin::instance()->get_current_page()->get_page_id()?>"/>
           <input type="hidden" name="section" value="<?php echo WShop_Admin::instance()->get_current_menu()->id?>"/>
           <input type="hidden" name="tab" value="<?php echo WShop_Admin::instance()->get_current_submenu()->id?>"/>
       		<div class="order-list" id="wshop-order-list">
       		<?php $table->display(); ?>
       		</div>
    	</form>
    	<script type="text/javascript">
			(function($){
				window.wshop_view ={
					delete:function(id){
						if(confirm('<?php echo __('Are you sure?',WSHOP)?>'))
						this._update_order(id,'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'delete'),true,true)?>');
					},
					restore:function(id){
						this._update_order(id,'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'restore'),true,true)?>');
					},
					trash:function(id){
						this._update_order(id,'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'trash'),true,true)?>');
					},
					_update_order:function(id,ajax_url){
						if(!ajax_url){
							return;
						}
						
						$('#wpbody-content').loading();
						$.ajax({
							url:ajax_url,
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:{
								id:id
							},
							dataType:'json',
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert(e.errmsg);
									return;
								}
								
								location.reload();
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo esc_attr( 'System error while modifing coupon!', WSHOP); ?>');
							}
						});
					}
				};
		})(jQuery);
	</script>
	</div>
	<?php
	}
}

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class WShop_Coupon_List_Table extends WP_List_Table {

    /**
     * @var WShop_Menu_Order_Default_Settings
     * @since 1.0.0
     */
    public $api;
 
    private $status;
    private $code;
    /**
     * @param WShop_Menu_Order_Default_Settings $api
     * @param array $args
     * @since 1.0.0
     */
    public function __construct($api, $args = array() ) {
        $this->api = $api;
         
        parent::__construct( $args );
        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable ,'amount');
        
        $this->status = isset($_REQUEST['status'])?$_REQUEST['status']:null;
        if(!$this->status||!in_array($this->status, $this->get_all_order_status())){
            $this->status=WShop_Coupon::STATUS_PUBLISH;
        }
        
        $this->code =isset($_REQUEST['code'])?stripslashes($_REQUEST['code']):null;
    }
    
    public function process_action(){
        $bulk_action = $this->current_action();
        if(empty($bulk_action)){
            return;
        }
         
        check_admin_referer( 'bulk-' . $this->_args['plural'] );
         
        $coupon_ids   = isset($_POST['coupon_ids'])?$_POST['coupon_ids']:null;;
        if(!$coupon_ids||!is_array($coupon_ids)){
            return;
        }
     
        foreach ($coupon_ids as $order_id){
            
            $error =WShop_Coupon_Helper::update_coupon($order_id, $bulk_action);
            if(!WShop_Error::is_valid($error)){
                ?><div class="notice notice-error is-dismissible"><p><?php echo $error->errmsg;?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
                return;
            }
       }
    }
    
    public function get_all_order_status(){
        return array(
            WShop_Coupon::STATUS_PUBLISH,
            WShop_Coupon::STATUS_INAVTICE
        );
    }
    
    function get_sortable_columns() {
        return array(
            'expire_date' => array( 'expire_date', false ),
            'amount' => array( 'amount', false ),
        );
    }

    function get_views() {
        global $wpdb;
       
    
        $result =$wpdb->get_row(
           "select sum(if(o.`status`='".WShop_Coupon::STATUS_PUBLISH."',1,0)) as active,
                   sum(if(o.`status`='".WShop_Coupon::STATUS_INAVTICE."' ,1,0)) as trash
            from `{$wpdb->prefix}wshop_coupon` o;");
         
        $form_count= array(
            WShop_Coupon::STATUS_PUBLISH=> array(
                'title'=>__('Published',WSHOP),
                'count'=>intval( $result->active )
            ),
           WShop_Coupon::STATUS_INAVTICE    => array(
                'title'=>__('Trash',WSHOP),
                'count'=>intval( $result->trash )
            )
        );
    
        $current =null;
        $index=0;
        foreach ($form_count as $key=>$val){
            if($index++==0){
                $current=$key;
            }
    
            if($this->status==$key){
                $current=$key;
                break;
            }
        }
    
        $page_now = WShop_Admin::instance()->get_current_admin_url();
        $views=array();
        foreach ($form_count as $key=>$data){
            $now = $current==$key?"current":"";
            $views[$key] ="<a class=\"{$now}\" href=\"{$page_now}&status={$key}\">{$data['title']} <span class=\"count\">(<span>{$data['count']}</span>)</span></a>";
        }
         
        return $views;
    }

    
    function prepare_items() {
        $sort_column  = empty( $_REQUEST['orderby'] ) ? null : $_REQUEST['orderby'];
        $sort_columns = array_keys( $this->get_sortable_columns() );

        if (!$sort_column|| ! in_array( strtolower( $sort_column ), $sort_columns ) ) {
            $sort_column = 'amount';
        }

        $sort = isset($_REQUEST['order']) ? $_REQUEST['order']:null;
        if(!in_array($sort, array('asc','desc'))){
            $sort ='desc';
        }

        $status =empty($this->status)?"":" and o.status='{$this->status}'";
        
        global $wpdb;
        $sql=  "select count(o.id) as qty
                from `{$wpdb->prefix}wshop_coupon` o
                where (%s ='' or o.code=%s)  
                      $status;";
        
        $query = $wpdb->get_row($wpdb->prepare($sql, $this->code,$this->code));

        $total = intval($query->qty);
        $per_page = 20;
        if($per_page<=0){$per_page=20;}
        $total_page = intval(ceil($total/($per_page*1.0)));
        $this->set_pagination_args( array(
            'total_items' => $total,
            'total_pages' => $total_page,
            'per_page' => $per_page,
            'status'=>$this->status,
            'code'=>$this->code
        ));

        $pageIndex =$this->get_pagenum();
        $start = ($pageIndex-1)*$per_page;
        $end = $per_page;

        $sql ="select o.*
                from `{$wpdb->prefix}wshop_coupon` o
                where (%s ='' or o.code=%s)  
                      $status
                order by o.$sort_column $sort
                limit $start,$end;";
     
        $this->items = $wpdb->get_results($wpdb->prepare($sql, $this->code,$this->code));   
    }
    
    function extra_tablenav( $which ) {
       if($which!='top'){
           return;
       }
       ?>
       
       <input type="search" id="search-code" name="code" style="height:32px;" value="<?php echo esc_attr($this->code)?>" placeholder="<?php echo __('Coupon code',WSHOP)?>"/>
		<input type="submit" class="button" style="line-height: 32px;height:32px;" value="<?php echo __('Filter',WSHOP)?>">
       <?php 
    }
    
    function get_bulk_actions() {
        if ( $this->status == 'I' ) {
            return array(
                'restore' => esc_html__( 'Restore', WSHOP ),
                'delete' => esc_html__( 'Delete permanently', WSHOP ),
            );
        }

        return array(
            'trash' => esc_html__( 'Move to trash', WSHOP )
        );
    }

    function get_columns() {
        return array(
            'cb'                    => '<input type="checkbox" />',
            'code'                  => __( 'Code', WSHOP ),
            'discount_type'         => __( 'Discount type', WSHOP ),
            'amount'                => __( 'Coupon amount', WSHOP ),
            'description'           => __( 'Description', WSHOP ),
            'usage_limit'           => __( 'Usage limit', WSHOP ),
            'expire_date'           => __( 'Expire date', WSHOP ),
        );
    }

    public function single_row( $item ) {
        echo '<tr id="form-tr-'.$item->id .'">';
        $this->single_row_columns( $item );
        echo '</tr>';
    }

    function single_row_columns( $item ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();

        foreach ( $columns as $column_name => $column_display_name ) {
            $classes = "$column_name column-$column_name";
            if ( $primary === $column_name ) {
                $classes .= ' has-row-actions column-primary';
            }

            if ( in_array( $column_name, $hidden ) ) {
                $classes .= ' hidden';
            }

            $data = 'data-colname="' . wp_strip_all_tags( $column_display_name ) . '"';

            $attributes = "class='$classes' $data";

            if ( 'cb' === $column_name ) {
                echo '<th scope="row" class="check-column">';
                echo $this->column_cb( $item );
                echo '</th>';
            }  elseif ( method_exists( $this, '_column_' . $column_name ) ) {
                echo call_user_func(
                    array( $this, '_column_' . $column_name ),
                    $item,
                    $classes,
                    $data,
                    $primary
                    );
            } elseif ( method_exists( $this, 'column_' . $column_name ) ) {
                echo "<td $attributes>";
                echo call_user_func( array( $this, 'column_' . $column_name ), $item );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            } else {
                echo "<td $attributes>";
                echo $this->column_default( $item, $column_name );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            }
        }
    }

	function column_cb( $form ) {
		$form_id = $form->id;
		?>
		<label class="screen-reader-text" for="cb-select-<?php echo esc_attr( $form_id ); ?>"><?php _e( 'Select coupon' ); ?></label>
		<input type="checkbox" class="wshop_list_checkbox" name="coupon_ids[]" value="<?php echo esc_attr( $form_id ); ?>" />
		<?php
	}

	public function column_amount($item){
	    switch ($item->discount_type){
	        case WShop_Coupon::COUPON_TYPE_FIXED:
	            ?><span class="amount"> <?php echo $item->amount;?></span><?php 
	            break;
	        case WShop_Coupon::COUPON_TYPE_PERCENTAGE:
	            ?><span class="amount"> <?php echo round($item->amount*100,1).'%';?></span><?php
	            break;
	        default:
	           ?><span class="amount"> <?php echo $item->amount;?></span><?php 
	            break;
	    }
	    
	}
	
	public function column_code($item){
	    $edit_url = WShop_Admin::instance()->get_current_admin_url(array(
	        'view'=>'edit',
	        'id'=>$item->id
	    ));
    ?>
        <a href="<?php echo $edit_url;?>" class="row-title"><strong><?php echo $item->code?></strong></a>
        
         <div class="row-actions">
         	 <?php if($this->status=='I'){
         	     ?>
          	      <span class="restore"><a href="javascript:void(0);" onclick="window.wshop_view.restore(<?php echo $item->id;?>);"><?php echo __('Restore',WSHOP)?></a> | </span>
              	  <span class="delete"><a href="javascript:void(0);" onclick="window.wshop_view.delete(<?php echo $item->id;?>);" ><?php echo __('Delete permanently',WSHOP)?></a></span>
          	     <?php 
         	 }else{
         	     ?>
         	     <span class="edit"><a href="<?php echo $edit_url;?>"><?php echo __('Edit',WSHOP)?></a> | </span>
             	 <span class="trash"><a href="javascript:void(0);" onclick="window.wshop_view.trash(<?php echo $item->id;?>);"><?php echo __('Trash',WSHOP)?></a></span>
         	     <?php 
         	 }?>
             
         </div>
        <?php 
    }
    
    public function column_discount_type($item){
        $discount_type = $item->discount_type;
        $types = WShop_Coupon::get_coupon_types();
        echo $types[$discount_type];
    }
    
    
    public function column_usage_limit($item){
        $msg =$item->usage_count." / ";
        if(WShop_Helper_String::is_null_or_empty($item->usage_limit)){
            $msg.='∞';
        }else{
            $msg.=$item->usage_limit;
        }
        
        echo $msg;
    }
    public function column_description($item){
       echo $item->description;
    } 
    
    public function column_expire_date($item){
        ?>
        <time><?php echo $item->expire_date?date('Y-m-d H:i',$item->expire_date):"--"?></time>
        <?php 
    }
  
	function no_items() {
		echo __( "You don't have any coupon!", WSHOP ) ;
	}
}
