<?php 

class WShop_Coupon extends WShop_Object{
    const STATUS_PUBLISH='A';
    const STATUS_INAVTICE='I';
    const COUPON_TYPE_FIXED='fixed';
    const COUPON_TYPE_PERCENTAGE='percent';

    /**
     * ID
     * @var long
     */
    public $id;
    
    /**
     * 优惠码(唯一的)
     * @var string
     */
    public $code;
    
    /**
     * 描述
     * @var string|NULL
     */
    public $description;
    
    /**
     * 优惠券类型
     * @var string
     */
    public $discount_type;
    
    /**
     * 折扣金额
     * @var decimal
     */
    public $amount;
    
    /**
     * 过期时间
     * @var long|NULL
     */
    public $expire_date;
    
    /**
     * 最少使用金额
     * @var decimal|NULL
     */
    public $minnum_spend;
    
    /**
     * 最多使用金额
     * @var decimal|NULL
     */
    public $maxnum_spend;
    
    /**
     * 是否允许与其他优惠券混用
     * @var bool
     */
    public $individual_use_only;
    
    /**
     * 使用次数限制
     * @var int|NULL
     */
    public $usage_limit;
    
    /**
     * 使用次数
     * @var int|NULL
     */
    public $usage_count=0;
    
    /**
     * 单人使用次数限制
     * @var int|NULL
     */
    public $usage_limit_per_user;
    
    /**
     * 状态
     * @var string
     */
    public $status;
    public $created_date;
    
    public function __construct($obj=null){
        parent::__construct($obj);
    }
    /**
     * {@inheritDoc}
     * @see WShop_Object::is_auto_increment()
     */
    public function is_auto_increment()
    {
        // TODO Auto-generated method stub
        return true;
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_primary_key()
     */
    public function get_primary_key()
    {
        // TODO Auto-generated method stub
        return 'id';
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_coupon';
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return array(
            'id'=>0,
            'code'=>null,
            'description'=>null,
            'discount_type'=>self::COUPON_TYPE_FIXED,
            'amount'=>0.00,
            'expire_date'=>null,
            'minnum_spend'=>null,
            'maxnum_spend'=>null,
            'individual_use_only'=>null,
            'usage_limit'=>null,
            'usage_limit_per_user'=>null,
            'created_date'=>current_time( 'timestamp' ),
            'usage_count'=>0,
            'status'=>self::STATUS_PUBLISH
            
        );
    }
  
    /**
     * 获取优惠码类型
     * @return string[]
     */
    public static function get_coupon_types(){
        return array(
            self::COUPON_TYPE_FIXED=>__('Fixed discount',WSHOP),
            self::COUPON_TYPE_PERCENTAGE=>__('Percentage discount',WSHOP)
        );
    }
    
    /**
     * 结算金额
     * @param decimal $amount
     * @return decimal
     */
    public function settle($amount){
        switch ($this->discount_type){
            case self::COUPON_TYPE_FIXED:
                return $this->amount;
            case self::COUPON_TYPE_PERCENTAGE:
                return $amount*$this->amount;
            default:
                return 0;
        }
    }
    
    /**
     * 结算金额
     * @param decimal $amount
     */
    public static function js_settle(){
        if(!defined('WSHOP_COUPON_JS_SETTLE')){
            define('WSHOP_COUPON_JS_SETTLE', '1');
        ?>
        <script type="text/javascript">
        	//计算出折扣的价格
			function wshop_coupon_settle_discount_amount(coupon,amount){
				if(typeof coupon !='object'){throw 'coupon is invalid!';}

				switch(coupon.discount_type){
					case '<?php echo self::COUPON_TYPE_FIXED?>':
						return Number(coupon.amount);
					case '<?php echo self::COUPON_TYPE_PERCENTAGE ?>':
						return Number(amount)*Number(coupon.amount);
					default:
						return 0;
				}
			}
		</script>
        <?php
        }
    }
    
}

class WShop_Coupon_Item extends WShop_Object{
    /**
     * {@inheritDoc}
     * @see WShop_Object::is_auto_increment()
     */
    public function is_auto_increment()
    {
        // TODO Auto-generated method stub
        return true;
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_primary_key()
     */
    public function get_primary_key()
    {
        // TODO Auto-generated method stub
        return "id";
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return "wshop_coupon_item";
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        // TODO Auto-generated method stub      
        return array(
            'id'=>0,
            'order_id'=>0,
            'customer_id'=>null,
            'coupon_id'=>null,
            'created_time'=>null,
            'status'=>null
        );
    }

    
}

class WShop_Coupon_Model extends Abstract_WShop_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        $collate=$this->get_collate();
        global $wpdb;
        $wpdb->query("CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_coupon` (
        	`id` INT(11) NOT NULL AUTO_INCREMENT,
        	`code` VARCHAR(64) NOT NULL,
        	`description` TEXT NULL,
        	`discount_type` VARCHAR(16) NOT NULL,
        	`amount` DECIMAL(18,2) NOT NULL,
        	`expire_date` BIGINT(20) NULL DEFAULT NULL,
        	`minnum_spend` DECIMAL(18,2) NULL DEFAULT NULL,
        	`maxnum_spend` DECIMAL(18,2) NULL DEFAULT NULL,
        	`individual_use_only` TINYINT(4) NOT NULL DEFAULT '0',
        	`usage_limit` BIGINT(20) NULL DEFAULT NULL,
        	`created_date` BIGINT(20) NOT NULL DEFAULT '0',
        	`usage_count` BIGINT(20) NOT NULL DEFAULT '0',
        	`usage_limit_per_user` BIGINT(20) NULL DEFAULT NULL,
        	`status` VARCHAR(2) NOT NULL,
        	PRIMARY KEY (`id`),
        	UNIQUE INDEX `code` (`code`),
        	INDEX `status` (`status`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $wpdb->query(
       "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_coupon_item` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
        	`order_id` BIGINT(20) NOT NULL,
        	`customer_id` BIGINT(20) NULL DEFAULT NULL,
        	`coupon_id` BIGINT(20) NOT NULL,
        	`created_time` BIGINT(20) NOT NULL,
        	`status` varchar(1) NOT NULL,
        	PRIMARY KEY (`id`)
        )
        $collate;");
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
    }
}

class WShop_Coupon_Helper{
     
    public static function update_coupon($id,$action){
        $coupon = new WShop_Coupon($id);
        if(!$coupon){
            return WShop_Error::err_code(404);
        }
         
        try {
            global $wpdb;
            switch ($action){
                case 'restore':
                    $coupon = new WShop_Coupon($coupon->id);
                    if(!$coupon->is_load()){
                        throw new Exception(__('Coupon is not found!',WSHOP));
                    }
                    
                    $result = $coupon->update(array(
                        'status'=>WShop_Coupon::STATUS_PUBLISH
                    ));
                   
                    if(!WShop_Error::is_valid($result)){
                        throw new Exception($result->errmsg);
                    }
                    break;
                case 'delete':
                    $coupon = new WShop_Coupon($coupon->id);
                    if(!$coupon->is_load()){
                        throw new Exception(__('Coupon is not found!',WSHOP));
                    }
                    $result = $coupon->remove();
                    if(!WShop_Error::is_valid($result)){
                        throw new Exception($result->errmsg);
                    }
                    break;
                case 'trash':
                    $result = $coupon->update(array(
                        'status'=>WShop_Coupon::STATUS_INAVTICE
                    ));
                   
                    if(!WShop_Error::is_valid($result)){
                        throw new Exception($result->errmsg);
                    }
                    break;
            }
        } catch (Exception $e) {
            return WShop_Error::error_custom($e->getMessage());
        }
         
        return WShop_Error::success();
    }
}
?>