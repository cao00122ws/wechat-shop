<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'includes/class-wshop-coupon.php';	
require_once 'abstract-xh-add-ons-api.php';
/**
 * 优惠码
 * @author rain
 *
 */
class WShop_Add_On_Coupon extends Abstract_WShop_Add_Ons_Coupon_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Coupon
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Coupon
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        $this->id='wshop_add_ons_coupon';
        $this->title=__('Coupon',WSHOP);
        $this->description='支持创建优惠券，支持折扣型和固定金额型优惠券';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->plugin_uri='https://www.wpweixin.net/product/1464.html';
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
    }
    
    public function on_install(){
        $api = new WShop_Coupon_Model();
        $api->init();
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_load()
     */
    public function on_load(){
        $this->m1();
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        $this->m2();
    }
   
    /**
     * @param WShop_Error $error
     * @param WShop_Order $order
     * @param WShop_Shopping_Cart $cart
     * @return WShop_Error
     */
    public function wshop_order_extra_amount($error,$order,$cart){
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        $coupons = $this->validate_coupons($cart);
        if($coupons instanceof WShop_Error){
            return $coupons;
        }
         
        if(count($coupons)==0){
            return $error;
        }
        
        $discount = 0;
        foreach ($coupons as $coupon){
            $discount+=$coupon->settle($order->total_amount);
        }
    
        $order->extra_amount[]=array(
            'title'=>__('Coupon',WSHOP),
            'amount'=> -$discount
        );
    
        $order->add_call_after_insert(function($order,$coupons){
            global $wpdb;
            $coupon_ids = array();
            $coupon_item_ids = array();
            foreach ($coupons as $coupon){
                $wpdb->insert("{$wpdb->prefix}wshop_coupon_item", array(
                    'order_id'=>$order->id,
                    'customer_id'=>get_current_user_id(),
                    'coupon_id'=>$coupon->id,
                    'created_time'=>current_time( 'timestamp' ),
                    'status'=>WShop_Coupon::STATUS_PUBLISH
                ));
                
                if(!empty($wpdb->last_error)){
                    WShop_Log::error($wpdb->last_error);
                    return WShop_Error::err_code(500);
                }
                $coupon_item_id = $wpdb->insert_id;
                if($coupon_item_id<=0){
                    return WShop_Error::err_code(500);
                }
                
                $coupon_ids[]=$coupon->id;
                $coupon_item_ids []=$coupon_item_id;
            }
            
            $order->__set_metas(array(
                'coupon'=>array(
                    'coupon_ids'=>$coupon_ids,
                    'coupon_item_ids'=>$coupon_item_ids
            )));
            
            return WShop_Error::success();
        },$coupons);
        
        return WShop_Error::success();
    }
    
    public function do_ajax(){
        $this->on_front_post();
        $this->on_admin_post();
    }
    
    /**
     * 
     * @param array $args
     * @param WShop_Order $order
     * @param string $transaction_id
     */
    public function wshop_order_complete_payment_args($args,$order,$transaction_id){
        if(!isset($order->metas['coupon']['coupon_item_ids'])||count($order->metas['coupon']['coupon_item_ids'])==0){
            return $args;
        }
        
        global $wpdb;
        
        $args['join']['coupon']=
        " inner join `{$wpdb->prefix}wshop_coupon_item` coupon_wshop_coupon_item  on coupon_wshop_coupon_item.order_id = core_wshop_order.id
          inner join `{$wpdb->prefix}wshop_coupon` coupon_wshop_coupon on coupon_wshop_coupon.id = coupon_wshop_coupon_item.coupon_id ";
            
        $args['set']['coupon']=",coupon_wshop_coupon_item.status='P',coupon_wshop_coupon.usage_count=(coupon_wshop_coupon.usage_count+1)";
        $args['where']['coupon'] = " and (coupon_wshop_coupon_item.status='".WShop_Coupon::STATUS_PUBLISH."')";
        
        return $args;
    }
    
    /**
     * 
     * @param WShop_Shopping_Cart $cart
     * @return WShop_Error|WShop_Coupon[]
     */
    public function validate_coupons($cart){
        $coupons = array();
        if(!isset($cart->coupons)||!$cart->coupons){
            return $coupons;
        }
    
        foreach ($cart->coupons as $coupon_id => $code){
            $coupon = new WShop_Coupon($coupon_id);
            if(!$coupon->is_load()){
                return  WShop_Error::error_custom(sprintf(__('Coupon is used or not found!(%s)',WSHOP),$code));
            }
    
            $error = $this->validate_coupon($cart,$coupon);
            if(!WShop_Error::is_valid($error)){
                return $error;
            }
             
            $coupons[]=$coupon;
        }
    
        return $coupons;
    }
    /**
     *
     * @param WShop_Shopping_Cart $cart
     * @return WShop_Coupon[]
     */
    public function get_validate_coupons($cart){
        $coupons = array();
        if(!isset($cart->coupons)||!$cart->coupons){
            return $coupons;
        }
    
        foreach ($cart->coupons as $coupon_id => $code){
            $coupon = new WShop_Coupon($coupon_id);
            if(!$coupon->is_load()){
                continue;
            }
    
            $error = $this->validate_coupon($cart,$coupon);
            if(!WShop_Error::is_valid($error)){
                continue;
            }
             
            $coupons[]=$coupon;
        }
    
        return $coupons;
    }
    /**
     *
     * @param WShop_Coupon $coupon
     */
    public function validate_coupon($cart,$coupon){
    
        //检查是否已过期
        if(!WShop_Helper_String::is_null_or_empty($coupon->expire_date)){
            if(intval($coupon->expire_date)<current_time( 'timestamp' )){
                return WShop_Error::error_custom(sprintf(__('Sorry!The coupon is expired!(%s)',WSHOP),$coupon->code));
            }
        }
         
        $cart_total = $cart->get_total();
        //检查订单最小金额
        if(!WShop_Helper_String::is_null_or_empty($coupon->minnum_spend)){
            if(floatval($coupon->minnum_spend)>$cart_total){
                return  WShop_Error::error_custom(sprintf(__('Sorry!The order amount is too small when use coupon!(%s)',WSHOP),$coupon->code));
            }
        }
    
        //检查订单最大金额
        if(!WShop_Helper_String::is_null_or_empty($coupon->maxnum_spend)){
            if(floatval($coupon->maxnum_spend)<$cart_total){
                echo WShop_Error::error_custom(sprintf(__('Sorry!The order amount is too large when use coupon!(%s)',WSHOP),$coupon->code))->to_json();
                exit;
            }
        }
         
        if(!isset($cart->coupons)||!is_array($cart->coupons)){
            $cart->coupons=array();
        }
         
        //         //检查当前优惠券是否重复使用
        //         if(in_array($coupon->id, $this->coupons)){
        //             return WShop_Error::error_custom(__('Sorry!The coupon can not be used twice in one order!',WSHOP));
        //         }
         
        //TODO 检查 当前金额不能与其他优惠券公用
        if($coupon->individual_use_only){
            $i =WShop_Helper_Array::where(array_keys($cart->coupons), function($m,$c){return $m->id!=$c->id;},$coupon);
            if($i&&count($i)>0){
                return WShop_Error::error_custom(sprintf(__('Sorry!The coupon cannot be used in conjunction with other coupons!(%s)',WSHOP),$coupon->code));
            }
        }
    
        //检查单人使用次数限制
        global $current_user;
        if(!WShop_Helper_String::is_null_or_empty($coupon->usage_limit_per_user)){
            if(is_user_logged_in()){
                global $wpdb;
                $query = $wpdb->get_row(
                    "select count(i.id) as qty
                    from {$wpdb->prefix}wshop_coupon_item i
                    where i.coupon_id={$coupon->id}
                          and i.status='P'
                          and i.customer_id={$current_user->ID};");
                 
                $user_usage_qty = intval($query->qty);
                if($user_usage_qty>=$coupon->usage_limit_per_user){
                    return WShop_Error::error_custom(sprintf(__('Sorry!The coupon is already invalid!(%s)',WSHOP),$coupon->code));
                }
            }
        }
         
        //检查总使用次数限制
        if(!WShop_Helper_String::is_null_or_empty($coupon->usage_limit)){
            global $wpdb;
            $query = $wpdb->get_row(
               "select count(i.id) as qty
                from {$wpdb->prefix}wshop_coupon_item i
                where i.coupon_id={$coupon->id}
                      and i.status='P';");
             
            $usage_qty = intval($query->qty);
            if($usage_qty>=$coupon->usage_limit){
                return WShop_Error::error_custom(sprintf(__('Sorry!The coupon is already invalid!(%s)',WSHOP),$coupon->code));
            }
        }
    
        return WShop_Error::success();
    }
    
    public function wshop_checkout_cart($call,$context){
        $call[]= function($context){
            echo WShop::instance()->WP->requires(WShop_Add_On_Coupon::instance()->domain_dir, 'coupon/checkout.php',$context);
        };
        
        return $call;
    }
    
    public function wshop_checkout_options_2($options){
        $options['enable_coupon']=array(
            'title'=>__('Enable coupon',WSHOP),
            'tr_css'=>'section-modal section-shopping_cart',
            'type'=>'checkbox',
            'description'=>__('Checkout with coupon.',WSHOP)
        );
        return $options;
    }
    private function on_front_post(){
        $action="wshop_{$this->id}";
        switch (isset($_REQUEST['tab'])?$_REQUEST['tab']:null){
            case 'coupon_remove':
                $request=WShop_Async::instance()->shortcode_atts(array(
                    'notice_str'=>null,
                    'action'=>$action,
                    $action=>null,
                    'tab'=>null
                ), stripslashes_deep($_REQUEST));
                
                if(!WShop::instance()->WP->ajax_validate($request, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
                    echo WShop_Error::err_code(701)->to_json();
                    exit;
                }
                 
                $cart = WShop_Shopping_Cart::get_cart();
                if($cart instanceof WShop_Error){
                    echo $cart->to_json();
                    exit;
                }
               
                $coupon_id = isset($_REQUEST['coupon_id'])?stripslashes($_REQUEST['coupon_id']):null;
                if(empty($coupon_id)){
                    echo WShop_Error::err_code(404)->to_json();
                    exit;
                }
                
                $new_coupons=array();
                if($cart->coupons){
                    foreach ($cart->coupons as $cid=>$code){
                        if($coupon_id!=$cid){
                            $new_coupons[$cid]=$code;
                        }
                    }
                }
                
                $error = $cart->update(array(
                    'coupons'=>$new_coupons
                ));
               
                echo $error->to_json();
                exit;
                
            case 'coupon_apply':
                $request=WShop_Async::instance()->shortcode_atts(array(
                    'notice_str'=>null,
                    'action'=>$action,
                    $action=>null,
                    'tab'=>null
                ), stripslashes_deep($_REQUEST));
            
                if(!WShop::instance()->WP->ajax_validate($request, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
                    echo WShop_Error::err_code(701)->to_json();
                    exit;
                }
                 
                $cart = WShop_Shopping_Cart::get_cart();
                if($cart instanceof WShop_Error){
                    echo $cart->to_json();
                    exit;
                }
                 
                $code = isset($_REQUEST['code'])?stripslashes($_REQUEST['code']):null;
                if(empty($code)){
                    echo WShop_Error::error_custom(__('Coupon is invalid!',WSHOP))->to_json();
                    exit;
                }
                
                $coupon = $this->add_coupon_to_cart($cart,$code);
                if($coupon instanceof WShop_Error){
                    echo $coupon->to_json();
                    exit;
                }
                
                echo WShop_Error::success($coupon)->to_json();
                exit;
        }
    }
    
    /**
     * 
     * @param WShop_Shopping_Cart $cart
     * @param string $code
     * @param string $clear
     * @return WShop_Error|WShop_Coupon
     */
    public function add_coupon_to_cart($cart,$code,$clear=false,$save_change=true){
        if(empty($code)){
            return WShop_Error::error_custom(__('Coupon is invalid!',WSHOP));
        }
        
        if($clear){
            $cart->coupons = array();
        }
        
        $coupon =new WShop_Coupon();
        $coupon->get_by('code', $code);
        if(!$coupon->is_load()){
            return WShop_Error::error_custom(sprintf(__('Coupon is used or not found!(%s)',WSHOP),$code));
        }
        
        $error = $this->validate_coupon($cart,$coupon);
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
         
        //检查当前优惠券是否重复使用
        if(in_array($coupon->id, array_keys($cart->coupons))){
            return WShop_Error::error_custom(__('Sorry!The coupon can not be used twice in one order!',WSHOP));
        }
         
        $cart->coupons[$coupon->id]=$coupon->code;
        
        //检查已拥有的优惠券再次进行检查
        $error = $this->validate_coupons($cart);
        if($error instanceof WShop_Error){
            return $error;
        }
        
        $cart->set_change('coupons', $cart->coupons);
        
        if($save_change){
            $error = $cart->save_changes();
            if($error instanceof WShop_Error){
                return $error;
            }
        }
        
        return $coupon;
    }
    
    private function on_admin_post(){
        $action ="wshop_{$this->id}";
        $datas=WShop_Async::instance()->shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null
        ), stripslashes_deep($_REQUEST));
        if(!WShop::instance()->WP->ajax_validate($datas,$_REQUEST['hash'],true)){
            echo WShop_Error::err_code(701)->to_json();
            exit;
        }
        
        global $current_user;
        $roles = $current_user?$current_user->roles:null;
        if(!$roles||!is_array($roles)||!in_array('administrator', $roles)){
            echo WShop_Error::err_code(501)->to_json();
            exit;
        }
       
        switch ($datas['tab']){
            case 'save_or_update':
                $obj = new WShop_Coupon(isset($_REQUEST['id'])?sanitize_key($_REQUEST['id']):null);
                $datas = WShop_Async::instance()->shortcode_atts(get_object_vars($obj),stripslashes_deep($_REQUEST));
                
                foreach ($datas as $key=>$val){
                    $datas[$key] = maybe_serialize($val);
                }
                
                if(empty($datas['code'])){
                    echo WShop_Error::error_custom(__('Coupon code is required!',WSHOP))->to_json();
                    exit;
                }
                
                $datas['amount'] = round(floatval($datas['amount']),2);
                if($datas['amount']<=0){
                    echo WShop_Error::error_custom(__('Coupon amount is invalid!',WSHOP))->to_json();
                    exit;
                }
                
                if(!in_array($datas['discount_type'], array_keys(WShop_Coupon::get_coupon_types()))){
                    $datas['discount_type']=WShop_Coupon::COUPON_TYPE_FIXED;
                }
                    
                $datas['expire_date'] =$datas['expire_date']===''?null:strtotime($datas['expire_date']);
                $datas['minnum_spend'] = $datas['minnum_spend']===''?null:round(floatval($datas['minnum_spend']),2);
                $datas['maxnum_spend'] = $datas['maxnum_spend']===''?null:round(floatval($datas['maxnum_spend']),2);
                $datas['individual_use_only'] = intval($datas['individual_use_only']);
                $datas['usage_limit'] = $datas['usage_limit']===''?null:intval($datas['usage_limit']);
                $datas['usage_limit_per_user'] = $datas['usage_limit_per_user']===''?null:intval($datas['usage_limit_per_user']);
               
                global $wpdb;
                $id=0;
                try {
                    if($obj->is_load()){
                        if($wpdb->get_row($wpdb->prepare("select id from {$wpdb->prefix}wshop_coupon where code=%s and id<>%s limit 1;", $datas['code'],$obj->id))){
                            echo WShop_Error::error_custom(__('Coupon code has been used!'))->to_json();
                            exit;
                        }
                        
                        unset($datas['id']);
                        unset($datas['status']);
                        
                        $coupon = new WShop_Coupon($obj->id);
                        if(!$coupon->is_load()){
                            throw new Exception(__('Coupon is not found!',WSHOP));
                        }
                        $result = $coupon->update($datas);
                       
                        $id=$obj->id;
                        if(!WShop_Error::is_valid($result)){
                            throw new Exception($result->to_json());
                        }
                    }else{
                        if($wpdb->get_row($wpdb->prepare("select id from {$wpdb->prefix}wshop_coupon where code=%s limit 1;", $datas['code']))){
                            echo WShop_Error::error_custom(__('Coupon code has been used!'))->to_json();
                            exit;
                        }
                        
                        unset($datas['id']);
                        $datas['status'] = WShop_Coupon::STATUS_PUBLISH;
                        
                        $coupon = new WShop_Coupon($datas);
                        $result = $coupon->insert();
                        if(!WShop_Error::is_valid($result)){
                            throw new Exception($result->to_json());
                        }
                        
                        $id=$coupon->id;
                    }
                } catch (Exception $e) {
                    WShop_Log::error($e);
                    echo WShop_Error::error_custom($e->getMessage())->to_json();
                    exit;
                }
                
                echo WShop_Error::success(array(
                    'id'=>$id
                ))->to_json();
                exit;
            case 'delete':
            case 'restore':
            case 'trash':
                $error =WShop_Coupon_Helper::update_coupon(isset($_REQUEST['id'])?sanitize_key($_REQUEST['id']):null, $datas['tab']);
                echo $error->to_json();
                exit;
        }
    }
}


return WShop_Add_On_Coupon::instance();
?>