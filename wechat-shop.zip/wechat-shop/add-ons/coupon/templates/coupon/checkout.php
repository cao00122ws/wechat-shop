<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
$api = WShop_Add_On_Coupon::instance();
$context = WShop_Temp_Helper::clear('atts','templates');

//表单支付等不含购物车，所以无法使用优惠码

$cart = WShop_Shopping_Cart::get_cart();
if($cart instanceof WShop_Error){
    WShop::instance()->WP->wp_die($cart,false,false);
    return;
}

?>
<div class="xh-title-soft clearfix"><?php echo __('Coupon',WSHOP)?></div>
<div class="block20"></div>

<label><?php echo __('Coupon',WSHOP)?></label>
<ol class="xh-coupons" id="coupon-container-<?php echo $context?>">
<?php 
   if(isset($cart->coupons)&&$cart->coupons){
       foreach ($cart->coupons as $coupon_id=>$code){
           ?><li id="coupon-list-<?php echo $coupon_id?>"><div><code><?php echo esc_html($code)?></code> <a id="btn-coupon-remove-<?php echo $coupon_id?>" href="javascript:void(0);" onclick="window.coupon_<?php echo $context;?>_view.remove_coupon(<?php echo $coupon_id;?>);"><?php echo __('remove',WSHOP)?></a></div></li><?php 
       }
   } 
?>
</ol>
<div class="xh-input-group">
    <input type="text" class="form-control" name="coupon_code" id="coupon_<?php echo $context;?>"/>
    <span class="xh-input-group-btn"><button class="xh-btn xh-btn-default" style="width:96px;" type="button" id="btn_coupon_<?php echo $context;?>" onclick="window.coupon_<?php echo $context;?>_view.apply_coupon();"><?php echo __('Apply',WSHOP)?></button></span>
</div>
 <?php WShop_Coupon::js_settle();?>   
<script type="text/javascript">
		(function($){
			$(document).bind('wshop_form_<?php echo $context;?>_submit',function(e,m){
				m.coupon_code=$('#coupon_<?php echo $context;?>').val();
			});
            <?php $coupons = $api->get_validate_coupons($cart);?>
			window.coupon_<?php echo $context;?>_view={
					__loading:false,
					coupons:<?php echo count($coupons)==0?"[]":json_encode($coupons)?>,
					remove_coupon:function(coupon_id){
						var data ={
							coupon_id:coupon_id
						};
						if(window.coupon_<?php echo $context;?>_view.__loading){
							return;
						}
						
						$.ajax({
							url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'coupon_remove'),true,true)?>',
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:data,
							dataType:'json',
							beforeSend:function(){
								window.coupon_<?php echo $context;?>_view.__loading=true;
								$('#btn-coupon-remove-'+coupon_id).text('<?php echo __('loading...',WSHOP)?>');
							},
							complete:function(){
								window.coupon_<?php echo $context;?>_view.__loading=false;
								$('#btn-coupon-remove-'+coupon_id).text('<?php echo __('remove',WSHOP)?>');
							},
							success:function(e){
								if(e.errcode!=0){
									alert( e.errmsg );
									return;
								}

								var new_coupons = [];
								var coupons = window.coupon_<?php echo $context;?>_view.coupons;
								if(!coupons){coupons=[];}
								for(var i=0;i<coupons.length;i++){
									if(coupons[i].id!=coupon_id){
										new_coupons.push(coupons[i]);
									}
								}
								
								window.coupon_<?php echo $context;?>_view.coupons=new_coupons;
								$('#coupon-list-'+coupon_id).fadeOut();
								$(document).trigger('wshop_<?php echo $context;?>_on_amount_change');
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo __( 'Ajax error while remove coupon', WSHOP); ?>' );
							}
						});
					},
					apply_coupon:function(){
						var data ={
							code:$.trim($('#coupon_<?php echo $context;?>').val())
						};
						
						if(data.code.length==0){return;}

						if(window.coupon_<?php echo $context;?>_view.__loading){
							return;
						}
						
						$.ajax({
							url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'coupon_apply'),true,true)?>',
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:data,
							dataType:'json',
							beforeSend:function(){
								window.coupon_<?php echo $context;?>_view.__loading=true;
								$('#btn_coupon_<?php echo $context;?>').attr('disabled','disabled').text('<?php echo __('Processing...',WSHOP)?>');
							},
							complete:function(){
								window.coupon_<?php echo $context;?>_view.__loading=false;
								$('#btn_coupon_<?php echo $context;?>').removeAttr('disabled').text('<?php echo __('Apply',WSHOP)?>');
							},
							success:function(e){
								if(e.errcode!=0){
									alert( e.errmsg );
									return;
								}

								if(!window.coupon_<?php echo $context;?>_view.coupons){window.coupon_<?php echo $context;?>_view.coupons=[];}
								window.coupon_<?php echo $context;?>_view.coupons.push(e.data);
								$('#coupon-container-<?php echo $context?>').append(
									'<li id="coupon-list-'+e.data.id+'"><div><code>'+e.data.code+'</code> <a id="btn-coupon-remove-'+e.data.id+'" href="javascript:void(0);" onclick="window.coupon_<?php echo $context;?>_view.remove_coupon('+e.data.id+');"><?php echo __('remove',WSHOP)?></a></div></li>'
								);
								$('#coupon_<?php echo $context;?>').val('');
								$(document).trigger('wshop_<?php echo $context;?>_on_amount_change');
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo __( 'Ajax error while apply coupon', WSHOP); ?>' );
							}
						});
					}
			};
			
			$(document).bind('wshop_<?php echo $context;?>_init_amount',function(e,m){
				//wshop_coupon_settle
				var coupons =window.coupon_<?php echo $context;?>_view.coupons;
				if(coupons){
					var discount =0;
					for(var i=0;i<coupons.length;i++){
						discount+=wshop_coupon_settle_discount_amount(coupons[i],m.total_amount);
					}
				}
				
				m.extra_amount.push({
					'title':'<?php echo __('Coupon',WSHOP)?>',
					'amount':-discount
				});
			});    
	
		})(jQuery);
</script>
