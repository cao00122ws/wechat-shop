<?php
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
$data = WShop_Temp_Helper::clear('atts','templates');

$atts = $data['atts'];
$content = $data['content'];

$content = empty($content)?__('Download now',WSHOP):$content;

$post_id = isset($atts['post_id'])?$atts['post_id']:null;
if(!$post_id){return;}

$download = new WShop_Download($post_id);
if(!$download->is_load()){
    return;
}

$downloads = $download->downloads?maybe_unserialize($download->downloads):null;
if(!$downloads||!is_array($downloads)){
    $downloads = array(
        'type'=>'simple',
        'content'=>$download->downloads
    );
}
$download->downloads = $downloads;

$product = new WShop_Product($post_id );
if(!$product->is_load()){
    return;
}

$roles = isset($atts['roles'])?$atts['roles']:null;
$roles = $roles?explode(',', $roles):array();

if(WShop::instance()->payment->is_validate_get_pay_per_view($post_id,$roles)){
   ?><div style="background:#f8f8f8;padding:30px 20px;border:1px dashed #ccc;position: relative;z-index:999;text-align:center;margin:15px 0"><?php
       $downloadTypes = WShop_Add_On_Download::instance()->get_download_types();
       if(isset($downloadTypes[$downloads['type']])){
           $call = $downloadTypes[$downloads['type']]['render'];
           $call($download);
       }
    ?></div><?php
    return;
}

?>
<div style="background:#f8f8f8;padding:50px 20px;border:1px dashed #ccc;position: relative;z-index:999;text-align:center;margin:15px 0">隐藏内容：
<span style="color: red">********<?php

echo WShop::instance()->WP->requires(WSHOP_DIR, 'button-purchase.php',array(
    'content'=>"支付".$product->get_single_price(true),
    'atts'=>$atts
));

?></span>下载<?php

if(!in_array('none', $roles)){
    if(function_exists('wshop_dialog_membership_checkout')){
        ?>，或者<?php
        wshop_dialog_membership_checkout(array(
            'class'=>'xh-btn xh-btn-warning xh-btn-sm',
            'location'=> isset($atts['location'])?$atts['location']:null,
        ),'升级VIP');
        ?>可下载全站内容。<?php
    }
}
?>
<span style="position: absolute;top:15px;left:15px;font-size:90%;color:#90949c;">
  付费下载
</span>
<span style="position: absolute;top:10px;right:10px;"><img style="width:22px;" src="<?php echo WSHOP_URL?>/assets/image/noshow.png" alt=""></span>
</div>
