<?php 
if ( ! defined ( 'ABSPATH' ) ) {
    die();
}

abstract class Abstract_WShop_Menu_Form_Edit{
   
    public function format_toolbar_menu_items( $menu_items, $compact = false ) {
        if ( empty( $menu_items ) ) {
            return '';
        }
    
        $output = '';
    
        $priorities = array();
        foreach ( $menu_items as $k => $menu_item ) {
            $priorities[ $k ] = isset($menu_item['priority'])?$menu_item['priority']:null;
        }
    
        array_multisort( $priorities, SORT_DESC, $menu_items );
    
        $keys     = array_keys( $menu_items );
        $last_key = array_pop( $keys ); // array_pop(array_keys($menu_items)) causes a Strict Standards warning in WP 3.6 on PHP 5.4
    
        foreach ( $menu_items as $key => $menu_item ) {
            if ( is_array( $menu_item ) ) {
                
                $sub_menu_str         = '';
                $count_sub_menu_items = 0;
                $sub_menu_items       = isset($menu_item['sub_menu_items'])?$menu_item['sub_menu_items']:null;
                if ( is_array( $sub_menu_items ) ) {
                    $sub_menu_items       = array_values( $sub_menu_items ); //reset numeric keys
                    $count_sub_menu_items = count( $sub_menu_items );
                }
                
                $menu_class = isset($menu_item['menu_class'])?$menu_item['menu_class']:null;
                
                if ( $count_sub_menu_items == 1 ) {
                    $label     = $compact ? (isset($menu_item['label'])?$menu_item['label']:null ) : (isset($sub_menu_items[0]['label'])?$sub_menu_items[0]['label']:null );
                    $menu_item = $sub_menu_items[0];
                } else {
                    $label        = isset($menu_item['label'])?$menu_item['label']:null;
                    $sub_menu_str =$this->toolbar_sub_menu_items( $sub_menu_items, $compact );
                }
                $link_class = esc_attr(isset($menu_item['link_class'])?$menu_item['link_class']:null);
                $icon       =isset($menu_item['icon'])?$menu_item['icon']:null ;
                $url        = esc_attr( isset($menu_item['url'])?$menu_item['url']:null );
                $title      = esc_attr(isset($menu_item['title'])?$menu_item['title']:null );
                $onclick    = esc_attr( isset($menu_item['onclick'])?$menu_item['onclick']:null);
                $label      = esc_html( $label );
                $target     = isset($menu_item['target'])?$menu_item['target']:null;
                
                $link = "<a class='{$link_class}' onclick='{$onclick}' onkeypress='{$onclick}' title='{$title}' href='{$url}' target='{$target}'>{$icon} {$label}</a>" . $sub_menu_str;
                if ( $compact ) {
                    $divider = $key == $last_key ? '' : ' | ';
                    if ( $count_sub_menu_items > 0 ) {
                        $menu_class .= ' wshop_form_action_has_submenu';
                    }
                    $output .= '<span class="' . $menu_class . '">' . $link . $divider . '</span>';
                } else {
                
                    $output .= "<li class='{$menu_class}'>{$link}</li>";
                }
            } elseif ( $compact ) {
                $divider = $key == $last_key ? '' : ' | ';
                $output .= '<span class="edit">' . $menu_item . $divider . '</span>';
            }
        }
    
        return $output;
    }
    
    public function toolbar_sub_menu_items( $menu_items, $compact = false ) {
        if ( empty( $menu_items ) ) {
            return '';
        }
    
        $sub_menu_items_string = '';
        foreach ( $menu_items as $menu_item ) {
             $menu_class = esc_attr(isset($menu_item['menu_class']) ?$menu_item['menu_class']:null );
                $link_class = esc_attr(isset($menu_item['link_class']) ?$menu_item['link_class']:null );
                $url        = isset($menu_item['url']) ?$menu_item['url']:null;
                $label      = esc_html(isset($menu_item['label']) ?$menu_item['label']:null);
                $target     = esc_attr(isset($menu_item['target']) ?$menu_item['target']:null);
                $sub_menu_items_string .= "<li class='{$menu_class}'><a href='{$url}' class='{$link_class}' target='{$target}'>{$label}</a></li>";
        }
        
        return '<div class="gf_submenu"><ul>' . $sub_menu_items_string . '</ul></div>';
    }
  
} 
?>