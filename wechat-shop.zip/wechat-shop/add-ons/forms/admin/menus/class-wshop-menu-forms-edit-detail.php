<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

require_once 'abstract-wshop-menu-form-edit.php';

class WShop_Forms_Edit_Detail extends Abstract_WShop_Menu_Form_Edit {
    /**
     * 
     * @var WShop_Form
     */
    private $form;
    
    public function __construct($form_id=0){
        $this->form= new WShop_Form($form_id); 
        if(!$this->form->is_load()){
            WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
            return;
        }
    }
   
	public function view() {
	    $wform = $this->form;
		global $wpdb;
		$api =WShop_Add_On_Modal_Forms_Payment::instance();
        ?>
       
        <script type="text/javascript">
			(function($){
				window.wshop_editor={
					is_processing:false,
					_form:<?php echo json_encode($wform);?>,
					id_body:'#wpbody',
					get_fields:function(){
						return this._form?this._form.fields:null;
					},
					get_field:function(field_id){
						var fields = this.get_fields();
						if(!fields){
							return null;
						}

						for(var i=0;i<fields.length;i++){
							if(fields[i].id==field_id){
								return fields[i];
							}
						}

						return null;
					},
					_last_msg_time:0,
					warning:function(msg){
						this._last_msg_time=(new Date()).getTime();
						$('#form-msg')
						.removeClass()
						.addClass(' notice notice-warning  is-dismissible')
						.html('<p>'+msg+'</p><button type="button" onclick="window.wshop_editor.hide_msg();" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button>')
						.show();

						setTimeout(function(){
							if((new Date()).getTime()>=(window.wshop_editor._last_msg_time+1500)){
								window.wshop_editor.hide_msg();
							}
							
						},1500);
					},
					error:function(msg){
						this._last_msg_time=(new Date()).getTime();
						$('#form-msg')
						.removeClass()
						.addClass('notice notice-error  is-dismissible')
						.html('<p>'+msg+'</p><button type="button" onclick="window.wshop_editor.hide_msg();" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button>')
						.show();
						setTimeout(function(){
							if((new Date()).getTime()>=(window.wshop_editor._last_msg_time+1500)){
								window.wshop_editor.hide_msg();
							}
							
						},1500);
					},
					success:function(msg){
						this._last_msg_time=(new Date()).getTime();
						$('#form-msg')
						.removeClass()
						.addClass('notice notice-success is-dismissible')
						.html('<p>'+msg+'</p><button type="button" onclick="window.wshop_editor.hide_msg();" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button>')
						.show();
						setTimeout(function(){
							if((new Date()).getTime()>=(window.wshop_editor._last_msg_time+1500)){
								window.wshop_editor.hide_msg();
							}
							
						},1500);
					},
					hide_msg:function(){
						$('#form-msg').hide(200);
					},
					loading:{
						show:function(){
							$('#form-container').loading();
						},
						hide:function(){
							$('#form-container').loading('hide');
						}
					},
					submit:function(){
						this.field.load_settings();
						var price = parseFloat($.trim($('#wform_price').val()));
						this._form.title = $.trim($('#wform_title').val());
						this._form.description = $.trim($('#wform_description').val());
						this._form.price =isNaN(price)||price<=0?0:price ;
						if(window.wshop_editor.is_processing){
							return;
						}

						window.wshop_editor.is_processing=true;
						$('#btn-form-submit').attr('disabled','disabled').val('<?php echo esc_attr('Loading...')?>');
						$.ajax({
							url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'save_or_update_form'),true,true)?>',
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:{
								form:JSON.stringify(this._form)
							},
							dataType:'json',
							complete:function(){
								window.wshop_editor.is_processing=false;
								$('#btn-form-submit').removeAttr('disabled','disabled').val('<?php echo esc_attr('Submit')?>');
							},
							success:function(e){
								if(e.errcode!=0){
									window.wshop_editor.warning(e.errmsg);
									return;
								}
								
								window.wshop_editor.success('<?php echo esc_attr('The form info was modified successfully!',WSHOP)?>');
							},
							error:function(e){
								console.error(e.responseText);
								window.wshop_editor.error('<?php echo esc_attr( 'System error while modifing form!', WSHOP); ?>');
							}
						});
					},
					field:{
						//正在拖拽的field	
						field_dragging:0,

						//field id
						id_field:'.field_type input',
						load_settings:function(){
							var fields = window.wshop_editor.get_fields();
							if(!fields){
								return;
							}

							var new_fields = [];
							for(var i=0;i<fields.length;i++){
								var field = fields[i];
								var $field =$('#field_'+field.id);
								if($field.length==0){
									continue;
								}
								
								field.sort = $field.prevAll().length;
								$(document).trigger('wshop_form_field_'+field.id+'_submit', field);
								new_fields.push(field);;
							}

							window.wshop_editor._form.fields=new_fields;
							return window.wshop_editor._form.fields.sort(function(l,r){return l.sort>r.sort;});
					    },
						init:function(){
							this.load_settings();
							//声明：类型队列可以拖拽到form fields中
							$(this.id_field).draggable({
								//允许draggable被拖拽到指定的sortables中，如果使用此选项helper属性必须设置成clone才能正常工作。
						        connectToSortable: window.wshop_editor.form.id_container,
						        //拖拽元素时的显示方式。（如果是函数，必须返回值是一个DOM元素）可选值：'original', 'clone', Function  
						        helper: function(){
									return jQuery(this).clone(true);
								},
								//当元素拖拽结束后，元素回到原来的位置。   
						        revert: 'invalid',
						        //防止在指定的对象上开始拖动
						        cancel: false,
						        //The element passed to or selected by the appendTo option will be used as the draggable helper's container during dragging. By default, the helper is appended to the same container as the draggable.  
						        appendTo: window.wshop_editor.id_body,
						        //强制draggable只允许在指定元素或区域的范围内移动，可选值：'parent', 'document', 'window', [x1, y1, x2, y2].   
						        containment: 'document',
						        //当鼠标开始拖拽时，触发此事件。
						        start: function(event, ui){
							        //避免在ajax新增field时，用户操作其他field
									if(window.wshop_editor.is_processing){
										return false;
									}

									return true;
						        }
						    });
						},
						copy:function(field_id){
							this.load_settings();
							var field =window.wshop_editor.get_field(field_id);
							if(!field){
								return;
							}

							var index = $('#field_'+field_id).prevAll().length;
							this.add(field,index+1);
						},
						Delete:function(field_id){
							// Confirm that user is aware about entry data being deleted.
							if ( ! confirm( "<?php echo __( "Warning! Deleting this field will also delete all entry data associated with it. 'Cancel' to stop. 'OK' to delete", WSHOP );?>" ) ) {
								return;
							}

							if(window.wshop_editor._form&&window.wshop_editor._form.fields){
								for ( var i = 0; i < window.wshop_editor._form.fields.length; i++ ) {
									if ( window.wshop_editor._form.fields[i].id == field_id ) {
										window.wshop_editor._form.fields.splice(i, 1);
										$( '#field_' + field_id ).fadeOut( 'slow', function() {
											$(this).remove();
										});
										
										break;
									}
								}
							}
						},
						add:function(field_obj,index){
							if(window.wshop_editor.is_processing){
								return;
							}

							window.wshop_editor.is_processing=true;
							window.wshop_editor.loading.show();
							$.ajax({
								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'add_field'),true,true)?>',
								type:'post',
								timeout:60*1000,
								async:true,
								cache:false,
								data:{
									field:JSON.stringify(field_obj)
								},
								dataType:'json',
								complete:function(){
									window.wshop_editor.is_processing=false;
									window.wshop_editor.loading.hide();
								},
								success:function(e){
									if(e.errcode!=0){
										window.wshop_editor.warning(e.errmsg);
										return;
									}

									var field = e.data.field;
									var field_html = e.data.html;
									
									if(!window.wshop_editor._form.fields){
										window.wshop_editor._form.fields=[];
									}
									window.wshop_editor._form.fields.splice(index, 0, field);
									if(index===0){
							            $(window.wshop_editor.form.id_container).prepend(field_html);
							        } else {
							            $(window.wshop_editor.form.id_container).children().eq(index - 1).after(field_html);
							        }
									
								    window.wshop_editor.field.on_field_load(field.id);

								},
								error:function(e){
									console.error(e.responseText);
									window.wshop_editor.error(<?php echo json_encode( esc_html__( 'Ajax error while adding field', WSHOP) ); ?>);
								}
							});
						},
						on_field_load:function(field_id){
							 $("#field_" + field_id).animate(
							    { backgroundColor: '#FFFBCC' }, 
							    'fast', 
							    function(){
								    $(this).animate(
										{backgroundColor: '#FFF'}, 
										'fast', 
										function(){ $(this).css('background-color', '');}
									)
								}
							)
						  	.hover(
						      function () {
                                  var $this =$(this);
                                  if($this.attr('data-editing')){
                                  	return;
                                  } 
                                  if(!$this.hasClass('wshop_field_hover')){
                                  	$this.addClass("wshop_field_hover");
                                  }
						      },
						      function () {
                                  var $this =$(this);
                                  if($this.attr('data-editing')){
                                  	return;
                                  } 
                                  
                                  if($this.hasClass('wshop_field_hover')){
                                  	$this.removeClass("wshop_field_hover");
                                  }
						      }
						    );

							$(".wshop-tips").tipTip({
								attribute: "title",
								defaultPosition:'top'
							});
						},
						on_setting:function(field_id){
							var $field_document = $('#field_'+field_id);
							if($field_document.length<=0){
								return;
							}
							$('.selectable.wshop_field_hover').not('#field_'+field_id).each(function(){
								var $this = $(this);
								$this.removeAttr('data-editing').removeClass("wshop_field_hover");
								$('#wshop_field_settings_'+$this.attr('data-id')).slideUp(200);
							});
							
							if(!$field_document.hasClass('wshop_field_hover')){
								$field_document.addClass("wshop_field_hover");
							}
							
							if($field_document.attr('data-editing')){
								//close editing
								$field_document.removeAttr('data-editing');
								$('#wshop_field_settings_'+field_id).slideUp(200);
							}else{
								$field_document.attr('data-editing',true);
								$('#wshop_field_settings_'+field_id).slideDown(200);
							}
						}
					},
					form:{
						//ID:表单fields容器
						id_container:'#wshop_forms_fields',
						//ID:表单设置
						id_settings:'#wshop_field_settings',

						//排序时，允许拖拽的把柄
						id_sortable_handler:'.wshop_field_admin_icons',
						//正在拖拽的element id
						id_field_dragging:0,
						
						init:function(){
							//声明：form fields 可排序
							$(this.id_container).sortable({
								/*
								阻止排序动作在匹配的元素上发生
								阻止field排序发生在field settings 表单中
								*/
						        cancel: this.id_settings,
						        //限制排序的动作只能在item元素中的某个元素开始。
						        handle: this.id_sortable_handler,
						        
						        start: function(event, ui){
							        if(window.wshop_editor.field.id_field_dragging >0){
										return false;
								    }
								    
						            window.wshop_editor.field.id_field_dragging = ui.item[0].id;
						            return true;
						        },
								tolerance: "pointer",
						        over: function( event, ui ) {
						            if(ui.helper.hasClass('ui-draggable-dragging')){
						                ui.helper.data('original_width', ui.helper.width())
						                ui.helper.data('original_height', ui.helper.height())
						                ui.helper.width(ui.sender.width()-25);
						                ui.helper.height(ui.placeholder.height());
						            } else {
						                var h = ui.helper.height();
						                if(h > 300){
						                    h = 300;
						                }
						                ui.placeholder.height(h);
						            }
						        },
						        out: function( event, ui ) {
						            if(ui.helper && ui.helper.hasClass('ui-draggable-dragging')){
						                ui.helper.width(ui.helper.data('original_width'));
						                ui.helper.height(ui.helper.data('original_height'));
						            }
						        },
						        placeholder: "field-drop-zone",
						        beforeStop: function( event, ui ) {
						            $( window.wshop_editor.form.id_container).height('100%');

						            var type = ui.helper.data('type');
						            if(typeof type == 'undefined'){
							            //只是简单排序
						                return;
						            }
						            
						            var index=ui.item.index();
						            ui.item.remove();
						            
						            window.wshop_editor.field.add({
										sort:index,
										field_type:type,
										form_id:window.wshop_editor._form.id
							        },index);
						        },
						        //当排序动作结束时且元素坐标已经发生改变时触发此事件。
						        update:function(event, ui){
							        //标记结束
						        	window.wshop_editor.field.id_field_dragging=0;
							    }
						    });
						}
					},
					init:function(){
						this.form.init();
						this.field.init();
					}
				};

				$(function(){
					window.wshop_editor.init();
					$('#btn-form-submit').click(function(){
						window.wshop_editor.submit();
					});
				});


				function initMenus() {
					jQuery('ul.menu ul').hide();
					jQuery.each(jQuery('ul.menu'), function(){
						jQuery('#' + this.id + '.expandfirst ul:first').show();
					});
					jQuery('ul.menu li .button-title-link').click(
						function() {
							var checkElement = jQuery(this).next();
							var parent = this.parentNode.parentNode.id;

							if(jQuery('#' + parent).hasClass('noaccordion')) {
								jQuery(this).next().slideToggle('normal');
								return false;
							}
							if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
								if(jQuery('#' + parent).hasClass('collapsible')) {
									jQuery('#' + parent + ' ul:visible').slideUp('normal', function(){jQuery(this).prev().removeClass('gf_button_title_active')});
								}
								return false;
							}
							if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
								jQuery('#' + parent + ' ul:visible').slideUp('normal', function(){jQuery(this).prev().removeClass('gf_button_title_active')});
								checkElement.slideDown('normal', function(){jQuery(this).prev().addClass('gf_button_title_active')});
								return false;
							}
						}
					);
				}
				jQuery(document).ready(function() {initMenus();});
				jQuery(document).ready(function() {	
					jQuery('div.wshop-add-buttons-title').append('<span class="wshop-add-buttons-caret-down"><i class="fa fa-caret-down"></i></span>');
				});

			})(jQuery);
		</script>
		<div id="form-msg" style="display:none;"></div>
		<div class="wrap wshop_forms_edit_form ">
		<h1>
			<span><?php echo esc_html( $wform->title ); ?></span>
			<span class="gf_admin_page_formid">ID: <?php echo $wform->id; ?></span>
		</h1>
		
		<div class="wshop_form_toolbar">
			<ul class="wshop_form_toolbar_links">
			<li>
				<a class="form-boolbar-item gf_toolbar_active" href="#form-content-0"><i class="fa fa-pencil-square-o fa-lg"></i> 基本</a>
			</li>
			
			<li>
				<a class="form-boolbar-item" href="#form-content-1"><i class="fa fa-bars fa-lg"></i> 表单</a>
			</li>
			
			<li>
				<a href="javascript:void(0);" target="_blank"><i class="fa fa-eye fa-lg"></i> 预览</a>
			</li>	
			</ul>
			
			<span style="float:right;margin-top:10px;">
				<input type="button" id="btn-form-submit" class="button button-large button-primary update-form" value="<?php echo esc_attr('Submit')?>"/>
			</span>	
		</div>
		<script type="text/javascript">
			(function($){
				$('.form-boolbar-item').click(function(){
					$('.form-boolbar-item.gf_toolbar_active').removeClass('gf_toolbar_active');
					$('.form-boolbar-content').hide();
					$(this).addClass('gf_toolbar_active');
					$($(this).attr('href')).show();
					return false;
				});
			})(jQuery);
		</script>
		<div id="form-content-0" class="form-boolbar-content">
			<table class="form-table">
			    <tbody>
			    <tr valign="top" class="">
                	<th scope="row" class="titledesc">
                		<label for="wform_title"><?php echo __('Title',WSHOP)?></label>
        			</th>
                	<td class="forminp">
                		<fieldset>
                			<legend class="screen-reader-text">
                				<span><?php echo __('Title',WSHOP)?></span>
                			</legend>
                			<input class="input-text regular-input " type="text" name="wform_title" id="wform_title" style="min-width:400px;" value="<?php echo esc_attr($wform->title)?>" placeholder="">
        				</fieldset>
                	</td>
                </tr>
                
                <tr valign="top" class="">
                	<th scope="row" class="titledesc">
                		<label for="wform_description"><?php echo __('Description',WSHOP)?></label>
        			</th>
                	<td class="forminp">
                		<fieldset>
                			<legend class="screen-reader-text">
                				<span><?php echo __('Description',WSHOP)?></span>
                			</legend>
                			<textarea class="input-text regular-input " name="wform_description" id="wform_description" style="min-width:400px;" rows="3" placeholder=""><?php echo esc_textarea($wform->description)?></textarea>
        				</fieldset>
                	</td>
                </tr>
                
                <tr valign="top" class="">
                	<th scope="row" class="titledesc">
                		<label for="wform_price"><?php echo __('Price',WSHOP)?></label>
        			</th>
                	<td class="forminp">
                		<fieldset>
                			<legend class="screen-reader-text">
                				<span><?php echo __('Price',WSHOP)?></span>
                			</legend>
                			<input class="input-text regular-input " type="text" name="wform_price" id="wform_price" style="min-width:400px;" value="<?php echo esc_attr($wform->price)?>" placeholder="">
        				</fieldset>
                	</td>
                </tr>
                
    			</tbody>
    		</table>
		</div>
		
		<div id="form-content-1" style="display:none;" class="form-boolbar-content">
			<table style="width:100%;"  >
        		<tr>
        		<td class="pad_top" valign="top" style="width:100%;" id="form-container">
        	
        		<ul id="wshop_forms_fields" class="wshop_forms_fields top_label form_sublabel_below description_below ui-sortable" style="position: relative;">
        			<?php 
        			$wform->to_editable();
        			?>
        		</ul>
        		</td>
        		<td valign="top" align="right">
        			<div id="add_fields">
        				<div id="floatMenu">
        
        					<!-- begin add button boxes -->
        					<ul id="sidebarmenu1" class="menu collapsible expandfirst">
        
        						<?php
        						$fields = $api->get_fields();
        						$groups = $api->get_groups();
        						$index =0;
        						foreach ($groups as $key=>$settings){
        						    ?>
        						    <li id="add_<?php echo esc_attr( $key ) ?>" class="add_field_button_container">
        								<div class="button-title-link <?php echo ($index++==0) ? 'gf_button_title_active' : '' ?>">
        									<div class="wshop-add-buttons-title"><?php echo esc_html( $settings['title'] ); ?></div>
        								</div>
        								<ul>
        									<li class="wshop-add-buttons">
        										<ol class="field_type">
        											<?php 
        											foreach ($fields as $field){
        											    if($field->get_group()==$key){
        											        ?>
        											        <li>
        											      	<input type="button" class="button ui-draggable ui-draggable-handle" data-type="<?php echo esc_attr($field->field_type)?>" value="<?php echo esc_attr($field->get_field_title())?>" />
        											        </li><?php 
        											    }
        											}?>
        										</ol>
        									</li>
        								</ul>
        							</li>
        						    <?php 
        						}
        						?>
        					</ul>
        					
        				</div>
        			</div>
        		</td>
        		</tr>
        		</table>
			</div>
		</div>

		<?php
	}

	
	
}
