<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}
require_once 'abstract-wshop-menu-form-edit.php';
class WShop_Forms_Edit_List extends Abstract_WShop_Menu_Form_Edit {

	public function view() {
		global $wpdb;
		$api = WShop_Add_On_Modal_Forms_Payment::instance();
		?>
		
		<style type="text/css">
			body div#TB_window[style] {
				width: 405px !important;
				height: 340px !important;
				margin-left: -202px !important;
			}

			body #TB_ajaxContent {
				height: 480px !important;
				overflow: hidden;
			}

			
		</style>

		<div id="gf_new_form_modal" style="display:none;">
			<div class="wshop_dialog_new_form">

				<div class="setting-row">
					<label for="new_form_title"><?php esc_html_e( 'Form Title', WSHOP ); ?>
						<span class="wshop_field_required">*</span></label><br />
					<input type="text" class="regular-text" value="" id="new_form_title" tabindex="9000">
				</div>

				<div class="setting-row">
					<label for="new_form_description"><?php esc_html_e( 'Form Description', WSHOP ); ?></label><br />
					<textarea class="regular-text" id="new_form_description" tabindex="9001"></textarea>
				</div>
				
				<div class="setting-row">
					<label for="new_form_title"><?php esc_html_e( 'Price', WSHOP ); ?>
						<span class="wshop_field_required">*</span></label><br />
					<input type="text" class="regular-text" value="" id="new_form_price" tabindex="9002">
				</div>
				
				<div class="submit-row">
					<input type="button" class="button button-large button-primary" onclick="window.wshop_list.submit();" value="<?php echo esc_html__( 'Create Form', WSHOP );?>" id="btn-form-create" tabindex="9002" />
					<div id="gf_new_form_error_message" style="display:inline-block;"></div>
				</div>

			</div>
		</div>
		
		<div class="wrap">
		<h2>
			<?php esc_html_e( 'Forms', WSHOP );?>
			<a class="add-new-h2" href="javascript:void(0);" onclick="window.wshop_list.open_modal_add_form();"><?php echo esc_html__( 'Add New', WSHOP )?> </a>
		</h2>

		<?php

		$table = new WShop_Forms_Edit_List_Table($this);
		$table->process_action();
		$table->views();
		$table->prepare_items();
		?>
		<form class="wshop-list" method="get">
    		<input type="hidden" value="<?php echo WShop_Admin::instance()->get_current_page()->get_page_id()?>" name="page" />
    		<input type="hidden" value="<?php echo WShop_Admin::instance()->get_current_menu()->id?>" name="section" />
    		<input type="hidden" value="<?php echo WShop_Admin::instance()->get_current_submenu()->id?>" name="tab" />
    		<input type="hidden" value="<?php echo esc_attr( isset($_REQUEST['status'])?$_REQUEST['status']:null);?>" name="status" />
    		<div class="wshop-list">
    		<?php $table->display(); ?>
    		</div>
		</form>
		<script type="text/javascript">
			(function($){
					window.wshop_list={
						items:<?php echo empty($table->items)?"[]":json_encode($table->items)?>,	
						get_form:function(form_id){
							if(!this.items){
								return null;
							}

							for(var i=0;i<this.items.length;i++){
								if(this.items[i].id==form_id){
									return this.items[i];
								}
							}

							return null;
						},		
						open_modal_add_form:function(){
							$('#new_form_title,#new_form_description,#new_form_price').val('');
							$('#gf_new_form_error_message').empty();

							tb_show(<?php echo json_encode( esc_html__( 'Create a New Form', WSHOP ) ); ?>, '#TB_inline?width=375&amp;inlineId=gf_new_form_modal');
						},
						is_processing:false,
						submit:function(){
							var price =parseFloat($.trim($('#new_form_price').val()));
							var form={
								title:$.trim($('#new_form_title').val()),
								description:$.trim($('#new_form_description').val()),
								price:isNaN(price)||price<=0?0:price
							};
							
							$('#gf_new_form_error_message').empty();
							if(window.wshop_list.is_processing){
								return;
							}
							
							window.wshop_list.is_processing=true;
							$('#btn-form-create').attr('disabled','disabled').val('<?php echo __( 'Loading...', WSHOP );?>');
							$.ajax({
								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'save_or_update_form'),true,true)?>',
								type:'post',
								timeout:60*1000,
								async:true,
								cache:false,
								data:{
									form:JSON.stringify(form)
								},
								dataType:'json',
								complete:function(){
									window.wshop_list.is_processing=false;
									$('#btn-form-create').removeAttr('disabled').val('<?php echo __( 'Create Form', WSHOP );?>');
								},
								success:function(e){
									if(e.errcode!=0){
										$('#gf_new_form_error_message').html( e.errmsg );
										return;
									}

									$('#btn-form-create').attr('disabled','disabled').val(<?php echo json_encode( esc_html__( 'Saved! Redirecting...', WSHOP ) ); ?>);
									location.reload();
								},
								error:function(e){
									console.error(e.responseText);
									$('#gf_new_form_error_message').html(<?php echo json_encode( esc_html__( 'Ajax error while adding form', WSHOP) ); ?>);
								}
							});
						},
						__update_form_status:function(form_id,new_status,callback){
							var form = this.get_form(form_id);
							if(!form){
								return;
							}

							$.ajax({
								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'update_form_status'),true,true)?>',
								type:'post',
								timeout:60*1000,
								async:true,
								cache:false,
								data:{
									form_id:form.id,
									new_status:new_status
								},
								dataType:'json',
								success:function(e){
									if(e.errcode!=0){
										alert( e.errmsg );
										location.reload();
										return;
									}

									callback(form,new_status);
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo  esc_html__( 'Ajax error while changing form', WSHOP); ?>');
									location.reload();
								}
							});
						},
						toggle_active:function(form_id){
							var form = this.get_form(form_id);
							if(!form){
								return;
							}
							var new_status ='A';
							if(form.status=='I'||form.status=='A'){
								new_status='P';
							}else{
								new_status='A';
							}

							form.status=new_status;
							if(new_status=='P'){
								$('#form-btn-active-'+form_id).attr('src','<?php echo $api->domain_url?>/assets/images/active1.png')
							}else{
								$('#form-btn-active-'+form_id).attr('src','<?php echo $api->domain_url?>/assets/images/active0.png')
							}
							
							this.__update_form_status(form_id,form.status,function(form,new_status){
								
							});
						},
						restore:function(form_id){
							var form = this.get_form(form_id);
							if(!form){
								return;
							}

							form.status='A';
							$('#form-tr-'+form.id).hide(200);
							
							this.__update_form_status(form_id,form.status,function(form,new_status){
								
							});
						},
						_delete:function(form_id){
							var form = this.get_form(form_id);
							if(!form){
								return;
							}

							form.status='I';
							$('#form-tr-'+form.id).hide(200);
							
							this.__update_form_status(form_id,form.status,function(form,new_status){
								
							});
						},
						copy:function(form_id){
							var form = this.get_form(form_id);
							if(!form){
								return;
							}

							if(window.wshop_list.is_processing){
								return;
							}
							
							window.wshop_list.is_processing=true;
							jQuery('#the-list').loading();
							$.ajax({
								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'copy_form'),true,true)?>',
								type:'post',
								timeout:60*1000,
								async:true,
								cache:false,
								data:{
									form_id:form.id
								},
								dataType:'json',
								complete:function(){
									window.wshop_list.is_processing=false;
									jQuery('#the-list').loading('hide')
								},
								success:function(e){
									if(e.errcode!=0){
										alert( e.errmsg );
										return;
									}

									location.reload();
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo  esc_html__( 'Ajax error while copying form', WSHOP); ?>');
								}
							});
						},
						remove:function(form_id){
							var form = this.get_form(form_id);
							if(!form){
								return;
							}
							
							$('#form-tr-'+form.id).hide(200);
							
							$.ajax({
								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'remove_form'),true,true)?>',
								type:'post',
								timeout:60*1000,
								async:true,
								cache:false,
								data:{
									form_id:form.id
								},
								dataType:'json',
								success:function(e){
									if(e.errcode!=0){
										alert( e.errmsg );
										location.reload();
										return;
									}
								},
								error:function(e){
									console.error(e.responseText);
									alert('<?php echo  esc_html__( 'Ajax error while removing form', WSHOP); ?>');
									location.reload();
								}
							});
						}
					};
			})(jQuery);
		</script>
		</div>
	<?php
	}
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class WShop_Forms_Edit_List_Table extends WP_List_Table {

	public $status = null;

	/**
	 * 
	 * @var WShop_Forms_Edit_List
	 */
	public $api;

	public function __construct($api, $args = array() ) {
	    $this->api = $api;
	    
		parent::__construct( $args );
		$columns               = $this->get_columns();
		$hidden                = array();
		$sortable              = $this->get_sortable_columns();
		$this->_column_headers = array( $columns, $hidden, $sortable,'title');
	
		$this->status          = isset($_REQUEST['status'])?$_REQUEST['status']:null;
	}

	function get_sortable_columns() {
		return array(
			'id'    => array( 'id', false )
		);
	}
	function display_tablenav( $which ) {
	    if ( 'top' === $which ) {
	        wp_nonce_field( 'bulk-' . $this->_args['plural'] );
	    }
	    ?>
    	<div class="tablenav <?php echo esc_attr( $which ); ?>">
    
    		<?php if ( $this->has_items() ): ?>
    		<div class="alignleft actions bulkactions">
    			<?php $this->bulk_actions( $which ); ?>
    		</div>
    		<?php endif;
    		$this->extra_tablenav( $which );
    		$this->pagination( $which );
            ?>
    
    		<br class="clear" />
    	</div>
    	<?php
    }
    
	public function search_box( $text, $input_id ) {
	    if ( empty( $_REQUEST['s'] ) && !$this->has_items() )
	        return;
	
        $input_id = $input_id . '-search-input';

        if ( ! empty( $_REQUEST['orderby'] ) )
            echo '<input type="hidden" name="orderby" value="' . esc_attr( $_REQUEST['orderby'] ) . '" />';
        if ( ! empty( $_REQUEST['order'] ) )
            echo '<input type="hidden" name="order" value="' . esc_attr( $_REQUEST['order'] ) . '" />';
        if ( ! empty( $_REQUEST['post_mime_type'] ) )
            echo '<input type="hidden" name="post_mime_type" value="' . esc_attr( $_REQUEST['post_mime_type'] ) . '" />';
        if ( ! empty( $_REQUEST['detached'] ) )
            echo '<input type="hidden" name="detached" value="' . esc_attr( $_REQUEST['detached'] ) . '" />';
        ?>
    	<p class="search-box">
    		<label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php echo $text; ?>:</label>
    		<input type="search" id="<?php echo esc_attr( $input_id ); ?>" name="s" value="<?php _admin_search_query(); ?>" placeholder="<?php echo esc_attr(__('title',WSHOP))?>" />
    		<?php submit_button( $text, '', '', false, array( 'id' => 'search-submit' ) ); ?>
    	</p>
    	<?php
	}
	function get_views() {
	    global $wpdb;
	    $result =$wpdb->get_row(
	        "select  sum(if(f.`status`='I',0,1)) as total,
	                 sum(if(f.`status`='A',1,0)) as inactive,
            		 sum(if(f.`status`='P',1,0)) as active,
            		 sum(if(f.`status`='I',1,0)) as trash
	        from `{$wpdb->prefix}wshop_form` f;");
	    
	    $form_count= array(
	        'total'    => array(
	            'title'=>__('All',WSHOP),
	            'count'=>intval( $result->total )
	        ),
	        'A' => array(
	            'title'=>__('Inactive',WSHOP),
	            'count'=>intval( $result->inactive )
	        ),
	        'P'    => array(
	            'title'=>__('Active',WSHOP),
	            'count'=>intval( $result->active )
	        ),
	        'I'    => array(
	            'title'=>__('Trash',WSHOP),
	            'count'=>intval( $result->trash )
	        )
	    );
	    
	    $current =null;
	    $index=0;
	    foreach ($form_count as $key=>$val){
	        if($index++==0){
	            $current=$key;
	        }
	    
	        if($this->status&&$this->status==$key){
	            $current=$key;
	            break;
	        }
	    }
	    
	    $page_now = WShop_Admin::instance()->get_current_admin_url();
	    $views=array();
	    foreach ($form_count as $key=>$data){
	        $now = $current==$key?"current":"";
	        $views[$key] ="<a class=\"{$now}\" href=\"{$page_now}&status={$key}\">{$data['title']} <span class=\"count\">(<span>{$data['count']}</span>)</span></a>";
	    }
	     
	    return $views;
	}

	function prepare_items() {

		$sort_column  = empty( $_REQUEST['orderby'] ) ? 'id' : $_REQUEST['orderby'];
		$sort_columns = array_keys( $this->get_sortable_columns() );

		if ( ! in_array( strtolower( $sort_column ), $sort_columns ) ) {
			$sort_column = 'id';
		}
       
		$sort = isset($_REQUEST['order']) ? $_REQUEST['order']:null;
		if(!in_array($sort, array('asc','desc'))){
		    $sort ='asc';
		}
		
		$keywords   = isset($_REQUEST['s'])?mb_strimwidth(urldecode($_REQUEST['s']), 0, 16,'','utf-8'):null;
		$keywords=str_replace('%', '', $keywords);
	
		if(!in_array($this->status, array('A','P','I'))){
		    $this->status=null;
		}
		global $wpdb;
		$status =empty($this->status)?" and f.status<>'I'":" and f.status='{$this->status}'";
		
		$query = $wpdb->get_row(
		    $wpdb->prepare("select count(f.id) as qty
		    from `{$wpdb->prefix}wshop_form` f 
		    where (%s='' or f.title like %s)
		          $status ;"
			    , $keywords,"%$keywords%")
		);
		
		$total = intval($query->qty);
		$per_page = 20;
		if($per_page<=0){$per_page=20;}
		$total_page = intval(ceil($total/($per_page*1.0)));
		$this->set_pagination_args( array(
		   	'total_items' => $total,
			'total_pages' => $total_page,
			'per_page' => $per_page,
		    's'=>$keywords,
		    'status'=>$this->status,
		    'page'=>WShop_Admin::instance()->get_current_page()->get_page_id(),
		    'section'=>WShop_Admin::instance()->get_current_menu()->id,
		    'tab'=>WShop_Admin::instance()->get_current_submenu()->id,
		) );
		
		$pageIndex =$this->get_pagenum();
		$start = ($pageIndex-1)*$per_page;
		$end = $per_page;
		
		$this->items = $wpdb->get_results(
		    $wpdb->prepare(
		   "select f.*
		    from `{$wpdb->prefix}wshop_form` f
		    where (%s='' or f.title like %s)
		          $status 
		    order by f.$sort_column $sort
		    limit $start,$end;", $keywords,"%$keywords%"));
	}

	function get_bulk_actions() {
		if ( $this->status == 'I' ) {
			return array(
				'restore' => esc_html__( 'Restore', WSHOP ),
				'delete' => esc_html__( 'Delete permanently', WSHOP ),
			);
		}
		
		return array(
		    'trash' => esc_html__( 'Move to trash', WSHOP ),
			'activate' => esc_html__( 'Mark as Active', WSHOP ),
			'deactivate' => esc_html__( 'Mark as Inactive', WSHOP )
		);
	}

	function get_columns() {
		return array(
			'cb'         => '<input type="checkbox" />',
			'is_active'  => '',
			'title'      => esc_html__( 'Title', WSHOP ),
			'id'         => esc_html__( 'ID', WSHOP ),
		    //'short_code' => esc_html__('Short Code',WSHOP)
		);
	}

	public function single_row( $item ) {
	    echo '<tr id="form-tr-'.$item->id .'">';
	    $this->single_row_columns( $item );
	    echo '</tr>';
	}
	
	function single_row_columns( $item ) {
		list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();

		foreach ( $columns as $column_name => $column_display_name ) {
			$classes = "$column_name column-$column_name";
			if ( $primary === $column_name ) {
				$classes .= ' has-row-actions column-primary';
			}

			if ( in_array( $column_name, $hidden ) ) {
				$classes .= ' hidden';
			}

			// Comments column uses HTML in the display name with screen reader text.
			// Instead of using esc_attr(), we strip tags to get closer to a user-friendly string.
			$data = 'data-colname="' . wp_strip_all_tags( $column_display_name ) . '"';

			$attributes = "class='$classes' $data";

			if ( 'cb' === $column_name ) {
				echo '<th scope="row" class="check-column">';
				echo $this->column_cb( $item );
				echo '</th>';
			}  elseif ( method_exists( $this, '_column_' . $column_name ) ) {
				echo call_user_func(
					array( $this, '_column_' . $column_name ),
					$item,
					$classes,
					$data,
					$primary
				);
			} elseif ( method_exists( $this, 'column_' . $column_name ) ) {
				echo "<td $attributes>";
				echo call_user_func( array( $this, 'column_' . $column_name ), $item );
				echo $this->handle_row_actions( $item, $column_name, $primary );
				echo "</td>";
			} else {
				echo "<td $attributes>";
				echo $this->column_default( $item, $column_name );
				echo $this->handle_row_actions( $item, $column_name, $primary );
				echo "</td>";
			}
		}
	}


	function get_primary_column_name() {
		return 'title';
	}

	function _column_is_active( $form, $classes, $data, $primary ) {
		echo '<th scope="row" class="manage-column column-is_active">';
		if ( $this->status !== 'I' ) {
			?>
			<img id="form-btn-active-<?php echo esc_attr($form->id)?>" class="wshop_active_toggle_icon" src="<?php echo esc_url(WShop_Add_On_Modal_Forms_Payment::instance()->domain_url) ?>/assets/images/active<?php echo intval( $form->status=='P'?1:0 ) ?>.png" style="cursor: pointer;"  onclick="window.wshop_list.toggle_active(<?php echo absint( $form->id ); ?>); " />
			<?php
		}
		echo '</th>';
	}

	function column_title( $form ) {
	    $page_now =WShop_Admin::instance()->get_current_admin_url();
		echo '<strong><a href="'.$page_now.'&id='. absint( $form->id ) .'">' . esc_html( $form->title ) . '</a></strong>';
	}

	function column_id( $form ) {
	    $page_now =WShop_Admin::instance()->get_current_admin_url();
		echo '<a href="'.$page_now.'&id='. absint( $form->id ) .'">' .absint( $form->id ) . '</a>';
	}
	
// 	function column_short_code( $form ) {
// 	    echo '<code>[wshop_form form_id="'.$form->id.'"]</code>';
// 	}
	
	function column_cb( $form ) {
		$form_id = $form->id;
		?>
		<label class="screen-reader-text" for="cb-select-<?php echo esc_attr( $form_id ); ?>"><?php _e( 'Select form' ); ?></label>
		<input type="checkbox" class="wshop_list_checkbox" name="form[]" value="<?php echo esc_attr( $form_id ); ?>" />
		<?php
	}

	protected function handle_row_actions( $form, $column_name, $primary ) {

		if ( $primary !== $column_name ) {
			return '';
		}

		?>
		<div class="row-actions">
			<?php
			$api =WShop_Add_On_Modal_Forms_Payment::instance();
			if ( $this->status == 'I' ) {
				$form_actions['restore'] = array(
					'label'        => __( 'Restore', WSHOP ),
					'title'        => __( 'Restore', WSHOP ),
					'url'          => 'javascript:void(0);',
					'onclick'      => 'window.wshop_list.restore(' . absint( $form->id ) . ');',
					'priority'     => 600,
				);
				$form_actions['delete']  = array(
					'label'        => __( 'Delete permanently', WSHOP ),
					'title'        => __( 'Delete permanently', WSHOP ),
					'menu_class'   => 'delete',
					'url'          => 'javascript:void(0);',
					'onclick'      => 'window.wshop_list.remove(' . absint( $form->id ) . ');',
					'priority'     => 500,
				);

			} else {
			    $page_now =WShop_Admin::instance()->get_current_admin_url();
				$form_actions['edit'] = array(
                    'label'        => __( 'Edit', WSHOP ),
                    'short_label'  => esc_html__( 'Editor', WSHOP ),
                    'icon'         => '<i class="fa fa-pencil-square-o fa-lg"></i>',
                    'title'        => __( 'Edit this form', WSHOP ),
                    'url'          => $page_now."&id={$form->id}",
                    'menu_class'   => 'wshop_form_toolbar_editor',
                    'link_class'   => '',
                    'capabilities' => array('administrator'),
                    'priority'     => 1000,
                );
            
                // ---- Preview ----
				
                $form_actions['preview'] = array(
                    'label'        => __( 'Preview', WSHOP ),
                    'icon'         => '<i class="fa fa-eye fa-lg"></i>',
                    'title'        => __( 'Preview this form', WSHOP ),
                    'url'          => WShop::instance()->ajax_url(array(
                                        'action'=>"wshop_{$api->id}",
                                        'tab'=>'preview'
                                    ),true,true)."&id={$form->id}",
                                    
                    'menu_class'   => 'wshop_form_toolbar_preview',
                    'link_class'   => '',
                    'target'       => '_blank',
                    'capabilities' => array('administrator'),
                    'priority'     => 700,
                );

				$form_actions['duplicate'] = array(
					'label'        => __( 'Duplicate', WSHOP ),
					'title'        => __( 'Duplicate this form', WSHOP ),
					'url'          => 'javascript:void(0);',
					'onclick'      => 'window.wshop_list.copy(' . absint( $form->id ) . ');',
					'priority'     => 600,
				);

				$form_actions['trash'] = array(
					'label'        => __( 'Trash', WSHOP ),
					'title'        => __( 'Move this form to the trash', WSHOP ),
					'url'          => 'javascript:void(0);',
					'onclick'      => 'window.wshop_list._delete(' . absint( $form->id ) . ');',
					'menu_class'   => 'trash',
					'priority'     => 500,
				);

			}

			echo $this->api->format_toolbar_menu_items( $form_actions, true );

			?>

		</div>
		<?php
		return '';
	}

	function no_items() {
		printf( __( "You don't have any forms!", WSHOP ) );
	}

	function process_action() {
	    $bulk_action = $this->current_action();
	    if(empty($bulk_action)){
	        return;
	    }
	    
	    check_admin_referer( 'bulk-' . $this->_args['plural'] );
	    
	    $form_ids   = isset($_POST['form'])?$_POST['form']:null;;
	    if(!$form_ids||!is_array($form_ids)){
	        return;
	    }
	    $forms = array();
	    foreach ($form_ids as $form_id){
	        $form = new WShop_Form($form_id);
	        if(!$form->is_load()){
	            ?><div class="notice notice-error  is-dismissible"><p><?php echo WShop_Error::err_code(404)->errmsg;?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
			    return;
			}
			
			$forms[]=$form;
	    }
	    
	    try {
	        switch ( $bulk_action ) {
	            case 'trash' :
                    foreach ($forms as $form){
                        $form->status='I';
                        $form->save_or_update();
                    }
                    ?><div class="notice notice-success  is-dismissible"><p><?php echo __('Form moved to the trash!',WSHOP);?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
    				return;
    			case 'restore' :
    			     foreach ($forms as $form){
    			         $form->status='P';
    			         $form->save_or_update();
    			     }
    				?><div class="notice notice-success  is-dismissible"><p><?php echo __('Form restored!',WSHOP);?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
    				return;
                case 'delete':
    			case 'delete_entries' :
    			     foreach ($forms as $form){
    			         $form->remove();
    			     }
    				
    				?><div class="notice notice-success  is-dismissible"><p><?php echo __('Form deleted!',WSHOP);?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
    				return;
    			case 'deactivate' :
    			     foreach ($forms as $form){ 
    			         $form->status='A';
    				     $form->save_or_update();
    			     }
    				?><div class="notice notice-success  is-dismissible"><p><?php echo __('Form deactivated!',WSHOP);?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
    				return;
				case 'activate' :
				    foreach ($forms as $form){
				        $form->status='P';
				        $form->save_or_update();
				    }
				    ?><div class="notice notice-success  is-dismissible"><p><?php echo __('Form activated!',WSHOP);?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
				 return;
                default:
                    ?><div class="notice notice-error  is-dismissible"><p><?php echo WShop_Error::error_unknow()->errmsg;?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
                return;
    		}
	    } catch (Exception $e) {
	        ?><div class="notice notice-error  is-dismissible"><p><?php echo $e->getMessage();?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
	    }
	}

}
