<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
   
class WShop_Menu_Forms_Edit_Page extends Abstract_WShop_Settings_Page{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='add_ons_page_form_edit';
        $this->title=__('Forms',WSHOP);
    }
    
    /* (non-PHPdoc)
     * @see Abstract_WShop_Settings_Menu::menus()
     */
    public function menus(){
        return apply_filters("wshop_admin_page_{$this->id}",array(
            WShop_Menu_Forms_Edit::instance()
        ));
    }
}

/**
 * @since 1.0.0
 * @author ranj
 */
class WShop_Menu_Forms_Edit extends Abstract_WShop_Settings_Menu{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='add_ons_menu_form_edit';
        $this->title=__('Forms',WSHOP);
    }

    /* (non-PHPdoc)
     * @see Abstract_WShop_Settings_Menu::menus()
     */
    public function menus(){
        return apply_filters("wshop_admin_menu_{$this->id}", array(
            WShop_Menu_Forms_Edit_Settings::instance()
        ));
    }
}
    
class WShop_Menu_Forms_Edit_Settings extends Abstract_WShop_Settings {
    /**
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    private function __construct(){
        $this->id='add_ons_modal_forms_edit_settings';
        $this->title=__('Forms',WSHOP);
    }

    public function admin_form_start(){}
     
    public function admin_options(){
        $id   = isset($_GET['id'])?$_GET['id']:null; 
     
        if ( is_numeric( $id ) ) {
            require_once 'class-wshop-menu-forms-edit-detail.php';
            $api = new WShop_Forms_Edit_Detail($id);
    		$api->view();
        } else {
            require_once 'class-wshop-menu-forms-edit-list.php';
            $api = new WShop_Forms_Edit_List();
		    $api->view();
        }
	}
	
    public function admin_form_end(){} 
}


?>