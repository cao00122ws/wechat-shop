<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class Abstract_WShop_Add_Ons_Forms_Api extends Abstract_WShop_Add_Ons{
    public $u;
    public $i;
    public $k;
    protected function __construct(){
        $o = $this;
        $o->u = WSHOP_URL;
        $o->i = WShop_Install::instance()->get_plugin_options();
        $o->k=WShop::$license_id;
    }
    /**
     * 执行 on_load()
     */
    public function m1(){
        $o=$this;
        $o->m0(function($o){
            WShop_Async::instance()->async('wshop_form', array($o,'wshop_form'));
            add_filter('wshop_admin_menu_menu_default_modal',array($o,'wshop_admin_menu_menu_default_modal'),10,1);
            add_filter('wshop_checkout_options_2', array($o,'wshop_checkout_options_2'),10,1);
            add_filter('wshop_online_post_types', array($o,'wshop_online_post_types'),10,1);
            //add_filter('wshop_create_order_form', array($o,'wshop_create_order_form'),10,3);
            add_action('wshop_checkout_cart', array($o,'wshop_checkout_cart'),1,2);
            add_action('wshop_purchase_modal_shopping_cart_create_order', array($o,'create_order_checkout'),20,1);            
         
            add_action('wshop_order_email_sections', array($o,'wshop_order_email_sections'),10,1);
            add_filter('wshop_order_complete_payment_args', array($o,'wshop_order_complete_payment_args'),10,3);
            
            add_action('wshop_checkout_tab_form', array($o,'wshop_checkout_tab_form'),10,1);
        },function($o){
        });   
    }
    
    /**
     * 执行 on_init()
     */
    public function m2(){
        $o=$this;
        $o->m0(function($o){
            add_action('admin_init',array($o,'admin_init'),10);
            add_filter('wshop_order_view_admin_order_detail_order_data_column', array($o,'order_view_admin_order_detail_data_column'),10,1);
            add_action('wshop_order_items_view_checkout_order_recieved_sections', array($o,'checkout_order_recieved_sections'),10,1);
       
            if(is_admin()){
                $o->register_scripts();
                add_action( 'admin_enqueue_scripts', array($o, 'enqueue_admin_scripts' ) );
                add_action('restrict_manage_posts', array($o,'restrict_manage_posts'),10,2);
                add_action( 'pre_get_posts', array( $o, 'pre_get_posts' ) ,10,1);
                add_filter('posts_join', array($o,'posts_join'),10,2);
                add_filter('wp_count_posts', array($o,'wp_count_posts'),10,3);
                add_filter('views_edit-wshop_forms_entry', array($o,'views_edit_wshop_forms_entry'),10,1);
            }
        
            $o->setting_uris=array();
            $o->setting_uris['settings']=array();
            $o->setting_uris['license']=array();
            $o->setting_uris['settings']['title']=__('Settings',WSHOP);
            $o->setting_uris['settings']['url']=admin_url('admin.php?page=wshop_page_default&section=menu_default_modal&sub=wshop_add_ons_form');
            
            $api = WShop_Install::instance();
            $o->setting_uris['license']['title']=__('Change license',WSHOP);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);            
           
        },function($o){
            $o->setting_uris=array();
            $o->setting_uris['license']=array();
           
            $api = WShop_Install::instance();
            $o->setting_uris['license']['title']=__('License',WSHOP);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);
        });
    }

    public function m0($func_success,$func_fail){
	    $o = $this;
	    $website=$o->u;
	    $website = strtolower($website);
	    $license_id = $o->id;
	    if(strpos($website, 'http://')===0){
	        $website = substr($website, 7);
	    }else if(strpos($website, 'https://')===0){
	        $website = substr($website, 8);
	    }
	   
	    //去掉二级目录
	    if(strpos($website, '/')!==false){
	        $websites = explode('/', $website);
	        $website = $websites[0];
	    }
	    $prewebsite =$website;
	    $info = $o->i;
	    $license =$info&&isset($info[$o->id])?$info[$o->id]:null;
	    $licenses= $license?explode('=', $license):array();
	    $license =count($licenses)>0?$licenses[0]:null;
	    $expire=count($licenses)>1?$licenses[1]:null;
	    
        $id=$o->id;
	    $bk=0;
	    while (true){
	        $str =$expire."|".$website."|".$id; 
	        $str =md5($str);
	        $b =0;
	        for ($i=0;$i<strlen($str);$i++){
	            $b+= ord($str[$i]);
	        }
	     
	        $xx=md5($str.$b)==$license;
	        $o->ia=$xx;
	        if($xx){
	            if($func_success){
	                $func_success($o);
	            }
	            break;
	        }
    
            if(substr_count($website,'.')<=1){ 
                if($bk<count($o->k)){
                    $website=$prewebsite;
                    $license =$info&&isset($info['license'])?$info['license']:null;
                    $licenses= $license?explode('=', $license):array();
                    $license =count($licenses)>0?$licenses[0]:null;
                    $expire=count($licenses)>1?$licenses[1]:null;
                    $id = $o->k[$bk++];
                    continue;
                }
                
                if($func_fail){
                    $func_fail($o);
                }
                break;
            }
    
            $index = strpos($website, '.');
            $website = substr($website, $index+1);
	    } 
	}
}