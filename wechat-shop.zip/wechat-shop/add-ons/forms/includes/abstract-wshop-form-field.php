<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

abstract class Abstract_WShop_Form_Field{
    public $id;
    /**
     * 表单ID
     * @var int
     */
    public $form_id;

    /**
     * 字段类型
     * @var string
     */
    public $field_type;
    
    /**
     * 排序
     * @var int
     */
    public $sort;
    
    /**
     * 附加属性
     * @var object
     */
    public $metas=null;

    /**
     * @param array|object $obj
     */
    public function __construct($obj=null)
    {
        if($obj&&is_object($obj)){
            $obj = get_object_vars($obj);
        }
       
        if($obj&&is_array($obj)){
            foreach ( $obj as $key => $value ){
                $this->{$key} = maybe_unserialize($value);
            }
        }
        
        if(is_array($this->metas)){
            $this->metas = (object)$this->metas;
        }
    }
   public function is_load(){return true;}
    /**
     * 获取html label
     * @return string
     * @since 1.0.0
     */
    public function get_input_label(){
        return isset($this->metas->label)?$this->metas->label:__('No Title',WSHOP);
    }
    
    /**
     * 获取input name
     * @return string
     * @since 1.0.0
     */
    public function get_input_name(){
        if(isset($this->metas->html_id)&&!empty($this->metas->html_id)){
            return $this->metas->html_id;
        }
        
        return "field_{$this->id}";
    }

    /**
     *
     * @param string $context 当前表单回话
     */
    public function get_input_id($context){
        if(!$this->form_id){
            throw new Exception('unknow form id');
        }
        if(isset($this->metas->html_id)&&!empty($this->metas->html_id)){
            return "field_{$context}_{$this->metas->html_id}";
        }
        return "field_{$context}_{$this->form_id}_{$this->id}";
    }
    
    /**
     * 获取field 名称
     * @return string
     * @since 1.0.0
     */
    abstract function get_field_title();
    
    /**
     * @return string  standard|advanced|...
     * @since 1.0.0
     */
    public function get_group()
    {
        return 'standard';
    }
 
    /**
     * 编辑模式 html
     * @return NULL|string
     * @since 1.0.0
     */
    public function to_editable(){
        return WShop::instance()->WP->requires(
            WShop_Add_On_Modal_Forms_Payment::instance()->domain_dir,
            "form/fields/{$this->field_type}/editable.php",
            array(
                'field'=>$this
            ));
    }
 
    /**
     * 验证并绑定表单数据
     * @param Abstract_WShop_Order $order
     * @since 1.0.0
     */
    public function validate_field($func_insert_data=null){     
        $input_name =$this->get_input_name();
        $label =$this->get_input_label();
        $data = isset($_REQUEST[$input_name])?stripslashes($_REQUEST[$input_name]):null;
        if(isset($this->metas->required)&&$this->metas->required&&empty($data)){
            return WShop_Error::error_custom(sprintf(__("%s is required!",WSHOP),$label));
        }
    
        $error = apply_filters("wshop_form_validate_{$input_name}", WShop_Error::success(),$data,$this);
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        $error = call_user_func_array($func_insert_data,array($this,$data));
        if(!WShop_Error::is_valid($error)){ 
           return $error;
        }
        return array(
            'label'=>$label,
            'val'=>$data,
            'hidden'=>isset($this->metas->hidden_in_entry)?$this->metas->hidden_in_entry:false
        );
    }
   
   
    /**
     * 获取输出html
     * @param string $context 当前表单会话ID
     * @return NULL|string
     * @since 1.0.0
     */
    public function to_html($context,$func_get_data=null){
       
        return WShop::instance()->WP->requires(
            WShop_Add_On_Modal_Forms_Payment::instance()->domain_dir,
            "form/fields/{$this->field_type}/html.php",
            array(
                'field'=>$this,
                'context'=>$context,
                'val'=>call_user_func_array($func_get_data,array($this,isset($this->metas->default)?$this->metas->default:null))
            ));
    }
}
?>