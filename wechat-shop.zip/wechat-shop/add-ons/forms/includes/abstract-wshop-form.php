<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

abstract class Abstract_WShop_Form{
    /**
     * ID
     * @var int
     */
    public $id;

    /**
     * 判断是否成功加载实体
     * @return boolean
     */
    public function is_load(){
        return $this->id>0;
    }
}
?>