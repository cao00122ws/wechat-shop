<?php 


class WShop_Forms_Entry extends WShop_Post_Object{ 
    const POST_T ='wshop_forms_entry';
    public $form_id;
    public $fields=array();
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_forms_entry';
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return array(
            'post_ID'=>0,
            'form_id'=>0,
            'order_id'=>null,
            'fields'=>array()
        );
    }
    
    public function get_form(){
        if(!$this->is_load()){
            return null;
        }
        
        return new WShop_Forms($this->form_id);
    }
    
    public function get_fields(){
        if(!$this->fields||!is_array($this->fields)){
            $this->fields = array();
        }
        
        return $this->fields;
    }
    
}

class WShop_Forms_Entry_Model extends Abstract_WShop_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        global $wpdb;
        $collate=$this->get_collate();
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_forms_entry` (
            	`post_ID` INT(11) NOT NULL,
            	`form_id` INT(11) NOT NULL,
            	`order_id` INT(11) NULL DEFAULT NULL,
            	`fields` TEXT NULL DEFAULT NULL,
            	PRIMARY KEY (`post_ID`)
            )
            $collate");
    
        if(!empty($wpdb->last_error)){
            throw new Exception($wpdb->last_error);
        }
    }
}

class WShop_Forms_Entry_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Forms_Enrty_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="form_entry";
        $this->title = __('Form entry',WSHOP);
        
        foreach ($this->get_post_types() as $post_type=>$label){
            add_filter( "manage_{$post_type}_posts_columns", array($this,'manage_posts_columns'),11 ,1);
            add_action( "manage_{$post_type}_posts_custom_column", array( $this, 'manage_posts_custom_column' ),11, 2 );
        }
    }
    
    public function manage_posts_columns($existing_columns){
        global $current_wshop_form,$wpdb;
        if(!$current_wshop_form){
            return $existing_columns;
        }
        $current_wshop_form = new WShop_Forms($current_wshop_form->ID);
        if(!$current_wshop_form->is_load()){
            return $existing_columns;
        }
        
        $fields = $current_wshop_form->get_fields();
        if(!$fields||count($fields)==0){
            return $existing_columns;
        }
        
        $new_existing_columns=array();
        foreach ($existing_columns as $key=>$title){
            $new_existing_columns[$key]=$title;
            if($key=='title'){
                foreach ($fields as $field){
                    if($field->field_type=='subtitle'){
                        continue;
                    }
                    $new_existing_columns['OID']=__('Order ID',WSHOP);
                    if(!isset($field->metas->hidden_in_entry)||!$field->metas->hidden_in_entry)
                    $new_existing_columns[$field->get_input_name()] = $field->get_input_label();
                }
            }
        }
        
        return apply_filters('wshop_form_entry_columns', $new_existing_columns,$current_wshop_form);
    }
    
    public function manage_posts_custom_column($column,$post_ID){
        global $wp_query;
        global $current_wshop_entry;
        if(!$current_wshop_entry||$current_wshop_entry->post_ID!=$post_ID){
            $current_wshop_entry = new WShop_Forms_Entry($post_ID);
        }
        
        if(!$current_wshop_entry->is_load()){
            return;
        }
        
        $html = apply_filters('wshop_form_entry_columns_html',false,$column, $current_wshop_entry);
        if($html){
            echo $html;
            return;
        }
        
       if($column=='OID'){
           echo $current_wshop_entry->get('order_id');
           return;
       }
       
        $fields = $current_wshop_entry->get_fields();
        if(!$fields||count($fields)==0||!isset($fields[$column]['val'])){
            return;
        }
        
        echo $fields[$column]['val'];
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
     public function init_form_fields(){
        global $post;
        $this->form_fields = apply_filters('wshop_forms_entry_fields', array(
            'fields'=>array(
                'title'=>__('Fields',WSHOP),
                'type'=>'custom',
                'func'=>function( $key,$field_api,$data){
                    global $post;
                    $entry = new WShop_Forms_Entry($post);
                    if(!$entry->is_load()){
                        return;
                    }
                    
                    ?>
                    </table>
                  	<table class="form-table">
        				<?php 
        				$form = new WShop_Forms($entry->form_id);
        				if($form->is_load()){
        				    $entryfields = $entry->get_fields();
        				    foreach ($form->get_fields() as $field){
        				        if($field->field_type=='subtitle'){continue;}
        				        $entry = $entryfields&&isset($entryfields[$field->metas->html_id])?$entryfields[$field->metas->html_id]:null;
        				        
        				        ?>
            				    <tr valign="top" class="">
                                	<th scope="row" class="titledesc">
                                		<label for="wshop_settings_default_basic_default_exchange_rate"><?php echo $entry?$entry['label']:$field->get_input_label()?></label>
                        			</th>
                                	<td class="forminp">
                                		<fieldset>
                                			<legend class="screen-reader-text">
                                				<span><?php echo $entry?$entry['label']:$field->get_input_label()?></span>
                                			</legend>
                                			<input class="input-text regular-input " type="text"value="<?php echo esc_attr($entry?$entry['val']:"")?>" name="<?php echo "_entry_field_{$field->metas->html_id}"?>" style="min-width:400px;" />
                        				</fieldset>
                                	</td>
                                </tr>
            				    <?php 
        				    }
        				}
        				?>
        			</table>
        			<table class="form-table">
                    <?php 
                }
            )
        ),$post);
    }

    public function get_post_types()
    {
        return array(
            WShop_Forms_Entry::POST_T=>__('Form entry',WSHOP)
        );
    }

    /**
     * 
     * @return WShop_Forms_Entry
     */
    public function get_object($post){
        return new WShop_Forms_Entry($post->ID);
    }

    public function process_object_update($post){
        global $wpdb;
        $product =$this->get_object($post);
        if(!$product){
            return WShop_Error::success();
        }
        
        $form = $product->get_form();
        if($form&&$form->is_load()){
            foreach ($form->get_fields() as $field){
                if(isset($_POST["_entry_field_{$field->metas->html_id}"])){
                    $val = stripslashes($_POST["_entry_field_{$field->metas->html_id}"]);
                    
                    if(!isset($product->fields[$field->metas->html_id])){
                        $product->fields[$field->metas->html_id]['val'] =$val;
                        $product->fields[$field->metas->html_id]['label'] =$field->get_input_label();
                    }else{
                        $product->fields[$field->metas->html_id]['val'] =$val;
                    }
                }
            }
        }
        
        $error =  $product->update(array(
            'fields'=>$product->fields
        ));
    
        $error = apply_filters('wshop_process_object_update', $error,$product);
        return apply_filters("wshop_{$post->post_type}_process_object_update", $error,$product);
    }
}
?>