<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class WShop_Forms extends WShop_Post_Object{ 
    const POST_T ='wshop_forms';
    public $fields = array();
    
    public function __construct($obj=null){
        parent::__construct($obj);
        $this->rebuild_fields();
    }
   
    public function to_html($context,$func_get_data=null){
        if(!$func_get_data){
            $func_get_data = function($field,$default=null){
                if(!$field instanceof Abstract_WShop_Form_Field){
                    return $default;
                }
        
                if(!is_user_logged_in()){
                    return $default;
                }
        
                if('yes'!=WShop_Add_On_Modal_Forms_Payment::instance()->get_option('remember_data')){
                    return $default;
                }
                
                return get_user_meta(get_current_user_id(),"xh_form_{$field->get_input_name()}",true);
            };
        }
        
        foreach ($this->get_fields() as $field){
            echo $field->to_html($context,$func_get_data);
        }
    }
    
    public function validate_field($func_insert_data=null){
        if(!$func_insert_data){
            $func_insert_data = function($field,$val=null){
                if(!$field instanceof Abstract_WShop_Form_Field){
                    return WShop_Error::err_code(500);
                }
        
                if(!is_user_logged_in()){
                    return WShop_Error::success();
                }
           
                update_user_meta(get_current_user_id(),"xh_form_{$field->get_input_name()}",$val);
                
                return WShop_Error::success();
            };
        }
      
        $results = array();
        foreach ($this->get_fields() as $field){
            $val = $field->validate_field($func_insert_data);

            if($val===false){
                continue;
            }
            
            if($val instanceof WShop_Error&&!WShop_Error::is_valid($val)){
                return $val;
            }
        
            $results[]=array(
                'field'=>$field,
                'val'=>$val
            );
        }
        $error = apply_filters("wshop_form_validate", WShop_Error::success(),$results,$this);
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        return $results;
    }
    
    /**
     * @return Abstract_WShop_Form_Field[]
     */
    public function get_fields(){
        if(!$this->fields||!is_array($this->fields)){$this->fields=array();}
        return $this->fields;
    }
    
    private function rebuild_fields(){
        //rebuild fields
        $fields = $this->get_fields();
        
        $_fields=array();
        if($fields){
            foreach ($fields as $field){
                if(is_object($field)){
                    $field_type = $field->field_type;
                }else if(is_array($field)){
                    $field_type = $field['field_type'];
                }

                if(!isset($field_type)||empty($field_type)){
                    continue;
                }
    
                $class = self::get_field_class($field_type);
                if(!class_exists($class)){
                    continue;
                }
                $field =new $class($field);
                
                $field->form_id = $this->post_ID;
                $_fields[$field->sort]=$field;
            }
        }
        
        ksort($_fields);
        reset($_fields);
        $this->fields =$_fields;
    }
  
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_forms';
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_forms_properties', array(
            'post_ID'=>0,
            'fields'=>array()
        ));
    }
    
    public function to_editable(){
       $fields = $this->get_fields();
        foreach ($fields as $field){
            echo $field->to_editable();
        }
    }
    
    /**
     * @return Abstract_WShop_Form_Field[]
     * @since 1.0.0
     */
    public static function get_all_fields(){
        require_once 'fields/class-wshop-form-field-password.php';
        require_once 'fields/class-wshop-form-field-text.php';
        require_once 'fields/class-wshop-form-field-textarea.php';
        require_once 'fields/class-wshop-form-field-subtitle.php';
        require_once 'fields/class-wshop-form-field-checkbox.php';
        require_once 'fields/class-wshop-form-field-hidden.php';
        require_once 'fields/class-wshop-form-field-email.php';
        require_once 'fields/class-wshop-form-field-radio.php';
        require_once 'fields/class-wshop-form-field-select.php';
        require_once 'fields/class-wshop-form-field-image.php';
        
        $fields = array(
            new WShop_Form_Field_Text(),
            new WShop_Form_Field_Password(),
            new WShop_Form_Field_Textarea(),
            new WShop_Form_Field_Subtitle(),
            new WShop_Form_Field_Checkbox(),
            new WShop_Form_Field_Hidden(),
            new WShop_Form_Field_Email(),
            new WShop_Form_Field_Radio(),
            new WShop_Form_Field_Select(),
            new WShop_Form_Field_Image()
        );
        
        return apply_filters('wshop_form_fields', $fields);
    }
    
    /**
     * @return array
     * @since 1.0.0
     */
    public static function get_all_groups(){
        return apply_filters('wshop_form_groups', array(
            'standard'=>array(
                'title'=>__( 'Standard Fields', WSHOP ),
                'description'=>''
            ),
            'advanced'=>array(
                'title'=>__( 'Advanced Fields', WSHOP ),
                'description'=>''
            )
        ));
    }

    /**
     * 获取class
     * @param string $type
     * @return string class name
     * @since 1.0.0
     */
    public static function get_field_class($field_type){
        foreach (self::get_all_fields() as $obj){
            if($obj->field_type==$field_type){
                return get_class($obj);
            }
        }
    
        return null;
    }
    
}

class WShop_Forms_Product extends WShop_Post_Object{
    const POST_T ='wshop_forms_product';
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_forms_product';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_forms_product_properties', array(
            'post_ID'=>0,
            'form_id'=>null
        ));
    }
}

class WShop_Forms_Model extends Abstract_WShop_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        global $wpdb;
        $collate=$this->get_collate();
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_forms` (
            	`post_ID` INT(11) NOT NULL,
            	`fields` TEXT NULL DEFAULT NULL,
            	PRIMARY KEY (`post_ID`)
            )
            $collate");
    
        if(!empty($wpdb->last_error)){
            throw new Exception($wpdb->last_error);
        }
        
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_forms_product` (
                `post_ID` INT(11) NOT NULL,
                `form_id` INT(11) NULL DEFAULT NULL,
                PRIMARY KEY (`post_ID`)
            )
            $collate");
        
        if(!empty($wpdb->last_error)){
            throw new Exception($wpdb->last_error);
        }   
    }
}

class WShop_Forms_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Forms_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="form";
        $this->title = __('Form',WSHOP);
    }
   
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
    public function init_form_fields(){
        global $post;
        $this->form_fields = apply_filters('wshop_forms_fields', array(
            'fields'=>array(
                'title'=>__('Fields',WSHOP),
                'type'=>'custom',
                'func'=>function( $key,$field_api,$data){

                    $api = WShop_Add_On_Modal_Forms_Payment::instance();
                    $field = $field_api ->get_field_key($key);
                    global $post;
                    $form = new WShop_Forms($post);
                    if(!$form->is_load()){
                        $form ->post_ID=$post->ID;
                    }
                    ?>
                  	</table>
                  	<input type="hidden" name="<?php echo $field?>" id="<?php echo $field?>"/>
                  	<script type="text/javascript">
            			(function($){
            				window.xh_form_editor={
            					is_processing:false,
            					_form:<?php echo json_encode($form);?>,
            					id_body:'#wpbody',
            					get_fields:function(){
            						return this._form?this._form.fields:null;
            					},
            					get_field:function(field_id){
            						var fields = this.get_fields();
            						if(!fields){
            							return null;
            						}
            
            						for(var i=0;i<fields.length;i++){
            							if(fields[i].id==field_id){
            								return fields[i];
            							}
            						}
            
            						return null;
            					},
            					_last_msg_time:0,
            					warning:function(msg){
            						this._last_msg_time=(new Date()).getTime();
            						$('#form-msg')
            						.removeClass()
            						.addClass(' notice notice-warning  is-dismissible')
            						.html('<p>'+msg+'</p><button type="button" onclick="window.xh_form_editor.hide_msg();" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button>')
            						.show();
            
            						setTimeout(function(){
            							if((new Date()).getTime()>=(window.xh_form_editor._last_msg_time+1500)){
            								window.xh_form_editor.hide_msg();
            							}
            							
            						},1500);
            					},
            					error:function(msg){
            						this._last_msg_time=(new Date()).getTime();
            						$('#form-msg')
            						.removeClass()
            						.addClass('notice notice-error  is-dismissible')
            						.html('<p>'+msg+'</p><button type="button" onclick="window.xh_form_editor.hide_msg();" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button>')
            						.show();
            						setTimeout(function(){
            							if((new Date()).getTime()>=(window.xh_form_editor._last_msg_time+1500)){
            								window.xh_form_editor.hide_msg();
            							}
            							
            						},1500);
            					},
            					success:function(msg){
            						this._last_msg_time=(new Date()).getTime();
            						$('#form-msg')
            						.removeClass()
            						.addClass('notice notice-success is-dismissible')
            						.html('<p>'+msg+'</p><button type="button" onclick="window.xh_form_editor.hide_msg();" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button>')
            						.show();
            						setTimeout(function(){
            							if((new Date()).getTime()>=(window.xh_form_editor._last_msg_time+1500)){
            								window.xh_form_editor.hide_msg();
            							}
            							
            						},1500);
            					},
            					hide_msg:function(){
            						$('#form-msg').hide(200);
            					},
            					loading:{
            						show:function(){
            							$('#form-container').loading();
            						},
            						hide:function(){
            							$('#form-container').loading('hide');
            						}
            					},
            					submit:function(){
            						this.field.load_settings();
            						$('#<?php echo $field?>').val(JSON.stringify(this._form.fields));
            					},
            					field:{
            						//正在拖拽的field	
            						field_dragging:0,
            
            						//field id
            						id_field:'.field_type input',
            						load_settings:function(){
            							var fields = window.xh_form_editor.get_fields();
            							if(!fields){
            								return;
            							}
            
            							var new_fields = [];
            							for(var i=0;i<fields.length;i++){
            								var field = fields[i];
            								var $field =$('#field_'+field.id);
            								if($field.length==0){
            									continue;
            								}
            								
            								field.sort = $field.prevAll().length;
            								$(document).trigger('wshop_form_field_'+field.id+'_submit', field);
            								new_fields.push(field);;
            							}
            
            							window.xh_form_editor._form.fields=new_fields;
            							return window.xh_form_editor._form.fields.sort(function(l,r){return l.sort>r.sort;});
            					    },
            						init:function(){
            							this.load_settings();
            							//声明：类型队列可以拖拽到form fields中
            							$(this.id_field).draggable({
            								//允许draggable被拖拽到指定的sortables中，如果使用此选项helper属性必须设置成clone才能正常工作。
            						        connectToSortable: window.xh_form_editor.form.id_container,
            						        //拖拽元素时的显示方式。（如果是函数，必须返回值是一个DOM元素）可选值：'original', 'clone', Function  
            						        helper: function(){
            									return jQuery(this).clone(true);
            								},
            								//当元素拖拽结束后，元素回到原来的位置。   
            						        revert: 'invalid',
            						        //防止在指定的对象上开始拖动
            						        cancel: false,
            						        //The element passed to or selected by the appendTo option will be used as the draggable helper's container during dragging. By default, the helper is appended to the same container as the draggable.  
            						        appendTo: window.xh_form_editor.id_body,
            						        //强制draggable只允许在指定元素或区域的范围内移动，可选值：'parent', 'document', 'window', [x1, y1, x2, y2].   
            						        containment: 'document',
            						        //当鼠标开始拖拽时，触发此事件。
            						        start: function(event, ui){
            							        //避免在ajax新增field时，用户操作其他field
            									if(window.xh_form_editor.is_processing){
            										return false;
            									}
            
            									return true;
            						        }
            						    });
            						},
            						copy:function(field_id){
            							this.load_settings();
            							var field =window.xh_form_editor.get_field(field_id);
            							if(!field){
            								return;
            							}
            
            							var index = $('#field_'+field_id).prevAll().length;
            							this.add(field,index+1);
            						},
            						Delete:function(field_id){
            							// Confirm that user is aware about entry data being deleted.
            							if ( ! confirm( "<?php echo __( "Warning! Deleting this field will also delete all entry data associated with it. 'Cancel' to stop. 'OK' to delete", WSHOP );?>" ) ) {
            								return;
            							}
            
            							if(window.xh_form_editor._form&&window.xh_form_editor._form.fields){
            								for ( var i = 0; i < window.xh_form_editor._form.fields.length; i++ ) {
            									if ( window.xh_form_editor._form.fields[i].id == field_id ) {
            										window.xh_form_editor._form.fields.splice(i, 1);
            										$( '#field_' + field_id ).fadeOut( 'slow', function() {
            											$(this).remove();
            										});
            										
            										break;
            									}
            								}
            							}
            						},
            						add:function(field_obj,index){
            							if(window.xh_form_editor.is_processing){
            								return;
            							}
            
            							window.xh_form_editor.is_processing=true;
            							window.xh_form_editor.loading.show();
            							$.ajax({
            								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'add_field'),true,true)?>',
            								type:'post',
            								timeout:60*1000,
            								async:true,
            								cache:false,
            								data:{
            									field:JSON.stringify(field_obj)
            								},
            								dataType:'json',
            								complete:function(){
            									window.xh_form_editor.is_processing=false;
            									window.xh_form_editor.loading.hide();
            								},
            								success:function(e){
            									if(e.errcode!=0){
            										window.xh_form_editor.warning(e.errmsg);
            										return;
            									}
            
            									var field = e.data.field;
            									var field_html = e.data.html;
            									
            									if(!window.xh_form_editor._form.fields){
            										window.xh_form_editor._form.fields=[];
            									}
            									window.xh_form_editor._form.fields.splice(index, 0, field);
            									if(index===0){
            							            $(window.xh_form_editor.form.id_container).prepend(field_html);
            							        } else {
            							            $(window.xh_form_editor.form.id_container).children().eq(index - 1).after(field_html);
            							        }
            									
            								    window.xh_form_editor.field.on_field_load(field.id);
            
            								},
            								error:function(e){
            									console.error(e.responseText);
            									window.xh_form_editor.error(<?php echo json_encode( esc_html__( 'Ajax error while adding field', WSHOP) ); ?>);
            								}
            							});
            						},
            						on_field_load:function(field_id){
            							 $("#field_" + field_id).animate(
            							    { backgroundColor: '#FFFBCC' }, 
            							    'fast', 
            							    function(){
            								    $(this).animate(
            										{backgroundColor: '#FFF'}, 
            										'fast', 
            										function(){ $(this).css('background-color', '');}
            									)
            								}
            							)
            						  	.hover(
            						      function () {
                                              var $this =$(this);
                                              if($this.attr('data-editing')){
                                              	return;
                                              } 
                                              if(!$this.hasClass('xh_form_field_hover')){
                                              	$this.addClass("xh_form_field_hover");
                                              }
            						      },
            						      function () {
                                              var $this =$(this);
                                              if($this.attr('data-editing')){
                                              	return;
                                              } 
                                              
                                              if($this.hasClass('xh_form_field_hover')){
                                              	$this.removeClass("xh_form_field_hover");
                                              }
            						      }
            						    );
            
            							$(".xh-form-tips").tipTip({
            								attribute: "title",
            								defaultPosition:'top'
            							});
            						},
            						on_setting:function(field_id){
            							var $field_document = $('#field_'+field_id);
            							if($field_document.length<=0){
            								return;
            							}
            							$('.selectable.xh_form_field_hover').not('#field_'+field_id).each(function(){
            								var $this = $(this);
            								$this.removeAttr('data-editing').removeClass("xh_form_field_hover");
            								$('#xh_form_field_settings_'+$this.attr('data-id')).slideUp(200);
            							});
            							
            							if(!$field_document.hasClass('xh_form_field_hover')){
            								$field_document.addClass("xh_form_field_hover");
            							}
            							
            							if($field_document.attr('data-editing')){
            								//close editing
            								$field_document.removeAttr('data-editing');
            								$('#xh_form_field_settings_'+field_id).slideUp(200);
            							}else{
            								$field_document.attr('data-editing',true);
            								$('#xh_form_field_settings_'+field_id).slideDown(200);
            							}
            						}
            					},
            					form:{
            						//ID:表单fields容器
            						id_container:'#xh_forms_fields',
            						//ID:表单设置
            						id_settings:'#xh_form_field_settings',
            
            						//排序时，允许拖拽的把柄
            						id_sortable_handler:'.xh_field_admin_icons',
            						//正在拖拽的element id
            						id_field_dragging:0,
            						
            						init:function(){
            							//声明：form fields 可排序
            							$(this.id_container).sortable({
            								/*
            								阻止排序动作在匹配的元素上发生
            								阻止field排序发生在field settings 表单中
            								*/
            						        cancel: this.id_settings,
            						        //限制排序的动作只能在item元素中的某个元素开始。
            						        handle: this.id_sortable_handler,
            						        
            						        start: function(event, ui){
            							        if(window.xh_form_editor.field.id_field_dragging >0){
            										return false;
            								    }
            								    
            						            window.xh_form_editor.field.id_field_dragging = ui.item[0].id;
            						            return true;
            						        },
            								tolerance: "pointer",
            						        over: function( event, ui ) {
            						            if(ui.helper.hasClass('ui-draggable-dragging')){
            						                ui.helper.data('original_width', ui.helper.width())
            						                ui.helper.data('original_height', ui.helper.height())
            						                ui.helper.width(ui.sender.width()-25);
            						                ui.helper.height(ui.placeholder.height());
            						            } else {
            						                var h = ui.helper.height();
            						                if(h > 300){
            						                    h = 300;
            						                }
            						                ui.placeholder.height(h);
            						            }
            						        },
            						        out: function( event, ui ) {
            						            if(ui.helper && ui.helper.hasClass('ui-draggable-dragging')){
            						                ui.helper.width(ui.helper.data('original_width'));
            						                ui.helper.height(ui.helper.data('original_height'));
            						            }
            						        },
            						        placeholder: "field-drop-zone",
            						        
            						        beforeStop: function( event, ui ) {
            						            $( window.xh_form_editor.form.id_container).height('100%');
            
            						            var type = ui.helper.data('type');
            						            if(typeof type == 'undefined'){
            							            //只是简单排序
            						                return;
            						            }
            						            
            						            var index=ui.item.index();
            						            ui.item.remove();
            						            
            						            window.xh_form_editor.field.add({
            										sort:index,
            										field_type:type,
            										form_id:window.xh_form_editor._form.post_ID
            							        },index);
            						        },
            						        //当排序动作结束时且元素坐标已经发生改变时触发此事件。
            						        update:function(event, ui){
            							        //标记结束
            						        	window.xh_form_editor.field.id_field_dragging=0;
            							    }
            						    });
            						}
            					},
            					init:function(){
            						this.form.init();
            						this.field.init();
            					}
            				};
            
            				$(function(){
            					window.xh_form_editor.init();
            					$('form#post').submit(function(){
            						if(!window.xh_form_editor._form.fields){
            							window.xh_form_editor._form.fields=[];
									}
									var dom_len = $('ul#xh_forms_fields>li').length;
									if(dom_len!=window.xh_form_editor._form.fields.length){
										alert('数据异常，请刷新页面后重试！');
										return false;
									}
            						window.xh_form_editor.submit();
            					});
            				});
            
            
            				function initMenus() {
            					jQuery('ul.menu ul').hide();
            					jQuery.each(jQuery('ul.menu'), function(){
            						jQuery('#' + this.id + '.expandfirst ul:first').show();
            					});
            					jQuery('ul.menu li .button-title-link').click(
            						function() {
            							var checkElement = jQuery(this).next();
            							var parent = this.parentNode.parentNode.id;
            
            							if(jQuery('#' + parent).hasClass('noaccordion')) {
            								jQuery(this).next().slideToggle('normal');
            								return false;
            							}
            							if((checkElement.is('ul')) && (checkElement.is(':visible'))) {
            								if(jQuery('#' + parent).hasClass('collapsible')) {
            									jQuery('#' + parent + ' ul:visible').slideUp('normal', function(){jQuery(this).prev().removeClass('gf_button_title_active')});
            								}
            								return false;
            							}
            							if((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
            								jQuery('#' + parent + ' ul:visible').slideUp('normal', function(){jQuery(this).prev().removeClass('gf_button_title_active')});
            								checkElement.slideDown('normal', function(){jQuery(this).prev().addClass('gf_button_title_active')});
            								return false;
            							}
            						}
            					);
            				}
            				jQuery(document).ready(function() {initMenus();});
            				jQuery(document).ready(function() {	
            					jQuery('div.xh-form-add-buttons-title').append('<span class="xh-form-add-buttons-caret-down"><i class="fa fa-caret-down"></i></span>');
            				});
            
            			})(jQuery);
            		</script>
            		<div id="form-msg" style="display:none;"></div>
            		<div class="wrap xh-forms-edit ">
            		
            		<div id="form-content-1"  class="form-boolbar-content">
            			<table style="width:100%;"  >
                    		<tr>
                    		<td class="pad_top" valign="top" style="width:100%;" id="form-container">
                    	
                    		<ul id="xh_forms_fields" class="xh_forms_fields top_label form_sublabel_below description_below ui-sortable" style="position: relative;">
                    			<?php 
                    			$form->to_editable();
                    			?>
                    		</ul>
                    		</td>
                    		<td valign="top" align="right">
                    			<div id="add_fields">
                    				<div id="floatMenu">
                    
                    					<!-- begin add button boxes -->
                    					<ul id="sidebarmenu1" class="menu collapsible expandfirst">
                    
                    						<?php
                    						
                    						$fields = WShop_Forms::get_all_fields();
                    						$groups = WShop_Forms::get_all_groups();
                    						$index =0;
                    						foreach ($groups as $key=>$settings){
                    						    ?>
                    						    <li id="add_<?php echo esc_attr( $key ) ?>" class="add_field_button_container">
                    								<div class="button-title-link <?php echo ($index++==0) ? 'gf_button_title_active' : '' ?>">
                    									<div class="xh-form-add-buttons-title"><?php echo esc_html( $settings['title'] ); ?></div>
                    								</div>
                    								<ul>
                    									<li class="xh-form-add-buttons">
                    										<ol class="field_type">
                    											<?php 
                    											foreach ($fields as $field){
                    											    if($field->get_group()==$key){
                    											        ?>
                    											        <li>
                    											      	<input type="button" class="button ui-draggable ui-draggable-handle" data-type="<?php echo esc_attr($field->field_type)?>" value="<?php echo esc_attr($field->get_field_title())?>" />
                    											        </li><?php 
                    											    }
                    											}?>
                    										</ol>
                    									</li>
                    								</ul>
                    							</li>
                    						    <?php 
                    						}
                    						?>
                    					</ul>
                    					
                    				</div>
                    			</div>
                    		</td>
                    		</tr>
                    		</table>
            			</div>
            		</div>
                  	
                  	<table class="form-table">
                    <?php 
                },
                'validate'=>function( $key,$field_api){
                    $field = $field_api ->get_field_key($key);
                    $fields =  isset($_POST[$field])?json_decode(stripcslashes($_POST[$field]),true):null;
                    
                    if($fields){
                        $sort = 0;
                        foreach ($fields as $field){
                            $label = isset($field['metas']['label'])?$field['metas']['label']:null;
                            if(empty($label)){
                                $field_api->errors[]=__("Field's label is required!",WSHOP);
                                return null;
                            }
                            
                            $form_id = isset($field['metas']['html_id'])?$field['metas']['html_id']:null;
                            if(empty($form_id)){
                                $field_api->errors[]=sprintf(__("%s's ID is required!",WSHOP),"[$label]");
                                return null;
                            }
                            
                            $times = 0;
                            foreach ($fields as $compare){
                                $cform_id = isset($compare['metas']['html_id'])?$compare['metas']['html_id']:null;
                                if(strcasecmp($cform_id, $form_id)===0){
                                    $times++;
                                }
                                
                                if($times>1){
                                    $field_api->errors[]=sprintf(__("%s's ID is repeat!",WSHOP),"[$label]");
                                    return null;
                                }
                            }
                        }
                    }
                    
                    return $fields;
                }
            )
        ),$post);
    }

    public function get_post_types()
    {
        return array(
            WShop_Forms::POST_T=>__('Form',WSHOP)
        );
    }

    public function get_object($post){
        return new WShop_Forms($post->ID);
    }
}

class WShop_Form_Product_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Form_Product_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="form_product";
        $this->title = __('Form',WSHOP);
    }

    /**
     * {@inheritDoc}
     * @see Abstract_XH_WShop_Fields::init_form_fields()
     */
    public function init_form_fields(){
        global $post;
        $this->form_fields =  apply_filters('wshop_form_product_fields',
            array(
                'form_id'=>array(
                    'title'=>__('Form',WSHOP),
                    'type'=>'custom',
                    'func'=>function($key,$api,$data){
                            global $post;
                            $product = $post;
                            $field = $api ->get_field_key($key);
                            $val = $api->get_option($key);
                            global $post,$wpdb;
                            $forms =$wpdb->get_results(
                               "select p.*
                                from {$wpdb->prefix}posts p
                                inner join {$wpdb->prefix}wshop_forms f on f.post_ID = p.ID
                                where p.post_status='publish'
                                      and p.post_type='".WShop_Forms::POST_T."';");
                            ?>
                            <tr valign="top" class="">
                                <th scope="row" class="titledesc">
                            		<label><?php echo __('Form',WSHOP)?></label>
                    			</th>
                            	<td class="forminp">
                                    <fieldset>
                            			<legend class="screen-reader-text">
                            				<span><?php echo __('Form',WSHOP);?></span>
                            			</legend>
                            			
                            			<select class="input-text wide-input " name="<?php echo $field;?>" >
                            				<?php if($forms){
                            				    foreach ($forms as $form){
                            				        ?><option value="<?php echo $form->ID?>" <?php echo $form->ID==$val?'selected':'';?>><?php echo $form->post_title?></option><?php 
                            				    }
                            				}?>
                            			</select>
                            			<?php if(apply_filters('wshop_enable_form_shortcodes_help', true,$product)){
                            			    ?>
                            			    <br/>
                        					<p class="description" style="float:right;">            
                        						<a href="" target="_blank"><code>[wshop_form]</code></a><a class="wshop-btn-insert" href="javascript:void(0);" onclick="window.wshop_post_editor.add_content('[wshop_form post_id=\'<?php echo $post->ID?>\']立即报名[/wshop_form]');"><?php echo __('Insert into post content',WSHOP)?></a>
                                             </p>
                            			    <?php 
                            			}?>
                            			
                    				</fieldset>
                				</td>
            				</tr>
            			<?php 
                    }
              )
        ),$post);
    }

    /**
     * {@inheritDoc}
     * @see Abstract_XH_WShop_Fields::get_post_types()
     */
    public function get_post_types()
    {
        $post_types = WShop_Add_On_Modal_Forms_Payment::instance()->get_option('post_types',array());
     
        global $wp_post_types;
        $types = array();
        if($post_types&&$wp_post_types){
            foreach ($wp_post_types as $key=>$type){
                if(!in_array($key, $post_types)){continue;}
                 
                if($type->show_ui&&$type->public){
                    $types[$type->name]=(empty($type->label)?$type->name:$type->label).'('.$type->name.')';
                }
            }
        }
        
        return $types;
    }

    /**
     * {@inheritDoc}
     * @see Abstract_XH_WShop_Fields::get_object()
     */
    public function get_object($post)
    {
        return new WShop_Forms_Product($post);
    } 
}
?>