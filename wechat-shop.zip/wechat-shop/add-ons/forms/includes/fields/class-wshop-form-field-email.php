<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Form_Field_Email extends Abstract_WShop_Form_Field{
    public function __construct($obj=array()){
        parent::__construct($obj);  
        $this->field_type ="email";
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Form_Field::get_field_title()
     */
    public function get_field_title()
    {
        return __('Email',WSHOP);
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Form_Field::validate_field($func_insert_data)
     */
    public function validate_field($func_insert_data=null){
        $data = parent::validate_field($func_insert_data);
        if($data instanceof WShop_Error){
            return $data;
        }
        
        if(!empty($data['val'])&& !is_email($data['val'])){
            return WShop_Error::error_custom(__("Please enter a correct email address!",WSHOP));
        }
        
        return $data;
    }
    
    /**
     * @return string  standard|advanced|...
     * @since 1.0.0
     */
    public function get_group()
    {
        return 'advanced';
    }
}
?>