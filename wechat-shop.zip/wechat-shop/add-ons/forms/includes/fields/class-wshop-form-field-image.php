<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Form_Field_Image extends Abstract_WShop_Form_Field{
    public function __construct($obj=array()){
        parent::__construct($obj);  
        $this->field_type ="image";
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Form_Field::get_field_title()
     */
    public function get_field_title()
    {
        return __('Image uploader',WSHOP);
    }
    
    /**
     * @return string  standard|advanced|...
     * @since 1.0.0
     */
    public function get_group()
    {
        return 'advanced';
    }
    
    public function validate_field($func_insert_data=null){
        $input_name =$this->get_input_name();
        $label =$this->get_input_label();
        $data = isset($_REQUEST[$input_name])?stripslashes($_REQUEST[$input_name]):null;
      
       
        $img =$data? json_decode($data,true):null;
        if($img&&!WShop::instance()->WP->ajax_validate($img, $img['hash'],false)){
            return WShop_Error::error_custom(__('Invalid image data',WSHOP));
        }
        
        $data = $img?esc_url_raw($img['url']):null;
        
        if(isset($this->metas->required)
            &&$this->metas->required
            &&(empty($data)||$data==(WSHOP_URL.'/assets/image/default.png'))){
            return WShop_Error::error_custom(sprintf(__("%s is required!",WSHOP),$label));
        }
        
        $error = apply_filters("wshop_form_validate_{$input_name}", WShop_Error::success(),$data,$this);
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        $error = call_user_func_array($func_insert_data,array($this,$data));
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        $entry_show = isset($this->metas->entry_show)?$this->metas->entry_show:null;
        $val = null;
        if($entry_show=='img'){
            $val='<img src="'.$data.'" style="max-width:40px;max-height:40px;" />';
        }else{
            $val = $data;
        }
        
        return array(
            'label'=>$label,
            'val'=>apply_filters('wshop_form_img_val', $val,$data,$entry_show),
            'hidden'=>isset($this->metas->hidden_in_entry)?$this->metas->hidden_in_entry:false
        );
    }
   
}
?>