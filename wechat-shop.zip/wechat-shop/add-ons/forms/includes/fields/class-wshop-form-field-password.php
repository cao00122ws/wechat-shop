<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Form_Field_Password extends Abstract_WShop_Form_Field{
    public function __construct($obj=array()){
        parent::__construct($obj);  
        $this->field_type ="password";
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Form_Field::get_field_title()
     */
    public function get_field_title()
    {
        return __('Password',WSHOP);
    }
    
    public function validate_field($func_insert_data=null){
        $input_name =$this->get_input_name();
        $label =$this->get_input_label();
        $data = isset($_REQUEST[$input_name])?stripslashes($_REQUEST[$input_name]):null;
        if(isset($this->metas->required)&&$this->metas->required&&empty($data)){
            return WShop_Error::error_custom(sprintf(__("%s is required!",WSHOP),$label));
        }
    
        //do not insert data in user meta
        //$func_insert_data($this,$data);
        
        $error = apply_filters("wshop_form_validate_{$input_name}", WShop_Error::success(),$data,$this);
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        $error = call_user_func_array($func_insert_data,array($this,$data));
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        return array(
            'label'=>$label,
            'val'=>$data,
            'hidden'=>isset($this->metas->hidden_in_entry)?$this->metas->hidden_in_entry:false
        );
    }
    
    public function to_html($context,$func_get_data=null){
         
        return WShop::instance()->WP->requires(
            WShop_Add_On_Modal_Forms_Payment::instance()->domain_dir,
            "form/fields/{$this->field_type}/html.php",
            array(
                'field'=>$this,
                'context'=>$context,
                'val'=>null
            ));
    }
}
?>