<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Form_Field_Subtitle extends Abstract_WShop_Form_Field{
    public function __construct($obj=array()){
        parent::__construct($obj);  
        $this->field_type ="subtitle";
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Form_Field::get_group()
     */
    public function get_group()
    {
        return 'advanced';
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Form_Field::get_field_title()
     */
    public function get_field_title()
    {
        return __('Subtitle',WSHOP);
    }
    
    public function validate_field($func_insert_data=null){
        return false;
    }
}
?>