<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
 

require_once 'includes/class-wshop-forms.php';
require_once 'includes/class-wshop-forms-entry.php';
require_once 'includes/abstract-wshop-form-field.php';
require_once 'abstract-xh-add-ons-api.php';
/**
 * @author rain
 *
 */
class WShop_Add_On_Modal_Forms_Payment extends Abstract_WShop_Add_Ons_Forms_Api{
   
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Modal_Forms_Payment
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Modal_Forms_Payment
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wshop_add_ons_form';
        $this->title=__('Forms',WSHOP);
        $this->description='可以创建任意自定义字段的表单，同时支持微信和支付宝支付，应用场景：付费报名';
        $this->version='1.0.2';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->plugin_uri = 'https://www.wpweixin.net/product/1468.html';
        $this->author_uri='https://www.wpweixin.net';
       
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
     
        $this->setting_uris = array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url('admin.php?page=wshop_page_default&section=menu_default_modal&sub=wshop_add_ons_form')
            )
        );
        $this->init_form_fields();
        parent::__construct();
   }
   
   public function init_form_fields(){
       $fields =array(
           'remember_data'=>array(
               'title'=>__('Remember data',WSHOP),
               'type'=>'checkbox',
               'default'=>'yes',
               'description'=>'每次填写表单时，表单默认值为上次提交的数据'
           ),
           'post_types'=>array(
                'title'=>__('Bind post types',WSHOP),
                'type'=>'multiselect',
                'func'=>true,
                'options'=>array($this,'get_post_type_options')
            )
       );
   
       $this->form_fields = apply_filters('wshop_pay_fields', $fields);
   }
   
   public function get_post_type_options(){
       return apply_filters('wshop_modal_form_post_types', parent::get_post_type_options());
   }
   
    public function on_install(){
        $api = new WShop_Forms_Model();
        $api->init();
       
        $api = new WShop_Forms_Entry_Model();
        $api->init();
    }
    
    public function on_load(){
        $this->m1();
    }

    public function on_init(){
        $this->m2();
    }

    public function views_edit_wshop_forms_entry($views){
        unset($views['mine']);
        return $views;
    }
    /**
     * Modify returned post counts by status for the current post type.
     *
     * @since 3.7.0
     *
     * @param object $counts An object containing the current post_type's post
     *                       counts by status.
     * @param string $type   Post type.
     * @param string $perm   The permission to determine if the posts are 'readable'
     *                       by the current user.
     */
    public function wp_count_posts($counts, $type, $perm){       
        if($type!=WShop_Forms_Entry::POST_T){
            return $counts;
        }
   
        $cache_key = _count_posts_cache_key( $type, $perm );
        
        global $wpdb,$wp_query;
        
        $query = "SELECT post_status, COUNT( * ) AS num_posts FROM {$wpdb->posts}
                  inner join {$wpdb->prefix}wshop_forms_entry mi on mi.post_ID = {$wpdb->prefix}posts.ID
                  WHERE post_type = %s and post_status!='pre-publish' ";
        
        $current_wshop_form =$this->set_current_form($wp_query);
        $post_parent = $current_wshop_form?$current_wshop_form->post_ID:0;
        
        $query.=" and {$wpdb->posts}.post_parent = $post_parent ";
        
        if ( 'readable' == $perm && is_user_logged_in() ) {
            $post_type_object = get_post_type_object($type);
            if ( ! current_user_can( $post_type_object->cap->read_private_posts ) ) {
                $query .= $wpdb->prepare( " AND (post_status not in ( 'private','pre-publish') OR ( post_author = %d AND post_status = 'private' and post_status!='pre-publish' ))",
                    get_current_user_id()
                    );
            }
        }
        $query .= ' GROUP BY post_status';
        
        $results = (array) $wpdb->get_results( $wpdb->prepare( $query, $type ), ARRAY_A );
   
        $counts = array_fill_keys( get_post_stati(), 0 );
        
        foreach ( $results as $row ) {
            $counts[ $row['post_status'] ] = $row['num_posts'];
        }
        
        $counts = (object) $counts;
        return $counts;
    }
    
    private function set_current_form($wp_query){
        global $current_wshop_form,$wpdb;
        if(!$current_wshop_form){
            $form_id = isset($_REQUEST['post_parent'])?intval($_REQUEST['post_parent']):0;
            $current_wshop_form = $wpdb->get_row(
                "select *
                from {$wpdb->prefix}wshop_forms f
                inner join {$wpdb->prefix}posts p on p.ID = f.post_ID
                where p.post_status='publish'
                and p.post_type='".WShop_Forms::POST_T."'
                and ($form_id=0 or f.post_ID =$form_id)
                limit 1;");
        }
        
        if($current_wshop_form){
            $wp_query->set( 'post_parent', $current_wshop_form->ID);
        }
        
        return $current_wshop_form;
    }
    
    /**
     *
     * @param array $args
     * @param WP_Query $wp_query
     */
    public function posts_join( $join, $wp_query){
        remove_filter('posts_join', array($this,'posts_join'),10);
        if(!is_admin()||$wp_query->get('post_type')!=WShop_Forms_Entry::POST_T){
            return $join;
        }
    
        global $pagenow;
        if($pagenow!='edit.php'||!isset($_REQUEST['post_type'])||$_REQUEST['post_type']!=WShop_Forms_Entry::POST_T){
            return $join;
        }
        
        global $wpdb;
        $join.=" inner join {$wpdb->prefix}wshop_forms_entry mi on mi.post_ID = {$wpdb->prefix}posts.ID";
            
        return $join; 
    }
    
    /**
     * 
     * @param array $args
     * @param WShop_Order $order
     * @param string $transaction_id
     */
    public function wshop_order_complete_payment_args($args,$order,$transaction_id){
        if(!isset($order->metas['form']['entry_id'])){
            return $args;
        }
        
        global $wpdb;
        $entry_id = absint($order->metas['form']['entry_id']);
        $args['join']['form'] ="inner join {$wpdb->prefix}posts form_wshop_form_entry_post on form_wshop_form_entry_post.ID= $entry_id
                                 inner join {$wpdb->prefix}wshop_forms_entry form_wshop_form_entry on form_wshop_form_entry.post_ID = form_wshop_form_entry_post.ID";
        $args['set']['form'] =",form_wshop_form_entry_post.post_status='publish',form_wshop_form_entry.order_id=core_wshop_order.id";
        $args['where']['form'] ="and (form_wshop_form_entry_post.post_status='pre-publish' and form_wshop_form_entry_post.post_type='".WShop_Forms_Entry::POST_T."')";
        
        return $args;
    }
    
    public function wshop_admin_menu_menu_default_modal($menus){
        $menus[]=$this;
        return $menus;
    }
    
    //表单数据
    public function create_order_checkout(&$cart){
       $form = WShop_Add_On_Modal_Forms_Payment::instance()->get_order_checkout_form();
        if(!$form){
            return;
        }

        $form = WShop_Add_On_Modal_Forms_Payment::form_validate($cart,$form);
        if($form instanceof WShop_Error){
            throw new Exception($form->errmsg);
        }
    }
  
    public function wshop_checkout_tab_form($request){
        $action = isset($request['action'])?$request['action']:null;
        $datas=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null,
            'section'=>null,//支付方式：付费下载 ， 快速支付等
            'hash'=>null
        ), $request);
        
        if(!WShop::instance()->WP->ajax_validate($datas, $datas['hash'])){
            echo WShop_Error::err_code(701)->to_json();
            exit;
        }
         
        if(!is_user_logged_in()&&!WShop::instance()->WP->is_enable_guest_purchase()){
            echo WShop_Error::err_code(501)->to_json();
            exit;
        }
        
        if(!isset($request['section'])||empty($request['section'])){
            echo WShop_Error::err_code(600)->to_json();
            exit;
        }
        
        $cart = WShop_Shopping_Cart::empty_cart(false);
        if($cart instanceof WShop_Error){
            echo $cart->to_json();
            exit;
        }
        
        $payment_method = isset($request['payment_method'])?$request['payment_method']:null;
        if(empty($payment_method)){
            $payments = WShop::instance()->payment->get_payment_gateways();
            if($payments&&count($payments)>0){
                $payment_method =$payments[0]->id;
            }
        }
        
        $cart->__set_payment_method($payment_method);
        $post_id = isset($request['post_id'])?$request['post_id']:null;
        
        $product = new WShop_Product($post_id);
        if(!$product->is_load()){
            echo WShop_Error::error_custom(404)->to_json();exit;
        }
        
        $form_product=null;
        if($product->get('post_type')==WShop_Forms::POST_T){
            //兼容老版本
            $form = WShop_Add_On_Modal_Forms_Payment::form_validate($cart,$post_id);
            if($form instanceof WShop_Error){
                echo $form->to_json();exit;
            }
            
        }else{
            $form_product = $post_id?new WShop_Forms_Product($post_id):null;
            if(!$form_product||!$form_product->is_load()){
                echo WShop_Error::err_code(404)->to_json();exit;
            }
        
            $form = WShop_Add_On_Modal_Forms_Payment::form_validate($cart,$form_product->get('form_id'));
            if($form instanceof WShop_Error){
                echo $form->to_json();exit;
            }
        }
        
        $cart = $cart->__add_to_cart($product->post_ID);
        if($cart instanceof WShop_Error){
            echo $cart->to_json();
            exit;
        }
       
        $cart->__set_metas(array(
            'section'=>$request['section'],
            'location'=>isset($request['location'])?$request['location']:null
        ));
    
        $order = $cart->create_order();
        if($order instanceof WShop_Error){
            echo $order->to_json();
            exit;
        }
    
        echo WShop_Error::success(array(
            'redirect_url'=>$order->get_pay_url()
        ))->to_json();
        exit;
    }
    
    public function wshop_create_order_form($func,$cart,$request){
        return array(function($cart,$request){
            $cart->__empty_cart();
             
            $payment_method = isset($request['payment_method'])?$request['payment_method']:null;
            if(empty($payment_method)){
                $payments = WShop::instance()->payment->get_payment_gateways();
                if($payments&&count($payments)>0){
                    $payment_method =$payments[0]->id;
                }
            }
            
            $cart->__set_payment_method($payment_method);
            $post_id = isset($request['post_id'])?$request['post_id']:null;
            
            $product = new WShop_Product($post_id);
            if(!$product->is_load()){
                return WShop_Error::error_custom(404);
            }
            
            $form_product=null;
            if($product->get('post_type')==WShop_Forms::POST_T){
                //兼容老版本
                $form = WShop_Add_On_Modal_Forms_Payment::form_validate($cart,$post_id);
                if($form instanceof WShop_Error){
                    return $form;
                }
            }else{
                $form_product = $post_id?new WShop_Forms_Product($post_id):null;
                if(!$form_product||!$form_product->is_load()){
                    return WShop_Error::error_custom(404);
                }
                
                $form = WShop_Add_On_Modal_Forms_Payment::form_validate($cart,$form_product->get('form_id'));
                if($form instanceof WShop_Error){
                    return $form;
                }
            }
           
            
            try {
                $func = apply_filters('wshop_form_created_order_add_to_cart', function($cart,$product,$form_product,$request){
                    return $cart->__add_to_cart($product->post_ID);
                },$cart,$product,$form_product,$request);
                
                $cart = call_user_func_array($func, array($cart,$product,$form_product,$request));
            } catch (Exception $e) {
                $code =$e->getCode();
                return new WShop_Error($code==0?-1:$code,$e->getMessage());
            }
            
            $cart->__set_metas(array(
                'location'=>isset($request['location'])?$request['location']:null
            ));
            
            return $cart;
        });
    }
    
    public function wshop_online_post_types($post_types){
        $types = $this->get_option('post_types');
         
        if($types){
            foreach ($types as $type){
                if(!in_array($type, $post_types)){
                    $post_types[]=$type;
                }
            }
        }
         
        return apply_filters('wshop_form_online_post_types', $post_types);
    }
    /**
     * 新增表单选项
     * @param array $settings
     */
    public function wshop_checkout_options_2($settings){
        $settings['form_id'] = array(
            'title'=>__('Checkout form',WSHOP),
            'type'=>'select',
            'func'=>true,
            'tr_css'=>'section-modal section-shopping_cart',
            'options'=>array($this,'get_form_options')
        );
    
        return $settings;
    }
   
    public function admin_init(){
        global $pagenow;
        if(strcasecmp($pagenow, 'edit.php')!==0
            ||!isset($_GET['post_type'])
            ||strcasecmp($_GET['post_type'], WShop_Forms_Entry::POST_T)!==0
            ||!isset($_GET['export_action'])
            ){
            return;
        }
        
        global $wpdb;
        
		$q = $_GET;
		if(!isset($q['post_parent'])){
		    wp_die(__('Please select form!',WSHOP));
		    exit;
		}
		$q['post_status']='publish';
    	$q['m'] = isset($q['m']) ? (int) $q['m'] : 0;
    	$q['cat'] = isset($q['cat']) ? (int) $q['cat'] : 0;
    	$post_stati  = get_post_stati();
    
    	if ( isset($q['post_type']) && in_array( $q['post_type'], get_post_types() ) )
    		$post_type = $q['post_type'];
    	else
    		$post_type = 'post';
    
    	$avail_post_stati = get_available_post_statuses($post_type);
    
    	if ( isset($q['post_status']) && in_array( $q['post_status'], $post_stati ) ) {
    		$post_status = $q['post_status'];
    		$perm = 'readable';
    	}
    
    	if ( isset( $q['orderby'] ) ) {
    		$orderby = $q['orderby'];
    	} elseif ( isset( $q['post_status'] ) && in_array( $q['post_status'], array( 'pending', 'draft' ) ) ) {
    		$orderby = 'modified';
    	}
    
    	if ( isset( $q['order'] ) ) {
    		$order = $q['order'];
    	} elseif ( isset( $q['post_status'] ) && 'pending' == $q['post_status'] ) {
    		$order = 'ASC';
    	}
    
    	$query = $q;
    	
    	// Hierarchical types require special args.
    	if ( is_post_type_hierarchical( $post_type ) && !isset($orderby) ) {
    		$query['orderby'] = 'menu_order title';
    		$query['order'] = 'asc';
    		$query['posts_per_page'] = -1;
    		$query['posts_per_archive_page'] = -1;
    		$query['fields'] = 'id=>parent';
    	}
    
    	if ( ! empty( $q['show_sticky'] ) ){
    		$query['post__in'] = (array) get_option( 'sticky_posts' );
    	}
    	
    	$page_size = 200;
    	$page_index = 1;
    	$query['posts_per_page']=$page_size;
    	$query['paged']=$page_index; 
    	
    	$wp_query = new WP_Query( $query );
    
    	$total_items = $wp_query->found_posts;
    	$page_count = $wp_query->max_num_pages;
    	$items = $wp_query->posts;
    	if(count($items)==0){
    	    wp_die(__('No post found!',WSHOP));
    	    exit;
    	}
    	
    	$dir = '/uploads/'.date_i18n('Y/m/d').'/';
    	if(!WShop_Install::instance()->load_writeable_dir(WP_CONTENT_DIR.$dir,true)){
    	    wp_die(sprintf(__('Create file dir failed when export post data(%s)!',WSHOP),WP_CONTENT_DIR.$dir));
    	    exit;
    	}
    	
    	$filename = time().'.csv';
    	$fp = @fopen(WP_CONTENT_DIR. $dir.$filename, 'w');
    	if(!$fp){
    	    wp_die(sprintf(__('Create file failed when export post data(%s)!',WSHOP),WP_CONTENT_DIR. $dir.$filename));
    	    exit;
    	}
    	
    	try {
    	    $form = new WShop_Forms($q['post_parent']);
    	    if(!$form->is_load()){
    	        throw new Exception(WShop_Error::error_unknow()->errmsg);
    	    }
    	    
        	$columns = array(
        	    '_OID_'
        	);
        	$first_line=array(
        	   apply_filters('wshop_form_entry_export_oid_name',  __('Order ID',WSHOP),$form)
        	);
        	
        	foreach ($form->get_fields() as $field){
        	    if($field->field_type=='subtitle'){
        	        continue;
        	    }
        	    $columns[]=$field->get_input_name();
        	    $first_line[]=$field->get_input_label();
        	}
        	 
        	$columns=apply_filters('wshop_forms_entry_export_columns', $columns,$form);
        	$first_line=apply_filters('wshop_forms_entry_export_first_line', $first_line,$form);
        	
        	fputcsv($fp, $first_line);
    	
        	for($index=1;$index<=$page_count;$index++){
        	    $query['paged']=$index;
        	    $wp_query = new WP_Query( $query );
        	   
        	    $items = $wp_query->posts;
        	    if(!$items){
        	        break;
        	    }
        	    
        	    foreach ($wp_query->posts as $post){
        	        $entry = new WShop_Forms_Entry($post->ID);
        	        if(!$entry->is_load()){
        	           continue;
        	        }
        	        
        	        $fields = $entry->get_fields();
        	        
        	        $line = array();
        	        foreach ($columns as $column){
        	            $val =apply_filters('wshop_form_entry_export_column', false,$column,$entry,$post,$form);
        	            if($val){
        	                $line[]=$val;
        	                continue;
        	            }
        	            
        	            if($column=='_OID_'){
        	                $line[]=$entry->order_id;
        	                continue;
        	            }
        	            
        	            $val = '';
        	            if($fields&&isset($fields[$column]['val'])){
        	               $val = $fields[$column]['val'];
        	            }
        	            
        	            $line[]=$val;
        	        }
        	        $line =apply_filters('wshop_form_entry_export_column_after', $line,$entry,$post,$form);
        	        fputcsv($fp, $line);
        	    }
        	}
    	} catch (Exception $e) {
    	    if($fp){
    	        fclose($fp);
    	    }
    	    wp_die($e->getMessage());
    	    exit;
    	}
    	
    	fclose($fp);
    	
        $file_size =filesize(WP_CONTENT_DIR. $dir.$filename);
        if($file_size>1024*1024*3){
            wp_die('导出文件过大，请手动<a href="'.WP_CONTENT_URL. $dir.$filename.'">下载</a>');
            exit;
        }
        
        header('Content-type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.$filename.'"');
        header("Content-Length: ". $file_size);
        readfile(WP_CONTENT_DIR. $dir.$filename);
        exit;
    }
    
    public function form_received($atts,$content=null){
        return WShop::instance()->WP->requires($this->domain_dir, 'form/form-received.php',array(
            'atts'=>$atts,
            'content'=>$content
        ));
    }

    /**
     * 对表单条目进行筛选
     * @param WP_Query $q
     */
    public function pre_get_posts($q ){
        remove_filter('pre_get_posts', array( $this, 'pre_get_posts' ) ,10);
        
        if ( ! $q->is_main_query() ) {
            return;
        }
        
        if(!is_admin()){
            return;
        }
        
        global $pagenow;
        if($pagenow!='edit.php'){
            return;
        }

        $post_type = $q->get('post_type');
        if($post_type!=WShop_Forms_Entry::POST_T ){
            return;
        }
        
        $this->set_current_form($q);
    }
    
    public function restrict_manage_posts($post_type,$which=0){
        if($which!='top'){
            return;
        }
        
        if($post_type!=WShop_Forms_Entry::POST_T){
            return;
        }
        ?>
         <style type="text/css">.select2-container {width: 200px !important;}</style>
        <select name="post_parent" class="wshop-search" data-type='<?php echo WShop_Forms::POST_T ?>' data-sortable="true" data-placeholder="<?php echo __( 'Search for a form(ID/post_title)&hellip;', WSHOP); ?>" data-allow_clear="true">
			<?php 
			 global $wpdb,$current_wshop_form;
			 if($current_wshop_form){
			     ?><option value="<?php echo $current_wshop_form->ID?>" ><?php echo $current_wshop_form->post_title;?></option><?php 
			 }
			?>
		</select>
        <?php 
        
        submit_button( __( 'Export',WSHOP ), 'primary', 'export_action', false, array( 'id' => 'post-export-submit','style'=>'float:right;margin: 1px 8px 0 0;') );
    }
    
    public function checkout_order_recieved_sections($order){
        echo WShop::instance()->WP->requires($this->domain_dir, 'form/order-view-checkout-order-received.php',array(
            'order'=>$order
        ));
    }
    
    public function wshop_order_email_sections($order){
        echo WShop::instance()->WP->requires($this->domain_dir, 'form/order_email_sections.php',array(
            'order'=>$order
        ));
    }
    
    /**
     * 
     * @param WShop_Order $order
     */
    public function order_view_admin_order_detail_data_column($order){
        echo WShop::instance()->WP->requires($this->domain_dir, 'form/order-view-admin-order-detail-data-column.php',array(
            'order'=>$order
        ));
    }
    
    /**
     * @return string[]
     * @since 1.0.0
     */
    public function get_form_options(){
        $options = array(
            0=>__('Select...',WSHOP)
        );
        global $wpdb;
        $forms =$wpdb->get_results(
            "select * 
             from {$wpdb->prefix}wshop_forms f
             inner join {$wpdb->prefix}posts p on p.ID =f.post_ID 
             where p.post_status='publish';");
        if($forms){
            foreach ($forms as $form){
                $options[$form->post_ID]=$form->post_title;
            }
        }
        
        return $options;
    }

    /**
     * 表单html
     * @param array $atts
     * @param string $content
     * @since 1.0.0
     */
    public function wshop_form($atts = array(),$content=null){        
        return WShop_Async::instance()->async_call('wshop_form', function(&$atts,&$content){
            if(!isset($atts['location'])||empty($atts['location'])){
                $atts['location'] =  WShop_Helper_Uri::get_location_uri();
            }
        
            //兼容老版本
            if(isset($atts['form_id'])&&!empty($atts['form_id'])){
                $atts['post_id']=$atts['form_id'];
            }
            
            if(!isset( $atts['post_id'])||empty( $atts['post_id'])){
                if(method_exists(WShop::instance()->WP, 'get_default_post')){
                    $default_post = WShop::instance()->WP->get_default_post();
                    $atts['post_id']=$default_post?$default_post->ID:0;
                }else{
                    global $wp_query,$post;
                    $default_post=$wp_query?$wp_query->post:null;
                    if(!$default_post&&$post){
                        $default_post = $post;
                    }
                    $atts['post_id']=$default_post?$default_post->ID:0;
                }
            }
            
        },function(&$atts,&$content){
            $content=empty($content)?__('Submit',WSHOP):$content;
            return WShop::instance()->WP->requires(WShop_Add_On_Modal_Forms_Payment::instance()->domain_dir, 'form/purchase-content.php',array(
                'atts'=>$atts,
                'content'=>$content
            ));
        },
       array(
           'style'=>null,
           'post_id'=>0,
           'form_id'=>0,//此字段已废除
           'class'=>'xh-btn xh-btn-danger xh-btn-lg',
           'location'=>null
        ),
        $atts,
        $content);
    }
   
    public function register_post_types(){
        register_post_type( WShop_Forms::POST_T,
            array(
                'labels' => array(
                    'name' => __('Form',WSHOP),
                    'singular_name' =>__('Form',WSHOP),
                    'add_new' => __('Add New',WSHOP),
                    'add_new_item' =>__('Add New Form',WSHOP),
                    'edit' =>  __('Edit',WSHOP),
                    'edit_item' => __('Edit Form',WSHOP),
                    'new_item' => __('New Form',WSHOP),
                    'view' => __('View',WSHOP),
                    'view_item' => __('View Form',WSHOP),
                    'search_items' => __('Search Form',WSHOP),
                    'not_found' => __('No Form found',WSHOP),
                    'not_found_in_trash' => __('No Form found in trash',WSHOP),
                    'parent' => __('Parent Form',WSHOP)
                ),
                //决定自定义文章类型在管理后台和前端的可见性
                'public' => true,
                'wshop_ignore'=>true,
                'wshop_include'=>false,
                'menu_position' => 15,
                'exclude_from_search '=>false,
                'publicly_queryable'=>false,
                'hierarchical'=>false,
                'supports' => array( 'title', /*'excerpt', 'editor','comments', 'thumbnail','page-attributes'*/ ),
                //创建自定义分类。在这里没有定义
                //'taxonomies' => array( ),
                //启用自定义文章类型的存档功能
                'has_archive' => true,
                'show_in_menu'=>WShop_Admin::menu_tag
            ));
        
        register_post_type( WShop_Forms_Entry::POST_T,
            array(
                'labels' => array(
                    'name' => __('Form entry',WSHOP),
                    'singular_name' =>__('Form entry',WSHOP),
                    'add_new' => __('Add New',WSHOP),
                    'add_new_item' =>__('Add New Form entry',WSHOP),
                    'edit' =>  __('Edit',WSHOP),
                    'edit_item' => __('Edit Form entry',WSHOP),
                    'new_item' => __('New Form entry',WSHOP),
                    'view' => __('View',WSHOP),
                    'view_item' => __('View Form entry',WSHOP),
                    'search_items' => __('Search Form entry',WSHOP),
                    'not_found' => __('No Form entry found',WSHOP),
                    'not_found_in_trash' => __('No Form entry found in trash',WSHOP),
                    'parent' => __('Parent Form entry',WSHOP)
                ),
                //决定自定义文章类型在管理后台和前端的可见性
                'public' => true,
                'wshop_ignore'=>true,
                'wshop_include'=>false,
                'menu_position' => 15,
                'exclude_from_search '=>false,
                'publicly_queryable'=>false,
                'hierarchical'=>false,
                'supports' => array( 'title', /* 'excerpt','editor','comments', 'thumbnail','page-attributes'*/ ),
                //创建自定义分类。在这里没有定义
                //'taxonomies' => array( ),
                //启用自定义文章类型的存档功能
                'has_archive' => true,
                'show_in_menu'=>WShop_Admin::menu_tag
            ));
    }
    
    public function do_ajax(){
        $action ="wshop_{$this->id}";
        $datas=WShop_Async::instance()->shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null
        ), stripslashes_deep($_REQUEST));
      
        $this->on_admin_post($datas);
    }

    public function register_fields(){
        WShop_Forms_Fields::instance();
        WShop_Forms_Entry_Fields::instance();
        WShop_Form_Product_Fields::instance();
    }
   
    public function wshop_async_load_wshop_form($html,$request,$other){
       return WShop_Add_On_Modal_Forms_Payment::instance()->wshop_form($request,$other['content']);
    }
   
    public function wshop_checkout_cart($call,$context){
       $call[]=function($context){
           echo WShop::instance()->WP->requires(WShop_Add_On_Modal_Forms_Payment::instance()->domain_dir, 'form/checkout-order-pay-form.php',array(
            'context'=>$context
            ));
        };
        return $call;
    }
  
    public function get_order_checkout_form(){
        $form_id =WShop_Settings_Checkout_Options::instance()->get_option('form_id');
        if(!$form_id){
            return null;
        }
        $form_id = apply_filters('wshop_checkout_form_id', $form_id);
        $form = new WShop_Forms($form_id);
        if(!$form->is_load()){
            return null;
        }
        
        return $form;
    }
   
    /**
     * @param WShop_Shopping_Cart $cart
     * @param int|WShop_Forms $form_id
     */
    public static function form_validate($cart,$form_id){
        if(!$form_id){
            return WShop_Error::error_custom(__('Form is invalid!',WSHOP));
        }
        $form =$form_id instanceof WShop_Forms?$form_id: new WShop_Forms($form_id);
        if(!$form->is_load()){
            return WShop_Error::error_custom(__('Form is invalid!',WSHOP));
        }
        
        $field_datas = $form->validate_field();
        if($field_datas instanceof WShop_Error){
            return $field_datas;
        }
        
        $fields = array();
        foreach ($field_datas as $item){
            $field = $item['field'];
            $val = $item['val'];
             
            $fields[$field->get_input_name()] = $val;
        }
        
        $post_ID = wp_insert_post(array(
            'post_title' => $form->post_title,
            'post_status' => 'pre-publish',
            'post_author' =>get_current_user_id(),
            'post_type' => WShop_Forms_Entry::POST_T,
            'post_parent'=>$form->post_ID
        ),true);
        
        if($post_ID instanceof WP_Error){
           return WShop_Error::wp_error($post_ID);
        }
        
        $entry = new WShop_Forms_Entry(array(
            'post_ID'=>$post_ID,
            'form_id'=>$form->post_ID,
            'order_id'=>null,
            'fields'=>$fields
        ));
        
        $error =$entry->insert();
        if(!WShop_Error::is_valid($error)){
             return $error;
        }
        
        $metas = array(
            'entry_id'=>$entry->post_ID,
            'form_id'=>$form->post_ID,
            'title'=>$form->post_title,
            'desc'=>$form->post_excerpt,
            'fields'=>$fields
        );
        
        $cart->__set_metas(array(
            'form'=>$metas
        ));
        
        return $form;
    } 
 
  
    private function on_admin_post($datas){
        if(!WShop::instance()->WP->ajax_validate($datas,isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
            echo WShop_Error::err_code(701)->to_json();
            exit;
        }
        
        global $current_user;
        $roles = $current_user?$current_user->roles:null;
        if(!$roles||!is_array($roles)||!in_array('administrator', $roles)){
            echo WShop_Error::err_code(501)->to_json();
            exit;
        }
        
        switch ($datas['tab']){
            case 'add_field':
                $propertys = isset($_POST['field'])?json_decode(stripslashes($_POST['field']),true):null;
                if(!isset($propertys['field_type'])){
                    echo WShop_Error::err_code(404)->to_json();
                    exit;
                }
        
                try {
                    $propertys['id']=time();
                    if(!isset($propertys['metas']['html_id'])||empty($propertys['metas']['html_id'])){
                        $propertys['metas']['html_id']="id_".$propertys['id'];
                    }
                    
                    $class =WShop_Forms::get_field_class($propertys['field_type']);
                    if(!$class){
                        throw new Exception(__('invalid field type',WSHOP));
                    }
                   
                    $obj = new $class($propertys);
                    echo WShop_Error::success(array(
                        'field'=>$obj,
                        'html'=>$obj->to_editable()
                    ))->to_json();
                    exit;
                } catch (Exception $e) {
                    WShop_Log::error($e->getMessage());
                    echo WShop_Error::error_custom($e->getMessage())->to_json();
                    exit;
                }
                exit;
        }
    }
    
    /**
     * Enqueues registered WShop Forms scripts.
     *
     * @since  Unknown
     * @access public
     *
     * @param null $hook Not used.
     */
    public function enqueue_admin_scripts( $hook ) {
       global $post;
       if(!$post||$post->post_type!=WShop_Forms::POST_T){
           return;
       }
       
       $styles=array( 
            'font-awesome',
            'jquery-ui-custom',
            'xh-form-admin',
            'thickbox'
        );
        
        $scripts = array(
            'jquery-ui-core',
            'jquery-ui-sortable',
            'jquery-ui-draggable',
            'jquery-ui-tabs',
            'thickbox'
        );
        
       
        foreach ( $styles as $style ) {
            wp_enqueue_style( $style );
        }
        
        foreach ( $scripts as $script ) {
            wp_enqueue_script( $script );
        }
    }
    
    public function register_scripts() {
        $base_url = $this->domain_url.'/assets';
        $version  = WShop::instance()->version;
        $min      = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG  ? '' : '.min';
       
        wp_register_style( 'xh-form-admin', $base_url . "/css/form-admin{$min}.css", array(), $version );
        wp_register_style( 'jquery-ui-custom', $base_url . "/css/jquery-ui.custom{$min}.css", array(), $version );
        wp_register_style( 'font-awesome', $base_url . "/css/font-awesome{$min}.css", array(), $version );
        
    }
}

return WShop_Add_On_Modal_Forms_Payment::instance();
/*
  		add_filter('wshop_order_email_receiver', function($receive_email,$order){
        	$field_key = 'email';
        	$email = isset($order->metas['form']['fields'][$field_key]['val'])?$order->metas['form']['fields'][$field_key]['val']:null;
        	if(empty($email)||!is_email($email)){
        		return $receive_email;
        	}
        	
        	return $email;
        },10,2);
 * */
?>