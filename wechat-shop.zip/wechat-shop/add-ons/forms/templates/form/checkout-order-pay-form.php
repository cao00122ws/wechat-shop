<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$request = WShop_Temp_Helper::clear('atts','templates');
$context = $request['context'];
$form = WShop_Add_On_Modal_Forms_Payment::instance()->get_order_checkout_form();
if(!$form){
    return;
}
?>
<div class="xh-title-soft clearfix"><?php echo $form->get('post_title')?></div>
<div class="block20"></div>
<?php 
echo $form->to_html($context);