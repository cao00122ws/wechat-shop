<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
$atts =WShop_Temp_Helper::clear('atts','templates');;
$field = $atts['field'];
$context = $atts['context'];

$field_id = esc_attr($field->id);
if(!$field->metas){$field->metas=new stdClass();}

$label = $field->get_input_label();
$description = isset($field->metas->description)?$field->metas->description:null;
$css = isset($field->metas->css)?$field->metas->css:null;
$style = isset($field->metas->style)?$field->metas->style:null;

$default =$atts['val'];

$input_id = esc_attr($field->get_input_id($context));
$input_name =esc_attr($field->get_input_name());
$attr = isset($field->metas->attr)?$field->metas->attr:null;
?>
<div><label for="<?php echo $input_id?>"><input  <?php echo $attr;?> id="<?php echo $input_id?>" name="<?php echo $input_name?>" value="yes" type="checkbox" <?php echo $default?"checked":"";?> class="wshop-form-checkbox <?php echo esc_attr($css)?>" style="<?php echo esc_attr($style)?>"> <?php echo $label?> </label></div>

<script type="text/javascript">
		(function($){
			$(document).bind('wshop_form_<?php echo $context;?>_submit',function(e,m){
				m.<?php echo $input_name?>=$('#<?php echo $input_id ;?>:checked').length>0?'yes':null;
			});
		})(jQuery);
</script>
<?php 