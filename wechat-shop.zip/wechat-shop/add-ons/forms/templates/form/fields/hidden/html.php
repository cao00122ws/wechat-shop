<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
$atts =WShop_Temp_Helper::clear('atts','templates');;
$field = $atts['field'];
$context = $atts['context'];


$field_id = esc_attr($field->id);
if(!$field->metas){$field->metas=new stdClass();}
$label = $field->get_input_label();
$description = isset($field->metas->description)?$field->metas->description:null;
$default =$atts['val'];
$input_id = esc_attr($field->get_input_id($context));
$input_name =esc_attr($field->get_input_name());
?>
<input type="hidden" value="<?php echo esc_attr($default)?>" name="<?php echo $input_name;?>"  id="<?php echo $input_id;?>"/>

<script type="text/javascript">
		(function($){
			$(document).bind('wshop_form_<?php echo $context;?>_submit',function(e,m){
				m.<?php echo $input_name?>=$('#<?php echo $input_id ;?>').val();
			});
		})(jQuery);
</script>
<?php 