<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
$atts =WShop_Temp_Helper::clear('atts','templates');;
$field = $atts['field'];
$context = $atts['context'];

$field_id = esc_attr($field->id);
if(!$field->metas){$field->metas=new stdClass();}
$label = $field->get_input_label();
$description = isset($field->metas->description)?$field->metas->description:null;
$placeholder = isset($field->metas->placeholder)?$field->metas->placeholder:null;
$css = isset($field->metas->css)?$field->metas->css:null;
$style = isset($field->metas->style)?$field->metas->style:null;
$default =$atts['val']?$atts['val']:WSHOP_URL.'/assets/image/default.png';
$required = isset($field->metas->required)?$field->metas->required:false;
$size = isset($field->metas->size)?$field->metas->size:null;
$input_id = esc_attr($field->get_input_id($context));
$input_name =esc_attr($field->get_input_name());

$singles = explode('x', $size); 
$img_size=array(
    'width'=>0,
    'height'=>0
);
switch (count($singles)){
    case 1:
        $img_size=array(
            'width'=>absint($singles[0]),
            'height'=>absint($singles[0]),
        );
        break;
    case 2:
        $img_size=array(
            'width'=>absint($singles[0]),
            'height'=>absint($singles[1]),
        );
        break;
}

$default_val=array();
if(!empty($default)){
    $default_val = WShop::instance()->generate_request_params(array(
        'url'=>$default
    ));
}

if(doing_action('the_content')&& !defined('xh_webuploader')){
    define('xh_webuploader', 'xh_webuploader');
    ?>
    <style type="text/css">
    .webuploader-container {
    	position: relative;
    }
    .webuploader-element-invisible {
    	position: absolute !important;
    	clip: rect(1px 1px 1px 1px); /* IE6, IE7 */
        clip: rect(1px,1px,1px,1px);
    }
    
    .webuploader-pick {
    	position: relative;
    	display: inline-block;
    	cursor: pointer;
    	background: #337ab7;
    	padding: 4px 12px;
    	color: #fff;
    	text-align: center;
    	border-radius: 3px;
    	overflow: hidden;
    	margin-top:5px;
    	
    }
    .webuploader-pick-hover {
    	background: #00a2d4;
    }
    
    .webuploader-pick-disable {
    	opacity: 0.6;
    	pointer-events:none;
    }
    </style>
	<script type="text/javascript" src="<?php echo WSHOP_URL?>/assets/webuploader-0.1.7-alpha/webuploader.js"></script>
    <?php 
}
?>
<div class="xh-form-group" id="form-group-<?php echo $input_id?>">
    <label class="<?php echo $required?"required":""?>"  for="<?php echo $input_id;?>"><?php echo $label;?></label>
    <div>
    	<a href="<?php echo esc_url($default)?>" target="_blank" id="image-<?php print $input_id;?>-review"><img class="thumbnail" id="image-<?php print $input_id;?>" src="<?php echo esc_url($default)?>" style="max-width:80px;max-height:80px;"/></a>
    	<div id="image-<?php print $input_id;?>-picker"><?php echo __('Upload image',WSHOP)?></div>
    	 
        <span class="xh-help-block"><?php echo $description?></span>
        <input type="hidden" value="<?php echo esc_attr(json_encode($default_val))?>" name="<?php echo $input_name;?>" id="<?php echo $input_id;?>"/>
    </div>
</div>
<script type="text/javascript">
	(function($){
		if ( !WebUploader.Uploader.support() ) {
	       return;
	    }

		var <?php print $input_id;?>_config ={
			swf:'<?php echo WSHOP_URL?>/assets/webuploader-0.1.7-alpha/Uploader.swf',
			server:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_upload_img",'w'=>$img_size['width'],'h'=>$img_size['height']),true,true)?>',
			dnd:'#form-group-<?php echo $input_id?>',
			paste:document.body,
			pick:'#image-<?php print $input_id;?>-picker',
			accept:{
		        title: 'Images',
		        extensions: 'gif,jpg,jpeg,bmp,png',
		        mimeTypes: 'image/gif,image/jpg,image/jpeg,image/bmp,image/png'
		    },
		    auto :true,
		    fileNumLimit:1			    
		};

		     //do something
		var <?php print $input_id;?>_uploader = WebUploader.create(<?php print $input_id;?>_config);
		
		// 文件上传失败，显示上传出错。
		<?php print $input_id;?>_uploader.on( 'uploadStart', function( file ) {
			$('#image-<?php print $input_id;?>-picker .webuploader-pick').text('<?php echo __('Uploading...',WSHOP)?>');
		});
		// 文件上传失败，显示上传出错。
		<?php print $input_id;?>_uploader.on( 'uploadError', function( file ,reason) {
			<?php print $input_id;?>_uploader.reset();
			alert('<?php echo WShop_Error::err_code(500)->errmsg?>');
		});

		// 完成上传完了，成功或者失败，先删除进度条。
		<?php print $input_id;?>_uploader.on( 'uploadComplete', function( file ) {
			$('#image-<?php print $input_id;?>-picker .webuploader-pick').text('<?php echo __('Upload image',WSHOP)?>');
		});
		
		<?php print $input_id;?>_uploader.on( 'uploadSuccess', function( file ,response) {
			<?php print $input_id;?>_uploader.reset();
			
			if(!response||typeof response.errcode=='undefined'){
				alert('<?php echo WShop_Error::error_unknow()->errmsg?>');
				return;
			}
			
			if(response.errcode!=0){
				alert(response.errmsg);
				return;
			}

			$('#<?php echo $input_id;?>').val(JSON.stringify(response.data));
			$('#image-<?php print $input_id;?>').attr('src',response.data.url);
			$('#image-<?php print $input_id;?>-review').attr('href',response.data.url);
		});
		
	})(jQuery);
</script>

<script type="text/javascript">
		(function($){
			$(document).bind('wshop_form_<?php echo $context;?>_submit',function(e,m){
				m.<?php echo $input_name?>=$('#<?php echo $input_id ;?>').val();
			});
		})(jQuery);
</script>
<?php 