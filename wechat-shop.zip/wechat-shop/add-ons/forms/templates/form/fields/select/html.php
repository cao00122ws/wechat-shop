<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
$atts =WShop_Temp_Helper::clear('atts','templates');;
$field = $atts['field'];
$context = $atts['context'];


$field_id = esc_attr($field->id);
if(!$field->metas){$field->metas=new stdClass();}
$label = $field->get_input_label();
$description = isset($field->metas->description)?$field->metas->description:null;
$placeholder = isset($field->metas->placeholder)?$field->metas->placeholder:null;
$css = isset($field->metas->css)?$field->metas->css:null;
$style = isset($field->metas->style)?$field->metas->style:null;
$default =$atts['val'];
$required = isset($field->metas->required)?$field->metas->required:false;
$input_id = esc_attr($field->get_input_id($context));
$input_name =esc_attr($field->get_input_name());
$attr = isset($field->metas->attr)?$field->metas->attr:null;

$options = isset($field->metas->options)?$field->metas->options:null;
?>
<div class="xh-form-group">
    <label class="<?php echo $required?"required":""?>"  for="<?php echo $input_id;?>"><?php echo $label;?></label>
    <select <?php echo $attr;?> class="form-control <?php echo esc_attr($css)?>" style="<?php echo esc_attr($style)?>" name="<?php echo $input_name;?>"  id="<?php echo $input_id;?>">
    	<?php if($options){
    	    foreach (explode("\n", $options) as $row){
    	       if(empty($row)){continue;}
    	        $rows = explode('|', $row);
    	        if(count($rows)!=2){
    	           $rows = array($row,$row);
    	        }
    	        
    	        ?><option value="<?php echo esc_attr($rows[0])?>" <?php echo $default==$rows[0]?"selected":"";?>><?php echo esc_html($rows[1])?></option> <?php 
    	    }
    	}?>
    </select>
    <span class="xh-help-block"><?php echo $description?></span>
</div>
<script type="text/javascript">
		(function($){
			$(document).bind('wshop_form_<?php echo $context;?>_submit',function(e,m){
				m.<?php echo $input_name?>=$('#<?php echo $input_id ;?>').val();
			});
		})(jQuery);
</script>
<?php 