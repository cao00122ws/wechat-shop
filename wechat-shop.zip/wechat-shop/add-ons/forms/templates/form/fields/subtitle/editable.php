<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
$atts =WShop_Temp_Helper::clear('atts','templates');;
$field = $atts['field'];


$field_id = esc_attr($field->id);
if(!$field->metas){$field->metas=new stdClass();}
$label = $field->get_input_label();
$description = isset($field->metas->description)?$field->metas->description:null;
$css = isset($field->metas->css)?$field->metas->css:null;
$style = isset($field->metas->style)?$field->metas->style:null;
$html_id=isset($field->metas->html_id)?$field->metas->html_id:null;
?>
<li id="<?php echo "field_{$field_id}";?>" data-id="<?php echo $field_id?>" class="selectable xh_form_field" >
    <div class="xh_field_admin_icons">
    	<div class="xh_form_field_admin_header_title">
    		<?php echo $field->get_field_title();?>(ID:<span id="field-title-id-<?php echo $field_id?>"><?php echo $html_id?></span>)
    	</div>
    	<a class="field_delete_icon" title="<?php echo esc_attr(__( 'click to delete this field', WSHOP))?>" href="javascript:void(0);" onclick="window.xh_form_editor.field.Delete('<?php echo $field_id?>');"><i class="fa fa-times fa-lg"></i></a>
    	<a class="field_duplicate_icon" title="<?php echo esc_attr(__( 'click to duplicate this field', WSHOP))?>" href="javascript:void(0);" onclick="window.xh_form_editor.field.copy('<?php echo $field_id?>');"><i class="fa fa-files-o fa-lg"></i></a>
    	<a class="field_edit_icon edit_icon_collapsed" title="<?php echo esc_attr(__( 'click to expand and edit the options for this field', WSHOP))?>" href="javascript:void(0);" onclick="window.xh_form_editor.field.on_setting('<?php echo $field_id?>');"><i class="fa fa-caret-down fa-lg"></i></a>
    </div>
    <label class="xh_form_field_label" style="font-size:16px; ">
       <span id="field-label-<?php echo $field_id?>"><?php echo esc_html($label);?></span>     
    </label>
   
	<div class="xh_form_field_description" id="field-description-<?php echo $field_id?>"><?php echo $description;?></div>

	<!-- settings -->
	<script type="text/javascript">
		(function($){
			$(function(){
				jQuery("#xh_form_field_settings_<?php echo $field_id;?>").tabs();
			});
		})(jQuery);		
	</script>
		
	<div id="xh_form_field_settings_<?php echo $field_id;?>" class="xh_form_field_settings field-settings ui-tabs ui-widget ui-widget-content ui-corner-all" style="display:none;">
		<ul class="ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist">
			<li style="width:100px; padding:0px;" class="ui-state-default ui-corner-top ui-tabs-active ui-state-active" role="tab" tabindex="0" aria-selected="true" aria-expanded="true">
				<a href="#xh_form_tab<?php echo $field_id;?>_1" class="ui-tabs-anchor" role="presentation" tabindex="-1"><?php echo __('General',WSHOP)?></a>
            </li>
            <li style="width:100px; padding:0px; " class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-selected="false" aria-expanded="false">
                <a href="#xh_form_tab<?php echo $field_id;?>_2" class="ui-tabs-anchor" role="presentation" tabindex="-1"><?php echo __('Appearance',WSHOP)?></a>
            </li>
		</ul>
		
		<div id="xh_form_tab<?php echo $field_id;?>_1" class="ui-tabs-panel ui-widget-content ui-corner-bottom" role="tabpanel" aria-hidden="false">
    		<ul>
    			<li class="default_value_setting xh_form_field_setting">
        			<label for="field_html_id_<?php echo $field_id;?>">
        				 <?php echo __('ID',WSHOP)?> <i class="fa fa-question-circle xh-form-tips" title="<?php echo __('<h6>ID</h6>Html ID must be unique.',WSHOP)?>"></i><span style="color:red;">*</span>	  	
        			</label>
        			<input type="text" id="field_html_id_<?php echo $field_id;?>" value="<?php echo $html_id;?>"  autocomplete="off">
        			<script type="text/javascript">
        			
        			(function($){
						$('#field_html_id_<?php echo $field_id;?>').keyup(function(){
							$('#field-title-id-<?php echo $field_id?>').text($(this).val());
						});
            		})(jQuery);
        			</script>
        		</li>
				<li class="label_setting xh_form_field_setting">
        			<label for="field_label_<?php echo $field_id;?>">
        				<?php echo __('Label',WSHOP)?><i class="fa fa-question-circle xh-form-tips" title="<?php echo __('<h6>Field Label</h6>Enter the label for this HTML block. it will be displayed on the form.',WSHOP)?>"></i><span style="color:red;">*</span>	  
        			</label>
        			<input type="text" id="field_label_<?php echo $field_id;?>" value="<?php echo esc_attr($label)?>" class="fieldwidth-3" size="35">
        			<script type="text/javascript">
						(function($){
							$('#field_label_<?php echo $field_id;?>').keyup(function(){
								var label = $.trim($(this).val());
								if(label.length==0){
									$('#field-label-<?php echo $field_id?>').text('<?php echo __('No Title',WSHOP)?>');
									return;
								}

								$('#field-label-<?php echo $field_id?>').text(label);
							});
						})(jQuery);
        			</script>
        		</li>
        		
        		<li class="description_setting xh_form_field_setting">
        			<label for="field_description_<?php echo $field_id;?>">
        				<?php echo __('Description',WSHOP)?>	 <i class="fa fa-question-circle xh-form-tips" title="<?php echo __('<h6>Field Description</h6>Enter the description for the form field.  This will be displayed to the user and provide some direction on how the field should be filled out or selected.',WSHOP)?>"></i>	
        			</label>
        			<textarea id="field_description_<?php echo $field_id;?>" class="fieldwidth-3 fieldheight-2"><?php echo $description;?></textarea>
        			<script type="text/javascript">
						(function($){
							$('#field_description_<?php echo $field_id;?>').keyup(function(){
								var label = $.trim($(this).val());
								$('#field-description-<?php echo $field_id?>').html(label);
							});
						})(jQuery);
        			</script>
        		</li>
    		</ul>
		</div>
		
		<div id="xh_form_tab<?php echo $field_id;?>_2" class="ui-tabs-panel ui-widget-content ui-corner-bottom" role="tabpanel" aria-hidden="true" style="display: none;">
            <ul>
				<li class="css_class_setting xh_form_field_setting">
                    <label for="field_css_<?php echo $field_id;?>">
                       	 <?php echo __('Custom Class',WSHOP)?>   <i class="fa fa-question-circle xh-form-tips" title="<?php echo __('<h6>CSS Class Name</h6>Enter the CSS class name you would like to use in order to override the default styles for this field.',WSHOP)?>"></i>                        
                         </label>
                    <input type="text" id="field_css_<?php echo $field_id;?>" value="<?php echo esc_attr($css)?>"  class="field_placeholder fieldwidth-2 merge-tag-support mt-position-right mt-prepopulate ui-autocomplete-input">
                </li>

                 <li class="css_class_setting xh_form_field_setting">
                    <label for="field_style_<?php echo $field_id;?>">
                       	  <?php echo __('Custom Style',WSHOP)?>     <i class="fa fa-question-circle xh-form-tips" title="<?php echo __('<h6>CSS Style</h6>Enter the style you would like to use in order to override the default styles for this field.',WSHOP)?>"></i>                   
                        </label>
                    <textarea  id="field_style_<?php echo $field_id;?>" class="field_placeholder fieldwidth-2 merge-tag-support mt-position-right mt-prepopulate ui-autocomplete-input"><?php echo esc_attr($style)?></textarea>
                </li>
            </ul>
        </div>
    </div>
    <script type="text/javascript">
		(function($){
			//初始化拖动等效果
			$(function(){
				window.xh_form_editor.field.on_field_load(<?php echo $field_id?>);
			});

			//声明表单提交时，metas信息加载
			$(document).bind('wshop_form_field_<?php echo $field_id?>_submit',function(e,field){
				if(!field){
					throw "invalid field when submit";
				}

				field.metas= new Object();
				field.metas['html_id']=$.trim($('#field_html_id_<?php echo $field_id;?>').val());
				field.metas['label']=$.trim($('#field_label_<?php echo $field_id;?>').val());
				field.metas['description']=$.trim($('#field_description_<?php echo $field_id;?>').val());
				field.metas['css']=$.trim($('#field_css_<?php echo $field_id;?>').val());
				field.metas['style']=$.trim($('#field_style_<?php echo $field_id;?>').val());
			});
		})(jQuery);
    </script>
</li>