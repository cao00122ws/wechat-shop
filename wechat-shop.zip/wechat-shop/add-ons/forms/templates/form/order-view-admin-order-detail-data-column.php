<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$data = WShop_Temp_Helper::clear('atts','templates');
$order = $data['order'];
$form = isset($order->metas['form'])?$order->metas['form']:null;
$fields =$form&& isset($form['fields'])?$form['fields']:null;
if(!$form||!$fields){
    return;
}

?>
<div class="order_data_column">
	<h3><?php echo $form['title']?></h3>
	<div class="address">
		<?php foreach ($fields as $key=>$att){
		    if(isset($att['hidden'])&&$att['hidden']){continue;}
		    ?>
		    <p><strong><?php echo $att['label']?>:</strong><?php echo $att['val']?></p>
		    <?php 
		}?>
	</div>
</div>
<?php 