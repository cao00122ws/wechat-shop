<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$data = WShop_Temp_Helper::clear('atts','templates');
$order = $data['order'];
$fields =isset($order->metas['form'])&& isset($order->metas['form']['fields'])?$order->metas['form']['fields']:null;
if(!$fields){
    return;
}

foreach ($fields as $key=>$att){
    if(isset($att['hidden'])&&$att['hidden']){continue;}
    ?>
   <strong><?php echo $att['label']?>:</strong><?php echo $att['val']?><br/>
    <?php 
}
?>	
	