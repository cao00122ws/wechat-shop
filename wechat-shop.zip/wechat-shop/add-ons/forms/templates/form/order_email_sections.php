<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$data = WShop_Temp_Helper::clear('atts','templates');
$order = $data['order'];
$form = isset($order->metas['form'])?$order->metas['form']:null;
$fields =$form&& isset($form['fields'])?$form['fields']:null;
if(!$form||!$fields){
    return;
}

?>
<h2 style='color: #96588a; display: block; font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif; font-size: 18px; font-weight: bold; line-height: 130%; margin: 16px 0 8px; text-align: left;'><?php echo $form['title']?></h2>
<ul>
<?php foreach ($fields as $key=>$att){
	    if(isset($att['hidden'])&&$att['hidden']){continue;}
	    ?>
	    <li><strong><?php echo $att['label']?>:</strong> <span class="text" style='color: #3c3c3c; font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;'><?php echo $att['val']?></span></li>
	    <?php 
	}?>
</ul>
