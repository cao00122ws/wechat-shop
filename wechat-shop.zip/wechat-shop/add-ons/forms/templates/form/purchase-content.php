<?php
if (! defined('ABSPATH')) {
    exit();
}

$data = WShop_Temp_Helper::clear('atts','templates');
$request = $data['atts'];
$content = empty($data['content'])?__('Submit',WSHOP):$data['content'];
$context = WShop_Helper::generate_unique_id();
$api = WShop_Add_On_Modal_Forms_Payment::instance();
$product = new WShop_Product($request['post_id']);
if(!$product->is_load()){
    return;
}

$sale_price = $product->get_single_price(false);

//如果当前post就是form
if($product->get('post_type')==WShop_Forms::POST_T){
    $form = new WShop_Forms($request['post_id']);
}else{
    $form_product = new WShop_Forms_Product($request['post_id']);
    if(!$form_product->is_load()){
        return;
    }
    
    $form = new WShop_Forms($form_product->get('form_id'));
    if(!$form->is_load()){
        return;
    }
}

?>

<div class="xh-form">
	<?php echo $form->to_html($context); 
	
	    do_action('wshop_form_purchase_content_before_gateways',$form,$product,$form_product,$context);
	
	    if($sale_price>0){
    	   echo WShop::instance()->WP->requires(WSHOP_DIR, 'page/checkout-order-pay-payment-gateways.php',$context);
        }
        
        do_action('wshop_form_purchase_content_after_gateways',$form,$product,$form_product,$context);
        ?>
        <div class="block20"></div>    
        <div class="xh-form-group">
             <script type="text/javascript">
    			(function($){
    				$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
    					data.post_id = <?php echo $product->post_ID?>;
    				});
    				$(document).bind('wshop_<?php echo $context;?>_init_amount_before',function(e,m){
            			m.total_amount+=<?php echo $sale_price?>;
            		});
    				$(document).bind('wshop_<?php echo $context?>_show_amount',function(e,view){
        				var total =view.total_amount;
        				if(total>0){
        					$('#btn-pay-button-<?php echo $context?>').html(view.symbol+total.toFixed(2)+' <?php echo $content?>');
        				}else{
        					$('#btn-pay-button-<?php echo $context?>').html('<?php echo $content?>');
    	    			}
        			});
    			})(jQuery);
            </script>
         <?php 
       		echo WShop::instance()->WP->requires(WSHOP_DIR, '__purchase.php',array(
       		    'content'=>$content,
       		    'class'=>'xh-btn xh-btn-danger xh-btn-block xh-btn-membership',
       		    'location'=>$request['location'],
       		    'context'=>$context,
       		    'section'=>'form',
       		    'tab'=>'form',
       		    'modal'=>'shopping'
       		));
       		
             echo WShop::instance()->WP->requires(WSHOP_DIR, 'page/checkout-order-pay-total-amount.php',array(
                 'context'=>$context
             ));
         ?>
        </div>
</div>