<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
class WShop_Order_Invoice extends WShop_Post_Object{
    const POST_T ='wshop_order_invoice';
    public function __construct($obj=null){
        parent::__construct($obj);
    }
    
    public $enabled=false;
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name(){
        return 'wshop_order_invoice';
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_order_invoice_properties', array(
            'post_ID'=>null,
            'order_id'=>null,
            'invoice_type'=>null,
            'fields'=>null,
            'amount'=>null,
            'fee'=>0,
            'attachment'=>null
        ));
    }
}

class WShop_Invoice extends WShop_Post_Object{   
    public function __construct($obj=null){
        parent::__construct($obj);
    }
    
    public $enabled=false;
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name(){
        return 'wshop_invoice';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_invoice_properties', array(
            'post_ID'=>null,
            'enabled'=>false
        ));
    }
}

class WShop_Invoice_Model extends Abstract_WShop_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        $collate=$this->get_collate();
        global $wpdb;

        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_invoice` (
        	`post_ID` BIGINT(20) NOT NULL,
        	`enabled` VARCHAR(8) NULL DEFAULT NULL,
        	PRIMARY KEY (`post_ID`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_order_invoice` (
                `post_ID` BIGINT(20) NOT NULL,
                `order_id` BIGINT(20) NULL DEFAULT NULL,
                `invoice_type` VARCHAR(32) NULL DEFAULT NULL,
                `fields` TEXT NULL DEFAULT NULL,
                `amount` DECIMAL(18,2) NULL DEFAULT NULL,
                `fee` DECIMAL(18,2) NULL DEFAULT NULL,
                `attachment` TEXT NULL DEFAULT NULL,
                PRIMARY KEY (`post_ID`)
            )
            $collate;");
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
    }
}

class WShop_Order_Invoice_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;
     
    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Order_Invoice_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="order_invoice";
        $this->title = '订单发票'; 
        foreach ($this->get_post_types() as $post_type=>$label){
            add_filter( "manage_{$post_type}_posts_columns", array($this,'manage_posts_columns'),11 ,1);
            add_action( "manage_{$post_type}_posts_custom_column", array( $this, 'manage_posts_custom_column' ),11, 2 );
        }
    }
 
    public function manage_posts_columns($existing_columns){
        $new_existing_columns=array();
        foreach ($existing_columns as $key=>$title){
            $new_existing_columns[$key]=$title;
            if($key=='title'){
                $new_existing_columns['order_id']='订单ID';
                $new_existing_columns['invoice_type']='类型';
                $new_existing_columns['amount']='金额';
                $new_existing_columns['fee']='寄费';
                $new_existing_columns['detail']='详细信息';
            }
        }
    
        return apply_filters('wshop_order_invoice_columns', $new_existing_columns);
    }
    
    public function manage_posts_custom_column($column,$post_ID){
        global $current_wshop_order_invoice,$wpdb;
        if(!$current_wshop_order_invoice||$current_wshop_order_invoice->post_ID!=$post_ID){
            $current_wshop_order_invoice = new WShop_Order_Invoice($post_ID);
        }
    
        if(!$current_wshop_order_invoice->is_load()){
            return;
        }
    
        switch($column){
            case 'order_id':
                $order = new WShop_Order($current_wshop_order_invoice->order_id);
                if($order->is_load()){
                    $url = esc_url($order->get_edit_link());
                    $title = esc_attr($order->get_title());
                    echo "<a href=\"{$url}\" title=\"{$title}\">#{$current_wshop_order_invoice->order_id}</a>";
                }
                break;
            case 'amount':
                echo "<span>￥{$current_wshop_order_invoice->amount}</span>";
                break;
            case 'fee':
                echo "<span>￥{$current_wshop_order_invoice->fee}</span>";
                break;
            case 'invoice_type':
                $invoice_types = WShop_Add_On_Invoice::instance()->invoice_types;
                if(!$invoice_types||!is_array($invoice_types)||!isset($invoice_types[$current_wshop_order_invoice->invoice_type])){
                    break;
                }
                echo $invoice_types[$current_wshop_order_invoice->invoice_type]['title'];
                break;
            case 'detail':
                $invoice_types = WShop_Add_On_Invoice::instance()->invoice_types;
                if(!$invoice_types||!is_array($invoice_types)||!isset($invoice_types[$current_wshop_order_invoice->invoice_type])){
                    break;
                }
                
                if(!$invoice_types[$current_wshop_order_invoice->invoice_type]['fields']||!is_array($invoice_types[$current_wshop_order_invoice->invoice_type]['fields'])){
                    break;
                }
                
                $fields = $current_wshop_order_invoice->fields;
                if(!$fields||!is_array($fields)){
                    $fields=array();
                }
                
                ?><table><?php 
                foreach ($invoice_types[$current_wshop_order_invoice->invoice_type]['fields'] as $k=>$v){
                    ?><tr>
                    <td><?php echo $v['title']?></td>
                    <td><?php echo isset($fields[$k])?esc_html($fields[$k]):'';?></td>
                    </tr><?php 
                }  
                ?></table><?php 
                break;
        }
    }
    
    public function validate_invoice_fields($form_fields = array()) {
        if (empty ( $form_fields )) {
            return null;
        }
    
        $sanitized_fields = array ();
    
        foreach ( $form_fields as $key => $field ) {
            if(isset($field['ignore'])){
                continue;
            }
            
            $field_key = $this->get_field_key ( $key );
            $text = !is_array( $_POST [$field_key])? ( trim ( stripslashes ( $_POST [$field_key] ) ) ): $_POST [$field_key];
            $sanitized_fields [substr($key, strlen("__"))] = $text;
        }
        
        return $sanitized_fields;
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
    public function init_form_fields(){
        global $post;
        $this->form_fields = array(
            'order_id'=>array(
                'title'=>'订单ID',
                'type'=>'text'
            ),
            'amount'=>array(
                'title'=>'发票金额',
                'type'=>'text'
            ),
            'fee'=>array(
                'title'=>'寄费',
                'type'=>'text'
            ),
            'invoice_type'=>array(
                'title'=>'发票类型',
                'type'=>'select',
                'func'=>true,
                'options'=>array(WShop_Add_On_Invoice::instance(),'get_enabled_invoice_type_options')
            ),
            'fields'=>array(
                'title'=>'详细信息',
                'type'=>'custom',
                'func'=>function( $key,$field_api,$data){
                    $invoice_type = $field_api->get_option('invoice_type');
                    if(!isset(WShop_Add_On_Invoice::instance()->invoice_types[$invoice_type]['fields'])){
                        return;
                    }

                    $fieldsval = $field_api->get_option('fields');
                   
                    if(!$fieldsval||!is_array($fieldsval)){
                        $fieldsval=array();
                    }
                    
                    $fields = WShop_Add_On_Invoice::instance()->invoice_types[$invoice_type]['fields'];
                    if(!$fields){return;}
                    
                    $new_fields = array();
                    foreach ($fields as $k=>$v){
                        $new_fields["__".$k]=$v;
                        $new_fields["__".$k]['default'] = isset($fieldsval[$k])?$fieldsval[$k]:null;
                    }
                    
                    $field_api->generate_settings_html($new_fields);
                },
                'validate'=>function( $key,$field_api){
                    $invoice_type = $field_api->get_option('invoice_type');
                    if(!isset(WShop_Add_On_Invoice::instance()->invoice_types[$invoice_type]['fields'])){
                        return null;
                    }

                    $fields = WShop_Add_On_Invoice::instance()->invoice_types[$invoice_type]['fields'];
                    if(!$fields){return;}
                    $new_fields = array();
                    foreach ($fields as $k=>$v){
                        $new_fields["__".$k]=$v;
                    }
                    
                    $fieldsval = $field_api->get_option('fields');
                    if(!$fieldsval||!is_array($fieldsval)){
                        $fieldsval=array();
                    }
                    
                    $post_fields =  $field_api->validate_invoice_fields($new_fields);
                    if(!$post_fields||!is_array($post_fields)){
                        $post_fields=array();
                    }
                    foreach ($post_fields as $k=>$v){
                        $fieldsval[$k] = $v;
                    }
                    
                    return $fieldsval;
                }
            ),
            'attachment'=>array(
                'title'=>'发票附件',
                'type'=>'pdf',
                'description'=>'上传发票附件，并且文章状态改为“已发布”，用户即可收到携带发票信息的邮件'
            )
        );
    }
    public function generate_pdf_html($key, $data) {
        $field = $this->get_field_key ( $key );
        $defaults = array (
            'title' => '',
            'disabled' => false,
            'class' => '',
            'css' => '',
            'placeholder' => '',
            'type' => 'text',
            'desc_tip' => false,
            'description' => '',
            'custom_attributes' => array ()
        );
    
        $data = wp_parse_args ( $data, $defaults );
    
        ob_start ();
        ?>
	        <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
	        	<th scope="row" class="titledesc">
	        		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
	        		<?php echo $this->get_tooltip_html( $data ); ?>
	        	</th>
	        	<td class="forminp">
	        		<fieldset>
	        			<legend class="screen-reader-text">
	        				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
	        			</legend>
	        			<?php 
	        			$url =   wp_get_attachment_url($this->get_option( $key ));
	        			?>
						<p><a href="<?php echo esc_attr($url)?>" target="_blank" id="<?php echo esc_attr( $field ); ?>-file"><?php echo esc_html($url)?></a></p><br/>
						<input type="hidden" name="<?php echo esc_attr( $field ); ?>" id="<?php echo esc_attr( $field ); ?>" value="<?php echo esc_attr(  $this->get_option( $key ) ); ?>" />
						<input type="button" class="button" id="btn-<?php echo esc_attr( $field ); ?>-upload-img" value="上传PDF" />
						<a href="javascript:void(0);" style="margin-left:5px;" id="btn-<?php echo esc_attr( $field ); ?>-remove"><?php echo __('Remove',WSHOP)?></a>
						<script type="text/javascript">
						(function($){
							$('#btn-<?php echo esc_attr( $field ); ?>-upload-img').click(function() {  
								var send_attachment_bkp = wp.media.editor.send.attachment;
							    wp.media.editor.send.attachment = function(props, attachment) {
							    	$('#<?php echo esc_attr( $field ); ?>').val(attachment.id);
								    switch(attachment.mime){
								    	case 'application/pdf':
								    		$('#<?php echo esc_attr( $field ); ?>-file').css('display','block').text(attachment.url).attr('href',attachment.url);
								    		break;
								    	default:
									    	alert('只允许上传PDF文件！');
    								       return;
								    }
							       
							        wp.media.editor.send.attachment = send_attachment_bkp;
							    }
							    wp.media.editor.open();
							    return false;    
						    });   
						    $('#btn-<?php echo esc_attr( $field ); ?>-remove').click(function(){
								if(confirm('<?php echo __('Are you sure?',WSHOP)?>')){
									$('#<?php echo esc_attr( $field ); ?>').val('');
									$('#<?php echo esc_attr( $field ); ?>-file').css('display','none');
								}
							});
						})(jQuery);
						</script>
	        			
	        			<?php echo $this->get_description_html( $data ); ?>
	        		</fieldset>
	        	</td>
	        </tr>
	        <?php
			
		return ob_get_clean ();
	}
    public function get_option($key, $empty_value = null){
        if(strpos($key, "__")!==0){
            return parent::get_option($key, $empty_value);
        }
        $key = substr($key, strlen("__"));
        $invoice_type = parent::get_option('invoice_type');
        if(!isset(WShop_Add_On_Invoice::instance()->invoice_types[$invoice_type]['fields'])){
            return $empty_value;
        }
        
        $fields = WShop_Add_On_Invoice::instance()->invoice_types[$invoice_type]['fields'];
        if(!$fields){
            return $empty_value;
        }
        
        $fieldsval = parent::get_option('fields');
        if(!$fieldsval||!is_array($fieldsval)){
            $fieldsval=array();
        }
        
        if(isset($fields[$key])){
            return isset($fieldsval[$key])?$fieldsval[$key]:$empty_value;
        }
        
        return $empty_value;
    }
    
    public function get_post_types()
    {
        return array(WShop_Order_Invoice::POST_T=>'订单发票');
    }
    
    public function get_object($post){
        return new WShop_Order_Invoice($post);
    }
}

class WShop_Invoice_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;
   
    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Invoice_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="invoice";
        $this->title = '发票信息';
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
    public function init_form_fields(){
        global $post;
        $this->form_fields = array(
            'enabled'=>array(
                'title'=>__('Enabled',WSHOP),
                'type'=>'checkbox'
            )
        ); 
    }

    public function get_post_types()
    {
        $post_types= WShop_Add_On_Invoice::instance()->get_option('post_types');
  
        global $wp_post_types;
        $types = array();
        if($post_types&&$wp_post_types){
            foreach ($wp_post_types as $key=>$type){
                if(!in_array($key, $post_types)){continue;}
               
                if($type->show_ui&&$type->public){
                    $types[$type->name]=(empty($type->label)?$type->name:$type->label).'('.$type->name.')';
                }
            }
        }
    
        return apply_filters('wshop_invoice_post_types', $types);
    }

    public function get_object($post){
        return new WShop_Invoice($post);
    }
}