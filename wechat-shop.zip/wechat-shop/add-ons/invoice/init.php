<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

require_once 'abstract-xh-add-ons-api.php';
require_once 'includes/class-wshop-invoice.php';
/**
 * 手机登录
 * 
 * @author ranj
 * @since 1.0.0
 */
class WShop_Add_On_Invoice extends Abstract_WShop_Add_Ons_Invoice_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Invoice
     */
    private static $_instance = null;
    
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    
    /**

     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Invoice
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public $invoice_types=array();
    
    protected function __construct(){
        parent::__construct();
        $this->id='wshop_add_ons_invoice';
        $this->title='发票';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.3';
        $this->author=__('xunhuweb',WSHOP);
        $this->dir=  WShop_Helper_Uri::wp_dir(__FILE__);
        $this->plugin_uri='https://www.wpweixin.net';
        $this->author_uri='https://www.wpweixin.net'; 
        
        $this->init_invoice_types();
        $this->init_form_fields();
    }

    public function on_load(){
        $this->m1();
        $o = $this;
       
    }

    public function on_init(){
        $this->m2();
        $o = $this;
        add_filter('wp_count_posts', array($o,'wp_count_posts'),10,3);
    }
    
    public function wp_count_posts($counts, $type, $perm){
        if($type!=WShop_Order_Invoice::POST_T){
            return $counts;
        }
         
        $cache_key = _count_posts_cache_key( $type, $perm );
    
        global $wpdb,$wp_query;
    
        $query = "SELECT post_status, COUNT( * ) AS num_posts 
                    FROM {$wpdb->posts}
        inner join {$wpdb->prefix}wshop_order_invoice mi on mi.post_ID = {$wpdb->prefix}posts.ID
        WHERE post_type = %s and post_status!='pre-pending' ";
   
        if ( 'readable' == $perm && is_user_logged_in() ) {
            $post_type_object = get_post_type_object($type);
            if ( ! current_user_can( $post_type_object->cap->read_private_posts ) ) {
                $query .= $wpdb->prepare( " AND (post_status not in ( 'private','pre-pending') OR ( post_author = %d AND post_status = 'private' and post_status!='pre-pending' ))",
                    get_current_user_id()
                    );
            }
        }
        $query .= ' GROUP BY post_status';
    
        $results = (array) $wpdb->get_results( $wpdb->prepare( $query, $type ), ARRAY_A );
         
        $counts = array_fill_keys( get_post_stati(), 0 );
    
        foreach ( $results as $row ) {
            $counts[ $row['post_status'] ] = $row['num_posts'];
        }
    
        $counts = (object) $counts;
        return $counts;
    }
    public function wshop_order_list_title(){
        ?>
        <th style="width: 10%">发票</th>
        <?php
    }
    
    public function wshop_order_list_item($order){
        ?><td><?php
        if(isset($order->metas['invoice_id'])&&$order->metas['invoice_id']){
            $invoice = new WShop_Order_Invoice($order->metas['invoice_id']);
            if($invoice->is_load()){
                switch($invoice->post_status){
                    case 'pending':
                        ?><span style="color:red;">待开</span><?php
                        break;
                    case 'publish':
                        if($invoice->attachment){
							$url = wp_get_attachment_url($invoice->attachment);
							?><a href="<?php echo $url?>" target="_blank" download="invoice-<?php echo date('YmdHis')?>.pdf" style="color:green;">下载</a><?php
                        }else{
                            ?><span style="color:green;">已寄出</span><?php
                        }
                        
                        break;
                }
            }
        }
        ?></td><?php
    }
    
    public function get_post_type_options(){
        return WShop::instance()->payment->get_online_post_types();
    }
    
    public function register_menu($menus){
        $menus[20]=$this;
        return $menus;
    }
    
    public function register_fields(){
        WShop_Invoice_Fields::instance();
        WShop_Order_Invoice_Fields::instance();
    }
    
    public function on_install(){
        $api = new WShop_Invoice_Model();
        $api->init();
        $this->wshop_email_init();
        
    }
    
    public function wshop_email_init(){
        //======================================
        WShop_Email_Model::init_new_email('invoice-pending','待开发票','[{site_title}]待开发票 ',array(
            "{email:admin}"
        ),'有新的发票待开时，提醒管理员');
    
        WShop_Email_Model::init_new_email('invoice-pushed','发票已寄出','[{site_title}]发票已寄出',array(
            "{email:customer}"
        ),'有新的发票寄出时，提醒用户');
    }
    
    /**
     * 
     * @param int $post_ID
     * @param WP_Post $post
     * @param boolean $update
     */
    public function send_invoice_email($post_ID, $post, $update){
        if($post->post_type!=WShop_Order_Invoice::POST_T||$post->post_status!='publish'){
            return;
        }
        
        $invoice = new WShop_Order_Invoice($post_ID);
        if(!$invoice->is_load()){
            return;
        }
        $order = new WShop_Order($invoice->order_id);
        if(!$order){
            return;
        }

        if($invoice->invoice_type=='online'&&!$invoice->attachment){
            return;
        }
         
        $user_email = isset($invoice->fields['invoice_email'])&&is_email($invoice->fields['invoice_email'])?$invoice->fields['invoice_email']:null;
        if(empty($user_email)){
            $user = $post->post_author?get_user_by('id', $post->post_author):null;
            $user_email = $user&&is_email($user->user_email)?$user->user_email:null;
        }
        
        if(empty($user_email)){return;}
        
        $content =WShop::instance()->WP->requires(
            $this->dir,
            "emails/invoice-pushed.php",
            array('order'=>$order,'invoice'=>$invoice)
        );
        
        $email =new WShop_Email('invoice-pushed');
        
        return $email->send(array(
            '{email:customer}'=>$user_email
        ),$content);
    }

    public function send_new_invoice_email($error,$order){
        if(!isset($order->metas['invoice_id'])||!$order->metas['invoice_id']){
            return $error;
        }
    
        $invoice = new WShop_Order_Invoice($order->metas['invoice_id']);     
        if(!$invoice->is_load()/*||$invoice->invoice_type!='online'*/){
            return $error;
        }
 
        $content =WShop::instance()->WP->requires(
            $this->dir,
            "emails/invoice-pending.php",
            array('order'=>$order,'invoice'=>$invoice)
        );
    
        $email =new WShop_Email('invoice-pending');
        
        return $email->send(array(),$content);
    }
    
    
    public function wshop_order_complete_payment_args($args,$order,$transaction_id){
        if(!isset($order->metas['invoice_id'])||!$order->metas['invoice_id']){
            return $args;
        }
    
        global $wpdb;
        
        $args['join']['form'] ="inner join {$wpdb->prefix}wshop_order_invoice on {$wpdb->prefix}wshop_order_invoice.order_id = core_wshop_order.id
                                inner join {$wpdb->prefix}posts wshop_order_invoice_post on wshop_order_invoice_post.ID= {$wpdb->prefix}wshop_order_invoice.post_ID ";
        
        $args['set']['form'] =",wshop_order_invoice_post.post_status='pending'";
        $args['where']['form'] ="and (wshop_order_invoice_post.post_status='pre-pending' and wshop_order_invoice_post.post_type='".WShop_Order_Invoice::POST_T."')";
    
        return $args;
    }
    /**
     * 
     * @param WShop_Error $success
     * @param WShop_Order $order
     * @param WShop_Shopping_Cart $cart
     */
    public function wshop_order_extra_amount($success,$order,$cart){
        if(!WShop_Error::is_valid($success)){
            return $success;
        }
        
        //判断是否需要开发票
        $post_types = $this->get_option('post_types');
        if(!$post_types||!is_array($post_types)){
            $post_types = array();
        }
        
        if(!in_array($order->obj_type, $post_types)){
            return $success;
        }
        
        $order_items = $order->get_order_items();
        if(!$order_items){
            return $success;
        }
        
        $enable_invoice = false;
        foreach ($order_items as $item){
            $invoice = new WShop_Invoice($item->post_ID);
            if($invoice->is_load()&&$invoice->enabled=='yes'){
                $enable_invoice = true;
                break;
            }
        }
        if(!$enable_invoice){
            return $success;
        }
        $invoices = $this->get_enabled_invoice_types();
        $invoice_type = isset($_REQUEST['invoice_type'])?$_REQUEST['invoice_type']:null;
        if($invoice_type!=null&&$invoice_type=='none'){
            return $success;
        }
        
        if(!$invoice_type||!isset($invoices[$invoice_type])){
            return WShop_Error::error_custom('请选择发票信息！');
        }
        
        $fields = array(
            'title'=>$invoices[$invoice_type]['title'],
            'amount'=>$order->get_total_amount(false)
        );
        
        if($invoices[$invoice_type]['fields']&&is_array($invoices[$invoice_type]['fields'])){
            foreach ($invoices[$invoice_type]['fields'] as $k=>$v){
                $field_key = $invoice_type.'_'.$k;
                if(isset($v['validate'])){
                    $v =call_user_func_array($v['validate'],array($field_key,$v));
                    if($v && $v instanceof WShop_Error){
                        return $v;
                    }
                    $fields[$k] = $v;
                }else {
                    $val = isset($_REQUEST[$field_key])?stripslashes($_REQUEST[$field_key]):null;
                    if(isset($v['required'])&&$v['required']&&empty($val)){
                        return WShop_Error::error_custom(sprintf(__("%s is required!",WSHOP),$v['title']));
                    }
                    
                    $fields[$k] = $val;
                }
            }
        }
        
        $fee = call_user_func($invoices[$invoice_type]['fee']);
        if($fee>0){
            $order->extra_amount[]=array(
                'title'=>'发票',
                'amount'=> +$fee
            );
        }
       
        $order->add_call_after_insert(function($order,$invoice_type,$invocie,$fields){
            global $wpdb;
        
            $post_ID = wp_insert_post(array(
                'post_author'=>$order->customer_id?$order->customer_id:get_current_user_id(),
                'post_title'=>call_user_func($invocie['get_title'],$fields),
                'post_status'=>'pre-pending',
                'post_type'=>WShop_Order_Invoice::POST_T
            ),true);
            
            if(is_wp_error($post_ID)){
                return WShop_Error::wp_error($post_ID);
            }
            
            $wpdb->insert("{$wpdb->prefix}wshop_order_invoice", array(
                'post_ID'=>$post_ID,
                'order_id'=>$order->id,
                'invoice_type'=>$invoice_type,
                'fields'=>maybe_serialize($fields),
                'amount'=>$order->get_total_amount(false),
                'fee'=>call_user_func($invocie['fee']),
                'attachment'=>null
            ));
            
            if(!empty($wpdb->last_error)){
                return WShop_Error::error_custom($wpdb->last_error);
            }
            
            $invoice_id = $post_ID;
            $order->__set_metas(array('invoice_id'=>$invoice_id));
        
            return WShop_Error::success();
        },$invoice_type,$invoices[$invoice_type],$fields);
        
        return $success;
    }
    
    public function register_post_types(){
        register_post_type( WShop_Order_Invoice::POST_T,
            array(
                'labels' => array(
                    'name' => '发票',
                    'singular_name' =>'发票',
                    'add_new' => '新增',
                    'add_new_item' =>'新增发票',
                    'edit' =>  '编辑',
                    'edit_item' => '编辑发票',
                    'new_item' => '新发票',
                    'view' => '查看',
                    'view_item' => '查看发票',
                    'search_items' => '查询发票',
                    'not_found' => '未找到发票',
                    'not_found_in_trash' => '回收站中未找到发票',
                    'parent' => '父级发票'
                ),
                //决定自定义文章类型在管理后台和前端的可见性
                'public' => true,
                'wshop_ignore'=>true,
                'wshop_include'=>false,
                'menu_position' => 140,
                'exclude_from_search '=>false,
                'publicly_queryable'=>false,
                'hierarchical'=>false,
                'supports' => array( 'title', /*'excerpt', 'editor','comments', 'thumbnail','page-attributes'*/ ),
                //创建自定义分类。在这里没有定义
                //'taxonomies' => array( ),
                //启用自定义文章类型的存档功能
                'has_archive' => true,
                'show_in_menu'=>WShop_Admin::menu_tag
            ));
    }
    private function init_invoice_types(){
        $this->invoice_types = array(
            'none'=>array(
                'title'=>'无',
                'fee'=>function(){
                    return 0;
                },
                'fields'=>array()
            ),
            'online'=>array(
                'title'=>'电子发票',
                'fee'=>function(){
                    return 0;
                },
                'get_title'=>function($fields){
                    $title =isset($fields['title'])?esc_html($fields['title']):'[未知类型]';
                    $company_name =isset($fields['company'])?esc_html($fields['company']):'[未知公司]';
                    $amount = isset($fields['amount'])?esc_html($fields['amount']):'[未知金额]';
                    return apply_filters('wshop_order_invoice_title', "{$company_name}:{$title}(￥{$amount})");
                },
                'fields'=>array(
                    'company'=>array(
                        'title'=>'公司名称',
                        'required'=>true,
                        'type'=>'text'
                    ),
                    'invoice_no'=>array(
                        'title'=>'纳税识别号',
                        'required'=>true,
                        'type'=>'text'
                    ),
                    'invoice_email'=>array(
                        'title'=>'邮箱(接收电子发票)',
                        'required'=>true,
                        'type'=>'text',
                        'description'=>'电子发票以附件方式发到此邮箱',
                        'validate'=>function($k,$v){
                            $email = isset($_REQUEST[$k])?$_REQUEST[$k]:null;
                            if(empty($email)){
                                return WShop_Error::error_custom(sprintf(__("%s is required!",WSHOP),$v['title']));
                            }
                            
                            if(!is_email($email)){
                                return WShop_Error::error_custom(sprintf(__("%s is invalid!",WSHOP),$v['title']));
                            }
                            
                            return $email;
                        }
                    )
                )
            ),
            'offline'=>array(
                'title'=>'纸质发票',
                'fee'=>function(){
                    return round(floatval(WShop_Add_On_Invoice::instance()-> get_option('post_fee')),2);
                },
                'get_title'=>function($fields){
                    $title =isset($fields['title'])?esc_html($fields['title']):'[未知类型]';
                    $company_name =isset($fields['company'])?esc_html($fields['company']):'[未知公司]';
                    $amount = isset($fields['amount'])?esc_html($fields['amount']):'[未知金额]';
                    return apply_filters('wshop_order_invoice_title', "{$company_name}:{$title}(￥{$amount})");
                },
                'fields'=>array(
                    'company'=>array(
                        'title'=>'公司名称',
                        'required'=>true,
                        'type'=>'text'
                    ),
                    'invoice_no'=>array(
                        'title'=>'纳税识别号',
                        'required'=>true,
                        'type'=>'text'
                    ),
                    'shipping_address'=>array(
                        'title'=>'收件地址',
                        'required'=>true,
                        'type'=>'textarea',
                        'description'=>'纸质发票会邮寄到此地址'
                    )
                )
            )
        );
    }
    
    public function init_form_fields(){
        $this->form_fields =array(
            'invoice_type'=>array(
                'title'=>'发票类型',
                'type'=>'multiselect',
                'func'=>true,
                'options'=>array($this,'get_invoice_type_options')
            ),
            'post_fee'=>array(
                'title'=>'(纸质发票)寄送费用/￥',
                'type'=>'text',
                'default'=>'0'
            ),
            'post_types'=>array(
                'title'=>__('Bind post types',WSHOP),
                'type'=>'multiselect',
                'func'=>true,
                'options'=>array($this,'get_post_type_options')
            )
        );
    }
    
    public function get_invoice_type_options(){
        $options = array();
        foreach ($this->invoice_types as $type=>$s){
            $options[$type] = $s['title'];
        }
        
        return $options;
    }
    
    /**
     * 获取已启用的发票类型
     * @return array
     */
    public function get_enabled_invoice_types(){
        $types = $this->get_option('invoice_type');
        if(!$types||!is_array($types)){
            return null;
        }
        
        $results = array();
        foreach ($types as $t){
            $results[$t] = $this->invoice_types[$t];
        }
        return $results;
    }
    
    public function get_enabled_invoice_type_options(){
        $types = $this->get_option('invoice_type');
        if(!$types||!is_array($types)){
            return null;
        }
    
        $results = array();
        foreach ($types as $t){
            $results[$t] = $this->invoice_types[$t]['title'];
        }
        return $results;
    }
    
    public function register_membership_purchase_fields($context,$memberships){
        if(!$memberships||count($memberships)==0){
            return;
        }
        
        $invoice_types = $this->get_enabled_invoice_types();
        if(!$invoice_types||count($invoice_types)==0){
            return;
        }
        
        $post_types = $this->get_option('post_types');
        if(!$post_types||!is_array($post_types)){
            $post_types = array();
        }
        
        if(!in_array(WShop_Membership::POST_T, $post_types)){
            return;
        }
        
        $json_array = array();
        foreach ($memberships as $m){
            $invoice = new WShop_Invoice($m->post_ID);
            
            $json_array[]=array(
                'post_ID'=>$m->post_ID,
                'enabled' =>$invoice->is_load()?$invoice->enabled=='yes':false
            );
        }

        ?>
		<div id="section-invoice-<?php echo $context?>" style="display:none;">
            <div class="xh-form-group">
            	<label>发票:</label>
            	<select class="form-control" id="wshop-membership-<?php echo $context?>-invoice-type">
            		<?php foreach ($invoice_types as $k=>$v){
            		    $fee = call_user_func($v['fee']);
            		    $title = esc_html($v['title']);
            		    if($fee>0){
            		        $title .="(寄费：￥{$fee})";
            		    }
            		    ?>
            		    <option value="<?php echo esc_attr($k);?>"><?php echo $title;?></option>
            		    <?php 
            		}?>
            	</select>
    	    <script type="text/javascript">
              	(function($){
        			$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,m){
        				m.invoice_type=$('#wshop-membership-<?php echo $context?>-invoice-type').val();
        			});       
        		})(jQuery);
    		</script>
            </div>
            
            <?php foreach ($invoice_types as $k=>$v){
                 if($v['fields']){
                     $fields = array();
                     foreach ($v['fields'] as $k1=>$v1){
                         $fields[$k.'_'.$k1]=$v1;
                     }
                 }
                ?>
                <div id="wshop-membership-<?php echo $context?>-invoice-type-<?php echo $k?>" style="display:none;" class="invoice-type">
                	<?php echo WShop_Helper_Html_Form::generate_html($context, $fields)?>
                </div>
                <?php 
            }?>
             <div class="block20"></div>  
         </div>
         <script type="text/javascript">
			window.wshop_membership_invoices = <?php echo $json_array?json_encode($json_array):'[]';?>;
			(function($){
				$(document).bind('wshop_<?php echo $context?>_on_amount_change',function(){
					var post_ID = $('.wshop-membership-<?php echo $context?>.active').attr('data-id');
					for(var index=0;index<window.wshop_membership_invoices.length;index++){
						var invoice = window.wshop_membership_invoices[index];
						if(invoice.post_ID==post_ID&&invoice.enabled){
							$('#section-invoice-<?php echo $context?>').css('display','block');
							$('#wshop-membership-<?php echo $context?>-invoice-type').change();
							return;
						}
					}

					$('#section-invoice-<?php echo $context?>').css('display','none');
				});

				$('#wshop-membership-<?php echo $context?>-invoice-type').change(function(){
					var type = $(this).val();
					$('.invoice-type').css('display','none');
					$('#wshop-membership-<?php echo $context?>-invoice-type-'+type).css('display','block');
				});
				
			})(jQuery);			
		</script>
        <?php 
    }
    
}

return WShop_Add_On_Invoice::instance();
?>