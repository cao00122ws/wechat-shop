<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

/**
 * @author rain
 *
 */
class WShop_Add_On_Kaoshegong_CN extends Abstract_WShop_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Kaoshegong_Cn
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Kaoshegong_Cn
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wshop_add_ons_kaoshegong_cn';
        $this->title='kaoshegong.cn';
        $this->description='卡密：卡密代码替换成二维码';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        
    }
    
    public function on_load(){
        add_action('wshop_cdkey_field_upload', array($this,'cdkey_field_upload'),10,3);
        add_filter('wshop_cdkey_upload_codes', array($this,'wshop_cdkey_upload_codes'),10,4);
        add_filter('wshop_cdkey_code_admin_view', array($this,'wshop_cdkey_code_admin_view'),10,2);
        add_filter('wshop_require_dir', array($this,'wshop_require_dir'),10,2);
    }
    
    public function wshop_require_dir($dir,$template){
        if(!($template=='cdkey/purchase-success.php'
           ||$template=='cdkey/search-content.php'
            ||$template=='cdkey/order-received-section.php')){
            return $dir;
        }
        
        return $this->domain_dir;
    }
    
    public function wshop_cdkey_code_admin_view($html,$obj){
        $metas = maybe_unserialize($obj->metas);
        
        if($metas&&is_array($metas)&&isset($metas['type'])&&$metas['type']=='image'){
            ob_start();
            ?>
            <a href="<?php echo $metas['link']?>" target="_blank"><img src="<?php echo $metas['link']?>" style="max-width:50px;max-height:50px;"></a>
            <?php
            echo $html;
            return ob_get_clean();
        }
        
        return $html;
    }
    
    public function wshop_cdkey_upload_codes($upload_cdkey,$key,$api,$expire_date){
        $field = $api->get_field_key ( $key );
      
        if(!isset($_FILES["{$field}wsocial_qrcode_files"]['name'])||empty($_FILES["{$field}wsocial_qrcode_files"]['name'])||!is_array($_FILES["{$field}wsocial_qrcode_files"]['name'])){
            return $upload_cdkey;
        }
       
        $file_qty = count($_FILES["{$field}wsocial_qrcode_files"]['name']);
        for ($index = 0;$index<$file_qty;$index++){
            $type = isset($_FILES["{$field}wsocial_qrcode_files"]['type'][$index]);
            if(!in_array($type, array('image/png','image/jpg','image/jpeg'))){
                $api->errors[]="上传文件类型错误：必须是*.jpg,*.png格式的图片({$_FILES["{$field}wsocial_qrcode_files"]['name'][$index]})";
                return $upload_cdkey;
            }
            
            $_config =wp_get_upload_dir();
           
            $file_key = $_FILES["{$field}wsocial_qrcode_files"]['name'][$index];
            $_p = strripos($file_key, '.');
            if($_p===false){
                $api->errors[]="上传文件名不合法！({$_FILES["{$field}wsocial_qrcode_files"]['name'][$index]})";
                return $upload_cdkey;
            }
            
            $ext = substr($file_key, $_p);
            $_filename = md5(time().str_shuffle(time())).$ext;
            $filename = $_config['path'].'/'.$_filename;
            $fileurl = $_config['url'].'/'.$_filename;
            
            if(file_exists($filename)){
                $api->errors[]="保存文件时发生错误：文件名重名，请重新提交！({$_FILES["{$field}wsocial_qrcode_files"]['name'][$index]})";
                return $upload_cdkey;
            }
            
            $tmp =$_FILES["{$field}wsocial_qrcode_files"]['tmp_name'][$index];
          
            if(!@move_uploaded_file($tmp,$filename)){
                $api->errors[]="保存文件时发生错误：可能是文件目录不可写或其他原因.({$_FILES["{$field}wsocial_qrcode_files"]['name'][$index]},{$_config['path']})";
                return $upload_cdkey;
            }
            
            $upload_cdkey[]=array(
                'code'=>$file_key,
                'expire_date'=>$expire_date,
                'metas'=>array(
                    'type'=>'image',
                    'link'=>$fileurl
                )
            );
        }
       
        return $upload_cdkey;
    }
    
    public function cdkey_field_upload( $key,$api,$data){
        $field = $api->get_field_key ( $key );
        ?>
        <br/>
		<?php echo __('or',WSHOP)?>
		<br/>
		<div class="setting-row">
			<label>批量选择二维码文件<span class="wshop_field_required">*</span></label><br />
			<input type="file" multiple="multiple" name="<?php echo $field;?>wsocial_qrcode_files[]" />(*.png,*.jpg)
			<div class="description">提示：二维码文件名必须唯一(推荐顺序命名，方便管理)</div>
		</div>
		
        <?php 
    }
    
    
}

return WShop_Add_On_Kaoshegong_CN::instance();
?>