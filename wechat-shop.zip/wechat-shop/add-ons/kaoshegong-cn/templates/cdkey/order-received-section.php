<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

$request = WShop_Temp_Helper::clear('atts','templates');
$order = $request['order'];

global $wpdb;
$cdkey_items = $wpdb->get_results(
   "select *
    from {$wpdb->prefix}wshop_cdkey_item
    where purchase_order_id ={$order->id}
          and status='".WShop_Cdkey_Item::STATUS_SOLD."'");
if(!$cdkey_items||count($cdkey_items)==0){
    return;
}

?>

<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; color: #636363; border: 1px solid #e5e5e5;" border="1">
	<tbody>
	<tr class="order_item">
		<td class="td" style="text-align: left; vertical-align: middle; border: 1px solid #eee; word-wrap: break-word; color: #636363; padding: 12px;">收件人：</td>
		<td class="td" style="text-align: left; vertical-align: middle; border: 1px solid #eee; color: #636363; padding: 12px;"><?php echo  $order->get_email_receiver();?></td>
	</tr>
	<tr class="order_item">
		<td class="td" style="text-align: left; vertical-align: middle; border: 1px solid #eee; word-wrap: break-word; color: #636363; padding: 12px;"><?php echo WShop_Add_On_Cdkey::instance()->get_option('post_type_display')?></td>
		<td class="td" style="text-align: left; vertical-align: middle; border: 1px solid #eee; color: #636363; padding: 12px;">
		<ul style="list-style:none;">
		<?php 
		foreach ($cdkey_items as $cdkey_item){
		    $metas = maybe_unserialize($cdkey_item->metas);
		    if($metas&&is_array($metas)&&isset($metas['type'])&&$metas['type']=='image'){
		        ?>
        	    <li> <span class="text" style='color: #3c3c3c; font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;'><a href="<?php echo $metas['link']?>" target="_blank"><img style="max-width:200px;max-height:200px;" src="<?php echo $metas['link']?>"/></a></span></li>
        	    <?php 
            }else{
                ?>
        	    <li> <span class="text" style='color: #3c3c3c; font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;'><?php echo $cdkey_item->_code?></span></li>
        	    <?php 
            } 
		}
		?>
		</ul>
		</td>				
	</tr>
	</tbody>
</table>