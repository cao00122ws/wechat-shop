<?php 
if (! defined('ABSPATH')) {
    exit();
}


$api =WShop_Add_On_Cdkey::instance();
$transaction_id='';
if(isset($_REQUEST['id'])&&isset($_REQUEST['hash'])){
    if(!WShop::instance()->WP->ajax_validate(shortcode_atts(array(
        'hash'=>null,
        'id'=>null,
        'notice_str'=>null
    ), stripslashes_deep($_REQUEST)), $_REQUEST['hash'])){
        WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
        return ;
    }
    $order = new WShop_Order($_REQUEST['id']);
    $transaction_id =$order->is_load()?$order->transaction_id:null;
}

if( isset($_REQUEST['tid'])){
    $transaction_id = trim(stripslashes($_REQUEST['tid']));
}

$TOTAL_PURCHASE_QTY = 0;
if($transaction_id){
    global $wpdb;
    $codes =  $wpdb->get_results($wpdb->prepare(
       "select ci.*
        from {$wpdb->prefix}wshop_order o
        inner join {$wpdb->prefix}wshop_order_item oi on oi.order_id = o.id
        inner join {$wpdb->prefix}wshop_cdkey_item ci on ci.purchase_order_item_id = oi.id
        where o.transaction_id=%s
              and o.status in ('complete','processing')
              and ci.status='".WShop_Cdkey_Item::STATUS_SOLD."'", $transaction_id));
    
    $query = $wpdb->get_row($wpdb->prepare(
       "select sum(oi.qty) as total
        from {$wpdb->prefix}wshop_order o
        inner join  {$wpdb->prefix}wshop_order_item oi on oi.order_id = o.id
        where o.transaction_id=%s
              and o.status in ('complete','processing')", $transaction_id));
    $TOTAL_PURCHASE_QTY = intval($query->total);
}

$cdkey_item0 =array();
$cdkey_item1 =array();
if($codes){
    foreach ($codes as $code){
        $metas = maybe_unserialize($code->metas);
        if($metas&&is_array($metas)&&isset($metas['type'])&&$metas['type']=='image'){
            $cdkey_item1[]=$metas['link'];
        }else{
            $cdkey_item0[]=$code->_code;
        }
    }
}
?>
<style type="text/css">body{background: #f8f8f8;}</style>

 <div class="xh-layout-sm xh-posr">
	<span class="topbt"><a href="<?php echo $api->get_page_checkout_uri();?>"><?php echo $api->get_option('post_type_display')?>购买</a> <a href="<?php echo $api->get_page_checkout_uri(array('action'=>'search'));?>"><?php echo $api->get_option('post_type_display')?>查询</a></span>
     <div class="title xh-text-center">提取<?php echo $api->get_option('post_type_display')?></div>
         <p class="xh-text-center gray">请确认已复制或下载卡密后(合计:<?php echo $TOTAL_PURCHASE_QTY?>个)，关闭本页面(如果卡密个数不符，请联系管理员补单)</p>
         <form method="post" action="">
    		<div class="xh-form" style="padding-top:20px;">
                <?php 
                    if(count($cdkey_item0)>0){
                        ?><textarea class="form-control" style="min-height:200px;min-width:200px;"><?php foreach ($cdkey_item0 as $item){ echo esc_textarea($item."\r\n");}?></textarea>
                          <div style="float:right;"><a href="<?php echo $api->get_order_cdkeys_export_url($transaction_id,'csv')?>" class="xh-btn xh-btn-sm xh-btn-default">导出(.csv)</a> <a href="<?php echo $api->get_order_cdkeys_export_url($transaction_id,'txt')?>" class="xh-btn xh-btn-sm xh-btn-default">导出(.txt)</a></div>
                          <?php 
                    }
                    
                    if(count($cdkey_item1)>0){
                        ?>
                        <ul style="list-style:none;">
                        	<?php foreach($cdkey_item1 as $item){
                        	    ?>
                        	    <li><a href="<?php echo $item?>" target="_blank" ><img style="width:200px;height:200px;" src="<?php echo $item?>"/></a></li>
                        	    <?php 
                        	}?>
                        </ul>
                          <?php 
                    }
                    
                    if(count($cdkey_item0)==0&&count($cdkey_item1)==0&&!empty($transaction_id)){
                        ?>未查询到任何信息...<?php 
                    }?>
        	</div>
    	</form>  
</div>