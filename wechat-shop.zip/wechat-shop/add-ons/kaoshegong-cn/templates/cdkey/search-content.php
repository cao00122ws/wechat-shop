<?php 
if (! defined('ABSPATH')) {
    exit();
}

$context = WShop_Helper::generate_unique_id();
$api =WShop_Add_On_Cdkey::instance();
$transaction_id= isset($_REQUEST['tid'])?trim(stripslashes($_REQUEST['tid'])):null;
$codes=null;
if($transaction_id){
    global $wpdb;
    $codes =  $wpdb->get_results($wpdb->prepare("select ci.*
        from {$wpdb->prefix}wshop_order o
        inner join {$wpdb->prefix}wshop_order_item oi on oi.order_id = o.id
        inner join {$wpdb->prefix}wshop_cdkey_item ci on ci.purchase_order_item_id = oi.id
        where o.transaction_id=%s
        and o.status in ('complete','processing')
        ", $transaction_id));
}

$cdkey_item0 =array();
$cdkey_item1 =array();
if($codes){
    foreach ($codes as $code){
        $metas = maybe_unserialize($code->metas);
        if($metas&&is_array($metas)&&isset($metas['type'])&&$metas['type']=='image'){
            $cdkey_item1[]=$metas['link'];
        }else{
            $cdkey_item0[]=$code->_code;
        }
    }
}
?>
<style type="text/css">body{background: #f8f8f8;}</style>

 <div class="xh-layout-sm xh-posr">
	<span class="topbt"><a href="https://www.wpweixin.net/product/1465.html"><?php echo $api->get_option('post_type_display')?>详情</a> <a href="<?php echo $api->get_page_checkout_uri()?>"><?php echo $api->get_option('post_type_display')?>购买</a></span>
     <div class="title xh-text-center">迅虎自动发卡</div>
       <p class="xh-text-center gray">迅虎wordpress卡密,邀请码,优惠码销售插件</p>
     <form method="post" action="">
		<div class="xh-form"  style="padding-top:20px;">
		
        <div class="xh-form-group">
            <label>支付宝订单号/微信商户单号：</label>
            <input type="text" placeholder="请输入支付宝订单号/微信商户单号" class="form-control" value="<?php echo esc_attr($transaction_id)?>" name="tid" />
            <span class="xh-help-block"></span>
        </div>
            
        <div class="clearfix">
           <button class="xh-btn xh-btn-primary xh-btn-block xh-btn-lg" type="submit">查询<?php echo WShop_Add_On_Cdkey::instance()->post_type_display?></button>    
        </div>
        <div class="block20"></div>
        	<?php 
            if(count($cdkey_item0)>0){
                ?><textarea class="form-control" style="min-height:200px;min-width:200px;"><?php foreach ($cdkey_item0 as $item){ echo esc_textarea($item."\r\n");}?></textarea>
                  <div style="float:right;"><a href="<?php echo $api->get_order_cdkeys_export_url($transaction_id,'csv')?>" class="xh-btn xh-btn-sm xh-btn-default">导出(.csv)</a> <a href="<?php echo $api->get_order_cdkeys_export_url($transaction_id,'txt')?>" class="xh-btn xh-btn-sm xh-btn-default">导出(.txt)</a></div>
                  <?php 
            }
            
            if(count($cdkey_item1)>0){
                ?>
                <ul style="list-style:none;">
                	<?php foreach($cdkey_item1 as $item){
                	    ?>
                	    <li><a href="<?php echo $item?>" target="_blank" ><img style="width:200px;height:200px;" src="<?php echo $item?>"/></a></li>
                	    <?php 
                	}?>
                </ul>
                  <?php 
            }
            
            if(count($cdkey_item0)==0&&count($cdkey_item1)==0&&!empty($transaction_id)){
                ?>未查询到任何信息...<?php 
            }?>
	</div>
	</form>  
</div>