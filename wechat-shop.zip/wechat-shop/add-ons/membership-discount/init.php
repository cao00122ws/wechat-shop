<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
/**
 * @author rain
 *
 */
class WShop_Add_On_Membership_Discount extends Abstract_WShop_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Membership_Discount
     */
    private static $_instance = null;
    public $domain_url;
    public $domain_dir;
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Membership_Discount
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wshop_add_ons_membership_discount';
        $this->title='会员折扣';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';   
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->depends =array(
            'wshop_add_ons_membership'=>array(
                'title'=>__('Membership',WSHOP)
            )
        );
        
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
    }

    public function on_install(){
        global $wpdb;
        $column =$wpdb->get_row(
           "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_product'
            and table_schema ='".DB_NAME."'
					and column_name ='origional_price'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_product` add column `origional_price` decimal(18,2) NULL DEFAULT NULL;");
        }
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
    }
    
    public function on_load(){
        add_filter('wshop_product_fields0', array($this,'wshop_product_fields0'),10,3);
        add_filter('wshop_product_properties', array($this,'wshop_product_properties'),10,1);
        add_action('wshop_membership_purchase', array($this,'wshop_membership_purchase_item'),10,3);
    }
    
    /**
     * 
     * @param object $obj
     * @param WShop_Product $product
     */
    public function wshop_membership_purchase_item($html,$obj,$product){
        $origional_price = $product->get('origional_price');
        $sale_price = $product->get_single_price(false);
        if($origional_price&&$sale_price&&$origional_price>$sale_price){
            ob_start();
            ?>
            <span class="price"><?php echo $sale_price;?></span>
               <span class="title" >原价<i style="text-decoration:line-through;font-style: normal"><?php echo $origional_price?></i><br><?php echo $product->get('post_title')?></span>
               <span class="tvmp_pay_rec"><?php echo round($sale_price/($origional_price*1.0)*10)?>折</span>
            <?php 
            
            $html = ob_get_clean();
        }
        
        return $html;
    }
    
    public function wshop_product_properties($properties){
        $properties['origional_price']=0;
        return $properties;
    }
    public function wshop_product_fields0($settings,$post,$api){
        if(!$post||$post->post_type!=WShop_Membership::POST_T){return $settings;}
        $settings['origional_price']=array(
            'title'=>'商品原价',
            'type'=>'custom',
            'func'=>function($key,$api,$data){
                $field = $api->get_field_key ( $key );
                $defaults = array (
                    'title' => '',
                    'disabled' => false,
                    'class' => '',
                    'css' => '',
                    'placeholder' => '',
                    'type' => 'text',
                    'desc_tip' => false,
                    'description' => '',
                    'custom_attributes' => array ()
                );
                
                $data = wp_parse_args ( $data, $defaults );
                ?>
                <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
                	<th scope="row" class="titledesc">
                		<label for="<?php echo esc_attr( $field ); ?>"><?php echo wp_kses_post( $data['title'] ); ?></label>
                		<?php echo $api->get_tooltip_html( $data ); ?>
                	</th>
                	<td class="forminp">
                		<fieldset>
                			<legend class="screen-reader-text">
                				<span><?php echo wp_kses_post( $data['title'] ); ?></span>
                			</legend>
                			<?php $symbol =WShop_Currency::get_currency_symbol(WShop::instance()->payment->get_currency());?>
                			<?php echo $symbol?> <input class="wc_input_decimal input-text regular-input <?php echo esc_attr( $data['class'] ); ?>" type="text" name="<?php echo esc_attr( $field ); ?>" id="<?php echo esc_attr( $field ); ?>" style="<?php echo esc_attr( $data['css'] ); ?>" value="<?php echo esc_attr( ( $api->get_option( $key ) ) ); ?>" placeholder="<?php echo esc_attr( $data['placeholder'] ); ?>" <?php disabled( $data['disabled'], true ); ?> <?php echo $api->get_custom_attribute_html( $data ); ?> />
                			<?php echo $api->get_description_html( $data ); ?>
                		</fieldset>
                	</td>
                </tr>
                <?php
            }
        );
        
        return $settings;
    }
}

return WShop_Add_On_Membership_Discount::instance();
?>