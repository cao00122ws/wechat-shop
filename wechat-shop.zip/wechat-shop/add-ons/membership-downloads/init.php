<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'includes/class-wshop-membership-download.php';	
require_once 'abstract-xh-add-ons-api.php';

/**
 * @author rain
 *
 */
class WShop_Add_On_Membership_Download extends Abstract_WShop_Add_Ons_Membership_Download_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Membership_Download
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Membership_Download
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        $this->id='wshop_add_ons_membership_download';
        $this->title=__('Membership Download',WSHOP);
        $this->description='VIP才能查看下载内容，有独立的下载页面';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->plugin_uri='https://www.wpweixin.net/product/1466.html';
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        $this->depends =array(
            'wshop_add_ons_membership'=>array(
                'title'=>__('Membership',WSHOP)
            )
        );
        
        $this->init_form_fields();    
    }
   
    public function on_install(){
        $model = new WShop_Membership_Download_Model();
        $model->init();
    }
    
    public function register_fields(){
        WShop_Membership_Download_Field::instance();
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_load()
     */
    public function on_load(){
        add_filter('wshop_online_post_types',array($this,'wshop_online_post_types'),10,1);
        WShop_Query::instance()->register_endpoint('checkout', 'membership-downloads', array(
            'title'=>__('Dwonload page',WSHOP),
            'page_title'=>__('Dwonload page',WSHOP),
            'description'=>__('Endpoint for the "Checkout &rarr; Downloads page.',WSHOP)
        ),array($this,'account_membership_downloads'));
        $this->m1();
    }
    
    public function account_membership_downloads($html,$atts = array(),$content=null){
        return WShop::instance()->WP->requires($this->domain_dir, 'membership-downloads/membership-downloads.php',array(
            'atts'=>$atts,
            'content'=>$content
        ));
    }
    
    public function wshop_online_post_types($post_types){
        $types = $this->get_option('post_types');
         
        if($types){
            foreach ($types as $type){
                if(!in_array($type, $post_types)){
                    $post_types[]=$type;
                }
            }
        }
         
        return $post_types;
    }
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        $this->m2();
    }
    
    public function init_form_fields(){
        $fields =array(
            'enabled'=>array(
                'title'=>__('Enable/Disable',WSHOP),
                'type'=>'checkbox',
                'default'=>'yes'
            ),
            'post_types'=>array(
                'title'=>__('Bind post types',WSHOP),
                'type'=>'multiselect',
                'func'=>true,
    
                'options'=>array($this,'get_post_type_options')
            ),
            'new_download_page'=>array(
                'title'=>__('New download page',WSHOP),
                'type'=>'checkbox',
                'description'=>__('Enable a new download page.',WSHOP),
            )
        );
    
        $this->form_fields = apply_filters('wshop_membership_download_fields', $fields);
    }

    public function wshop_m_downloads($atts = array(),$content=null){
        if(!is_array($atts)){
            $atts = array();
        }
        return WShop_Async::instance()->async_call('wshop_m_downloads', function(&$atts,&$content){
            if(!isset($atts['post_id'])||empty($atts['post_id'])){
                if(method_exists(WShop::instance()->WP, 'get_default_post')){
                    $default_post = WShop::instance()->WP->get_default_post();
                    $atts['post_id']=$default_post?$default_post->ID:0;
                }else{
                    global $wp_query,$post;
                    $default_post=$wp_query?$wp_query->post:null;
                    if(!$default_post&&$post){
                        $default_post = $post;
                    }
                    $atts['post_id']=$default_post?$default_post->ID:0;
                }
            }
            
            if(!isset($atts['location'])||empty($atts['location'])){
                $atts['location'] =  WShop_Helper_Uri::get_location_uri();
            }
        
        },function(&$atts,&$content){
            $content = empty($content)?__('Download now',WSHOP):$content;
            if(WShop::instance()->payment->is_validate_get_pay_per_view($atts['post_id'],$atts['roles'])){
                $member_download = new WShop_Membership_Download($atts['post_id']);
                if(!$member_download->is_load()){
                    return null;
                }
                
                //跳到新的下载页面去
                $api =WShop_Add_On_Membership_Download::instance();
                if(apply_filters('wshop_membership_download_new_download_page', 'yes'===$api->get_option('new_download_page','no'),$atts)){
                    $params = array();
                    $page_url =WShop_Helper_Uri::get_uri_without_params(WShop::instance()->WP->get_checkout_uri('membership-downloads'),$params);
                    $request['location'] =$atts['location'];
                    $request['post_id'] = $atts['post_id'];
                    $request['roles'] = $atts['roles'];
                    $request = WShop::instance()->generate_request_params($request);
                
                    $link = apply_filters('wshop_membership_download_url_membership_downloads',$page_url."?".http_build_query(array_merge($params,$request)),$atts);
                    ob_start();
                    ?><a href="<?php echo $link;?>" class="<?php echo isset($atts['class'])?esc_attr($atts['class']):""?>" style="<?php echo isset($atts['style'])?esc_attr($atts['style']):""?>"><?php echo do_shortcode($content);?></a><?php
                   return ob_get_clean();
                }
               
                return do_shortcode($member_download->downloads);
            }
          
            return WShop::instance()->WP->requires(WShop_Add_On_Membership_Download::instance()->domain_dir, 'membership-downloads/membership-downloads-btn.php',array(
                'content'=>$content,
                'atts'=>$atts
            ));
        },
       array(
           'style'=>null,
           'post_id'=>0,
           'roles'=>null,
           'class'=>'xh-btn xh-btn-success xh-btn-sm',
           'location'=>null
       ),
        $atts,
        $content); 
    }
}

if(!function_exists('wshop_m_downloads')){
    function wshop_m_downloads($atts = array(),$content=null,$echo = true){
        $html = WShop_Add_On_Membership_Download::instance()->wshop_m_downloads($atts,$content);
        if($echo){echo $html;}else{return $html;}
    }
}
return WShop_Add_On_Membership_Download::instance();
?>