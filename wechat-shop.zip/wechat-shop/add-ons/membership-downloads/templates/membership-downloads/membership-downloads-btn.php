<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

$data = WShop_Temp_Helper::clear('atts','templates');

$atts = $data['atts'];
$content = $data['content'];
$link = WShop_Add_On_Membership::instance()->get_page_checkout_url();
$post_id = isset($atts['post_id'])?$atts['post_id']:null;
if(!$post_id){return;}
$product = new WShop_Product($post_id );
if(!$product->is_load()){
    return;
}
?>
<div style="border:1px dashed #f80000;padding:15px;text-align: center;">隐藏内容：
<span style="color: red">********,<?php echo WShop::instance()->WP->requires(WSHOP_DIR, 'button-purchase.php',array(
    'content'=>"支付".$product->get_single_price(true),
    'atts'=>$atts
));?></span>下载
<?php 
if(function_exists('wshop_dialog_membership_checkout')){
    ?> ，或者<a href="<?php echo $link;?>" class="xh-btn xh-btn-warning xh-btn-sm" style="<?php echo isset($atts['style'])?esc_attr($atts['style']):""?>">升级VIP</a>可下载全站内容。<?php 
}
?>           
</div>

