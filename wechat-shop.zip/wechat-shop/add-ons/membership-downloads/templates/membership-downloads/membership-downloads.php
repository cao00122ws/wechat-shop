<?php
if (! defined('ABSPATH')) {
    exit();
}

$request = WShop_Async::instance()->shortcode_atts(array(
    'location'=>null,
    'post_id'=>0,
    'roles'=>null
), stripslashes_deep($_REQUEST));

$params = WShop_Async::instance()->shortcode_atts(array(
    'notice_str'=>null
), stripslashes_deep($_REQUEST));

if(!WShop::instance()->WP->ajax_validate(array_merge($request,$params), isset($_REQUEST['hash'])?$_REQUEST['hash']:null,false)){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(701),false,false);
    return;
}

if(!WShop::instance()->payment->is_validate_get_pay_per_view($request['post_id'],$request['roles'])){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
    return;
}

$membership_download = new WShop_Membership_Download($request['post_id']);
if(!$membership_download->is_load()){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
    return;
}
$post = $membership_download->get_post();

?>
<style type="text/css">
body{background:#f8f8f8;padding-top:100px;}
</style>
<div class="xh-layout">
    <div class="title clearfix" style="text-align: center;"> <span ><?php echo __('Download page',WSHOP)?></span> </div>  
    <div class="xh-form ">
    <div class="block20"></div>
    <div class="xh-title clearfix "><?php echo __('Download content',WSHOP)?></div>
    <div class="block20"></div>
  
    <dl class="xh-prolist clearfix ">
    	<dt><a href=""><img src="<?php echo $membership_download->get_img()?>" alt=""></a></dt>
        <dd>
            <div class="ptitle"><?php echo $post->post_title?></div>
            
            <p class="price"><small class="gray"><?php echo $membership_download->post_excerpt?></small></p>
        </dd>
	</dl>
     <div class="xh-title clearfix "><?php echo __('Download details',WSHOP)?></div>    
        <dl class="xh-prolist clearfix" style="margin:10px 0;">
           <?php echo do_shortcode($membership_download->downloads);?> 
       </dl> 
    </div>
</div>
 <div style="text-align: center"> <a href="<?php echo $request['location']?>" class="xh-btn xh-btn-warring"><?php echo __('Go back',WSHOP)?></a> <a href="<?php echo home_url('/')?>" class="xh-btn xh-btn-warring "><?php echo __('Back to home',WSHOP)?></a></div>

