<?php
if (! defined('ABSPATH')) {
    exit();
}

global $wpdb;
$member_ship_items = $wpdb->get_results(
    "select *
     from {$wpdb->prefix}wshop_membership d
     inner join {$wpdb->prefix}posts p on p.ID = d.post_ID
     where p.post_status='publish'");

$member_ships=array();
if($member_ship_items){
    foreach ($member_ship_items as $item){
        $member_ships[]=new WShop_Membership($item);
    }
}
?>

<div class="xh-layout">
<div class="title clearfix" style="text-align: center;">  <span ><?php echo __('Membership upgrade',WSHOP)?></span> </div>

<div class="xh-form ">
    <div class="xh-title clearfix "><?php echo __('Membership purchase:',WSHOP)?></div>
    <div class="block20"></div>
     <div class="block20"></div>
    <div class="xh-member clearfix">
    <?php foreach ($member_ships as $member_ship){
        $product = new WShop_Product($member_ship->post_ID);
        if(!$product->is_load()){
            continue;
        }
        ?> <div class="xh-memberitem">
                <p class="htitle"><?php echo $member_ship->post_title?></p>
                <p class="xh-price"><?php echo $product->get_single_price(true) ?></p>
               
                <p><?php wshop_btn(array('post_id'=>$member_ship->post_ID))?></p>
           </div>
        <?php 
    }?>
    </div>
         <div class="block20"></div>
        
    </div>
    
</div>
 <div style="text-align: center"> 
<?php 
$location = isset($_GET['location'])?esc_url_raw($_GET['location']):null;
if(!empty($location)){
 ?><a href="<?php echo $location?>" class="xh-btn xh-btn-warring"><?php echo __('Go back',WSHOP)?></a><?php 
}?>

<a href="<?php echo home_url('/')?>" class="xh-btn xh-btn-warring "><?php echo __('Back to home',WSHOP)?></a></div>
