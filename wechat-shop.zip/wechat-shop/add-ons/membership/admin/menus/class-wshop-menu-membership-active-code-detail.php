<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WShop_Membership_Active_Code_Edit_Detail{
   
    public function __construct(){
    }
   
	public function view() {
	    $api = WShop_Add_On_Membership::instance();
        ?>
         <h1 class="wp-heading-inline"><?php echo __('Publish membership active code',WSHOP)?></h1>
           <div id="form-msg" style="display:none;"></div>     
                <hr class="wp-header-end">
                
                <form name="post" action="post.php" method="post" id="post">
                
                <div id="poststuff">
                <div id="post-body" class="metabox-holder columns-2">
                
                <div id="postbox-container-1" class="postbox-container">
                <div id="side-sortables" class="meta-box-sortables ui-sortable">
                
                    <div id="submitdiv" class="postbox ">
          
                        <h2 class="hndle ui-sortable-handle"><span><?php echo __('Publish',WSHOP)?></span></h2>
                        <div class="inside">
                        <div class="submitbox" id="submitpost">
                        
                        <div id="minor-publishing">
                        
                        
                        <div id="minor-publishing-actions">
                        <div id="save-action">
                        </div>
                        <div class="clear"></div>
                    </div>
                
                    <div id="misc-publishing-actions">
                    
                       
                    
                    </div>
                    <div class="clear"></div>
                </div>
                
                <div id="major-publishing-actions">
               
                <div id="publishing-action">
                	<span class="spinner"></span>
            		<input name="save" type="button" class="button button-primary button-large" id="form-publish" value="<?php echo __('Publish',WSHOP)?>">
                </div>
                <div class="clear"></div>
                </div>
                </div>
                
                </div>
                </div>
                </div>
                </div>
                
                
                <div id="postbox-container-2" class="postbox-container">
                <div id="normal-sortables" class="meta-box-sortables ui-sortable">
                <div id="wshop-coupon-data" class="postbox ">
                <h2 class="hndle ui-sortable-handle"><span><?php echo __('Upgrade data',WSHOP)?></span></h2>
                	<div class="inside">
                
                		<div id="coupon_options" class="panel-wrap coupon_data">
                
                			<div class="wc-tabs-back"></div>
                
                			<div id="general_coupon_data" class="panel wshop_options_panel" style="display: block;">
                			
                			<p class="form-field discount_type_field ">
                        		<label><?php echo __('Membership',WSHOP)?></label>
                        		
                        		<select id="form-membership" class="select short" >
                        			<option><?php echo __('Select...',WSHOP)?></option>
                        			<?php 
                        			 global $wpdb;
                                    $memberships = $wpdb->get_results(
                                       "select m.post_ID,
                                               p.post_title
                                        from {$wpdb->prefix}wshop_membership m
                                        inner join {$wpdb->prefix}posts p on p.ID = m.post_ID
                                        where p.post_status ='publish'
                                              and p.post_type='".WShop_Membership::POST_T."';");
                                    if($memberships){
                                        foreach ( $memberships as $membership ) {
                                            ?><option value="<?php echo $membership->post_ID?>"><?php echo $membership->post_title;?></option><?php
                                        }
                                    }?>
                        		</select> 
                			</p>
                		
                    		<p class="form-field expiry_date_field ">
                        		<label><?php echo __('Expire date',WSHOP)?></label>
                        		<input type="text" class="short" id="form-expire-date"   placeholder="<?php echo __('Unlimit',WSHOP)?>"/> 
                    		</p>
                    		
                    		<p class="form-field expiry_date_field ">
                        		<label><?php echo __('Qty',WSHOP)?></label>
                        		<input type="number" max="200" class="short" id="form-qty" value="1" > 
                    		</p>
                    		
                    		<script type="text/javascript">
                           		(function($){
                              		$(function(){
                              			$("#form-expire-date").focus(function() {
                                  			WdatePicker({
                                  				dateFmt: 'yyyy-MM-dd HH:mm'
                                  			});
                                  		});
                                  	});
                               	})(jQuery);
                    	   </script>
                		</div>
                		
                		<div class="clear"></div>
                		</div>
                	</div>
                </div>
                </div>
                <div id="advanced-sortables" class="meta-box-sortables ui-sortable"></div></div>
                </div><!-- /post-body -->
                <br class="clear">
                </div><!-- /poststuff -->
                </form>
                
            <script type="text/javascript">
				(function($){
					$('#form-publish').click(function(){
						var data ={
							membership_id:$('#form-membership').val(),
							expire_date:$.trim($('#form-expire-date').val()),
							qty:$('#form-qty').val()	
						};

						$.ajax({
							url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'save_or_update_membership_active_code'),true,true)?>',
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:data,
							dataType:'json',
							beforeSend:function(){
								$('#wpbody-content').loading();
							},
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert( e.errmsg );
									return;
								}

								location.href='<?php echo WShop_Admin::instance()->get_current_admin_url()?>';
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo __( 'Ajax error while adding upgrade', WSHOP); ?>' );
							}
						});
					});
				})(jQuery);
			</script>    
		<?php
	}
}
