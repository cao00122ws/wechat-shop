<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WShop_Membership_Active_Code_List {

	public function view() {
		global $wpdb;
		
		?>
		<div class="wrap">
		<h2>
		<?php esc_html_e( 'Membership active code', WSHOP );?>
		<a class="add-new-h2" href="<?php echo WShop_Admin::instance()->get_current_admin_url(array(
			    'view'=>'edit'
			))?>"><?php echo esc_html__( 'Add New', WSHOP )?> </a>
		</h2>
		
   		<?php
   		$table = new WShop_Membership_Active_Code_List_Table();
   		$table->process_action();
   		$table->views();
   		$table->prepare_items();
   		?>
    	<form method="post" id="form-membership">
    	   <input type="hidden" name="page" value="<?php echo WShop_Admin::instance()->get_current_page()->get_page_id()?>"/>
           <input type="hidden" name="section" value="<?php echo WShop_Admin::instance()->get_current_menu()->id?>"/>
           <input type="hidden" name="tab" value="<?php echo WShop_Admin::instance()->get_current_submenu()->id?>"/>
       		<div class="order-list" id="wshop-order-list">
       		<?php $table->display();
       		$api =WShop_Add_On_Membership::instance();
       		?>
       		</div>
    	</form>
    	<script type="text/javascript">
			(function($){
				window.wshop_view ={
					delete:function(id){
						if(confirm('<?php echo __('Are you sure?',WSHOP)?>'))
						this._update(id,'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'membership_active_code_delete'),true,true)?>');
					},
					_update:function(id,ajax_url){
						if(!ajax_url){
							return;
						}
						
						$('#wpbody-content').loading();
						$.ajax({
							url:ajax_url,
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:{
								id:id
							},
							dataType:'json',
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert(e.errmsg);
									return;
								}
								
								location.reload();
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo esc_attr( 'System error while modifing membership active code!', WSHOP); ?>');
							}
						});
					}
				};
		})(jQuery);
	</script>
	</div>
	<?php
	}
}

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class WShop_Membership_Active_Code_List_Table extends WP_List_Table {
    
    /**
     * @var WP_User
     */
    private $status;
    
    private $code;
    private $mid;
    
    /**
     * @param array $args
     * @since 1.0.0
     */
    public function __construct( $args = array() ) {
        parent::__construct( $args );
   
        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable ,'amount');
        
        $this->status = isset($_REQUEST['status'])?$_REQUEST['status']:null;
        if(!$this->status||!in_array($this->status, array(
            WShop_Membership_Active_Code::Active,
            WShop_Membership_Active_Code::Used
        ))){
            $this->status='';
        }
        $this->code  = isset($_REQUEST['code'])?$_REQUEST['code']:null;
        $this->mid  = isset($_REQUEST['mid'])?intval($_REQUEST['mid']):0;
    }
    
    public function process_action(){
        $bulk_action = $this->current_action();
        if(empty($bulk_action)){
            return;
        }
         
        check_admin_referer( 'bulk-' . $this->_args['plural'] );
         
        $mids   = isset($_POST['mids'])?$_POST['mids']:null;;
        if(!$mids||!is_array($mids)){
            return;
        }
    
        foreach ($mids as $member_item_id){
            $error =WShop_Membership_Helper::update_membership_Active_Code($member_item_id, $bulk_action);
            if(!WShop_Error::is_valid($error)){
                ?><div class="notice notice-error is-dismissible"><p><?php echo $error->errmsg;?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
                return;
            }
       }
    }
    
    function get_sortable_columns() {
        return array(
            'created_date' => array( 'created_date', false )
        );
    }

    
    function prepare_items() {
        $sort_column  = empty( $_REQUEST['orderby'] ) ? null : $_REQUEST['orderby'];
        $sort_columns = array_keys( $this->get_sortable_columns() );

        if (!$sort_column|| ! in_array( strtolower( $sort_column ), $sort_columns ) ) {
            $sort_column = 'created_date';
        }

        $sort = isset($_REQUEST['order']) ? $_REQUEST['order']:null;
        if(!in_array($sort, array('asc','desc'))){
            $sort ='desc';
        }
        $mid = $this->mid>0?" and o.membership_id={$this->mid}":"";

        global $wpdb;
        $sql=  "select count(o.code) as qty
                from `{$wpdb->prefix}wshop_membership_active_code` o
                where (%s='' or o.code=%s)
                      $mid
                      and (%s='' or o.status=%s);";
  
        $query = $wpdb->get_row($wpdb->prepare($sql, 
            $this->code,$this->code,
            $this->status,$this->status));

        $total = intval($query->qty);
        $per_page = 50;
        
        $total_page = intval(ceil($total/($per_page*1.0)));
        $this->set_pagination_args( array(
            'total_items' => $total,
            'total_pages' => $total_page,
            'per_page' => $per_page,
            'status'=>$this->status,
            'code'=>$this->code,
            'mid'=>$this->mid
        ));

        if(isset($_REQUEST['export'])&&$_REQUEST['export']==1){
            $dir = '/uploads/'.date_i18n('Y/m/d').'/';
            if(!WShop_Install::instance()->load_writeable_dir(WP_CONTENT_DIR.$dir,true)){
                wp_die(sprintf(__('Create file dir failed when export post data(%s)!',WSHOP),WP_CONTENT_DIR.$dir));
                exit;
            }
             
            $filename = time().'.csv';
            $fp = fopen(WP_CONTENT_DIR. $dir.$filename, 'w');
            if(!$fp){
                wp_die(sprintf(__('Create file failed when export post data(%s)!',WSHOP),WP_CONTENT_DIR. $dir.$filename));
                exit;
            }
            fputcsv($fp, array('激活码','会员等级'));
            $page =$total_page;
            try {
              while($page-->0){
                  $_page_index = $total_page-$page;
                  
                  $start = ($_page_index-1)*$per_page;
                  $end = $per_page;
                  $sql =
                 "select o.code,
                         s.post_title as membership_name
                  from `{$wpdb->prefix}wshop_membership_active_code` o
                  left join {$wpdb->prefix}posts s on s.ID = o.membership_id
                  where (%s='' or o.code=%s)
                          $mid
                          and (%s='' or o.status=%s)
                  order by o.$sort_column $sort
                  limit $start,$end;";
              
                  $items = $wpdb->get_results($wpdb->prepare($sql,
                      $this->code,$this->code,
                      $this->status,$this->status));
                  
                  if($items){
                      try {
                          foreach ($items as $item){
                              fputcsv($fp, array($item->code,$item->membership_name));
                          }
              
                      } catch (Exception $e) {
                          WShop_Log::error($e);
                          if($fp){
                              fclose($fp);
                          }
                          wp_die($e->getMessage());
                          exit;
                      }
                  }
              }
            } catch (Exception $e) {
                WShop_Log::error($e);
                if($fp){
                  fclose($fp);
                }
                wp_die($e->getMessage());
                exit;
            }
          
            fclose($fp);
            ?>
            <script type="text/javascript">
				jQuery(function(){
					location.href='<?php echo WP_CONTENT_URL. $dir.$filename?>';
				});
			</script>
            <?php 
        }
        
        $pageIndex =$this->get_pagenum();
        $start = ($pageIndex-1)*$per_page;
        $end = $per_page;
        $sql = "select *
                from `{$wpdb->prefix}wshop_membership_active_code` o
                 where (%s='' or o.code=%s)
                       $mid
                      and (%s='' or o.status=%s)
                order by o.$sort_column $sort
                limit $start,$end;";
        $items = $wpdb->get_results($wpdb->prepare($sql,
            $this->code,$this->code,
            $this->status,$this->status));   
        if($items){
            foreach ($items as $item){
                $this->items[]=new WShop_Membership_Active_Code($item);
            }
        }
    }
    
    function extra_tablenav( $which ) {
       if($which!='top'){
           return;
       }
       ?>
      
		<label><input name="code" type="text" placeholder="code" value="<?php echo esc_attr($this->code)?>" /></label>
        <select name="mid">
            <option value=""><?php echo __('Select membership...',WSHOP)?></option>
            <?php 
            global $wpdb;
            $memberships = $wpdb->get_results(
                "select m.post_ID,
                    p.post_title
                from {$wpdb->prefix}wshop_membership m
                inner join {$wpdb->prefix}posts p on p.ID = m.post_ID
                where p.post_status ='publish'
                    and p.post_type='".WShop_Membership::POST_T."';");
            if($memberships){
                foreach ( $memberships as $item) {
                    ?><option value="<?php echo esc_attr($item->post_ID);?>" <?php echo $this->mid==$item->post_ID?"selected":"";?>><?php echo esc_html($item->post_title);?></option><?php 
                }
            }
            ?>
        </select>
        <select name="status">
            <option value=""><?php echo __('Select status...',WSHOP)?></option>
            <?php 
            foreach ( array(
                WShop_Membership_Active_Code::Active=>'未使用',
                WShop_Membership_Active_Code::Used=>'已使用'
            ) as $key=>$label) {
                ?><option value="<?php echo esc_attr($key);?>" <?php echo $this->status==$key?"selected":"";?>><?php echo esc_html($label);?></option><?php 
            }
            ?>
        </select>
        <input type="hidden" name="export" id="hidden-membership-export"/> 
		<input type="button" id="btn-membership-search" class="button" style="line-height: 32px;height:32px;" value="<?php echo __('Filter',WSHOP)?>">
		<input type="button" id="btn-membership-export" class="button button-primary" style="line-height: 32px;height:32px;" value="<?php echo __('Export',WSHOP)?>">
       <script type="text/javascript">
			//
			(function($){
				$('#btn-membership-export').click(function(){
					$('#hidden-membership-export').val(1);
					$('#form-membership').submit();
				});

				$('#btn-membership-search').click(function(){
					$('#hidden-membership-export').val(0);
					$('#form-membership').submit();
				});
			})(jQuery);
		</script>
       <?php 
    }
    
    function get_bulk_actions() {
        return array(
            'membership_active_code_delete' => esc_html__( 'Delete permanently', WSHOP ),
        );
    }

    function get_columns() {
        return array(
            'cb'                    => '<input type="checkbox" />',
            'code'                  =>__('Code', WSHOP ),
            'membership'            =>__('Membership',WSHOP),
            'status'                =>__('Status',WSHOP),
            'detail'                =>__('Detail',WSHOP),
            'expire_date'           =>__('Expire date',WSHOP),
            'created_date'          =>__('Created date',WSHOP)
        );
    }

    function single_row_columns( $item ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();

        foreach ( $columns as $column_name => $column_display_name ) {
            $classes = "$column_name column-$column_name";
            if ( $primary === $column_name ) {
                $classes .= ' has-row-actions column-primary';
            }

            if ( in_array( $column_name, $hidden ) ) {
                $classes .= ' hidden';
            }

            $data = 'data-colname="' . wp_strip_all_tags( $column_display_name ) . '"';

            $attributes = "class='$classes' $data";

            if ( 'cb' === $column_name ) {
                echo '<th scope="row" class="check-column">';
                echo $this->column_cb( $item );
                echo '</th>';
            }  elseif ( method_exists( $this, '_column_' . $column_name ) ) {
                echo call_user_func(
                    array( $this, '_column_' . $column_name ),
                    $item,
                    $classes,
                    $data,
                    $primary
                    );
            } elseif ( method_exists( $this, 'column_' . $column_name ) ) {
                echo "<td $attributes>";
                echo call_user_func( array( $this, 'column_' . $column_name ), $item );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            } else {
                echo "<td $attributes>";
                echo $this->column_default( $item, $column_name );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            }
        }
    }

	function column_cb( $form ) {
		$form_id = $form->code;
		?>
		<label class="screen-reader-text" for="cb-select-<?php echo esc_attr( $form_id ); ?>"><?php _e( 'Select codes' ); ?></label>
		<input type="checkbox" class="wshop_list_checkbox" name="mids[]" value="<?php echo esc_attr( $form_id ); ?>" />
		<?php
	}

	public function column_code($item){
	   ?><code><?php echo $item->code?></code><?php 
    }
	
	public function column_status($item){
	    switch($item->status){
	        case WShop_Membership_Active_Code::Active:
	            echo "<span>未使用</span>";
	            break;
	        case WShop_Membership_Active_Code::Used:
	            echo "<span style=\"color:gray\">已使用</span>";
	            break;
	    }
    }
    
    public function column_detail($item){
        if($item->user_ID){
            $user = get_user_by('id', $item->user_ID);
            if($user){
                ?><div>用户:<?php echo $user->display_name?></div><?php 
            }
        }
        
        if($item->purchase_order_id){
            ?><div>订单ID:<?php echo $item->purchase_order_id?></div><?php 
        }
        
        if($item->purchase_order_item_id){
            $order_item = new WShop_Order_Item($item->purchase_order_item_id);
            $post = $order_item?get_post($order_item->post_ID):null;
            if($post){
                ?><div>角色:<?php echo $post->post_title?></div><?php
            }
        }
    }
    
    public function column_created_date($item){
        ?>
        <time><?php echo date('Y-m-d H:i',$item->created_date)?></time>
        <?php 
    }
    
    public function column_expire_date($item){
        ?>
        <time><?php echo $item->expire_date?date('Y-m-d H:i',$item->expire_date):null;?></time>
        <?php 
    }
    
    public function column_membership($item){
        $membership = $item->membership_id?new WShop_Membership($item->membership_id):null;
        if($membership){
            echo $membership->get('post_title');
        }
    }
        
	function no_items() {
		echo __( "You don't have any membership active code!", WSHOP ) ;
	}
}
