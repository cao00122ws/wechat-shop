<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WShop_Membership_Upgrade_History_List {

	public function view() {
		global $wpdb;
		?>
		<div class="wrap">
		<h2><?php esc_html_e( 'Membership upgrade history', WSHOP );?></h2>
   		<?php
   		$table = new WShop_Membership_Upgrade_History_List_Table();
   		$table->views();
   		$table->prepare_items();
   		?>
    	<form method="get" id="form-wshop-order">
    	   <input type="hidden" name="page" value="<?php echo WShop_Admin::instance()->get_current_page()->get_page_id()?>"/>
           <input type="hidden" name="section" value="<?php echo WShop_Admin::instance()->get_current_menu()->id?>"/>
           <input type="hidden" name="tab" value="<?php echo WShop_Admin::instance()->get_current_submenu()->id?>"/>
       		<div class="order-list" id="wshop-order-list">
       		<?php $table->display(); ?>
       		</div>
    	</form>
	</div>
	<?php
	}
}

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class WShop_Membership_Upgrade_History_List_Table extends WP_List_Table {
    
    /**
     * @var WP_User
     */
    private $customer;
    private $role;
    
    /**
     * @param array $args
     * @since 1.0.0
     */
    public function __construct( $args = array() ) {
        parent::__construct( $args );
        $this->customer =isset($_REQUEST['cid'])?get_user_by('id', intval($_REQUEST['cid'])):null;
        $this->role = isset($_REQUEST['role'])?sanitize_key(isset($_REQUEST['role'])):null;
        
        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable ,'amount');     
    }
    
    public function process_action(){
        $bulk_action = $this->current_action();
        if(empty($bulk_action)){
            return;
        }
         
        check_admin_referer( 'bulk-' . $this->_args['plural'] );
         
        $membership_ids   = isset($_POST['membership_ids'])?$_POST['membership_ids']:null;;
        if(!$membership_ids||!is_array($membership_ids)){
            return;
        }
     
    }
    
    function get_sortable_columns() {
        return array(
            'user'=>array('user_ID',false),
            'created_time' => array( 'created_time', false ),
            'expire_date' => array( 'expire_date', false ),
        );
    }

    
    function prepare_items() {
        $sort_column  = empty( $_REQUEST['orderby'] ) ? null : $_REQUEST['orderby'];
        $sort_columns = array_keys( $this->get_sortable_columns() );

        if (!$sort_column|| ! in_array( strtolower( $sort_column ), $sort_columns ) ) {
            $sort_column = 'created_time';
        }

        $sort = isset($_REQUEST['order']) ? $_REQUEST['order']:null;
        if(!in_array($sort, array('asc','desc'))){
            $sort ='desc';
        }

        $sql_user = empty($this->customer)?"":" and o.user_ID={$this->customer->ID} ";
       
        global $wpdb;
        $sql=  "select count(o.user_ID) as qty
                from `{$wpdb->prefix}wshop_membership_item_history` o
                inner join `{$wpdb->prefix}users`u on u.ID = o.user_ID
                where (%s='' or o.role=%s)
                      $sql_user;";
        
        $query = $wpdb->get_row($wpdb->prepare($sql, $this->role,$this->role));

        $total = intval($query->qty);
        $per_page = 50;
        
        $total_page = intval(ceil($total/($per_page*1.0)));
        $this->set_pagination_args( array(
            'total_items' => $total,
            'total_pages' => $total_page,
            'per_page' => $per_page,
            'cid'=>$this->customer?$this->customer->ID:null,
            'role'=>$this->role
        ));

        $pageIndex =$this->get_pagenum();
        $start = ($pageIndex-1)*$per_page;
        $end = $per_page;

        $sql = "select *
                from `{$wpdb->prefix}wshop_membership_item_history` o
                inner join `{$wpdb->prefix}users`u on u.ID = o.user_ID
                 where (%s='' or o.role=%s)
                      $sql_user
                order by o.$sort_column $sort
                limit $start,$end;";
     
        $items = $wpdb->get_results($wpdb->prepare($sql, $this->role,$this->role));   
        if($items){
            foreach ($items as $item){
                $this->items[]=new WShop_Membership_Item($item);
            }
        }
    }
    
    function extra_tablenav( $which ) {
       if($which!='top'){
           return;
       }
       ?><style type="text/css">.select2-container {width: 200px !important;}</style>
       <select class="wshop-search" data-type='customer' name="cid" data-sortable="true" data-placeholder="<?php echo __( 'Search for a customer(ID/user_login)&hellip;', WSHOP); ?>" data-allow_clear="true">
			<?php 
			if($this->customer){
			    ?>
			    <option value="<?php echo $this->customer->ID?>">
			    	<?php echo $this->customer->user_login;?>
			    </option>
			    <?php 
			}
			?>
		</select>
        <select name="role">
        <option value=""><?php echo __('Select...',WSHOP)?></option>
        <?php 
        $editable_roles = array_reverse( get_editable_roles() );
        
        $results = array();
        foreach ( $editable_roles as $role => $details ) {
            $name = translate_user_role($details['name'] );
            ?><option value="<?php echo esc_attr($role);?>" <?php echo $this->role==$role?"selected":"";?>><?php echo esc_html($name);?></option><?php 
        }
        
        ?>
        </select>
		<input type="submit" class="button" style="line-height: 32px;height:32px;" value="<?php echo __('Filter',WSHOP)?>">
       <?php 
    }
  
    function get_columns() {
        return array(
            'cb'                    => '<input type="checkbox" />',
            'user'                  =>__('User', WSHOP ),
            'role'                  =>__('Current role',WSHOP),
            'last_role'                  =>__('Last role',WSHOP),
            'expire_date'           =>__('Expire date',WSHOP),
            'purchase'              =>__('Order info',WSHOP),
            'created_time'          =>__('Created date',WSHOP)
        );
    }

    function single_row_columns( $item ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();

        foreach ( $columns as $column_name => $column_display_name ) {
            $classes = "$column_name column-$column_name";
            if ( $primary === $column_name ) {
                $classes .= ' has-row-actions column-primary';
            }

            if ( in_array( $column_name, $hidden ) ) {
                $classes .= ' hidden';
            }

            $data = 'data-colname="' . wp_strip_all_tags( $column_display_name ) . '"';

            $attributes = "class='$classes' $data";

            if ( 'cb' === $column_name ) {
                echo '<th scope="row" class="check-column">';
                echo $this->column_cb( $item );
                echo '</th>';
            }  elseif ( method_exists( $this, '_column_' . $column_name ) ) {
                echo call_user_func(
                    array( $this, '_column_' . $column_name ),
                    $item,
                    $classes,
                    $data,
                    $primary
                    );
            } elseif ( method_exists( $this, 'column_' . $column_name ) ) {
                echo "<td $attributes>";
                echo call_user_func( array( $this, 'column_' . $column_name ), $item );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            } else {
                echo "<td $attributes>";
                echo $this->column_default( $item, $column_name );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            }
        }
    }

	function column_cb( $form ) {
		$form_id = $form->id;
		?>
		<label class="screen-reader-text" for="cb-select-<?php echo esc_attr( $form_id ); ?>"><?php _e( 'Select user',WSHOP ); ?></label>
		<input type="checkbox" class="wshop_list_checkbox" name="membership_ids[]" value="<?php echo esc_attr( $form_id ); ?>" />
		<?php
	}

	public function column_user($item){
	    ?>
        <a target="_blank" href="<?php get_edit_user_link($item->user_ID)?>"><?php echo $item->user_login?></a>
        <?php 
    }
	
	public function column_role($item){
	   echo $item->role_name."  ({$item->role})";
    }
    
    public function column_last_role($item){
        echo $item->last_role_name."  ({$item->last_role})";
    }
    public function column_expire_date($item){
        ?>
        <time><?php echo !$item->expire_date?"--" :date('Y-m-d H:i',$item->expire_date)?></time>
        <?php 
    }
    
    public function column_created_time($item){
        ?>
        <time><?php echo date('Y-m-d H:i',$item->created_time)?></time>
        <?php 
    }
    
    public function column_purchase($item){
         if($item->purchase_order_id){
                echo __('Order:',WSHOP)?><a href="<?php echo admin_url("admin.php?page=wshop_page_order&section=menu_order_default&tab=menu_order_default_settings&view=edit&id={$item->purchase_order_id}")?>" target="_blank">#<?php echo $item->purchase_order_id;?></a> <?php
         }
    }
	
	function no_items() {
		echo __( "You don't have any membership upgrade history!", WSHOP ) ;
	}
}
