<?php

if ( ! defined ( 'ABSPATH' ) ) {
	die();
}

class WShop_Membership_Upgrade_List {

	public function view() {
		global $wpdb;
		?>
		<div class="wrap">
		<h2>
		<?php esc_html_e( 'Upgrade', WSHOP );?>
		<a class="add-new-h2" href="<?php echo WShop_Admin::instance()->get_current_admin_url(array(
			    'view'=>'edit'
			))?>"><?php echo esc_html__( 'Add New', WSHOP )?> </a>
		</h2>
		<div class="description" style="display:none;">请设置linux/win定时服务:<code>curl <?php echo WShop::instance()->ajax_url('xunhuweb_cron',false,false);?></code></div>
   		<?php
   		$table = new WShop_Membership_Upgrade_List_Table();
   		$table->process_action();
   		$table->views();
   		$table->prepare_items();
   		?>
    	<form method="get" id="form-wshop-order">
    	   <input type="hidden" name="page" value="<?php echo WShop_Admin::instance()->get_current_page()->get_page_id()?>"/>
           <input type="hidden" name="section" value="<?php echo WShop_Admin::instance()->get_current_menu()->id?>"/>
           <input type="hidden" name="tab" value="<?php echo WShop_Admin::instance()->get_current_submenu()->id?>"/>
       		<div class="order-list" id="wshop-order-list">
       		<?php $table->display();
       		$api =WShop_Add_On_Membership::instance();
       		?>
       		</div>
    	</form>
    	<script type="text/javascript">
			(function($){
				window.wshop_view ={
					delete:function(id){
						if(confirm('<?php echo __('Are you sure?',WSHOP)?>'))
						this._update_order(id,'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'membership_item_delete'),true,true)?>');
					},
					_update_order:function(id,ajax_url){
						if(!ajax_url){
							return;
						}
						
						$('#wpbody-content').loading();
						$.ajax({
							url:ajax_url,
							type:'post',
							timeout:60*1000,
							async:true,
							cache:false,
							data:{
								id:id
							},
							dataType:'json',
							complete:function(){
								$('#wpbody-content').loading('hide');
							},
							success:function(e){
								if(e.errcode!=0){
									alert(e.errmsg);
									return;
								}
								
								location.reload();
							},
							error:function(e){
								console.error(e.responseText);
								alert('<?php echo esc_attr( 'System error while modifing membership!', WSHOP); ?>');
							}
						});
					}
				};
		})(jQuery);
	</script>
	</div>
	<?php
	}
}

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class WShop_Membership_Upgrade_List_Table extends WP_List_Table {
    
    /**
     * @var WP_User
     */
    public $customer;
    public $role;
    public $is_show_expired;
    
    /**
     * @param array $args
     * @since 1.0.0
     */
    public function __construct( $args = array() ) {
        parent::__construct( $args );
        $this->customer =isset($_REQUEST['cid'])?get_user_by('id', intval($_REQUEST['cid'])):null;
        $this->role = isset($_REQUEST['role'])?sanitize_key($_REQUEST['role']):null;
        $this->is_show_expired = isset($_REQUEST['is_show_expired'])&&$_REQUEST['is_show_expired']=='yes'?true:false;
        
        $columns               = $this->get_columns();
        $hidden                = array();
        $sortable              = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable ,'amount');
        
    }
    
    public function process_action(){
        $bulk_action = $this->current_action();
        if(empty($bulk_action)){
            return;
        }
         
        check_admin_referer( 'bulk-' . $this->_args['plural'] );
         
        $membership_ids   = isset($_POST['membership_ids'])?$_POST['membership_ids']:null;;
        if(!$membership_ids||!is_array($membership_ids)){
            return;
        }
     
        foreach ($membership_ids as $member_item_id){
            
            $error =WShop_Membership_Helper::update_membership_item($member_item_id, $bulk_action);
            if(!WShop_Error::is_valid($error)){
                ?><div class="notice notice-error is-dismissible"><p><?php echo $error->errmsg;?></p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php echo esc_attr('Ignore this notice.',WSHOP)?></span></button></div><?php
                return;
            }
       }
    }
    
    function get_sortable_columns() {
        return array(
            'user'=>array('user_ID',false),
            'created_date' => array( 'created_date', false ),
            'expire_date' => array( 'expire_date', false ),
        );
    }

    
    function prepare_items() {
        $sort_column  = empty( $_REQUEST['orderby'] ) ? null : $_REQUEST['orderby'];
        $sort_columns = array_keys( $this->get_sortable_columns() );

        if (!$sort_column|| ! in_array( strtolower( $sort_column ), $sort_columns ) ) {
            $sort_column = 'user_ID';
        }

        $sort = isset($_REQUEST['order']) ? $_REQUEST['order']:null;
        if(!in_array($sort, array('asc','desc'))){
            $sort ='desc';
        }

        $sql_user = empty($this->customer)?"":" and o.user_ID={$this->customer->ID} ";
        $sql_show_expired ='';
        if(!$this->is_show_expired){
            $sql_show_expired=" and (o.expire_date is null or o.expire_date>".time().")";
        }
        
        global $wpdb;
        $sql=  "select count(o.user_ID) as qty
                from `{$wpdb->prefix}wshop_membership_item` o
                inner join {$wpdb->prefix}wshop_membership m on m.post_ID = o.membership_id
                inner join `{$wpdb->prefix}users`u on u.ID = o.user_ID
                where (%s='' or o.role=%s)
                      $sql_show_expired
                      $sql_user;";
  
        $query = $wpdb->get_row($wpdb->prepare($sql, $this->role,$this->role));

        $total = intval($query->qty);
        $per_page = 50;
        
        $total_page = intval(ceil($total/($per_page*1.0)));
        $this->set_pagination_args( array(
            'total_items' => $total,
            'total_pages' => $total_page,
            'per_page' => $per_page,
            'cid'=>$this->customer?$this->customer->ID:null,
            'role'=>$this->role,
            'is_show_expired'=>$this->is_show_expired
        ));

        $pageIndex =$this->get_pagenum();
        $start = ($pageIndex-1)*$per_page;
        $end = $per_page;

        $sql = "select *
                from `{$wpdb->prefix}wshop_membership_item` o
                inner join {$wpdb->prefix}wshop_membership m on m.post_ID = o.membership_id
                inner join `{$wpdb->prefix}users`u on u.ID = o.user_ID
                where (%s='' or o.role=%s)
                       $sql_show_expired
                       $sql_user
                order by o.$sort_column $sort
                limit $start,$end;";
        $items = $wpdb->get_results($wpdb->prepare($sql, $this->role,$this->role));   
        if($items){
            foreach ($items as $item){
                $this->items[]=new WShop_Membership_Item($item);
            }
        }
    }
    
    function extra_tablenav( $which ) {
       if($which!='top'){
           return;
       }
       ?><style type="text/css">.select2-container {width: 200px !important;}</style>
       <select  class="wshop-search" data-type='customer' name="cid" data-sortable="true" data-placeholder="<?php echo __( 'Search for a customer(ID/user_login)&hellip;', WSHOP); ?>" data-allow_clear="true">
			<?php 
			if($this->customer){
			    ?>
			    <option value="<?php echo $this->customer->ID?>">
			    	<?php echo $this->customer->user_login;?>
			    </option>
			    <?php 
			}
			?>
		</select>
		<label><input name="is_show_expired" <?php echo $this->is_show_expired?"checked":""?> value="yes" type="checkbox" /> 显示已过期</label>
        <select name="role">
        <option value=""><?php echo __('Select...',WSHOP)?></option>
        <?php 
        $editable_roles = array_reverse( get_editable_roles() );
        
        $results = array();
        foreach ( $editable_roles as $role => $details ) {
            $name = translate_user_role($details['name'] );
            ?><option value="<?php echo esc_attr($role);?>" <?php echo $this->role==$role?"selected":"";?>><?php echo esc_html($name);?></option><?php 
        }
        
        ?>
        </select>
		<input type="submit" id="btn-search" class="button" style="line-height: 32px;height:32px;" value="<?php echo __('Filter',WSHOP)?>">
		<input type="submit" id="btn-export" class="button button-primary" style="line-height: 32px;height:32px;" value="导出">
		<input type="hidden" name="__wshop_member_export__" value="0" id="search-export" />
		<script type="text/javascript">
			(function($){
				$('#btn-search').click(function(){
					$('#form-wshop-order').attr('method','GET');
					$('#search-export').val(0);
				});

				$('#btn-export').click(function(){
					$('#search-export').val(1);
					$('#form-wshop-order').attr('method','POST');
				});
			})(jQuery);
		</script>
       <?php 
    }
    
    function get_bulk_actions() {
        return array(
            'delete' => esc_html__( 'Delete permanently', WSHOP ),
        );
    }

    function get_columns() {
        return array(
            'cb'                    => '<input type="checkbox" />',
            'user'                  =>__('User', WSHOP ),
            'membership'            =>__('Membership',WSHOP),
            'expire_date'           =>__('Expire date',WSHOP),
            'created_date'          =>__('Created date',WSHOP)
        );
    }

    function single_row_columns( $item ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();

        foreach ( $columns as $column_name => $column_display_name ) {
            $classes = "$column_name column-$column_name";
            if ( $primary === $column_name ) {
                $classes .= ' has-row-actions column-primary';
            }

            if ( in_array( $column_name, $hidden ) ) {
                $classes .= ' hidden';
            }

            $data = 'data-colname="' . wp_strip_all_tags( $column_display_name ) . '"';

            $attributes = "class='$classes' $data";

            if ( 'cb' === $column_name ) {
                echo '<th scope="row" class="check-column">';
                echo $this->column_cb( $item );
                echo '</th>';
            }  elseif ( method_exists( $this, '_column_' . $column_name ) ) {
                echo call_user_func(
                    array( $this, '_column_' . $column_name ),
                    $item,
                    $classes,
                    $data,
                    $primary
                    );
            } elseif ( method_exists( $this, 'column_' . $column_name ) ) {
                echo "<td $attributes>";
                echo call_user_func( array( $this, 'column_' . $column_name ), $item );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            } else {
                echo "<td $attributes>";
                echo $this->column_default( $item, $column_name );
                echo $this->handle_row_actions( $item, $column_name, $primary );
                echo "</td>";
            }
        }
    }

	function column_cb( $form ) {
		$form_id = $form->ID;
		?>
		<label class="screen-reader-text" for="cb-select-<?php echo esc_attr( $form_id ); ?>"><?php _e( 'Select membership' ); ?></label>
		<input type="checkbox" class="wshop_list_checkbox" name="membership_ids[]" value="<?php echo esc_attr( $form_id ); ?>" />
		<?php
	}

	public function column_user($item){
	    $edit_url = WShop_Admin::instance()->get_current_admin_url(array('view'=>'edit','id'=>$item->user_ID));
	    ?>
        <a target="_blank" href="<?php echo get_edit_user_link($item->user_ID)?>"><?php echo $item->user_login?></a>
        <div class="row-actions">
         	  <span class="edit"><a href="<?php echo $edit_url;?>"><?php echo __('Edit',WSHOP)?></a> | </span>
              <span class="delete"><a href="javascript:void(0);" onclick="window.wshop_view.delete(<?php echo $item->user_ID;?>);" ><?php echo __('Delete permanently',WSHOP)?></a></span>
         </div>
        <?php 
    }
    public function column_membership($item){
        $wshop_current_membership = new WShop_Membership($item->membership_id);
        
        echo $wshop_current_membership->get('post_title')."  ({$wshop_current_membership->get('role')})";
    }
	
    
    public function column_expire_date($item){
        ?>
        <time><?php echo !$item->expire_date?"--" :date('Y-m-d H:i',$item->expire_date)?></time>
        <?php 
    }
    
    public function column_created_date($item){
        ?>
        <time><?php echo date('Y-m-d H:i',$item->created_date)?></time>
        <?php 
    }
   
	function no_items() {
		echo __( "You don't have any membership upgrade!", WSHOP ) ;
	}
}
