<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Menu_Membership_Upgrade_Page extends Abstract_WShop_Settings_Page{    
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }
    
    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='add_ons_page_membership_upgrade';
        $this->title=__('Membership manage',WSHOP);
        
        if(isset($_POST['__wshop_member_export__'])&&$_POST['__wshop_member_export__']=='1'){
            $dir = '/uploads/'.date_i18n('Y/m/d').'/';
            if(!WShop_Install::instance()->load_writeable_dir(WP_CONTENT_DIR.$dir,true)){
                wp_die(sprintf(__('Create file dir failed when export post data(%s)!',WSHOP),WP_CONTENT_DIR.$dir));
                exit;
            }
        
            $filename = time().'.csv';
            $fp = @fopen(WP_CONTENT_DIR. $dir.$filename, 'w');
            if(!$fp){
                wp_die(sprintf(__('Create file failed when export post data(%s)!',WSHOP),WP_CONTENT_DIR. $dir.$filename));
                exit;
            }
        
            $header =array(
                '用户ID',
                '用户昵称',
                '会员等级',
                '过期时间',
                '创建时间'
            );
            fputcsv($fp, $header);
        
            require_once 'class-wshop-menu-membership-upgrade-list.php';
            $api = new WShop_Membership_Upgrade_List_Table();
        
            $sort_column  = empty( $_REQUEST['orderby'] ) ? null : $_REQUEST['orderby'];
            $sort_columns = array_keys( $api->get_sortable_columns() );
        
            if (!$sort_column|| ! in_array( strtolower( $sort_column ), $sort_columns ) ) {
                $sort_column = 'user_ID';
            }
        
            $sort = isset($_REQUEST['order']) ? $_REQUEST['order']:null;
            if(!in_array($sort, array('asc','desc'))){
                $sort ='desc';
            }
        
            $sql_user = empty($api->customer)?"":" and o.user_ID={$api->customer->ID} ";
            $sql_show_expired ='';
            if(!$api->is_show_expired){
                $sql_show_expired=" and (o.expire_date is null or o.expire_date>".time().")";
            }
            try {
                global $wpdb;
                $sql=  "select count(o.user_ID) as qty
                from `{$wpdb->prefix}wshop_membership_item` o
                inner join {$wpdb->prefix}wshop_membership m on m.post_ID = o.membership_id
                inner join `{$wpdb->prefix}users`u on u.ID = o.user_ID
                where (%s='' or o.role=%s)
                $sql_show_expired
                $sql_user;";
        
                $query = $wpdb->get_row($wpdb->prepare($sql, $api->role,$api->role));
        
                $total = intval($query->qty);
                $per_page = 50;
        
                $total_page = intval(ceil($total/($per_page*1.0)));
        
                $pageIndex =1;
                while($pageIndex<=$total_page){
                    $start = ($pageIndex-1)*$per_page;
                    $end = $per_page;
        
                    $sql = "select *
                    from `{$wpdb->prefix}wshop_membership_item` o
                    inner join {$wpdb->prefix}wshop_membership m on m.post_ID = o.membership_id
                    inner join `{$wpdb->prefix}users`u on u.ID = o.user_ID
                    where (%s='' or o.role=%s)
                    $sql_show_expired
                    $sql_user
                    order by o.$sort_column $sort
                    limit $start,$end;";
                    $items = $wpdb->get_results($wpdb->prepare($sql, $api->role,$api->role));
                    if($items){
                        foreach ($items as $item){
                            $item=new WShop_Membership_Item($item);
                            $user = get_userdata($item->user_ID);
                            if(!$user){continue;}
        
                            $wshop_current_membership = new WShop_Membership($item->membership_id);
                            if(!$wshop_current_membership->is_load()){continue;}
        
        
                            $line = array(
                                $item->user_ID,
                                $user->user_login,
                                $wshop_current_membership->get('post_title')."  ({$wshop_current_membership->get('role')})",
                                !$item->expire_date?"--" :date('Y-m-d H:i',$item->expire_date),
                                date('Y-m-d H:i',$item->created_date)
                                );
                            fputcsv($fp, $line);
                        }
                    }
        
                    $pageIndex++;
                }
            } catch (Exception $e) {
                if($fp){
                    fclose($fp);
                }
                wp_die($e->getMessage());
                exit;
            }
        
            fclose($fp);
             
            $file_size =filesize(WP_CONTENT_DIR. $dir.$filename);
            if($file_size>1024*1024*3){
                wp_die('导出文件过大，请手动<a href="'.WP_CONTENT_URL. $dir.$filename.'">下载</a>');
                exit;
            }
        
            header('Content-type: application/octet-stream');
            header('Content-Disposition: attachment; filename="'.$filename.'"');
            header("Content-Length: ". $file_size);
            readfile(WP_CONTENT_DIR. $dir.$filename);
            exit;
        }
    }
    
    /* (non-PHPdoc)
     * @see Abstract_WShop_Settings_Menu::menus()
     */
    public function menus(){
        return apply_filters("wshop_admin_page_{$this->id}",array(
            WShop_Menu_Membership_Edit::instance(),
            WShop_Menu_Membership_Active_Code_Edit::instance()
        ));
    }
}
class WShop_Menu_Membership_Active_Code_Edit extends Abstract_WShop_Settings_Menu{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='add_ons_menu_membership_active_code';
        $this->title=__('Membership active code',WSHOP);
    }

    /* (non-PHPdoc)
     * @see Abstract_WShop_Settings_Menu::menus()
     */
    public function menus(){
        return apply_filters("wshop_admin_menu_{$this->id}", array(
            WShop_Menu_Membership_Active_Code_Settings::instance()
        ));
    }
}
/**
 * @since 1.0.0
 * @author ranj
 */
class WShop_Menu_Membership_Edit extends Abstract_WShop_Settings_Menu{
    /**
     * Instance
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * Instance
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    /**
     * 菜单初始化
     *
     * @since  1.0.0
     */
    private function __construct(){
        $this->id='add_ons_menu_membership_upgrade_edit';
        $this->title=__('Membership manage',WSHOP);
    }

    /* (non-PHPdoc)
     * @see Abstract_WShop_Settings_Menu::menus()
     */
    public function menus(){
        return apply_filters("wshop_admin_menu_{$this->id}", array(
            WShop_Menu_Membership_Upgrade_Settings::instance(),
            WShop_Menu_Membership_Upgrade_History_Settings::instance(),
            
        ));
    }
}
 
class WShop_Menu_Membership_Active_Code_Settings extends Abstract_WShop_Settings {
    /**
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    private function __construct(){
        $this->id='add_ons_modal_membership_active_code_settings';
        $this->title=__('Membership active code',WSHOP);
    }

    public function admin_form_start(){}
     
    public function admin_options(){
        if(isset($_REQUEST['view'])&&$_REQUEST['view']=='edit'){
            require_once 'class-wshop-menu-membership-active-code-detail.php';
            $api = new WShop_Membership_Active_Code_Edit_Detail();
            $api->view();
            return;
        }
        require_once 'class-wshop-menu-membership-active-code-list.php';
        $api = new WShop_Membership_Active_Code_List();
        $api->view();
        return;
    }

    public function admin_form_end(){}
}

class WShop_Menu_Membership_Upgrade_Settings extends Abstract_WShop_Settings {
    /**
     * @since  1.0.0
     */
    private static $_instance;
    
    /**
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    private function __construct(){
        $this->id='add_ons_modal_membership_upgrade_settings';
        $this->title=__('Current membership',WSHOP);
        
        
    }

    public function admin_form_start(){}
     
    public function admin_options(){
        if(isset($_REQUEST['view'])&&$_REQUEST['view']=='edit'){
            require_once 'class-wshop-menu-membership-upgrade-detail.php';
            $api = new WShop_Membership_Upgrade_Edit_Detail(isset($_REQUEST['id'])?$_REQUEST['id']:null);
            $api->view();
            return;
        }
        require_once 'class-wshop-menu-membership-upgrade-list.php';
        $api = new WShop_Membership_Upgrade_List();
        $api->view();
        return;
	}
	
    public function admin_form_end(){} 
}

class WShop_Menu_Membership_Upgrade_History_Settings extends Abstract_WShop_Settings {
    /**
     * @since  1.0.0
     */
    private static $_instance;

    /**
     * @since  1.0.0
     */
    public static function instance() {
        if ( is_null( self::$_instance ) )
            self::$_instance = new self();
            return self::$_instance;
    }

    private function __construct(){
        $this->id='add_ons_modal_membership_upgrade_history_settings';
        $this->title=__('Upgrade history',WSHOP);
    }

    public function admin_form_start(){}
     
    public function admin_options(){
       
        require_once 'class-wshop-menu-membership-upgrade-history-list.php';
        $api = new WShop_Membership_Upgrade_History_List();
        $api->view();
        return;
    }

    public function admin_form_end(){}
}
?>