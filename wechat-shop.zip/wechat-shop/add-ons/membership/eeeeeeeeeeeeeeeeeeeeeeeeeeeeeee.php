<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class Abstract_WShop_Add_Ons_Membership_Api extends Abstract_WShop_Add_Ons{
    public $u;
    public $i;
    public $k;
    protected function __construct(){
        $o = $this;
        $o->u = WSHOP_URL;
        $o->i = WShop_Install::instance()->get_plugin_options();
        $o->k=WShop::$license_id;
    }
    /**
     * 执行 on_load()
     */
    public function m1(){
        $o=$this;
        $o->m0(function($o){
            add_filter('wshop_cart_item_validate', array($o,'wshop_cart_item_validate'),10,4);
            add_action('wshop_membership_willbe_expired', array($o,'wshop_membership_willbe_expired'),10,1);
            add_action('wshop_membership_have_expired', array($o,'wshop_membership_have_expired'),10,1);
            add_action('wshop_membership_upgraded', array($o,'wshop_membership_upgraded'),10,1);
            add_action('wshop_email_init', array($o,'wshop_email_init'), 10);
            add_action('wshop_shopping_cart_item_added', array($o,'wshop_shopping_cart_item_added'),10,2);
            add_filter('wshop_order_membership_received_url', array($o,'wshop_order_membership_received_url'),10,2);
            add_filter('wshop_order_received_url', array($o,'wshop_order_received_url'),10,2);
            add_filter('wshop_order_membership_complete_payment_args', array($o,'wshop_order_complete_payment_args'),10,3);
            
            add_action('wshop_footer', array($o,'wshop_footer'),10,1);
            add_filter('uc_usercenter_content_membership', array($o,'uc_usercenter_content_membership'),10,1);
            add_action('uc_usercenter_content_btns', array($o,'uc_usercenter_content_btns'),10);
            
            add_filter('wshop_admin_pages', function($m){
                require_once 'admin/menus/class-wshop-menu-membership-upgrade.php';
                $m[35]=WShop_Menu_Membership_Upgrade_Page::instance();
                return $m;
            },10,1);
            
            add_filter('wshop_checkout_tab_membership', array($o,'wshop_checkout_tab_membership'),10,1);
            
            add_filter('wshop_product_single_price_html', array($o,'membership_discount_price'),11,4);
            
            add_filter('wshop_order_extra_amount', array($o,'wshop_order_extra_amount'),10,3);
        },function($o){
        });   
    }
    
    /**
     * 执行 on_init()
     */
    public function m2(){
        $o=$this;
        $o->m0(function($o){
            add_filter( 'manage_users_columns', array( $o, 'manage_users_columns' ) );
            add_filter( 'manage_users_custom_column', array( $o, 'manage_users_custom_column' ), 10, 3 );
            add_filter('wshop_unlimit_roles', array($o,'wshop_unlimit_roles'),10,1);
            add_filter('wshop_page_templates', array($o,'wshop_page_templates'),10,1);
            add_filter('wshop_admin_menu_menu_default_modal',array($o,'wshop_admin_menu_menu_default_modal'),10,1);
            $o->setting_uris=array();
            $o->setting_uris['settings']=array();
            $o->setting_uris['license']=array();
            $o->setting_uris['settings']['title']=__('Settings',WSHOP);
            $o->setting_uris['settings']['url']=admin_url('admin.php?page=wshop_page_default&section=menu_default_modal&sub=wshop_add_ons_membership');
            
            $api = WShop_Install::instance();
            $o->setting_uris['license']['title']=__('Change license',WSHOP);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);            
           
        },function($o){
            $o->setting_uris=array();
            $o->setting_uris['license']=array();
           
            $api = WShop_Install::instance();
            $o->setting_uris['license']['title']=__('License',WSHOP);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);
        });
    }

    public function m0($func_success,$func_fail){
	    $o = $this;
	    $website=$o->u;
	    $website = strtolower($website);
	    $license_id = $o->id;
	    if(strpos($website, 'http://')===0){
	        $website = substr($website, 7);
	    }else if(strpos($website, 'https://')===0){
	        $website = substr($website, 8);
	    }
	   
	    //去掉二级目录
	    if(strpos($website, '/')!==false){
	        $websites = explode('/', $website);
	        $website = $websites[0];
	    }
	    $prewebsite =$website;
	    $info = $o->i;
	    $license =$info&&isset($info[$o->id])?$info[$o->id]:null;
	    $licenses= $license?explode('=', $license):array();
	    $license =count($licenses)>0?$licenses[0]:null;
	    $expire=count($licenses)>1?$licenses[1]:null;
	    
        $id=$o->id;
	    $bk=0;
	    while (true){
	        $str =$expire."|".$website."|".$id; 
	        $str =md5($str);
	        $b =0;
	        for ($i=0;$i<strlen($str);$i++){
	            $b+= ord($str[$i]);
	        }
	     
	        $xx=md5($str.$b)==$license;
	        $o->ia=$xx;
	        if($xx){
	            if($func_success){
	                $func_success($o);
	            }
	            break;
	        }
    
            if(substr_count($website,'.')<=1){ 
                if($bk<count($o->k)){
                    $website=$prewebsite;
                    $license =$info&&isset($info['license'])?$info['license']:null;
                    $licenses= $license?explode('=', $license):array();
                    $license =count($licenses)>0?$licenses[0]:null;
                    $expire=count($licenses)>1?$licenses[1]:null;
                    $id = $o->k[$bk++];
                    continue;
                }
                
                if($func_fail){
                    $func_fail($o);
                }
                break;
            }
    
            $index = strpos($website, '.');
            $website = substr($website, $index+1);
	    } 
	}
}