<?php 

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Membership_Active_Code extends WShop_Object{
    const POST_T='wshop_membership_active_code';
    public function __construct($obj=null){
        parent::__construct($obj);
    }

    const Active ='A';
    const Used = 'D';
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_membership_active_code';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_membership_active_code_properties', array(
            'code'=>null,
            'membership_id'=>null,
            'purchase_order_id'=>null,
            'purchase_order_item_id'=>null,
            'expire_date'=>null,
            'created_date'=>null,
            'status'=>null,
            'user_ID'=>null
        ));
    }
    /**
     * {@inheritDoc}
     * @see WShop_Object::is_auto_increment()
     */
    public function is_auto_increment()
    {
        return false;
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_primary_key()
     */
    public function get_primary_key()
    {
        return 'code';
    }
}  


?>