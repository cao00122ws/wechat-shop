<?php 

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Membership extends WShop_Post_Object{
    const POST_T='wshop_membership';
    
    public $role;
    public $valid_time;
    public $purchase_discount;
    
    public function __construct($obj=null){
        parent::__construct($obj);
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_membership';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_membership_properties', array(
            'post_ID'=>null,
            'role'=>null,
            'valid_time'=>null,
            'purchase_discount'=>0
        ));
    }
    
    public function discount_amount($amount){
        return self::__discount_amount($amount,$this->purchase_discount);
    }
    
    public static function __discount_amount($amount,$purchase_discount){
        if(preg_match("/^\d+(\.\d+)?\%$/", $purchase_discount)){
            return round($amount*floatval(substr($purchase_discount, 0,-1))*0.01,2);
        }
        
        return round($amount-floatval($purchase_discount),2);
    }
    
    public function discount_format(){
        return self::__discount_format($this->purchase_discount);
    }
    
    public static function __discount_format($purchase_discount){
        if(preg_match("/^\d+(\.\d+)?\%$/", $purchase_discount)){
            return round(floatval(substr($purchase_discount, 0,-1)),2).'%';
        }
        
        $amount = round($purchase_discount,2);
        if($amount<=0){
            return '--';
        }
        
        return WShop_Currency::get_currency_symbol(WShop::instance()->payment->get_currency()).WShop_Helper_String::get_format_price($amount);
       
    }
}

class WShop_Membership_Item extends WShop_Object{
   
    public function get_obj_by($field_name,$field_val,$cache = false){
        //do not cache
        
        global $wpdb;
        $table_name ="{$wpdb->prefix}".$this->get_table_name();
        $primary_key = $this->get_primary_key();
    
        return $wpdb->get_row($wpdb->prepare(
           "select *
            from $table_name t
            inner join {$wpdb->prefix}users u on u.ID = t.user_ID
            where t.{$field_name}=%s
            limit 1;", $field_val));
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::is_auto_increment()
     */
    public function is_auto_increment()
    {
        // TODO Auto-generated method stub
        return false;
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_primary_key()
     */
    public function get_primary_key()
    {
        // TODO Auto-generated method stub
        return 'user_ID';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_membership_item';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_membership_item_properties', array(
            'user_ID'=>null,
            'role'=>null,
            'role_name'=>null,
            'last_role'=>null,
            'last_role_name'=>null,
            'membership_id'=>null,
            'expire_date'=>null,
            'created_date'=>current_time('timestamp'),
            'expire_warning'=>0
        ));
    }
    
    /**
     * 判断是否是高级会员
     */
    public function is_member(){
        return $this->is_load()&&$this->membership_id&&(!$this->expire_date||$this->expire_date>=current_time( 'timestamp' ));
    }
    
    public function get_role_name(){
        $role_name = $this->get('role_name');
        if(empty($role_name)){
            return $this->get('role');
        }
        
        return $role_name;
    }
    
    public function get_last_role_name(){
        $role_name = $this->get('last_role_name');
        if(empty($role_name)){
            return $this->get('last_role');
        }
    
        return $role_name;
    }
    
    /**
     * 
     * @param WShop_Membership $membership
     */
    public function set_expire_date($membership){
        if(!$membership->is_load()){
            throw new Exception('Membership info is unload!');
        }

        $valid_time = absint($membership->valid_time);
        if($valid_time<=0){
            $this->expire_date=null;
            return $this;
        }
        
        
        $year = absint($membership->valid_time/(12*30*24*60*60));
        $total_month = absint($membership->valid_time%(12*30*24*60*60));
        $month =  absint($total_month/(30*24*60*60));
        $total_day =absint($total_month%(30*24*60*60));
        $day = absint($total_day/(24*60*60));
        $total_hour =absint($total_day%(24*60*60));
        $hour =absint( $total_hour/(60*60));
        
        $now =current_time('timestamp');
        //如果用户已过期，那么设置过期时间为当前时间，方便叠加
        
        $this->expire_date = $this->expire_date?absint($this->expire_date):0;
        if( $this->expire_date<$now){
            $this->expire_date=$now;
        }
        
        //当前用户角色已不匹配，那么自动还原过期时间
        $user = get_userdata($this->user_ID);
        if(!$user){
            throw new Exception('userdata is not found!');
        }
        
        if(!$user->roles||!is_array($user->roles)){
            $user->roles=array();
        }
        
        if(!in_array($membership->role, $user->roles)){
            $this->expire_date=$now;
        }
        
        $this->expire_date = strtotime("+{$year} year +{$month} months +{$day} day +{$hour} hours", $this->expire_date);
       
        return $this;
    }
}

class WShop_Membership_Item_History extends WShop_Object{
    public function __construct($obj=null){
        parent::__construct($obj);
    }
    /**
     * {@inheritDoc}
     * @see WShop_Object::is_auto_increment()
     */
    public function is_auto_increment()
    {
        // TODO Auto-generated method stub
        return true;
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_primary_key()
     */
    public function get_primary_key()
    {
        // TODO Auto-generated method stub
        return 'id';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_membership_item_history';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {  
        // TODO Auto-generated method stub
        return apply_filters('wshop_membership_item_history_properties', array(
            'id'=>0,
            'user_ID'=>null,
            'role'=>null,
            'role_name'=>null,
            'last_role'=>null,
            'last_role_name'=>null,
            'membership_id'=>0,
            'purchase_order_id'=>null,
            'purchase_order_item_id'=>null,
            'expire_date'=>null,
            'created_time'=>current_time( 'timestamp')
        ));
    }

}

class WShop_Membership_Model extends Abstract_WShop_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        $collate=$this->get_collate();
        global $wpdb;
        //角色
        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_membership` (
        	`post_ID` BIGINT(20) NOT NULL,
        	`role` VARCHAR(32) NOT NULL,
        	`valid_time` BIGINT(20) NULL DEFAULT NULL,
        	`purchase_discount` VARCHAR(16) NULL DEFAULT NULL,
        	PRIMARY KEY (`post_ID`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_membership'
                  and table_schema ='".DB_NAME."'
			      and column_name ='purchase_discount'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_membership` add column `purchase_discount` VARCHAR(16) NULL DEFAULT NULL;");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
        
        //用户角色存档
        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_membership_item` (
            	`user_ID` BIGINT(20) NOT NULL,
            	`membership_id` BIGINT(20) NOT NULL,
            	`role_name` text NULL DEFAULT NULL,
            	`role` VARCHAR(64) NULL DEFAULT NULL,
            	`last_role_name` text NULL DEFAULT NULL,
            	`last_role` VARCHAR(64) NULL DEFAULT NULL,
            	`expire_date` BIGINT(20) NULL DEFAULT NULL,
            	`created_date` BIGINT(20) NOT NULL,
            	`expire_warning` TINYINT(4) NOT NULL DEFAULT '0',
            	PRIMARY KEY (`user_ID`)
        )
        $collate;");
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $column =$wpdb->get_row(
           "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_membership_item'
            and table_schema ='".DB_NAME."'
					and column_name ='membership_id'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_membership_item` add column `membership_id` BIGINT(20) NOT NULL DEFAULT 0;");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
        

        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_membership_item'
            and table_schema ='".DB_NAME."'
					and column_name ='last_role'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_membership_item` add column `last_role` VARCHAR(64) NULL DEFAULT NULL;");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
        

        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_membership_item'
            and table_schema ='".DB_NAME."'
					and column_name ='last_role_name'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_membership_item` add column `last_role_name` TEXT NULL DEFAULT NULL;");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
        
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_membership_item'
                  and table_schema ='".DB_NAME."'
				  and column_name ='role_name'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_membership_item` add column `role_name` TEXT NULL DEFAULT NULL;");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
        
        //记录用户升级历史记录
        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_membership_item_history` (
                `id`  BIGINT(20) NOT NULL AUTO_INCREMENT,
            	`user_ID` BIGINT(20) NOT NULL,
            	`role` VARCHAR(64) NULL DEFAULT NULL,
            	`role_name` TEXT NULL DEFAULT NULL,
            	`last_role` VARCHAR(64) NULL DEFAULT NULL,
            	`last_role_name` TEXT NULL DEFAULT NULL,
            	`membership_id` BIGINT(20) NULL DEFAULT NULL,
            	`purchase_order_id` BIGINT(20) NULL DEFAULT NULL,
            	`purchase_order_item_id` BIGINT(20) NULL DEFAULT NULL,
            	`created_time` BIGINT(20) NOT NULL,
            	`expire_date` BIGINT(20) NULL DEFAULT NULL,
            	PRIMARY KEY (`id`)
        )
        $collate;");
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_membership_item_history'
            and table_schema ='".DB_NAME."'
				  and column_name ='role_name'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_membership_item_history` add column `role_name` TEXT NULL DEFAULT NULL;");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
        
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_membership_item_history'
            and table_schema ='".DB_NAME."'
				  and column_name ='last_role_name'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_membership_item_history` add column `last_role_name` TEXT NULL DEFAULT NULL;");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_membership_item_history'
            and table_schema ='".DB_NAME."'
				  and column_name ='last_role'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_membership_item_history` add column `last_role` VARCHAR(64) NULL DEFAULT NULL;");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
        
        $wpdb->query(
            "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_membership_active_code` (
                 `code` varchar(64) NOT NULL,
                `user_ID` BIGINT(20) NOT NULL,
                `membership_id`  BIGINT(20) NULL DEFAULT NULL,
                `purchase_order_id` BIGINT(20) NULL DEFAULT NULL,
                `purchase_order_item_id` BIGINT(20) NULL DEFAULT NULL,
                `expire_date` BIGINT(20) NULL DEFAULT NULL,
                `created_date` BIGINT(20) NOT NULL,
                `status` varchar(1) NOT NULL,
                PRIMARY KEY (`code`)
            )
            $collate;");
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
    }
}

class WShop_Membership_Helper{
    public static function update_membership_item($id,$action){
        $membership = new WShop_Membership_Item($id);
        if(!$membership->is_load()){
            return WShop_Error::err_code(404);
        }
         
        try {
            global $wpdb;
            switch ($action){
                
                case 'membership_item_delete':
                    $membership_item = new WShop_Membership_Item($membership->user_ID);
                    if(!$membership_item->is_load()){
                        throw new Exception(__('Membership item is not found!',WSHOP));
                    }
                    
                    $result = $membership_item->remove();
                    if(!WShop_Error::is_valid($result)){
                        throw new Exception($result->errmsg);
                    }
                   
                    break;
               
            }
        } catch (Exception $e) {
            return WShop_Error::error_custom($e->getMessage());
        }
         
        return WShop_Error::success();
    }
    
    public static function update_membership_Active_Code($id,$action){   
        try {
            global $wpdb;
            switch ($action){
                case 'membership_active_code_delete':
                    $membership = new WShop_Membership_Active_Code($id);
                    if(!$membership->is_load()){
                        return WShop_Error::err_code(404);
                    }
                    
                    $result = $membership->remove();
                    if(!WShop_Error::is_valid($result)){
                        throw new Exception($result->errmsg);
                    }
                     
                    break;
                     
            }
        } catch (Exception $e) {
            return WShop_Error::error_custom($e->getMessage());
        }
         
        return WShop_Error::success();
    }
}


class WShop_Membership_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Membership_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="membership";
        $this->title = __('Membership',WSHOP);
    }

    public function admin_init(){
        parent::admin_init();
       
        add_action('post_edit_form_tag',array($this,'post_edit_form_tag'),10,1);
        foreach ($this->get_post_types() as $post_type=>$label){
            add_filter( "manage_{$post_type}_posts_columns", array($this,'manage_posts_columns'),11 ,1);
            add_action( "manage_{$post_type}_posts_custom_column", array( $this, 'manage_posts_custom_column' ),11, 2 );
        }
    }

    public function post_edit_form_tag($post){
        if(in_array($post->post_type, array_keys($this->get_post_types()))){
            echo ' enctype="multipart/form-data" ';
        }
    }

    public function manage_posts_columns($existing_columns){
        if(!$existing_columns){$existing_columns=array();}

        $has = false;
        $new_columns = array();
        foreach ($existing_columns as $key=>$v){
            $new_columns[$key]=$v;
            if($key=='title'){
                $new_columns['membership_role']=__('Role',WSHOP);
                $new_columns['membership_discount']=__('Discount',WSHOP);
                $new_columns['membership_valid_time']=__('Valid time',WSHOP);
                $has=true;
            }
        }

        return $new_columns;
    }

    public function manage_posts_custom_column($column,$post_ID){
        global $current_wshop_membership;
        if(!$current_wshop_membership||$current_wshop_membership->post_ID!=$post_ID){
            $current_wshop_membership =  new WShop_Membership($post_ID);
        }
        
        $membership =$current_wshop_membership;
        if(!$membership->is_load()){
            return;
        }

        if($column=='membership_role'){
            if($membership->role){
                $roles =wp_roles()->roles;
                echo $roles&&isset($roles[$membership->role])?translate_user_role($roles[$membership->role]['name']):$membership->role;
            }
        }
        
        if($column=='membership_discount'){
            echo $membership->discount_format();
        }

        if($column=='membership_valid_time'){
            $membership->valid_time =intval($membership->valid_time);
            if($membership->valid_time>0){
                $txt = "";
                $year = intval($membership->valid_time/(12*30*24*60*60));
                $total_month = intval($membership->valid_time%(12*30*24*60*60));
                if($year>0){
                    $txt =$year.__('year',WSHOP);
                }

                $month =  intval($total_month/(30*24*60*60));
                $total_day =intval($total_month%(30*24*60*60));
                if($month>0||strlen($txt)>0){
                    $txt .=$month.__('month',WSHOP);
                }

                $day = intval($total_day/(24*60*60));
                $total_hour =intval($total_day%(24*60*60));
                if($day>0||strlen($txt)>0){
                    $txt .=$day.__('day',WSHOP);
                }

                $hour =intval( $total_hour/(60*60));
                if($hour>0||strlen($txt)>0){
                    $txt .=$hour.__('hour',WSHOP);
                }

                echo $txt;
            }
        }
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
    public function init_form_fields(){
        global $post;
        $this->form_fields = apply_filters('wshop_membership_fields', array(
            'role'=>array(
                'title'=>__('Role',WSHOP),
                'type'=>'custom',
                'func'=>function( $key,$api,$data){
                    $field = $api ->get_field_key($key);
                    global $post;
                    ?>
                    <tr valign="top" class="">
                    	<th scope="row" class="titledesc">
                    		<label><?php echo __('Role',WSHOP)?></label>
            			</th>
                    	<td class="forminp">
                    		<fieldset>
                    			<legend class="screen-reader-text">
                    				<span><?php echo __('Role',WSHOP)?></span>
                    			</legend>
                    			<?php 
                    			$role = $api->get_option('role');
                    			$roles = $api->get_role_options();
                    			global $wpdb;
                    			?>
                    			<input id="<?php echo $field?>" name="<?php echo $field?>" value="<?php echo esc_attr($role)?>" list="<?php echo $field?>-roles" class="wc_input_decimal input-text regular-input "/>                    			
                    			<datalist id="<?php echo $field?>-roles">
                    			
                                   <?php foreach ($roles as $role=>$name){
                                     
                                       ?><option value="<?php echo esc_attr($role)?>"><?php echo esc_html($name);?></option><?php 
                                   }?>
                                </datalist>
                                <span style="margin:auto 5px;"><?php echo __('or',WSHOP)?></span>
                                <a href="javascript:void(0);" onclick="window.wshop_post_editor.remove_role();"><?php echo __('remove',WSHOP)?></a>
                                <p class="description"><?php echo __('Create new role or select a exists role.',WSHOP)?></p>
            				</fieldset>
            				<script type="text/javascript">
                                	jQuery(function($){
                                    		if(!window.wshop_post_editor){window.wshop_post_editor={};}
                                    		
                        					window.wshop_post_editor.remove_role = function(){
                        						if(!confirm('<?php echo __('Are you sure?',WSHOP)?>')){
													return;
                                				}

                                				var role = $.trim($('#<?php echo $field?>').val());
                                				if(!role){
													return;
                                    			}

                                				$('#wpbody-content').loading();
                                				<?php $ajax_api = WShop_Add_On_Membership::instance();?>
                    							$.ajax({
                    								url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$ajax_api->id}",'tab'=>'remove_role'),true,true)?>',
                    								type:'post',
                    								timeout:60*1000,
                    								async:true,
                    								cache:false,
                    								data:{
                    									role:role
                    								},
                    								dataType:'json',
                    								complete:function(){
                    									$('#wpbody-content').loading('hide');
                    								},
                    								success:function(e){
                    									if(e.errcode!=0){
                    										alert(e.errmsg);
                    										return;
                    									}
                    									
                    									location.reload();
                    								},
                    								error:function(e){
                    									console.error(e.responseText);
                    									alert('<?php echo esc_attr( 'System error while remove role!', WSHOP); ?>');
                    								}
                    							});
                        					};
                                    });
                        			
                        		</script>
                    	</td>
                    </tr>
                    <?php 
                },
               'validate'=>function($key,$api){
                    $field = $api ->get_field_key($key);
                    $role = isset($_POST[$field])?stripslashes($_POST[$field]):null;
                    if(empty($role)){
                       $api->errors[]=__('Role is required!',WSHOP);
                        return $role;
                    }
                    global $post;
                   
                    
                    $role_entity = get_role($role);
                    if(!$role_entity){
                        add_role($role, $role, array(
                            'read' => true
                        ));
                    }
                  
                    return $role;
                }
            ),
            'purchase_discount'=>array(
                'title'=>'(会员)购物折扣',
                'type'=>'text',
                'description'=>'输入金额或折扣(折扣带百分号)例：12.00、20%，用户购买商品时打折'
            ),
            'valid_time'=>array(
                'title'=>__('Valid time',WSHOP),
                'type'=>'custom',
                'func'=>function( $key,$api,$setting){
                    $field = $api ->get_field_key($key);
                    global $post;
                    $membership = new WShop_Membership($post->ID);
                    $data=$membership->is_load()?intval($membership->valid_time):0;
                    
                    $year = $data?(intval($data/(12*30*24*60*60))):null;
                    $total_month =$data?intval($data%(12*30*24*60*60)):null;
    
                    $month = $data? intval($total_month/(30*24*60*60)):null;
                    $total_day =$data?intval($total_month%(30*24*60*60)):null;
                     
                    $day =$data? intval($total_day/(24*60*60)):null;
                    $total_hour =$data?intval($total_day%(24*60*60)):null;
    
                    $hour = $data?intval($total_hour/(60*60)):null;
    
                    ?>
                    <tr valign="top" class="">
                    	<th scope="row" class="titledesc">
                    		<label><?php echo __('Valid time',WSHOP)?></label>
            			</th>
                    	<td class="forminp">
                    		<fieldset>
                    			<legend class="screen-reader-text">
                    				<span><?php echo __('Valid time',WSHOP)?></span>
                    			</legend>
                    			<input class="input-text regular-input" value="<?php echo $year;?>" style="width:50px;" type="text" name="<?php echo "{$field}_year"?>"/>年
                    			<input class="input-text regular-input" value="<?php echo $month;?>" style="width:50px;" type="text" name="<?php echo "{$field}_month"?>"/>月
                    			<input class="input-text regular-input" value="<?php echo $day;?>" style="width:50px;" type="text" name="<?php echo "{$field}_day"?>"/>天
                    			<input class="input-text regular-input" value="<?php echo $hour;?>" style="width:50px;" type="text" name="<?php echo "{$field}_hour"?>"/>小时
            					<p class="description"><?php echo __('one year=12 month, one month=30 day',WSHOP)?></p>
            				</fieldset>
                    	</td>
                    </tr>
                    <?php 
                },
                'validate'=>function($key,$api){
                    $field = $api->get_field_key ( $key );
                    $file_year = "{$field}_year";
                    $file_month = "{$field}_month";
                    $file_day = "{$field}_day";
                    $file_hour = "{$field}_hour";
                    
                    return (isset($_POST[$file_year])? intval($_POST[$file_year])*12*30*24*60*60:0)
                    +(isset($_POST[$file_month])? intval($_POST[$file_month])*30*24*60*60:0)
                    +(isset($_POST[$file_day])? intval($_POST[$file_day])*24*60*60:0)
                    +(isset($_POST[$file_hour])? intval($_POST[$file_hour])*60*60:0);
                }
            )
        ),$post);
    }

    public function get_post_types()
    {
        return array(
            WShop_Membership::POST_T=>__('Membership',WSHOP)
        );
    }

    public function get_object($post){
        return new WShop_Membership($post);
    }
}

?>