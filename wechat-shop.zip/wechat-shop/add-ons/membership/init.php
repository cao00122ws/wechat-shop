<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'includes/class-wshop-membership.php'; 
require_once 'includes/class-wshop-membership-active-code.php';
require_once 'abstract-xh-add-ons-api.php';
/**
 * @author rain
 *
 */
class WShop_Add_On_Membership extends Abstract_WShop_Add_Ons_Membership_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Membership
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Membership
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        
        $this->id='wshop_add_ons_membership';
        $this->title=__('Membership',WSHOP);
        $this->description='支持会员角色创建，设置会员有效期，价格，普通注册用户购买后成为会员';
        $this->version='1.0.1';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->plugin_uri='https://www.wpweixin.net/product/1467.html';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
      
        $this->init_form_fields();
    }
    
    public function on_update($old_version){
        if(version_compare($old_version, '1.0.0','==')){
            $api = new WShop_Membership_Model();
            $api->init(); 
        }
    }
    
    /**
     * @since 1.0.0
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields(){
        $this->form_fields =array(
            'page_checkout'=>array(
                'title'=>__('Checkout page',WSHOP),
                'description'=>null,
                'type'=>'select',
                'func'=>true,
                'default'=>null,
                'options'=>array($this,'get_page_options')
            ),
            'page_checkout_success'=>array(
                'title'=>__('Checkout success page',WSHOP),
                'description'=>null,
                'type'=>'select',
                'func'=>true,
                'default'=>null,
                'options'=>array($this,'get_page_options')
            ),
           'roles'=>array(
                'title'=>__('View unlimit roles',WSHOP),
                'type'=>'multiselect',
                'func'=>true,
                'options'=>array($this,'get_role_options')
            ),
            'post_types'=>array(
                'title'=>__('Discount Post Types',WSHOP),
                'type'=>'multiselect',
                'func'=>true,
                'options'=>array($this,'get_membership_discount_post_type_options')
            )
        );
    }
    
    public function get_membership_discount_post_type_options(){
        global $wp_post_types;
        $types = array();
    
        if(!$wp_post_types){
            return $types;
        }
    
        foreach ($wp_post_types as $key=>$type){
            if(in_array($key, array('attachment'))){continue;}
    
            if($type->show_ui&&$type->public
                /*&&!(isset($type->wshop_ignore)&&$type->wshop_ignore)*/
                &&!(isset($type->wshop_membership_discount_ignore)&&$type->wshop_membership_discount_ignore)
                &&$key!=WShop_Membership::POST_T
                ){
                $types[$key]=isset($type->label)&& !empty($type->label)?"{$type->label}({$key})":$key;
            }
        }
        return apply_filters('wshop_membership_discount_post_types', $types);
    }
    
    public function register_fields(){
        WShop_Membership_Fields::instance();
    }
    
    public function on_install(){
        $api = new WShop_Membership_Model();
        $api->init(); 
        $this->init_page_checkout();
        $this->init_page_checkout_success();
        $this->wshop_email_init();
    }

    /**
     *
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_load()
     */
    public function on_load(){
        $this->m1();
        
        WShop_Async::instance()->async('wshop_m', array($this,'wshop_m'));
        if(class_exists('XH_UC')&&class_exists('XH_UC_Menu')){
            XH_UC_Menu::instance()->register_endpoint_page('member-upgrade', array(
                'title'=> __('Member upgrade',WSHOP),
            ), array($this,'member_upgrade'));
            
            XH_UC_Menu::instance()->register_endpoint('shop', 'member-upgrade', 5, array(
                'title'=> __('Member upgrade',WSHOP),
                'icon'=>$this->domain_url.'/assets/images/vip.png'
            ));
        }
       
        add_filter('wshop_order_membership_complete_payment_status', function($status_complete_payment,$order,$transaction_id){
            return WShop_Order::Complete;
        },10,3);
    }
	
	public function wshop_unlimit_roles($roles){
		$rs = $this->get_option('roles');
        if($rs){
            foreach ($rs as $role){
                if(!in_array($role, $roles)){
                    $roles[]=$role;
                }
            }
        }

        return $roles;
	}
    public function add_shortcodes($shortcodes){
        $shortcodes['wshop_membership_rolename']=function($atts = array(),$content =null){
            return wshop_membership_rolename($atts,false);
        };
        
        $shortcodes['wshop_membership_expire_date']=function($atts = array(),$content =null){
            return wshop_membership_expire_date($atts,false);
        };
        
        $shortcodes['wshop_membership_checkout']=function($atts = array(),$content =null){
            return WShop::instance()->WP->requires(WShop_Add_On_Membership::instance()->domain_dir, 'membership/purchase-content.php');
        };
        
        $shortcodes['wshop_membership_checkout_success']=function($atts = array(),$content =null){
            return WShop::instance()->WP->requires(WShop_Add_On_Membership::instance()->domain_dir, 'membership/purchase-success.php');
        };
        
        $shortcodes['wshop_dialog_membership_checkout']=function($atts = array(),$content =null){
            return wshop_dialog_membership_checkout($atts,$content,false);
        };
        
        return $shortcodes;
    }
    public function wshop_m($atts = array(),$content = null){
        return WShop_Async::instance()->async_call('wshop_m', function(&$atts,&$content){
            if(isset($atts['member_id'])&&$atts['member_id']){
                $atts['post_id']=$atts['member_id'];
                unset($atts['member_id']);
            }
            
            if(!isset( $atts['post_id'])||empty( $atts['post_id'])){
                if(method_exists(WShop::instance()->WP, 'get_default_post')){
                    $default_post = WShop::instance()->WP->get_default_post();
                    $atts['post_id']=$default_post?$default_post->ID:0;
                }else{
                    global $wp_query,$post;
                    $default_post=$wp_query?$wp_query->post:null;
                    if(!$default_post&&$post){
                        $default_post = $post;
                    }
                    $atts['post_id']=$default_post?$default_post->ID:0;
                }
            }
            
            if(!isset($atts['location'])||empty($atts['location'])){
                $atts['location'] =  WShop_Helper_Uri::get_location_uri();
            }
    
        },function(&$atts,&$content){
            $content = empty($content)?__('Pay now',WSHOP):$content;
    
            if(!is_user_logged_in()){
                $request_url=wp_login_url($atts['location']);
                ob_start();
                ?><a href="<?php echo $request_url;?>" class="<?php echo isset($atts['class'])?esc_attr($atts['class']):""?>" style="<?php echo isset($atts['style'])?esc_attr($atts['style']):""?>"><?php echo do_shortcode($content);?></a><?php
                return ob_get_clean();
            }
            
            $atts['section'] ='membership';
            
            return WShop::instance()->WP->requires(WSHOP_DIR, 'button-purchase.php',array(
                'content'=>$content,
                'atts'=>$atts
            ));
        },
        array(
           'style'=>null,
           'member_id'=>0,
           'post_id'=>0,
           'class'=>'xh-btn xh-btn-danger xh-btn-lg',
           'location'=>null
       ),
        $atts,
        $content);
    }
    
    /**
     * 用户中心 会员升级
     * @return string
     */
    public function member_upgrade(){
        return WShop::instance()->WP->requires($this->domain_dir, 'membership/usercenter-purchase.php');
    }
    
    /**
     *
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        $this->m2();
    }
    
     /**
     * @param WShop_Error $error
     * @param WShop_Order $order
     * @param WShop_Shopping_Cart $cart
     * @return WShop_Error
     */
    public function wshop_order_extra_amount($error,$order,$cart){
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
       
        $discounts = $this->discount_formats();
        if(!$discounts||count($discounts)==0){
            return $error;
        }
        
        $post_types = $this->get_option('post_types');
        $items = $order->get_order_items();
        global $current_user;
        $member_role = $current_user&&$current_user->roles&&is_array($current_user->roles)&&count($current_user->roles)>0?$current_user->roles[0]:null;
        if(!$member_role||!isset($discounts[$member_role])){
            return $error;
        }
        
        $discount = 0;
        if($items){
            foreach ($items as $order_item){
                $post_type = isset($order_item->metas['post_type'])?$order_item->metas['post_type']:null;
                if(apply_filters('wshop_membership_discount_enabled',
                    !$post_types
                    ||!is_array($post_types)
                    ||!in_array($post_type, $post_types),$order_item->post_ID,$post_type)){
                        continue;
                }
                
                $subtotal = $order_item->get_subtotal(false);
                $discount += round($subtotal-WShop_Membership::__discount_amount($subtotal,$discounts[$member_role]),2);
            }
        }
         
        $order->extra_amount[]=array(
            'title'=>apply_filters('wshop_membership_discount_title', __('Membership Discount',WSHOP)),
            'amount'=> -$discount
        );
        
        return $error;
    }
    
    /**
     * 
     * @param string $sale_price
     * @param decimal $osale_price
     * @param boolean $symbol
     * @param WShop_Product $product
     */
    public function membership_discount_price($sale_price,$osale_price,$symbol,$product){
        if(!$symbol){
            return $sale_price;
        }
        
        if(!defined('DOING_AJAX')&&is_admin()){
            return $sale_price;
        }
        
        $post_types = $this->get_option('post_types');
        if(apply_filters('wshop_membership_discount_enabled', 
            !$post_types
            ||!is_array($post_types)
            ||!in_array($product->post->post_type, $post_types),$product->post_ID,$product->post->post_type)){
            return $sale_price;
        }
        
        $discounts = $this->discount_formats();
        if(!$discounts||count($discounts)==0){
            return $sale_price;
        }
       
        global $current_user;
        $member_role = $current_user&&$current_user->roles&&is_array($current_user->roles)&&count($current_user->roles)>0?$current_user->roles[0]:null;
        
        ob_start();
        $symbol_txt =$product->get_currency_symbol();
        if($member_role&&isset($discounts[$member_role])){
            $vip_price = WShop_Membership::__discount_amount($osale_price,$discounts[$member_role]);
            if($vip_price<$osale_price){
                ?><span style="color:gray;text-decoration:line-through"><?php echo $sale_price;?></span><?php
            }
            
             echo $symbol_txt.WShop_Helper_String::get_format_price($vip_price);
        }else{
            $min_amount = 0;
            //计算最低折扣价
            foreach ($discounts as $_role=>$_discount){
                $amount = WShop_Membership::__discount_amount($osale_price,$_discount);
                $min_amount = max(array($amount,$min_amount));
            }
            
            echo $sale_price;
            if($min_amount<$osale_price){
                ?><small>(会员价：<?php echo $symbol_txt.WShop_Helper_String::get_format_price($min_amount);?>)</small><?php
            }
        }
        
        return apply_filters('wshop_membership_discount_price_html', ob_get_clean(),$sale_price,$osale_price,$product);
    }
    
    public function discount_formats(){
        static $wshop_discounts=false;
        if($wshop_discounts!==false){
            return $wshop_discounts;
        }
        
        global $wpdb;
        $discounts = $wpdb->get_results(
            "select m.role,
                    m.purchase_discount
             from {$wpdb->prefix}wshop_membership m
             inner join {$wpdb->prefix}posts p on p.ID = m.post_ID
             where p.post_status='publish';");
        $wshop_discounts=array();
        if($discounts){
            foreach($discounts as $discount){
                $wshop_discounts[$discount->role] = $discount->purchase_discount;
            }
        }
        return $wshop_discounts;
    }
    
    public function uc_usercenter_content_membership($html){
        global $current_user;
        $member_item = new WShop_Membership_Item($current_user->ID);
        if($member_item->is_member()){
            ob_start();
            ?><p>当前会员等级：<span class="xhmem-status"><?php echo $member_item->get_role_name()?></span> 到期时间：<?php echo $member_item->expire_date?date('Y-m-d H:i',$member_item->expire_date):'--';?></p><?php
            return ob_get_clean();
        }
       
        return $html;
    }
    
    public function uc_usercenter_content_btns(){
        global $current_user;
        $member_item = new WShop_Membership_Item($current_user->ID);
        if(!$member_item->is_member()){
            wshop_dialog_membership_checkout(array('class'=>'xh-btn xh-btn-primary'),'升级VIP会员',true);
            
        }
    }
    
    public function wshop_footer($gateways){
        echo WShop::instance()->WP->requires($this->domain_dir, 'membership/__scripts.php');
    }
    
    public function wshop_email_init(){
        //======================================
        WShop_Email_Model::init_new_email('membership-upgraded',__('Membership upgraded',WSHOP),__('[{site_title}] Membership upgrade - {date}',WSHOP),array(
            "{email:admin}"
        ),
            __('New emails are sent to chosen recipient(s) when membership upgraded.',WSHOP));
        
        WShop_Email_Model::init_new_email('your-membership-have-upgraded',__('Your membership have upgraded',WSHOP),__('[{site_title}] Your membership have upgraded - {date}',WSHOP),array(
            "{email:customer}"
        ),
            __('New emails are sent to chosen recipient(s) when membership upgraded.',WSHOP));
        
        //========================================
        WShop_Email_Model::init_new_email('membership-willbe-expired',__('Membership will be expired',WSHOP),__('[{site_title}] Membership will be expired - {date}',WSHOP),array(
            "{email:admin}"
        ),
            __('New emails are sent to chosen recipient(s) when membership will be expired.',WSHOP));
        
        WShop_Email_Model::init_new_email('your-membership-willbe-expired',__('Your membership will be expired',WSHOP),__('[{site_title}] Your membership will be expired - {date}',WSHOP),array(
            "{email:customer}"
        ),
            __('New emails are sent to chosen recipient(s) when membership will be expired.',WSHOP));
        //========================================
        WShop_Email_Model::init_new_email('membership-have-expired',__('Membership have expired',WSHOP),__('[{site_title}] Membership will be expired - {date}',WSHOP),array(
            "{email:admin}"
        ),
            __('New emails are sent to chosen recipient(s) when membership have expired.',WSHOP));
        
        WShop_Email_Model::init_new_email('your-membership-have-expired',__('Your membership have expired',WSHOP),__('[{site_title}] Your membership have been expired - {date}',WSHOP),array(
            "{email:customer}"
        ),
            __('New emails are sent to chosen recipient(s) when membership have expired.',WSHOP));
    }
   
    public function wshop_order_membership_received_url($url,$order){
        $params = WShop::instance()->generate_request_params(array(
            'sid'=>isset($order->metas['membership_id'])?$order->metas['membership_id']:0
        ));
        
        return $this->get_page_checkout_success_url($params);
    }
    
    /**
     * 
     * @param string $url
     * @param WShop_Order $order
     */
    public function wshop_order_received_url($url,$order){
        if($order->obj_type==WShop_Membership::POST_T){
            $items = $order->get_order_items();
            if($items){
                foreach ($items as $item){
                    $params = WShop::instance()->generate_request_params(array(
                        'sid'=>$item->post_ID
                    ));
        
                    return $this->get_page_checkout_success_url($params);
                }
            }
        }
        
       
       return $url;
    }
    
    public function get_page_checkout_url($request = array()){
        $page_id = $this->get_option('page_checkout');
        $url = $page_id?get_permalink($page_id):null;
        if(!$url){
            return null;
        }
        
        return WShop_Helper_Uri::get_new_uri($url,$request);
    }
    
    public function get_page_checkout_success_url($request = array()){
        $page_id = $this->get_option('page_checkout_success');
        $url = $page_id?get_permalink($page_id):null;
        if(!$url){
            return null;
        }
     
        return WShop_Helper_Uri::get_new_uri($url,$request);
    }

    /**
     *
     * @param WShop_Error $success
     * @param WShop_Shopping_Cart $cart
     * @param WShop_Product $product
     */
    public function wshop_cart_item_validate($success,$cart,$product,$qty){
        if(!WShop_Error::is_valid($success)||$product->get('post_type')!=WShop_Membership::POST_T){
            return $success;
        }
    
        global $current_user;
        if(!is_user_logged_in()){
            return WShop_Error::err_code(501);
        }
        $membership =  $this->validate_membership_purchase($product->post_ID,$current_user);
        if($membership instanceof WShop_Error){
            return $membership;
        }
        
        return $success;
    }
    
    public function validate_membership_purchase($membership_id,$wp_user){     
        if(!$wp_user->roles||!is_array($wp_user->roles)){
            $wp_user->roles=array();
        }
        
        if(in_array('administrator', $wp_user->roles)){
            return WShop_Error::error_custom(__('Administrator can not do upgrade!',WSHOP));
        }
        
        $membership = new WShop_Membership($membership_id);
        if(!$membership->is_load()){
            return WShop_Error::error_custom(__('Membership is required!',WSHOP));
        }
        
        return $membership;
    }
    
    public function wshop_checkout_tab_membership($request){
        $action = isset($request['action'])?$request['action']:null;
        $datas=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null,
            'section'=>null,//支付方式：付费下载 ， 快速支付等
            'hash'=>null
        ), $request);
        
        if(!WShop::instance()->WP->ajax_validate($datas, $datas['hash'])){
            echo WShop_Error::err_code(701)->to_json();
            exit;
        }
         
        if(!is_user_logged_in()&&!WShop::instance()->WP->is_enable_guest_purchase()){
            echo WShop_Error::err_code(501)->to_json();
            exit;
        }
        
        if(!isset($request['section'])||empty($request['section'])){
            echo WShop_Error::err_code(600)->to_json();
            exit;
        }
        
        $cart = WShop_Shopping_Cart::empty_cart(false);
        if($cart instanceof WShop_Error){
            echo $cart->to_json();
            exit;
        }
        
        $post_id = isset($request['post_id'])?intval($request['post_id']):null;
        $payment_method = isset($request['payment_method'])?$request['payment_method']:null;
        $code = isset($request['code'])?$request['code']:null;
        $scope = isset($request['scope'])?$request['scope']:null;
        
        global $current_user;
        if(!is_user_logged_in()){
            echo WShop_Error::err_code(501)->to_json();exit;
        }
        
        $api = WShop_Add_On_Membership::instance();
        $membership =  $api->validate_membership_purchase($post_id,$current_user);
        if($membership instanceof WShop_Error){
            echo $membership->to_json();
            exit;
        }
        $cart instanceof WShop_Shopping_Cart;
        switch ($scope){
            case 'pay':
            default:
                $cart =  $cart->__add_to_cart($post_id);
                if($cart instanceof WShop_Error){
                    echo $cart->to_json();
                    exit;
                }
                
                $cart->__set_payment_method($payment_method);
                
                $cart->__set_metas(array(
                    'section'=>$request['section'],
                    'membership_id'=>$membership->post_ID,
                    'location'=>isset($request['location'])?$request['location']:null
                ));
               
                $order = $cart->create_order();
                if($order instanceof WShop_Error){
                    echo $order->to_json();
                    exit;
                }
                
                echo WShop_Error::success(array(
                    'redirect_url'=>$order->get_pay_url()
                ))->to_json();
                exit;
            case 'code':
                if(empty($code)){
                    echo WShop_Error::error_custom(__('Active code is required!',WSHOP))->to_json();exit;
                }
        
                $membership_code = new WShop_Membership_Active_Code($code);
                if(!$membership_code->is_load()){
                    echo WShop_Error::error_custom(__('Active code is invalid!',WSHOP))->to_json();exit;
                }
        
                if($membership_code->status!=WShop_Membership_Active_Code::Active){
                    echo WShop_Error::error_custom(__('Active code is used or invalid!',WSHOP))->to_json();exit;
                }
        
                if($membership_code->expire_date&&$membership_code->expire_date<current_time( 'timestamp')){
                    echo WShop_Error::error_custom(__('Active code is expired!',WSHOP))->to_json();exit;
                }
        
                if($membership_code->membership_id&&$membership_code->membership_id!=$post_id){
                    echo WShop_Error::error_custom(__('Active code is invalid!',WSHOP))->to_json();exit;
                }
        
                $error = $api->create_membership_item($membership,$current_user);
                if(!WShop_Error::is_valid($error)){
                    echo $error->to_json();exit;
                }
        
                $result = 0;
                $error = $membership_code->update(array(
                    'status'=>WShop_Membership_Active_Code::Used,
                    'user_ID'=>$current_user->ID
                ),$result);
        
                if(!WShop_Error::is_valid($error)){
                    echo $error->to_json();exit;
                }
                 
                $params = WShop::instance()->generate_request_params(array(
                    'sid'=>$request['post_id']
                ));
                 
                echo WShop_Error::success(array(
                    'redirect_url'=>WShop_Add_On_Membership::instance()->get_page_checkout_success_url($params)
                ))->to_json();exit;
        }
    }
   
    /**
     * 
     * @param WShop_Shopping_Cart $cart
     * @param WShop_Product $product
     */
    public function wshop_shopping_cart_item_added(&$cart,$product){
        if($product->post_type==WShop_Membership::POST_T){
            $cart->__set_meta('membership_id',$product->post_ID);
        }
    }
    
    public function create_membership_item($membership_id,$user_ID,$order_id=null,$order_item_id=null,$func_set_expired=null){
        $membership = $membership_id instanceof WShop_Membership?$membership_id: new WShop_Membership($membership_id);
        if(!$membership->is_load()){
            return WShop_Error::error_custom(sprintf(__('Membership update failed:membership is not found!(membership_id:%s)',WSHOP),$membership_id));
        }
            
        $user =$user_ID instanceof WP_User?$user_ID: get_user_by('id', $user_ID);
        if(!$user){
            return WShop_Error::error_custom(sprintf(__('Membership update failed:user is not found! (user_id:%s)',WSHOP),$user_ID));
        }
        
        if(!$func_set_expired){
            $func_set_expired = function($membership,$membership_item){
                 $membership_item->set_expire_date($membership);
                 return $membership_item;
            };
        }
        
        $user_ID=$user->ID;
        
        $membership_item = new WShop_Membership_Item($user_ID);
        if(!$membership_item->is_load()){
            $last_role = count($user->roles)>0?$user->roles[0]:null;
            $last_role_name = $last_role?translate_user_role($last_role):null;
            
            $membership_item = new WShop_Membership_Item(array(
                'user_ID'=>$user->ID,
                'membership_id'=>$membership->post_ID,
                'role'=>$membership->role,
                'role_name'=>$membership->get('post_title'),
                'last_role'=>$last_role,
                'last_role_name'=>$last_role_name,
                'expire_date'=>null,
                'expire_warning'=>0
            ));
        
            $membership_item = call_user_func_array($func_set_expired, array($membership,$membership_item));
        
            $error = $membership_item->insert();
            if(!WShop_Error::is_valid($error)){
                return $error;
            }
        
        }else{
            //更新membership
            $membership_item = call_user_func_array($func_set_expired, array($membership,$membership_item));
            $last_role = $membership_item->role;
            $last_role_name = $membership_item->role_name;
            
            $error = $membership_item->update(array(
                'last_role'=>$last_role,
                'last_role_name'=>$last_role_name,
                'role'=>$membership->role,
                'role_name'=>$membership->get('post_title'),
                'membership_id'=>$membership->post_ID,
                'expire_date'=>$membership_item->expire_date,
                'expire_warning'=>0
            ));
        
            if(!WShop_Error::is_valid($error)){
                return $error;
            }
        }
        
        $user->set_role($membership->role);
        
        $membership_item_history = new WShop_Membership_Item_History(array(
            'user_ID'=>$user->ID,
            'last_role'=>$membership_item->last_role,
            'last_role_name'=>$membership_item->get_last_role_name(),
            'role'=>$membership->role,
            'role_name'=>$membership_item->get_role_name(),
            'membership_id'=>$membership->post_ID,
            'purchase_order_id'=>$order_id,
            'purchase_order_item_id'=>$order_item_id,
            'expire_date'=>$membership_item->expire_date,
            'created_time'=>current_time( 'timestamp')
        ));
        
        $error = $membership_item_history->insert();
        if(!WShop_Error::is_valid($error)){
           return $error;
        }
        
        do_action('wshop_membership_upgraded',$user);
        return WShop_Error::success();
    }

    public function manage_users_columns( $columns ) {
        $new_columns = array();
        foreach ($columns as $key=>$v){
            $new_columns[$key]=$v;
            if($key=='role'){
                $new_columns['wshop_membership_expire_time']=__('Expire date',WSHOP);
            }
        }
        return $new_columns;
    }
    
    public function manage_users_custom_column( $value, $column_name, $user_id ) {
        if($column_name=='wshop_membership_expire_time'){
            $member_item = new WShop_Membership_Item($user_id);
            if($member_item->is_load()){
                
                if($member_item->expire_date){
                    $now = current_time('timestamp');
                    if($now>$member_item->expire_date){
                        return "<span style='color:red;'>".date('Y-m-d H:i',$member_item->expire_date)."</span>";
                    }else{
                        return "<span'>".date('Y-m-d H:i',$member_item->expire_date)."</span>";
                    }
                }
                
            }
        }
        return $value;
    }

    public function on_cron(){
        //对过期用户进行提醒
        global $wpdb;
        $now = current_time('timestamp');
        
        //提前7天提醒即将过期
        $pre_exipre_date = $now+apply_filters('wshop_membership_expire_warning_time', 7*24*60*60);
        
        //---即将过期------
        $pre_expired_memberships = $wpdb->get_results(
            "select *
             from {$wpdb->prefix}wshop_membership_item oi
             inner join {$wpdb->prefix}users u on u.ID = oi.user_ID
             where (
                        oi.expire_date is not null 
                        and oi.expire_date<=$pre_exipre_date 
                        and oi.expire_date>$now
                    )
                   and oi.expire_warning=0
             order by oi.created_date asc
             limit 10;");
        
        if($pre_expired_memberships){
            foreach ($pre_expired_memberships as $membership){
                $member_item = new WShop_Membership_Item($membership->user_ID);
                if($member_item->is_load()){
                    $result=null;
                    $error = $member_item->update(array(
                        'expire_warning'=>1
                    ),$result);
                    
                    if(!WShop_Error::is_valid($error)){
                        WShop_Log::debug("用户即将过期用户提醒邮件发送失败：{$error->to_json()}:".print_r($membership,true));
                        continue;
                    }
                    
                    if($result){
                        do_action('wshop_membership_willbe_expired',get_user_by('id', $membership->user_ID));
                    }
                }
            }
        }
        
        
        //---已过期------
        $expired_memberships = $wpdb->get_results(
           "select *
            from {$wpdb->prefix}wshop_membership_item oi
            inner join {$wpdb->prefix}users u on u.ID = oi.user_ID
            where (
                    oi.expire_date is not null
                    and oi.expire_date<$now
                )
            order by oi.created_date asc
            limit 10;");
        
        $default_role =get_option('default_role','subscriber');
        if(empty($default_role)){$default_role='subscriber';}
        
        if($expired_memberships){
            foreach ($expired_memberships as $membership){
                $wp_user = get_user_by('id', $membership->user_ID);
                if(!$wp_user){
                    continue;
                }
                
                $member_item = new WShop_Membership_Item($membership->user_ID);
                $last_role = $member_item->role;
                $last_role_name = $member_item->get_role_name();
                
                if($member_item->is_load()){
                    $result=null;
                    $error = $member_item->update(array(
                        'expire_warning'=>0,
                        'role'=>$default_role,
                        'role_name'=>translate_user_role($default_role),
                        'last_role'=>$last_role,
                        'membership_id'=>0,
                        'last_role_name'=>$last_role_name,
                        'expire_date'=>null,
                        'created_date'=>$now
                    ),$result);
                
                    if(!WShop_Error::is_valid($error)){
                        WShop_Log::debug("用户即将过期用户提醒邮件发送失败：{$error->to_json()}:".print_r($member_item,true));
                        continue;
                    }
                
                    if($result){
                        $wp_user->set_role($default_role);
                
                        $membership_item_history = new WShop_Membership_Item_History(array(
                            'user_ID'=>$wp_user->ID,
                            'role'=>$default_role,
                            'role_name'=>translate_user_role($default_role),
                            'last_role'=>$last_role,
                            'last_role_name'=>$last_role_name,
                            'membership_id'=>0,
                            'purchase_order_id'=>null,
                            'purchase_order_item_id'=>null,
                            'expire_date'=>null,
                            'created_time'=>current_time( 'timestamp')
                        ));
                        
                        $error = $membership_item_history->insert();
                        if(!WShop_Error::is_valid($error)){
                            WShop_Log::debug("升级记录插入失败：{$error->errmsg}:".print_r($member_item,true));
                            //忽略这个错误
                        }
                        
                        do_action('wshop_membership_have_expired',$wp_user);
                    }
                }
                
            }
        }
    }
    
    public function wshop_page_templates($ms){
        $ms[$this->domain_dir]['membership/purchase.php']=__('WShop - Membership checkout',WSHOP);
        return $ms;
    }
    
    public function wshop_admin_menu_menu_default_modal($menus){
        $menus[]=$this;
        return $menus;
    }
    private function init_page_checkout(){
        $page_id =intval($this->get_option('page_checkout',0));
        $page=null;
        if($page_id>0){
            return true;
        }
    
        $page_id =wp_insert_post(array(
            'post_type'=>'page',
            'post_name'=>'membership-checkout',
            'post_title'=>__('WShop - Membership checkout',WSHOP),
            'post_content'=>'[wshop_membership_checkout]',
            'post_status'=>'publish',
            'meta_input'=>array(
                '_wp_page_template'=>'membership/purchase.php'
            )
        ),true);
    
        if(is_wp_error($page_id)){
            WShop_Log::error($page_id);
            throw new Exception($page_id->get_error_message());
        }
    
        $this->update_option('page_checkout', $page_id,true);
        return true;
    }
    
    private function init_page_checkout_success(){
        $page_id =intval($this->get_option('page_checkout_success',0));
        $page=null;
        if($page_id>0){
            return true;
        }
    
        $page_id =wp_insert_post(array(
            'post_type'=>'page',
            'post_name'=>'membership-checkout-success',
            'post_title'=>__('WShop - Membership checkout success',WSHOP),
            'post_content'=>'[wshop_membership_checkout_success]',
            'post_status'=>'publish',
            'meta_input'=>array(
                '_wp_page_template'=>'membership/purchase.php'
            )
        ),true);
    
        if(is_wp_error($page_id)){
            WShop_Log::error($page_id);
            throw new Exception($page_id->get_error_message());
        }
    
        $this->update_option('page_checkout_success', $page_id,true);
        return true;
    }
    
 
    public function register_post_types(){
        register_post_type( WShop_Membership::POST_T,
            array(
                'labels' => array(
                    'name' => __('Membership',WSHOP),
                    'singular_name' =>__('Membership',WSHOP),
                    'add_new' => __('Add New',WSHOP),
                    'add_new_item' =>__('Add New Membership',WSHOP),
                    'edit' =>  __('Edit',WSHOP),
                    'edit_item' => __('Edit Membership',WSHOP),
                    'new_item' => __('New Membership',WSHOP),
                    'view' => __('View',WSHOP),
                    'view_item' => __('View Membership',WSHOP),
                    'search_items' => __('Search Membership',WSHOP),
                    'not_found' => __('No Membership found',WSHOP),
                    'not_found_in_trash' => __('No Membership found in trash',WSHOP),
                    'parent' => __('Parent Membership',WSHOP)
                ),
                //决定自定义文章类型在管理后台和前端的可见性
                'public' => true,
                'wshop_ignore'=>true,
                'wshop_include'=>true,
                'menu_position' => 15,
                'exclude_from_search '=>false,
                'publicly_queryable'=>false,
                'hierarchical'=>false,
                'supports' => array( 'title','excerpt', 'thumbnail'/* 'editor', 'comments', 'thumbnail', 'page-attributes'*/ ),
                //创建自定义分类。在这里没有定义
                //'taxonomies' => array( ),
                //启用自定义文章类型的存档功能
                'has_archive' => true,
                'show_in_menu'=>WShop_Admin::menu_tag
         ));
    }
   
    /**
     * 
     * @param array $args
     * @param WShop_Order $order
     * @param string $transaction_id
     */
    public function wshop_order_complete_payment_args($args,$order,$transaction_id){
        $args['executed']['membership'][]=function($order,$result){
            $membership_id = isset($order->metas['membership_id'])?$order->metas['membership_id']:null;
            $user_ID = $order->customer_id;
            
            $error =WShop_Add_On_Membership::instance()->create_membership_item($membership_id, $user_ID,$order->id);
            if(!WShop_Error::is_valid($error)){
                WShop_Log::error($error->to_string());
            }
        };
        
        return $args;
    }
    
    public function wshop_membership_have_expired($user){
        if(!is_email($user->user_email)){
            return;
        }
        
        $settings = apply_filters('wshop_membership_have_expired_settings', array(
            '{email:customer}'=>$user->user_email,
            '{date}'=>date_i18n('Y-m-d H:i')
        ),$user);
        
        $content =WShop::instance()->WP->requires(
            $this->domain_dir,
            "emails/membership-have-expired.php",
            array('user'=>$user)
            );
        
        $email = new WShop_Email('membership-have-expired');
        $email->send($settings,$content);
        
        $content =WShop::instance()->WP->requires(
            $this->domain_dir,
            "emails/your-membership-have-expired.php",
            array('user'=>$user)
            );
        
        $email = new WShop_Email('your-membership-have-expired');
        $email->send($settings,$content);
    }
    
    public function wshop_membership_willbe_expired($user){
        if(!is_email($user->user_email)){
            return;
        }
        
        $settings = apply_filters('wshop_membership_willbe_expired_settings', array(
            '{email:customer}'=>$user->user_email,
            '{date}'=>date_i18n('Y-m-d H:i')
        ),$user);
        
        $content =WShop::instance()->WP->requires(
            $this->domain_dir,
            "emails/membership-willbe-expired.php",
            array('user'=>$user)
            );
        
        $email = new WShop_Email('membership-willbe-expired');
        $email->send($settings,$content);
        
        $content =WShop::instance()->WP->requires(
            $this->domain_dir,
            "emails/your-membership-willbe-expired.php",
            array('user'=>$user)
            );
        
        $email = new WShop_Email('your-membership-willbe-expired');
        $email->send($settings,$content);
    }
    
    /**
     * 
     * @param WP_User $user
     */
    public function wshop_membership_upgraded($user){
        if(!is_email($user->user_email)){
            return;
        }
        
        $settings = apply_filters('wshop_membership_upgraded_email_settings', array(
            '{email:customer}'=>$user->user_email,
            '{date}'=>date_i18n('Y-m-d H:i')
        ),$user);

        $content =WShop::instance()->WP->requires(
            $this->domain_dir,
            "emails/membership-upgraded.php",
            array('user'=>$user)
        );
        
        $email = new WShop_Email('membership-upgraded');
        $email->send($settings,$content);
        
        $content =WShop::instance()->WP->requires(
            $this->domain_dir,
            "emails/your-membership-have-upgraded.php",
            array('user'=>$user)
        );
        
        $email = new WShop_Email('your-membership-have-upgraded');
        $email->send($settings,$content);
    }

    
    /**
     * 执行支付相关操作
     * @since 1.0.0
     */
    public function do_ajax(){
        $action ="wshop_{$this->id}";
    
        $this->on_admin_post();
    }
    
    
    private function on_admin_post(){
        $action ="wshop_{$this->id}";
        $datas=WShop_Async::instance()->shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null
        ), stripslashes_deep($_REQUEST));
        if(!WShop::instance()->WP->ajax_validate($datas,$_REQUEST['hash'],true)){
            echo WShop_Error::err_code(701)->to_json();
            exit;
        }
    
        global $current_user;
        $roles = $current_user?$current_user->roles:null;
        if(!$roles||!is_array($roles)||!in_array('administrator', $roles)){
            echo WShop_Error::err_code(501)->to_json();
            exit;
        }
        
        switch ($datas['tab']){
            case 'remove_role':
                $role = isset($_POST['role'])?stripslashes($_POST['role']):null;
                if(empty($role)){
                    echo WShop_Error::success()->to_json();
                    exit;
                }
                
                if($role=='administrator'){
                    echo WShop_Error::error_custom(__('Can not be remove administrator!',WSHOP))->to_json();
                    exit;
                }
                
                remove_role($role);
                
                echo WShop_Error::success()->to_json();
                exit;
            case 'membership_active_code_delete':
                $error = WShop_Membership_Helper::update_membership_Active_Code(isset($_REQUEST['id'])?$_REQUEST['id']:0, $datas['tab']);
                echo $error->to_json();
                exit;
            case 'membership_item_delete':
                $error = WShop_Membership_Helper::update_membership_item(isset($_REQUEST['id'])?$_REQUEST['id']:0, $datas['tab']);
                echo $error->to_json();
                exit;
            case 'save_or_update_membership_active_code':
                $membership_id =  isset($_POST['membership_id'])?intval($_POST['membership_id']):0;
                if($membership_id<=0){
                    $membership_id = null;
                }
                
                $expire_date =!isset($_POST['expire_date'])|| empty($_POST['expire_date'])?null:strtotime($_POST['expire_date']);
                $qty =  isset($_POST['qty'])?intval($_POST['qty']):0;
                if($qty<=0){
                    $qty = 1;
                }
                
                global $wpdb;
                
                while ($qty-->0){
                    $wpdb->insert("{$wpdb->prefix}wshop_membership_active_code", array(
                        'code'=>WShop_Helper_String::guid(),
                        'expire_date'=>$expire_date,
                        'membership_id'=>$membership_id,
                        'created_date'=>current_time( 'timestamp' ),
                        'status'=>WShop_Membership_Active_Code::Active
                    ));
                    
                    if(!empty($wpdb->last_error)){
                        WShop_Log::error($wpdb->last_error);
                        echo WShop_Error::error_custom($wpdb->last_error)->to_json();
                        exit;
                    }
                }
                echo WShop_Error::success()->to_json();
                exit;
            case 'save_or_update_membership_item':
                $user_id = isset($_POST['user_ID'])?$_POST['user_ID']:null;
                $user =$user_id? get_user_by('id', $user_id):null;
                if(!$user){
                    echo WShop_Error::error_custom(__('User info is not found!',WSHOP));
                    exit;
                }
                
                $membership_id = isset($_POST['membership_id'])?$_POST['membership_id']:0;
                $membership = $this->validate_membership_purchase($membership_id,$user);
                if($membership instanceof WShop_Error){
                    echo $membership->to_json();
                    exit;
                }
                
                echo $this->create_membership_item($membership, $user,null,null,function($membership,$membership_item){
                    $expired_time =isset($_POST['expire_date'])&&!empty($_POST['expire_date'])?strtotime($_POST['expire_date']):null;
                    if(!$expired_time){$expired_time=null;}
                    $membership_item->expire_date=$expired_time;
                   
                    return $membership_item;
                })->to_json();
                exit;
        }
    } 
}

if(!function_exists('wshop_m')){
    function wshop_m($atts=array(),$content = null,$echo = true){
        $api = WShop_Add_On_Membership::instance();
        if(!$atts||!is_array($atts)){$atts=array();}
        $atts['location'] = WShop_Helper_Uri::get_location_uri();
        
        $html = $api->wshop_m($atts,$content);
        if($echo){echo $html;}
        return $html;
    }
}

if(!function_exists('wshop_dialog_membership_checkout')){
    function wshop_dialog_membership_checkout($atts=array(),$content = null,$echo = true){
        $api = WShop_Add_On_Membership::instance();
        if(!$atts||!is_array($atts)){$atts=array();}
        
        if(!isset($atts['location'])||empty($atts['location'])){
            $atts['location'] = WShop_Helper_Uri::get_location_uri();
        }
        $html = WShop::instance()->WP->requires($api->domain_dir, 'membership/purchase-dialog.php',array(
            'atts'=>$atts,
            'content'=>$content
        ));
        
        if($echo){echo $html;}
        return $html;
    }
}

if(!function_exists('wshop_is_member')){
    function wshop_is_member($user=null,$roles = array()){
        global $current_user;
        if(!$user&&is_user_logged_in()){
            $user = $current_user;
        }
        
        if(!$user){
            return false;
        }
        
        if(isset($user->wshop_member_role)){
            return $user->wshop_member_role;
        }
        
        if(!$roles||!is_array($roles)){$roles=array();}        
        if(count($roles)==0){
            $roles = WShop_Add_On_Membership::instance()->get_option('roles',array());
            if(!$roles||!is_array($roles)){$roles=array();}
        }
        
        if(count($roles)==0){
            return false;
        }
        
        $user_roles = $user->roles;
        if(!$user_roles||!is_array($user_roles)){$user_roles=array();}
    
        foreach ($roles as $role){
            if(in_array($role, $user_roles)){
                if(is_user_logged_in()&&$current_user->ID==$user->ID){
                    $current_user->wshop_member_role=$role;
                }
                return $role;
            }
        }
        
        if(is_user_logged_in()&&$current_user->ID==$user->ID){
            $current_user->wshop_member_role=false;
        }
        return false;
    }
}

if(!function_exists('wshop_membership')){
    function wshop_membership(){
        if(!is_user_logged_in()){
            return null;
        }
        
        global $current_user;
        if(!isset($current_user->membershipitem)){
            $membershipitem = new WShop_Membership_Item($current_user->ID);
            $current_user->membershipitem = $membershipitem->is_load()&&(!$membershipitem->expire_date||$membershipitem->expire_date>current_time('timestamp'))?$membershipitem:null;
        }

        return $current_user->membershipitem;
    }
}

if(!function_exists('wshop_membership_valid')){
    function wshop_membership_valid($success,$failed,$roles=array()/*此参数已作废*/){
        if(!is_user_logged_in()){
            return call_user_func_array($failed,array(null));
        }
        
        global $current_user;
        if(!isset($current_user->membershipitem)){
             $membershipitem = new WShop_Membership_Item($current_user->ID);
             $current_user->membershipitem = $membershipitem->is_load()&&(!$membershipitem->expire_date||$membershipitem->expire_date>current_time('timestamp'))?$membershipitem:null;
        }
        
        if($current_user->membershipitem){
            return call_user_func_array($success, array($current_user,$current_user->membershipitem));
        }
        
        return call_user_func_array($failed,array($current_user));
    }
}

if(!function_exists('wshop_membership_rolename')){
    function wshop_membership_rolename($atts = array(),$echo = true){
        if(isset($atts['ID'])){
            $wp_user = get_user_by('id', absint($atts['ID']));
            if(!$wp_user){
                return '游客';
            } 
            
            $membershipitem = new WShop_Membership_Item($wp_user->ID);
            
            if(!$membershipitem||!(!$membershipitem->expire_date||$membershipitem->expire_date>current_time('timestamp'))){
                return '注册用户';
            }
            return $membershipitem->get_role_name();
        }else{
            if(is_user_logged_in()){
                global $current_user;
                if(!isset($current_user->membershipitem)){
                    $membershipitem = new WShop_Membership_Item($current_user->ID);
                    $current_user->membershipitem = $membershipitem->is_load()&&(!$membershipitem->expire_date||$membershipitem->expire_date>current_time('timestamp'))?$membershipitem:null;
                }
                
                if(!$current_user->membershipitem){
                    return '注册用户';
                }
                return $current_user->membershipitem->get_role_name();
            }
        }
       
        return '游客';
    }
}
if(!function_exists('wshop_membership_expire_date')){
    function wshop_membership_expire_date($atts = array(),$echo = true){
        if(isset($atts['ID'])){
            $wp_user = get_user_by('id', absint($atts['ID']));
            if(!$wp_user){
                return '--';
            }
        
            $membershipitem = new WShop_Membership_Item($wp_user->ID);
            if(!$membershipitem||!(!$membershipitem->expire_date||$membershipitem->expire_date>current_time('timestamp'))){
                return '--';
            }
            return $membershipitem->expire_date?date('Y-m-d H:i',$membershipitem->expire_date):'永久有效';
        }else{
            if(is_user_logged_in()){
                global $current_user;
                if(!isset($current_user->membershipitem)){
                    $membershipitem = new WShop_Membership_Item($current_user->ID);
                     $current_user->membershipitem = $membershipitem->is_load()&&(!$membershipitem->expire_date||$membershipitem->expire_date>current_time('timestamp'))?$membershipitem:null;
                }
        
                if(!$current_user->membershipitem){
                    return '--';
                }
                 return $current_user->membershipitem->expire_date?date('Y-m-d H:i',$current_user->membershipitem->expire_date):'永久有效';
            }
        }
         
        return '--';
    }
}
return WShop_Add_On_Membership::instance();
?>