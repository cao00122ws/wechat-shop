<?php 

$data = WShop_Temp_Helper::clear('atts','templates');

$context = isset($data['context'])?$data['context']:null;
if(empty($context)){
    $context = WShop_Helper::generate_unique_id();
}

?>
<div class="xh-form clearfix"> 
	<label>请选择会员类型</label>
     	<ul class="xh-vip clearfix">
     		<?php 
     		 global $wpdb;
     		 $memberships = $wpdb->get_results(
     		     "select *
     		      from {$wpdb->prefix}wshop_membership m
                  inner join {$wpdb->prefix}posts p on p.ID = m.post_ID
     		      where p.post_type='".WShop_Membership::POST_T."'
     		            and p.post_status='publish'
     	          order by p.menu_order;");
     		 if($memberships){
     		     $index = 0;
     		     foreach ($memberships as $item){
     		         $product = new WShop_Product($item->ID);
     		         if(!$product->is_load()){
     		             continue;
     		         }
     		         $item->product = $product;
     		         ?>
     		         <li>
         		         <a href="javascript:void(0);" class="wshop-membership-<?php echo $context?> <?php echo $index++===0?'active':''?>" data-id="<?php echo $item->ID?>">
             		         <?php 
             		         ob_start();
             		         ?>
             		           <span class="price"><?php echo $product->get_single_price(true)?></span> 
             		           <span class="title"><?php echo $product->get('post_title')?></span>
             		         <?php
             		         echo apply_filters('wshop_membership_purchase',ob_get_clean(),$item,$product);
             		         ?>
         		         </a> 
     		         </li>
     		         <?php 
     		     }
     		 }
     		?>
     		
     	</ul>
     	<script type="text/javascript">
			(function($){
				$('.wshop-membership-<?php echo $context?>').click(function(){
					$('.wshop-membership-<?php echo $context?>.active').removeClass('active');
					$(this).addClass('active');

					$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
				});

				$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
					data.post_id = $('.wshop-membership-<?php echo $context?>.active').attr('data-id');
				});
			})(jQuery);
     	</script>
        <div class="block20"></div>  
        <?php 
            do_action('wshop_membership_purchase_fields',$context,$memberships);
        ?>
                
        <div class="paymentbar clearfix">
            <a href="#section-payment-<?php echo $context?>" class="wshop-sections-<?php echo $context?> active" data-id="pay">在线支付</a>
            <a href="#section-code-<?php echo $context?>" class="wshop-sections-<?php echo $context?>" data-id="code">激活码</a>
        </div>
        <div class="box" id="section-payment-<?php echo $context?>">
        	
        	<p class="clearfix paylist">
        		<?php 
        		$payments = WShop::instance()->payment->get_payment_gateways();
        		if($payments){
        		    $index = 0;
        		    foreach ($payments as $payment){
        		        ?><label><input type="radio" <?php echo $index++==0?'checked':'';?> name="payment_method-<?php echo $context?>" value="<?php echo $payment->id?>" class="payment-method-<?php echo $context?>"/><img src="<?php echo $payment->icon?>" style="vertical-align:middle;" alt="<?php echo esc_attr($payment->title)?>"></label><?php 
        		    }
        		}
        		?>
                <script type="text/javascript">
                	(function($){
                		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
    						data.payment_method = $('.payment-method-<?php echo $context?>:checked').val();
                    	});
                	})(jQuery);
                </script>
            </p>
        </div>
        
        <div class="box" style="display: none;" id="section-code-<?php echo $context?>">
            
            <div class="xh-form-group">
            	<label>输入激活码:</label>
                <input type="text" class="form-control" id="wshop-code-<?php echo $context?>" value="" />
            </div>
            <script type="text/javascript">
            	(function($){
            		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
    					data.code = $.trim($('#wshop-code-<?php echo $context?>').val());
                	});
            	})(jQuery);
            </script>
        </div>  	
		<script type="text/javascript">
			(function($){
				$('.wshop-sections-<?php echo $context?>').click(function(event){
					$($('.wshop-sections-<?php echo $context?>.active').removeClass('active').attr('href')).hide();;
					$($(this).addClass('active').attr('href')).show();
					event.preventDefault();
					return false;
				});

				$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
					data.scope = $('.wshop-sections-<?php echo $context?>.active').attr('data-id');
            	});
			})(jQuery);
		</script>
          
        <div class="block20"></div>
        
        <div class="xh-form-group">
        	<?php 
           		echo WShop::instance()->WP->requires(WSHOP_DIR, '__purchase.php',array(
           		    'content'=>__('Pay Now',WSHOP),
           		    'class'=>'xh-btn xh-btn-danger xh-btn-block xh-btn-membership',
           		    'location'=>WShop_Helper_Uri::get_location_uri(),
           		    'context'=>$context,
           		    'section'=>'membership',
           		    'modal'=>'shopping',
           		    'tab'=>'membership'
           		));
           		
           		echo WShop::instance()->WP->requires(WSHOP_DIR, 'page/checkout-order-pay-total-amount.php',array(
           		    'context'=>$context
           		));
                ?>
        </div>
</div>