<div class="wshop-pay-button" id="wshop-modal-membership" style="display:none;">
    	<div class="cover"></div>
        <div class="xh-buy-vip">
         	<a href="javascript:void(0);" class="vip-close" ><img src="<?php echo WSHOP_URL?>/assets/image/v2.ui2.close2.png" alt="close"></a>
            <div class="topbar">
            	<b>会员购买</b> 
            	<?php if(!is_user_logged_in()){
            	    ?><span class="xh-pull-right">你还没有登录，请先<a href="<?php echo wp_login_url(WShop_Helper_Uri::get_location_uri())?>" >登录</a></span><?php 
            	}?>   	   
            </div>
            <?php 
            $api = WShop_Add_On_Membership::instance();
            echo WShop::instance()->WP->requires($api->domain_dir, 'membership/__purchase.php');?>
        </div>
    </div>
    
    <script type="text/javascript">
    	(function($){
    		$('.wshop-pay-button .xh-buy-vip .vip-close,#wshop-modal-membership .cover').click(function(){
    			$('#wshop-modal-membership').hide();
    		});
    		if(!window.__modal_membership_resize){
    			window.__modal_membership_resize=function(){
    				var $ul =$('#wshop-modal-membership .xh-buy-vip');
    				var width = window.innerWidth,height = window.innerHeight;
    				if (typeof width != 'number') { 
    				    if (document.compatMode == 'CSS1Compat') {
    				        width = document.documentElement.clientWidth;
    				        height = document.documentElement.clientHeight;
    				    } else {
    				        width = document.body.clientWidth;
    				        height = document.body.clientHeight; 
    				    }
    				}
    				$ul.css({
						top:((height - $ul.height()) / 2) + "px",
						left:((width - $ul.width()) / 2) + "px"
					});
    			};
    		}
    		$(window).resize(function(){
    			window.__modal_membership_resize();
    		});
    	})(jQuery);
    </script>