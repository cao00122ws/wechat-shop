<?php 
if (! defined('ABSPATH')) {
    exit();
}
$api = WShop_Add_On_Membership::instance();

?>
<div class="xh-buy-vip">
   	   <div class="topbar"><b>会员购买</b> 
	<?php if(!is_user_logged_in()){
	    ?><span class="xh-pull-right">你还没有登录，请先<a href="<?php echo wp_login_url(WShop_Helper_Uri::get_location_uri())?>" >登录</a> 或 <a href="<?php echo wp_registration_url()?>" >注册</a></span><?php 
	}?>   	   
</div>
<?php echo WShop::instance()->WP->requires($api->domain_dir, 'membership/__purchase.php');?>
</div>