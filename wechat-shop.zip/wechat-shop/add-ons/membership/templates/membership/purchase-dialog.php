<?php 
if (! defined('ABSPATH')) {
    exit();
}
$data = WShop_Temp_Helper::clear('atts','templates');
$atts = !is_array($data['atts'])?array():$data['atts'];
$content =empty( $data['content'])?__('Upgrade membership',WSHOP):$data['content'];
$api = WShop_Add_On_Membership::instance();
$context = WShop_Helper::generate_unique_id();
$class = isset($atts['class'])?$atts['class']:'xh-btn xh-btn-danger xh-btn-lg';
$style = isset($atts['style'])?$atts['style']:null;
$location = isset($atts['location'])?$atts['location']:null;
//如果是移动端，那么直接跳转到会员购买页面
if(WShop_Helper_Uri::is_app_client()){
    $url = $api->get_page_checkout_url();
    ?><a href="<?php echo $url;?>" class="<?php echo $class?>" style="<?php echo $style?>"><?php echo do_shortcode($content);?></a><?php
    return;
}

if(!is_user_logged_in()){
    $url = wp_login_url($location);
    ?><a href="<?php echo $url;?>" class="<?php echo $class?>" style="<?php echo $style?>"><?php echo do_shortcode($content);?></a><?php
    return;
}
?>
<a href="javascript:void(0);" id="btn-pay-<?php echo $context?>" class="<?php echo $class?>" style="<?php echo $style?>"><?php echo do_shortcode($content);?></a>
<script type="text/javascript">
	(function($){
		$('#btn-pay-<?php echo $context?>').click(function(){
			$('.wshop-pay-button').hide();
			
			$('#wshop-modal-membership').css('display','block');
			window.__modal_membership_resize();
		});
	})(jQuery);
</script>


