<?php 
if (! defined('ABSPATH')) {
    exit();
}
global $current_user;
if(!is_user_logged_in()){
   WShop::instance()->WP->wp_die(WShop_Error::err_code(501),false,false);
    return;
}
$api = WShop_Add_On_Membership::instance();
$membership_item = new WShop_Membership_Item(get_current_user_id());
if(!$membership_item->is_load()){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
    return;
}

?>
<div class="xh-buy-vip" style="padding:50px 0;text-align: center;font-size:140%;">
   	  <h3 style="color:green;">恭喜您！会员升级成功！</h3>
   	       		<p style="font-size:15px;">当前角色：<?php echo $membership_item->get_role_name()?> ，到期时间：<?php echo $membership_item->expire_date>0?date('Y-m-d H:i',$membership_item->expire_date):'永久'?></p>
</div>