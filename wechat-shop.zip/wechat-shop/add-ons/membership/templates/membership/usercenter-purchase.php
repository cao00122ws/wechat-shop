<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
XH_UC_Menu::instance()->header();

$api = WShop_Add_On_Membership::instance();

?>
<style>
.xh-btn.xh-btn-membership{padding:6px 20px;}
.xh-btn-membership.xh-btn-block{display:inline-block;width:auto;}
</style>
<div class="setting_header"><span>会员升级</span></div>
<div class="xh-buy-vip" style="border:0;float:left">

<?php echo WShop::instance()->WP->requires($api->domain_dir, 'membership/__purchase.php');?>
</div>


<?php XH_UC_Menu::instance()->footer();?>