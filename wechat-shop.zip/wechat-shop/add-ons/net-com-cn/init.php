<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
/**
 * @author rain
 *
 */
class WShop_Add_On_Net_Com_CN extends Abstract_WShop_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Net_Com_CN
     */
    private static $_instance = null;
   
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Net_Com_CN
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wshop_add_ons_net_com_cn';
        $this->title='net-com.cn';
        $this->description='订单邮件接收者为文章作者。新订单->收件人：请设置为 {email:admin},{email:author}';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';   
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
    }

    /**
     * @param WShop_Order $order
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_load()
     */
    public function on_load(){
        add_filter('wshop_order_email_new_order', function($calls,$order){
            $calls[]=function($order){
                
                $order_items = $order->get_order_items();
                if(!$order_items||count($order_items)==0){return;}
                $post = get_post($order_items[0]->post_ID);
                if(!$post){return;}
                $wp_user = get_userdata($post->post_author);
                if(!$wp_user||!$wp_user->user_email||!is_email($wp_user->user_email)){return;}
                
                $settings =  array(
                    '{email:author}'=>$wp_user->user_email,
                    '{order_number}'=>$order->id,
                    '{order_date}'=>date('Y-m-d H:i',$order->paid_date)
                );
                
                $content =WShop::instance()->WP->requires(
                    WSHOP_DIR,
                    "emails/new-order.php",
                    array('order'=>$order)
                );
                
                $email =new WShop_Email('new-order');
                return $email->send($settings,$content);
            };
            return $calls;
            
        },10,2);
    }
}

return WShop_Add_On_Net_Com_CN::instance();
?>