<?php 

class WShop_Pay_Per_View extends WShop_Post_Object{
    public function __construct($obj=null){
        parent::__construct($obj);
    }
    
    public $contents = array();
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_pay_per_view';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_pay_per_view_properties', array(
            'post_ID'=>null,
            'contents'=>array()
        ));
    }
}

class WShop_Pay_Per_View_Model extends Abstract_WShop_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        $collate=$this->get_collate();
        global $wpdb;
        //角色
        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_pay_per_view` (
        	`post_ID` BIGINT(20) NOT NULL,
        	`contents` TEXT NULL DEFAULT NULL,
        	PRIMARY KEY (`post_ID`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
    }
}

class WShop_Pay_Per_View_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;
    public $_post_content=false;
    public $_post_edit=false;
    public $_post_request=array();
    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Pay_Per_View_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="pay_per_view";
        $this->title = __('Pay per view',WSHOP);
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
    public function init_form_fields(){
        global $post;
        $this->form_fields = apply_filters('wshop_pay_per_view_fields', array(
            'contents' => array(
                'title' => __('Purchase display', WSHOP),
                'type' => 'custom',
                'func' =>function($key,$api,$data){
                    $field = $api ->get_field_key($key)."_before";
                    global $post;
                ?>
                    
    				<?php 
    				$field1 = $api ->get_field_key($key)."_after";
    				?>
    				<tr valign="top" class="">
                    	<th scope="row" class="titledesc">
                    		<label>隐藏内容</label>
            			</th>
                    	<td class="forminp">
                            <fieldset>
                    			<legend class="screen-reader-text">
                    				<span>隐藏内容</span>
                    			</legend>
                    			<textarea rows="3" placeholder="内容不会保留在文本框内" cols="20" class="input-text wide-input " name="<?php echo $field1;?>" id="<?php echo $field1;?>" style="min-width:400px;"></textarea>
            					<p class="description">  
            						提示：隐藏内容需要插入文章后才会生效!          
            						<a href="" target="_blank"><code>[wshop_paid]</code></a><a class="wshop-btn-insert" href="javascript:void(0);" onclick="window.wshop_post_editor.pay_per_view_paid();"><?php echo __('Insert into post content',WSHOP)?></a>
                                   <script type="text/javascript">
                                    jQuery(function($){
                                    	if(!window.wshop_post_editor){window.wshop_post_editor={};}
                                        	window.wshop_post_editor.pay_per_view_paid=function(){
                                        	var content = $.trim($('#<?php echo $field1;?>').val());
                        					var text ='[wshop_paid post_id="<?php echo $post->ID?>" show_buy_btn="true"]'+content+'[/wshop_paid]';
                        					window.wshop_post_editor.add_content(text);
                        					$('#<?php echo $field1;?>').val('');
                                        };
                                    });
                        			</script>
                                    </p>
            				</fieldset>
        				</td>
    				</tr>
                    <?php
                 },
                 'validate'=>function($key,$api){
                     global $post;
                     if(!$post){
                         return null;
                     }
                     if(!defined('wshop_pay_per_view_admin_editing')){
                         define('wshop_pay_per_view_admin_editing', true);
                     }
                     $hidden = WShop_Pay_Per_View_Fields::instance();
                     $hidden->_post_content=array();
                     $hidden->_post_edit = true;
                     do_shortcode(stripslashes($_POST['content']));
                     $contents =$hidden->_post_content;
                     $hidden->_post_content=array();
                     $hidden->_post_edit=false;
                     return $contents;
                 })
        ),$post);
    }

    public function get_post_types()
    {
        $post_types= WShop_Add_On_Modal_Pay_Per_View::instance()->get_option('post_types');
  
        global $wp_post_types;
        $types = array();
        if($post_types&&$wp_post_types){
            foreach ($wp_post_types as $key=>$type){
                if(!in_array($key, $post_types)){continue;}
               
                if($type->show_ui&&$type->public){
                    $types[$type->name]=(empty($type->label)?$type->name:$type->label).'('.$type->name.')';
                }
            }
        }
    
        return apply_filters('wshop_pay_per_view_post_types', $types);
    }

    public function get_object($post){
        return new WShop_Pay_Per_View($post);
    }
}

?>