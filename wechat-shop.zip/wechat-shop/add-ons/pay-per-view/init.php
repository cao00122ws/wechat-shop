<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'abstract-xh-add-ons-api.php';
require_once 'includes/class-wshop-pay-per-view.php';

/**
 * 注意wshop_paid wshop_unpaid 仅支持在 the_content()且是single()内调用
 * @author rain
 *
 */
class WShop_Add_On_Modal_Pay_Per_View extends Abstract_WShop_Add_Ons_Pay_Pay_View_Api{   
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Modal_Pay_Per_View
     */
    private static $_instance = null;
 
    private $dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Modal_Pay_Per_View
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        $this->version = '1.0.1';
        $this->id='wshop_add_ons_pay_per_view';
        $this->title=__('Pay Per View',WSHOP);
        $this->description='支持多个隐藏内容插入文章中，支付可见';     
        
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->plugin_uri='https://www.wpweixin.net/product/1469.html';
        $this->dir = WShop_Helper_Uri::wp_dir(__FILE__);
        
        $this->init_form_fields();    
    }
  
    public function on_install(){
        $api = new WShop_Pay_Per_View_Model();
        $api->init();
    }
    public  function on_load(){
        $this->m1();
        add_filter('wshop_online_post_types', array($this,'wshop_online_post_types'));
    }
    
    public function register_fields(){
        WShop_Pay_Per_View_Fields::instance();
    }
    
    public function wshop_online_post_types($post_types){
        $types = $this->get_option('post_types');
         
        if($types){
            foreach ($types as $type){
                if(!in_array($type, $post_types)){
                    $post_types[]=$type;
                }
            }
        }
         
        return $post_types;
    }
    public  function on_init(){
        $this->m2();
    }

    public function wshop_order_received_url($url,$order){
        if(isset($order->metas['location'])&&!empty($order->metas['location'])){
            return esc_url_raw($order->metas['location']);
        }
        return $url;
    }
    
    /**
     * @since 1.0.0
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields(){
        $fields =array(
            'post_types'=>array(
                'title'=>__('Bind post types',WSHOP),
                'type'=>'multiselect',
                'func'=>true,
                'options'=>array($this,'get_post_type_options')
            )
        );
        
        $this->form_fields = apply_filters('wshop_pay_per_view_fields', $fields);
    }

    public function get_post_type_options(){
       return apply_filters('wshop_modal_fast_shopping_post_types', parent::get_post_type_options());
    }
    
    public function wshop_btn_view($atts=array(),$content=null){
       return WShop_Async::instance()->async_call('wshop_btn_view',
            function(&$atts,&$content){
                if(!isset($atts['post_id'])||empty($atts['post_id'])){
                    if(method_exists(WShop::instance()->WP, 'get_default_post')){
                        $default_post = WShop::instance()->WP->get_default_post();
                        $atts['post_id']=$default_post?$default_post->ID:0;
                    }else{
                        global $wp_query,$post;
                        $default_post=$wp_query?$wp_query->post:null;
                        if(!$default_post&&$post){
                            $default_post = $post;
                        }
                        $atts['post_id']=$default_post?$default_post->ID:0;
                    }
                }
                
                if(!isset($atts['location'])||empty($atts['location'])){
                    $atts['location'] =  WShop_Helper_Uri::get_location_uri();
                }
            }, 
            function(&$atts,&$content){
                //付费后隐藏
                if(WShop::instance()->payment->is_validate_get_pay_per_view($atts['post_id'],empty($atts['roles'])?null:explode(',',$atts['roles'] ))){
                    return null;
                }
                $content=empty($content)?__('Pay Now',WSHOP):$content;
                $atts['section'] = 'pay_per_view';
                return WShop::instance()->WP->requires(WSHOP_DIR, 'button-purchase.php',array(
                    'content'=>$content,
                    'atts'=>$atts
                ));
                
            },  
            array(
                'style'=>null,
                'post_id'=>0,
                'modal'=>null,
                'roles'=>null,
                'class'=>'xh-btn xh-btn-danger xh-btn-lg',
                'location'=>null
           ),
            $atts, 
            $content);
    }
    
    /**
     * 付费后才能查看
     * @param array $atts 
     * @param string $content
     */
    public function wshop_paid($atts=array(),$content=null){
       return WShop_Async::instance()->async_call('wshop_paid',
            function(&$atts,&$content){
                if(apply_filters('wshop_payper_view_conditions',!(doing_action('the_content')&&is_singular())&&!defined('wshop_pay_per_view_admin_editing'))){
                    $content= null;
                    return;
                }
                if(!isset($atts['post_id'])||empty($atts['post_id'])){
                    if(method_exists(WShop::instance()->WP, 'get_default_post')){
                        $default_post = WShop::instance()->WP->get_default_post();
                        $atts['post_id']=$default_post?$default_post->ID:0;
                    }else{
                        global $wp_query,$post;
                        $default_post=$wp_query?$wp_query->post:null;
                        if(!$default_post&&$post){
                            $default_post = $post;
                        }
                        $atts['post_id']=$default_post?$default_post->ID:0;
                    }
                }
                
                if(!isset($atts['location'])||empty($atts['location'])){
                    $atts['location'] =  WShop_Helper_Uri::get_location_uri();
                }
                
                $c = $content;
                $api =  WShop_Pay_Per_View_Fields::instance();
                if($api->_post_content===false){
                    $api->_post_content = array();
                }
                $index = count($api->_post_content);
                $api->_post_content[$index]=$c;
               
                $content = $index;
            }, 
            function(&$atts,&$content){
                if(is_null($content)){return null;}
                $post = get_post($atts['post_id']);
                if(!$post){
                    return null;
                }
                
                $api = WShop_Add_On_Modal_Pay_Per_View::instance();
                $settings = WShop_Pay_Per_View_Fields::instance();
                $onlines = $api->get_option('post_types');
                if(!in_array($post->post_type, $onlines)){
                    return null;
                }
                
                $post_ID =$post->ID;
                
                if(!isset($settings->_post_request[$post_ID])){
                    $settings->_post_request[$post_ID]=$api->is_validate_get_data($atts);
                }
               
                if($settings->_post_content===false){
                    $pay_per_view = new WShop_Pay_Per_View($post_ID);
                    $settings->_post_content = $pay_per_view->is_load()?$pay_per_view->contents:null;
                }
               
                    if($settings->_post_request[$post_ID]){
                        if($settings->_post_content){
                            $html =$settings->_post_content[$content];
                            //兼容老版本
                            if(is_array($html)){
                                return do_shortcode($html['content']);
                            }
                            
                            return do_shortcode($html);
                        }
                    }
                    
                    $product = new WShop_Product($post->ID);
                    if($product->is_load()&&$product->get_single_price(false)>0){
	                    $show_buy_btn = isset($atts['show_buy_btn'])&&$atts['show_buy_btn']!=='false'&&$atts['show_buy_btn']!=='0'?true:false;   
	                    return WShop::instance()->WP->requires($this->dir, 'pay-per-view/button-purchase.php',array(
	                        'product'=>$product,
	                        'roles'=>isset($atts['roles'])&&!empty($atts['roles'])?explode(',', $atts['roles']):array(),
	                        'show_buy_btn'=>$show_buy_btn
	                    ));
                    }
               
                return '';
            },  
            array(
                   'post_id'=>0,
                   'roles'=>null,
                   'location'=>null,
                   'show_buy_btn'=>null
               ),
            $atts, 
            $content);
    }
    
    public function wshop_unpaid($atts=array(),$content=null){
        return WShop_Async::instance()->async_call('wshop_unpaid',
            function(&$atts,&$content){
                //避免多次调用短代码而造成混乱
                if(apply_filters('wshop_payper_view_conditions',!(doing_action('the_content')&&is_singular())&&!defined('wshop_pay_per_view_admin_editing'))){
                    $content= null;
                    return;
                }
                if(!isset($atts['post_id'])||empty($atts['post_id'])){
                    if(method_exists(WShop::instance()->WP, 'get_default_post')){
                        $default_post = WShop::instance()->WP->get_default_post();
                        $atts['post_id']=$default_post?$default_post->ID:0;
                    }else{
                        global $wp_query,$post;
                        $default_post=$wp_query?$wp_query->post:null;
                        if(!$default_post&&$post){
                            $default_post = $post;
                        }
                        $atts['post_id']=$default_post?$default_post->ID:0;
                    }
                }
                
                if(!isset($atts['location'])||empty($atts['location'])){
                    $atts['location'] =  WShop_Helper_Uri::get_location_uri();
                }
                
                $c = $content;
                $api =  WShop_Pay_Per_View_Fields::instance();
                if($api->_post_content===false){
                    $api->_post_content = array();
                }
                $index = count($api->_post_content);
                $api->_post_content[$index]=$c;
                $content = $index;
            }, 
            function(&$atts,&$content){
                if(is_null($content)){return null;}
                $post = get_post($atts['post_id']);
                if(!$post){
                    return null;
                }
               
                $api = WShop_Add_On_Modal_Pay_Per_View::instance();
                $settings = WShop_Pay_Per_View_Fields::instance();
                $onlines = $api->get_option('post_types');
                if(!in_array($post->post_type, $onlines)){
                    return null;
                }
                
                $post_ID =$post->ID;
                
                if(!isset($settings->_post_request[$post_ID])){
                    $settings->_post_request[$post_ID]=$api->is_validate_get_data($atts);
                }
               
                if($settings->_post_content===false){
                    $pay_per_view = new WShop_Pay_Per_View($post_ID);
                    $settings->_post_content = $pay_per_view->is_load()?$pay_per_view->contents:null;
                }
                
                if(!$settings->_post_request[$post_ID]&& $settings->_post_content){
                    $html =$settings->_post_content[$content];
                    //兼容老版本
                    if(is_array($html)){
                        return do_shortcode($html['content']);
                    }
                    
                    return do_shortcode($html);
                }
                
                return null;
            },  
           array(
                   'post_id'=>0,
                   'roles'=>null,
                   'location'=>null
               ), 
            $atts, 
            $content);
    }
    
    /**
     * 判断用户是否可以下载付费内容
     * @param array $atts
     * @return boolean
     */
    public function is_validate_get_data($atts){
        $post_id = isset($atts['post_id'])?$atts['post_id']:null;
        if(!$post_id){
            return false;
        }
        
        $is_validate = apply_filters('wshop_pay_per_view_is_validate_get_data', false,$atts);
        if($is_validate){
            return $is_validate;
        }
        
        return WShop::instance()->payment->is_validate_get_pay_per_view($post_id,isset($atts['roles'])&&!empty($atts['roles'])?explode(',', $atts['roles']):null); 
    }
}

return WShop_Add_On_Modal_Pay_Per_View::instance();
?>