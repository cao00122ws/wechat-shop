<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

$request = WShop_Temp_Helper::clear('atts','templates');
$product = $request['product'];
$roles = $request['roles'];
?><div style="background:#f8f8f8;padding:30px 20px;border:1px dashed #ccc;position: relative;z-index:999;text-align:center;margin:15px 0">
	<p>此处内容需要付费<?php if(function_exists('wshop_dialog_membership_checkout')){echo '或购买VIP';}?>才能显示</p>
	
	<?php  
	echo WShop::instance()->WP->requires(WSHOP_DIR, 'button-purchase.php',array(
        'content'=>$product->get_single_price(true)."立即支付",
        'atts'=>array(
            'section'=>'pay_per_view',
            'location'=>  get_permalink($product->post),
            'class'=>'xh-btn xh-btn-sm xh-btn-success',
            'post_id'=>$product->post->ID
        )
    ));
    
    if(!in_array('none', $roles)){
        if(function_exists('wshop_dialog_membership_checkout')){
            ?> <span class='xh-hidde'>或</span> <?php 
            wshop_dialog_membership_checkout(array(
                'class'=>'xh-btn xh-btn-sm xh-btn-success',
                'location'=>  get_permalink($product->post),
            ),'升级VIP');
        }
    }
?>
<span style="position: absolute;top:15px;left:15px;font-size:90%;color:#90949c;">
  付费内容
</span>
<span style="position: absolute;top:10px;right:10px;"><img style="width:22px;" src="<?php echo WSHOP_URL?>/assets/image/noshow.png" alt=""></span>
</div>