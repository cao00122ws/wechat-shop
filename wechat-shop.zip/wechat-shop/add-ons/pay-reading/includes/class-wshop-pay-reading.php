<?php 

class WShop_Pay_Reading extends WShop_Post_Object{
    public $roles=array();
    
    public function get_roles(){
        if($this->roles&&is_string($this->roles)){
            $this->roles = array($this->roles);
        }
        
        
        return is_array($this->roles)?$this->roles:array('all');
    }
    
    public function __construct($obj=null){
        parent::__construct($obj);
    }
    
    public $contents = array();
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_pay_reading';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_pay_reading_properties', array(
            'post_ID'=>null,
            'roles'=>null
        ));
    }
}

class WShop_Pay_Reading_Model extends Abstract_WShop_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        $collate=$this->get_collate();
        global $wpdb;
        //角色
        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_pay_reading` (
        	`post_ID` BIGINT(20) NOT NULL,
        	`roles` TEXT NULL DEFAULT NULL,
        	PRIMARY KEY (`post_ID`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
    }
}

class WShop_Pay_Reading_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;
   
    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Pay_Per_View_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="pay_reading";
        $this->title = __('Pay reading',WSHOP);
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
    public function init_form_fields(){
        global $post;
        $this->form_fields = array(
            'roles'=>array(
                'title'=>__('Limit',WSHOP),
                'type'=>'custom',
                'default'=>array('all'),
                'description'=>'文章内容插入“more”标签，可以标记需要付费阅读的区域',
                'func'=>function($key,$api,$data){
                    $field = $api->get_field_key($key);
                    $defaults = array (
            	        'title' => '',
            	        'class' => '',
            	        'css' => '',
            	        'desc_tip' => false,
                        'description'=>null,
            	        'custom_attributes' => array (),
            	        'options' => array ()
            	    );
            	
            	    $data = wp_parse_args ( $data, $defaults );
                    $val = $api->get_option($key,array('all'));
                    if(!$val||!is_array($val)){
                        $val=array('all');
                    }
                    ?>
                    <tr valign="top" class="">
                    	<th scope="row" class="titledesc">
                    		<label><?php echo esc_html($data['title']);?></label>
            			</th>
                    	<td class="forminp">
                			 <style type="text/css">
                			     .wshop-roles li label{margin-right:10px !important;}              
		                     </style>
                            <fieldset>
                    			<legend class="screen-reader-text">
                    				<span><?php echo $data['title'];?></span>
                    			</legend>
                    			
                    			<ul style="list-style:none;" class="wshop-roles">
                    				<li><label><input class="role" data-index="0" name="<?php echo "{$field}[]"?>" type="checkbox" value="all" <?php echo in_array('all', $val)?'checked':'';?>/> 所有人免费阅读</label></li>
                    				<li><label><input class="role" data-index="1" name="<?php echo "{$field}[]"?>" type="checkbox" value="none" <?php echo in_array('none', $val)?'checked':'';?>/> 所有人付费阅读</label></li>
                    				
                    				<li>指定角色免费阅读：
                    				<?php 
                    				    $roles = $api->get_role_options();
                    				    if(!$roles){$roles=array();}
                    				    foreach ($roles as $role=>$name){
                    				        ?><label><input class="role" data-index="2" type="checkbox" <?php echo in_array($role, $val)?'checked':'';?> value="<?php echo $role?>" name="<?php echo "{$field}[]"?>"/> <?php echo $name?></label> <?php 
                    				    }
                    				?>
                    				</li>
                    			</ul>
                    			<script type="text/javascript">
									(function($){
											$('.wshop-roles .role').click(function(){
												var name = $(this).attr('data-index');
												$('.wshop-roles .role[data-index!='+name+']').removeAttr('checked');
											});
									})(jQuery);
                    			</script>
            					<p class="description"><?php echo $data['description'];?></p>
            				</fieldset>
        				</td>
    				</tr>
                    <?php 
                }
            )
        ); 
    }

    public function get_post_types()
    {
        $post_types= WShop_Add_On_Pay_Reading::instance()->get_option('post_types');
  
        global $wp_post_types;
        $types = array();
        if($post_types&&$wp_post_types){
            foreach ($wp_post_types as $key=>$type){
                if(!in_array($key, $post_types)){continue;}
               
                if($type->show_ui&&$type->public){
                    $types[$type->name]=(empty($type->label)?$type->name:$type->label).'('.$type->name.')';
                }
            }
        }
    
        return apply_filters('wshop_pay_reading_post_types', $types);
    }

    public function get_object($post){
        return new WShop_Pay_Reading($post);
    }
}