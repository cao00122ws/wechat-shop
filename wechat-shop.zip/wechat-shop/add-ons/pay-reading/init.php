<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'abstract-xh-add-ons-api.php';
require_once 'includes/class-wshop-pay-reading.php';

class WShop_Add_On_Pay_Reading extends Abstract_WShop_Add_Ons_Pay_Reading_Api{   
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Pay_Reading
     */
    private static $_instance = null;
 
    private $dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Pay_Reading
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        $this->version = '1.0.1';
        $this->id='wshop_add_ons_pay_reading';
        $this->title=__('Pay reading',WSHOP);     
        $this->description='文章部分内容隐藏，付费阅读全文';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->dir = WShop_Helper_Uri::wp_dir(__FILE__);
        
        $this->init_form_fields();    
    }
  
    public function init_form_fields(){
        $this->form_fields = array(
            'post_types'=>array(
                'title'=>__('Bind post types',WSHOP),
                'type'=>'multiselect',
                'func'=>true,
                'options'=>array($this,'get_post_type_options')
            )
        );
    }
    
    public function on_install(){
        $api = new WShop_Pay_Reading_Model();
        $api->init();
    }
    public  function on_load(){
        $this->m1();
    }
    public  function on_init(){
        $this->m2();
    }
    public function register_fields(){
        WShop_Pay_Reading_Fields::instance();
    }
    
    public function do_ajax(){
        $action = "wshop_{$this->id}";
        $request=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));
        
        switch ($request['tab']){
            case 'layze_load':
                $request['post_id'] = isset($_REQUEST['post_id'])?$_REQUEST['post_id']:null;
                if(!WShop::instance()->WP->ajax_validate($request,$request['hash'],true)){
                    echo WShop_Error::err_code(701)->to_json();exit;
                }
                
                global $wp_query,$post;
                $post = get_post($request['post_id']);
                if(!$post){
                    echo WShop_Error::err_code(404)->to_json();exit;
                }
                $wp_query->setup_postdata($post);
                
                $obj = new WShop_Pay_Reading($post->ID);
                
                $product = new WShop_Product($post->ID);
                
                echo WShop_Error::success($this->render_post_content($obj,$product,null))->to_json();
                exit;
        }
    }
    public function wshop_order_received_url($url,$order){
        $location = isset($order->metas['location'])&&!empty($order->metas['location'])?esc_url_raw($order->metas['location']):null;
        if(!empty($location)){
            return $location;
        }
    
        return $url;
    }
     
    public function wshop_online_post_types($post_types){
        $types = $this->get_option('post_types');
         
        if($types){
            foreach ($types as $type){
                if(!in_array($type, $post_types)){
                    $post_types[]=$type;
                }
            }
        }
         
        return $post_types;
    }
    
    public function wshop_admin_menu_menu_default_modal($modals){
        $modals[]=$this;
        return $modals;
    }
    
    public function the_content($content){
        $types = $this->get_option('post_types');
        if(!$types||!is_array($types)){
            return $content;
        }
        
        if(!is_singular($types)){
            return $content;
        }
        
        $post = get_post();
        if(!$post||post_password_required( $post )){
            return $content;
        }

        $obj = new WShop_Pay_Reading($post->ID);
        if(!$obj->is_load()||in_array('all', $obj->get_roles())){
            return $content;
        }
        
        $product = new WShop_Product($post->ID);
        if(!$product->is_load()){
            return $content;
        }
        
        if($product->get_single_price(false)<=0){
            return $content;
        }
        
        ob_start();
        if('yes'===WShop_Settings_Default_Basic_Default::instance()->get_option('enable_async')){ ?>
           <div id="wshop-main-post-content-<?php echo $post->ID?>" class="wshop wshop-layzeload"></div>
            <script type="text/javascript">
            jQuery(function($){
            	$('#wshop-main-post-content-<?php echo $post->ID?>').block({
					message: '',
					overlayCSS: {
						background: '#fff',
						opacity: 0.6
					}
				});
            	$.ajax({
		            type: "POST",
		            url: '<?php print WShop::instance()->ajax_url(array('action'=>"wshop_{$this->id}",'post_id'=>$post->ID,'tab'=>'layze_load'),true,true);?>',
		            timeout:6000,
		            cache:false,
		            dataType:'json',
		            complate:function(){
		            	$('#wshop-main-post-content-<?php echo $post->ID?>').unblock();
    		        },
		            success:function(e){
		                if (e && e.errcode==0) {
			                $('#wshop-main-post-content-<?php echo $post->ID?>').html(e.data);
		                    return;
		                }
		                
		                console.error(e.errmsg);
		            },
		            error:function(e){
		            	console.error(e.responseText);
		            }
		        });
            });
            </script>
            <?php 
        }else{
            echo $this->render_post_content($obj,$product,$content);
        }
       
        return ob_get_clean();
    }
    
    public function render_post_content($obj,$product,$content=null){
        return WShop::instance()->WP->requires($this->dir, 'pay-reading/button-purchase.php',array(
            'obj'=>$obj,
            'product'=>$product,
            'content'=>$content
        ));
    }
}

return WShop_Add_On_Pay_Reading::instance();
?>