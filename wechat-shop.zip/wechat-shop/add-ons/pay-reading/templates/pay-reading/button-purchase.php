<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

$request = WShop_Temp_Helper::clear('atts','templates');
$product = $request['product'];
$obj = $request['obj'];
$content = $request['content'];

global $post,$page, $more, $preview, $pages, $multipage;
if(!$post){
    return;
}
if($page<=0){$page=1;}

$content = WShop_Temp_Helper::clear('atts','templates');
//如果内容为空，说明是ajax加载，那么直接组装$pages
if(empty($content)&&$pages){
    $content='';
    foreach ($pages as $page){
        $content.=$page;
    }
}

if(!$obj->is_load()
    ||!$product->is_load()
    ||$product->get_single_price(false)<=0
    ||WShop::instance()->payment->is_validate_get_pay_per_view($post->ID,$obj->get_roles())
    ){
    echo do_shortcode($content);
    return;
}

//不考虑文章分页的情况
if ( $page > count( $pages ) ){ // if the requested page doesn't exist
    $page = count( $pages ); // give them the highest numbered page that DOES exist
}

$content =$page==0?$content: $pages[$page - 1];
if ( preg_match( '/<!--more(.*?)?-->/', $content, $matches ) ) {
    $content = explode( $matches[0], $content); 
} else {
    $content = array($content );
}

if($content&&is_array($content)&&count($content)>1){
    echo do_shortcode($content[0]);
}

if($content[0]&&strlen($content[0])>200){
    ?>
    <style type="text/css">
        .wshop-pay-reading{position: relative;}
        .wshop-pay-reading .wshop-layzeload-content{
            position:absolute;
            bottom:0;
            width:100%;
            z-index:101;
            padding:180px 0 40px 0;
            text-align:center;
            background-image: -webkit-gradient(linear,left top, left bottom,from(rgba(255,255,255,0)),color-stop(70%, #fff));
            background-image: linear-gradient(-180deg,rgba(255,255,255,0) 0%,#fff 70%);
        }
        </style>
    <?php 
}
?>
<div class="wshop-pay-reading">
	<div class="wshop-layzeload-content"><?php 

echo WShop::instance()->WP->requires(WSHOP_DIR, 'button-purchase.php',array(
    'content'=>$product->get_single_price(true)."查看全文",
    'atts'=>array(
        'section'=>'pay-reading',
        'location'=>  get_permalink($post),
        'class'=>'xh-btn xh-btn-border',
        'post_id'=>$post->ID
    )
));

if(!in_array('none', $obj->get_roles())){
    if(function_exists('wshop_dialog_membership_checkout')){
        ?> <span class='xh-hidde'>或</span> <?php 
        wshop_dialog_membership_checkout(array(
            'class'=>'xh-btn xh-btn-border-warning',
            'location'=>  get_permalink($post),
        ),'购买VIP查看全站');
    }
}
?>	</div>
</div><?php 

if($content&&is_array($content)&&count($content)>2){
    $next_content = '';
    for ($index=2;$index<count($content);$index++){
        $next_content.= $content[$index];
    }
    
    echo do_shortcode($next_content);
}