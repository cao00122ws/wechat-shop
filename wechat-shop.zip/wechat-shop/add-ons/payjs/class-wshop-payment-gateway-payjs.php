<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

class WShop_Payment_Gateway_Payjs extends Abstract_WShop_Payment_Gateway{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Payment_Gateway_Payjs
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Payment_Gateway_Payjs
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='payjs';
        $this->group = 'wechat';
        $this->title=__('Wechat Pay',WSHOP);
        
        $this->icon=WSHOP_URL.'/assets/image/payjs-l.png';
        $this->icon_small=WSHOP_URL.'/assets/image/payjs.png';
        
        $this->init_form_fields ();
        $this->enabled ='yes'==$this->get_option('enabled');
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields() {
        $this->form_fields = array (
            'enabled' => array (
                'title' => __ ( 'Enable/Disable', WSHOP ),
                'type' => 'checkbox',
                'label' => __ ( 'Enable payjs payment', WSHOP ),
                'default' => 'yes'
            ),
			'mchid' => array (
					'title' =>  __('Merchant ID', WSHOP),
					'type' => 'text',
					'css' => 'width:400px' ,
				        'description'=>'<a href="https://payjs.cn/ref/ZBABED">立即申请开通</a>'
			),
			'mchkey' => array (
					'title' =>  __('Sign Key', WSHOP),
					'type' => 'text',
					'css' => 'width:400px'
			)
        );
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Payment_Gateway::process_payment()
     */
    public function process_payment($order)
    {
        $api = WShop_Add_On_Payjs::instance();
        
        return WShop_Error::success(WShop::instance()->ajax_url(array(
            'action'=>"wshop_{$api->id}",
            'tab'=>'pay',
            'order_id'=>$order->id
        ),true,true));
    }
    
}
?>