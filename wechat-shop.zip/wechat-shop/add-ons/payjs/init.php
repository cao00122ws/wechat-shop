<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
	require_once 'abstract-xh-add-ons-api.php';	
require_once 'class-wshop-payment-gateway-payjs.php';	   
/**
 * @author rain
 *
 */
class WShop_Add_On_Payjs extends Abstract_WShop_Add_Ons_Payjs_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Payjs
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Payjs
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        $this->id='wshop_add_ons_payjs';
        $this->title=__('Payjs',WSHOP);
        $this->description='微信官方个人支付接口，支持微信扫码和公众号支付。<a href="https://payjs.cn/ref/ZBABED">立即申请开通</a>';
        $this->version='1.0.1';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url("admin.php?page=wshop_page_default&section=menu_default_checkout&sub=payjs")
            )
        );
    }

    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        $this->m2();
    }
    
    public function on_after_init(){ 
        if(isset($_REQUEST['action'])&&$_REQUEST['action']=='__wshop_payment_payjs_callback__'){
            $request = shortcode_atts(array(
                'sn'=>null,
                'notice_str'=>null,
                'action'=>null,
                'hash'=>null
            ), stripslashes_deep($_REQUEST));
        
            if($request['hash']!=WShop_Helper::generate_hash($request, WShop::instance()->get_hash_key())){
                wp_die('invalid sign!');
            }
        
            $order = WShop::instance()->payment->get_order('sn', $request['sn']);
            if(!$order){
                wp_die('invalid order!');
            }
            if($order->is_paid()){
                wp_redirect($order->get_received_url());
                exit;
            }
            if ( ! $guessurl = site_url() ){
                $guessurl = wp_guess_url();
            }
            ?><html>
            	<head>
                <meta charset="utf-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
                <meta name="keywords" content="">
                <meta name="description" content="">   
                <title>微信支付收银台</title>
                <style>
                     *{margin:0;padding:0;}
                      body{padding-top: 50px; background: #f2f2f4;}
                     .clearfix:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }
                    .clearfix { display: inline-block; }
                    * html .clearfix { height: 1%; }
                    .clearfix { display: block; }
                      .xh-title{height:35px;line-height:35px;text-align:center;font-size:30px;margin-bottom:20px;font-weight:300;}
                      .qrbox{max-width: 900px;margin: 0 auto;background:#f9f9f9;padding:35px 20px 20px 50px;}
                      
                      .qrbox .left{width: 95%;        
                         display: block;
                        margin: 0px auto;}
                      .qrbox .left .qrcon{
                        border-radius: 10px;
                        background: #fff;
                        overflow: visible;
                        text-align: center;
                        padding-top:25px;
                        color: #555;
                        box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .05);
                        vertical-align: top;
                        -webkit-transition: all .2s linear;
                        transition: all .2s linear;
                      }
                        .qrbox .left .qrcon .logo{width: 100%;}
                        .qrbox .left .qrcon .title{font-size: 16px;margin: 10px auto;width: 100%;height:30px;line-height:30px;overflow:hidden;text-overflow :ellipsis }
                        .qrbox .left .qrcon .price{font-size: 22px;margin: 0px auto;width: 100%;}
                        .qrbox .left .qrcon .bottom{border-radius: 0 0 10px 10px;
                        width: 100%;
                        background: #32343d;
                        color: #f2f2f2;padding:15px 0px;text-align: center;font-size: 14px;}
                       .qrbox .sys{width: 60%;float: right;text-align: center;padding-top:20px;font-size: 12px;color: #ccc}
                       .qrbox img{max-width: 100%;}
                       @media (max-width : 767px){
                    .qrbox{padding:20px;}
                        .qrbox .left{width: 95%;float: none;}   
                        .qrbox .sys{display: none;}
                       }
                       
                       @media (max-width : 320px){
                       body{padding-top:35px;}
                      }
                      @media ( min-width: 321px) and ( max-width:375px ){
                    body{padding-top:35px;}
                  }
                </style>
                </head>
                
                <body >
               	
                  <div class="qrbox clearfix">
                  <div class="left">
                     <div class="qrcon">
                      
                       <h5><img src="<?php print WSHOP_URL;?>/assets/image/wechat/logo.png" style="height:40px;" alt=""></h5>
                         <div class="title"><?php print $order->get_title();?></div>
                     	 <div class="price">￥<?php echo $order->get_total_amount(false);?></div>
                     	  <br/>
                     	  
                     	   <br/>
                     	   <div class="bottom">支付成功，跳转中...</div>
                     	   <script src="<?php echo $guessurl.'/wp-includes/js/jquery/jquery.js'; ?>"></script>
                        <script type="text/javascript">
                             (function($){
                            		window.view={
                        				query:function () {
                        			        $.ajax({
                        			            type: "POST",
                        			            url: '<?php print WShop::instance()->ajax_url(array(
                        			                'action'=>'wshop_checkout_v2',
                        			                'order_id'=>$order->id,
                        			                'tab'=>'is_paid'
                        			            ),true,true);?>',
                        			            timeout:6000,
                        			            cache:false,
                        			            dataType:'json',
                        			            success:function(e){
                        			            	if (e && e.data.paid) {
                            			                $('#weixin-notice').css('color','green').text('已支付成功，跳转中...');
                            		                    location.href = e.data.received_url;
                            		                    return;
                            		                }
                        			                
                        			                setTimeout(function(){window.view.query();}, 2000);
                        			            },
                        			            error:function(){
                        			            	 setTimeout(function(){window.view.query();}, 2000);
                        			            }
                        			        });
                        			    }
                            		};
                           		 window.view.query();
                            	})(jQuery);
                            	</script>
                     </div>
                     </div>
                  </div>
                 
                </body>
                </html>
            	<?php
           exit; 
        }
        
        
        if(!isset($_POST['payjs_order_id'])
           ||!isset($_POST['transaction_id'])
            ||!isset($_POST['out_trade_no'])
            ||!isset($_POST['return_code'])
            ||!isset($_POST['sign'])
            ||!isset($_POST['mchid'])
            ||!isset($_POST['attach'])
            ||$_POST['attach']!='wshop_payjs'
           ){
            return;
        }
        
        $response =stripslashes_deep($_POST);
        
        $sign = $response['sign'];
        unset($response['sign']);
        $api = WShop_Payment_Gateway_Payjs::instance();
        $appid = $api->get_option('appid');
        $appsecret = $api->get_option('appsecret');
        $mchid = $api->get_option('mchid');
        $mchkey = $api->get_option('mchkey');
        
        if($this->generate_sign($response, $mchkey)!=$sign){
            return;
        }
        
        $sn = isset($response['out_trade_no'])?$response['out_trade_no']:null;
        $order = WShop::instance()->payment->get_order('sn', $sn);
        if(!$order){
            return;
        }
        
        $transaction_id = $response["transaction_id"];
       
        try {
            $request = array(
                'payjs_order_id'=>$response['payjs_order_id']
            );
            $request['sign'] = $this->generate_sign($request, $mchkey);
            $query = WShop_Helper_Http::http_post('https://payjs.cn/api/check',$request);
            $query = json_decode($query,true);
          
            if(isset($query['return_code'])&&$query['return_code']=='1'&&isset($query['status'])&&$query['status']=='1'){
                $error = $order->complete_payment($transaction_id);
                if(WShop_Error::is_valid($error)){
                    echo 'success';
                    exit;
                }
        
                throw new Exception($error->errmsg);
            }
        } catch (Exception $e) {
            WShop_Log::error($e);
            echo 'faild';
            exit;
        }
        
        echo 'faild';
        exit;
    }
 
    /**
     * 执行支付相关操作
     * @since 1.0.0
     */
    public function do_ajax(){
       
        $action ="wshop_{$this->id}";
        $datas=WShop_Async::instance()->shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null
        ), stripslashes_deep($_REQUEST));
        
        switch ($datas['tab']){
            case 'pay':
                $datas['order_id']=isset($_REQUEST['order_id'])?WShop_Helper_String::sanitize_key_ignorecase($_REQUEST['order_id']):'';
                if(!WShop::instance()->WP->ajax_validate($datas, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
                    WShop::instance()->WP->wp_die(WShop_Error::err_code(701));
                    exit;
                }
                
                if(WShop_Helper_Uri::is_wechat_app()){
                    require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/payjs/jsapi.php');
                }else{
                    require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/payjs/qrcode.php');
                }
                exit;
                
               
        }
    }
 
  
    /**
     * 微信签名
     * @param array $parameter
     * @param string $mchkey
     * @return string
     */
    public function generate_sign(array $parameter,$mchkey){
        ksort($parameter);
        reset($parameter);
       
        return strtoupper(md5(urldecode(http_build_query($parameter)).'&key='.$mchkey));;
    }
    
    
}

return WShop_Add_On_Payjs::instance();
?>