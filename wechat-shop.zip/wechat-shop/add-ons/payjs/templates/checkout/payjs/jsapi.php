<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

$order_id =isset($_GET['order_id'])?$_GET['order_id']:'';
$order = WShop::instance()->payment->get_order('id', $order_id);
if(!$order){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404));
    exit;
}

if(!$order->can_pay()){
    WShop::instance()->WP->wp_die(WShop_Error::error_custom(__('Current order is paid or expired!',WSHOP)));
    exit;
}

try {

    $api = WShop_Add_On_Payjs::instance();
    $payment_gateway = WShop_Payment_Gateway_Payjs::instance();
    $mchid = $payment_gateway->get_option('mchid');
    $mchkey = $payment_gateway->get_option('mchkey');

    //创建订单支付编号
    $sn = $order->generate_sn();
    if($sn instanceof WShop_Error){
        throw new Exception($sn->errmsg);
    }

    $startTime = date_i18n('YmdHis' );
    $expiredTime = date('YmdHis',current_time( 'timestamp' )+10*60);
    //若过期时间不对，请检查时区
    $exchange_rate = round(floatval(WShop_Settings_Default_Basic_Default::instance()->get_option('exchange_rate')),3);
    if($exchange_rate<=0){
        $exchange_rate = 1;
    }
    
    $p = array(
        'sn'=>$sn,
        'notice_str'=>str_shuffle(time()),
        'action'=>'__wshop_payment_payjs_callback__'
    );
    $p['hash'] = WShop_Helper::generate_hash($p, WShop::instance()->get_hash_key());
    $return_url = home_url('/?'.http_build_query($p));
    
    $request = array(
        'mchid'=>$mchid,
        'total_fee'=>round($order->get_total_amount()*100*$exchange_rate),
        'out_trade_no'=>$sn,
        'body'=> "No{$order->id}",
        'notify_url'=>home_url('/'),
        'attach' =>'wshop_payjs',
        'callback_url'=>$return_url
    );
    $request['sign'] = $api->generate_sign($request,$mchkey);
    ?>
    	<html>
    	<head>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    	<title>微信支付</title>
    	<meta charset="utf-8">
    	</head>
    	<body>
    		<form id="form-pay" action="https://payjs.cn/api/cashier" method="post">
    			<?php foreach ($request as $key=>$val){
    			    ?><input type="hidden" name="<?php echo $key?>"  value="<?php echo $key=='callback_url'||$key=='notify_url'?esc_url_raw($val): esc_attr($val)?>"/><?php 
    			}?>
    		</form>
    		<script type="text/javascript">
    		document.getElementById('form-pay').submit();
    		</script>
    	</body>
    	</html>
        <?php 
}catch(Exception $e){
    WShop::instance()->WP->wp_die($e);exit;
}