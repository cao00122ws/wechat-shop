<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

class WShop_Payment_Gateway_Paypal extends Abstract_WShop_Payment_Gateway{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Payment_Gateway_Paypal
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Payment_Gateway_Paypal
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='paypal';
        $this->group = 'card';
        $this->title=__('Paypal',WSHOP);
        $this->description ='只需一个PayPal账户，全球1.9亿网购买家触手可得，不管您有没有网站，拥有PayPal账户就能接收全球203个国家和地区买家的付款，而他们可以用最常用的信用卡、借记卡或银行账户等多种方式支付，跨境网上收款就是这么简单。';
        
        $url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->icon=$url.'/assets/images/paypal-l.png';
        $this->icon_small=$url.'/assets/images/paypal.png';
        
        $this->init_form_fields ();
        $this->enabled ='yes'==$this->get_option('enabled');
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields() {
        
        $this->form_fields = array (
            'enabled' => array (
                'title' => __ ( 'Enable/Disable', WSHOP ),
                'type' => 'checkbox',
                'label' => __ ( 'Enable paypal payment', WSHOP ),
                'default' => 'no'
            ),
        	'email' => array(
        		'title'       => __( 'PayPal email', WSHOP ),
        		'type'        => 'email',
        		'description' => __( 'Please enter your PayPal email address; this is needed in order to take payment.',WSHOP ),
        		'default'     => get_option( 'admin_email' ),
        		'desc_tip'    => true,
        		'placeholder' => 'you@youremail.com',
        	),
        	'identity_token' => array(
        		'title'       => __( 'PayPal identity token', WSHOP ),
        		'type'        => 'text',
        		'description' => __( 'Optionally enable "Payment Data Transfer" (Profile > Profile and Settings > My Selling Tools > Website Preferences) and then copy your identity token here. This will allow payments to be verified without the need for PayPal IPN.', WSHOP ),
        		'default'     => '',
        		//'desc_tip'    => true,
        		//'placeholder' => '',
        	)
             ,
        	'testmode' => array(
        		'title'       => __( 'PayPal sandbox', WSHOP ),
        		'type'        => 'checkbox',
        		'label'       => __( 'Enable PayPal sandbox', WSHOP ),
        		'default'     => 'no',
        		'description' => sprintf( __( 'PayPal sandbox can be used to test payments. Sign up for a <a href="%s">developer account</a>.', WSHOP ), 'https://developer.paypal.com/' )
        	    .'<br/>paypal_test_Buz@paypal.com 收款账户<br/>
                        paypal_test_per@paypal.com 付款账户<br/>
        	                                    密码都是12345678<br/>
        	                               账户设置登陆  https://www.sandbox.paypal.com',
        	),
//         	'paymentaction' => array(
//         		'title'       => __( 'Payment action', WSHOP),
//         		'type'        => 'select',
//         		'class'       => 'wc-enhanced-select',
//         		'description' => __( 'Choose whether you wish to capture funds immediately or authorize payment only.', WSHOP ),
//         		'default'     => 'sale',
//         		'desc_tip'    => true,
//         		'options'     => array(
//         			//'sale'          => __( 'Capture', WSHOP),
//         			'authorization' => __( 'Authorize', WSHOP),
//         		),
//         	),
            
        	'page_style' => array(
        		'title'       => __( 'Page style', WSHOP ),
        		'type'        => 'text',
        		'description' => __( 'Optionally enter the name of the page style you wish to use. These are defined within your PayPal account. This affects classic PayPal checkout screens.', WSHOP ),
        		'default'     => '',
        		'desc_tip'    => true,
        		'placeholder' => __( 'Optional', WSHOP ),
        	),
        	'image_url' => array(
        		'title'       => __( 'Image url', WSHOP),
        		'type'        => 'text',
        		'description' => __( 'Optionally enter the URL to a 150x50px image displayed as your logo in the upper left corner of the PayPal checkout pages.', WSHOP),
        		'default'     => '',
        		'desc_tip'    => true,
        		'placeholder' => __( 'Optional', WSHOP),
        	),
            'currency'=>array(
                'title'=>__('Paypal Currency',WSHOP),
                'type'=>'select',
                'default'=>'USD',
                'func'=>true,
                'options'=>function(){
                    $currencies = WShop_Currency::get_currencies();
                    
                    $options = array();
                    foreach ($currencies as $currency=>$name){
                        $symbol = WShop_Currency::get_currency_symbol($currency);
                        $options[$currency] = "{$name}({$symbol})";
                    }
                    array_flip($options);
                    ksort($options);
                    array_flip($options);
                    return $options;
                }
            ),
            'exchange_rate'=>array(
                'title'=>__('Exchange Rate',WSHOP),
                'type'=>'text',
                'default'=>'1',
                'description'=>__('Set exchange rate to paypal currency. default 1.',WSHOP)
            )
        );
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Payment_Gateway::process_payment()
     */
    public function process_payment($order){
        $sn = $order->generate_sn();
        $paypal_currency = $this->get_option('currency');
        $order->__set_metas(array(
            '_paypal_currency'=>$paypal_currency
        ));
        $args = array_merge(
            array(
                'cmd'           => '_cart',
                'business'      => $this->get_option( 'email' ),
                'no_note'       => 1,
                'currency_code' => $paypal_currency,
                'charset'       => 'utf-8',
                'rm'            => is_ssl() ? 2 : 1,
                'upload'        => 1,
                'return'        => $order->get_received_url(),
                'cancel_return' => $order->get_back_url(),
                'page_style'    => $this->get_option( 'page_style' ),
                'image_url'     => esc_url_raw( $this->get_option( 'image_url' ) ),
                'paymentaction' => 'sale',//$this->get_option( 'paymentaction' ),
                'bn'            => 'xunhu_Cart',
                'custom'        => 'wshop_paypal',
                'invoice'       => $sn,
                'notify_url'    => home_url('/'),
                'no_shipping' => 1,
                'tax_cart' => 0.00
            ),
            $this->get_order_item_request($order)
        );
       
        $paypal_args = http_build_query( $args);
    
        $request_url =null;
        if ( 'yes'==$this->get_option('testmode') ) {
            $request_url = 'https://www.sandbox.paypal.com/cgi-bin/webscr?test_ipn=1&' . $paypal_args;
        } else {
            $request_url = 'https://www.paypal.com/cgi-bin/webscr?' . $paypal_args;
        }
        
        $result = $order->save_changes();
        if($result instanceof WShop_Error){
            return $result;
        }
        return WShop_Error::success($request_url);
    }
   
    /**
     * 
     * @param WShop_Order $order
     */
    private function get_order_item_request($order){
        $order_items = $order->get_order_items();
        $results = array();
        $order_item_total = 0;
        $exchange_rate = floatval($this->get_option('exchange_rate'));
        $order_total = round($order->get_total_amount(false)*$exchange_rate,2);
        
        if($order_items){
            $index = 1;
            foreach ($order_items as $order_item){
                $results["item_name_{$index}"] = mb_strimwidth($order_item->get_title(), 0, 100,'...','utf-8');
                $results["quantity_{$index}"] = $order_item->qty;
                
                $price = round($order_item->get_price(false)*$exchange_rate,2);
                
                $results["amount_{$index}"] = $price;
                $order_item_total+=$price;
                $results["item_number_{$index}"] = $order_item->post_ID;
                $index++;
            }
        }
        
        //对价格进行解析
        if($order_item_total>$order_total){
            $results['discount_amount_cart'] = round($order_item_total-$order_total,2);
        }else if($order_total>$order_item_total){
            $results['shipping_1'] = round($order_total-$order_item_total,2);
        }
        
        return $results;
    }
}
?>