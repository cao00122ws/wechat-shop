<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'class-wshop-payment-gateway-paypal.php';	   
/**
 * @author rain
 *
 */
class WShop_Add_On_Paypal extends Abstract_WShop_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Paypal
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Paypal
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wshop_add_ons_paypal';
        $this->title=__('Paypal',WSHOP);
        $this->description='只需一个PayPal账户，全球1.9亿网购买家触手可得，不管您有没有网站，拥有PayPal账户就能接收全球203个国家和地区买家的付款，而他们可以用最常用的信用卡、借记卡或银行账户等多种方式支付，跨境网上收款就是这么简单。';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url("admin.php?page=wshop_page_default&section=menu_default_checkout&sub=paypal")
            )
        );
    }

    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        add_filter('wshop_admin_menu_menu_default_checkout', function($menu){
            $menu[]= WShop_Payment_Gateway_Paypal::instance();
            return $menu;
        },10,1);
        
        add_filter('wshop_payments', function($payment_gateways){
            $payment_gateways[] =WShop_Payment_Gateway_Paypal::instance();
            return $payment_gateways;
        },10,1);
    }
 
    /**
     * 监听支付成功回调
     * @since 1.0.0
     */
    public function on_after_init(){ 
        // 
        $posted = wp_unslash( $_POST ); 
        //$posted = json_decode('{"mc_gross":"6.80","invoice":"124958-15337037980303-10301","protection_eligibility":"Eligible","item_number1":"847","payer_id":"NRNNY26RVS25U","tax":"0.00","payment_date":"21:50:27 Aug 07, 2018 PDT","payment_status":"Pending","charset":"UTF-8","first_name":"paypal buyer","notify_version":"3.9","custom":"wshop_paypal","payer_status":"verified","business":"paypal_test_Buz@paypal.com","num_cart_items":"1","verify_sign":"A1txllAklcf0z.ZLdza62zYaQkfwAiOhEHmW3IgkZ.ZfA5guGHe4JWtr","payer_email":"paypal_test_per@paypal.com","txn_id":"26W39007B4986284C","payment_type":"instant","last_name":"\u9646","item_name1":"dev233","receiver_email":"paypal_test_Buz@paypal.com","shipping_discount":"0.00","quantity1":"1","insurance_amount":"0.00","receiver_id":"T3SFNJ7M786Z4","pending_reason":"multi_currency","txn_type":"cart","discount":"27.20","mc_gross_1":"34.00","mc_currency":"AUD","residence_country":"US","test_ipn":"1","shipping_method":"Default","transaction_subject":"","payment_gross":"","ipn_track_id":"1d1be09660e"}',true);
        if (  !isset( $posted['business'] )
            ||!isset( $posted['invoice'] )
            ||!isset($posted['verify_sign'])
            ||!isset($posted['custom'])
            ||$posted['custom']!='wshop_paypal'
            ) {
            return;
        }
       
        $order = WShop::instance()->payment->get_order('sn', $posted['invoice']);
        if(!$order||$order->is_paid()){
            return;
        }
        
        $transaction_result = $this->validate_transaction($posted ); 
        if ( $transaction_result ) {
			// Lowercase returned variables.
			$posted['payment_status'] = strtolower( $posted['payment_status'] );

			if ( method_exists( $this, 'payment_status_' . $posted['payment_status'] ) ) {
				call_user_func( array( $this, 'payment_status_' . $posted['payment_status'] ), $order, $posted );
			}
        } 
    }
    
    /**
     * Check for a valid transaction type.
     *
     * @param string $txn_type Transaction type.
     */
    protected function validate_transaction_type( $txn_type ) {
        $accepted_types = array( 'cart', 'instant', 'express_checkout', 'web_accept', 'masspay', 'send_money', 'paypal_here' );
    
        if ( ! in_array( strtolower( $txn_type ), $accepted_types, true ) ) {
            WShop_Log::error( 'Aborting, Invalid type:' . $txn_type );
            exit;
        }
    }
    
    /**
     * Check currency from IPN matches the order.
     *
     * @param WShop_Order $order    Order object.
     * @param string   $currency Currency code.
     */
    protected function validate_currency( $order, $currency ) {
        $_paypal_currency = isset($order->metas['_paypal_currency'])?$order->metas['_paypal_currency']:null;
        if ($_paypal_currency !== $currency ) {
            WShop_Log::error( 'Payment error: Currencies do not match (sent "' . $order->currency . '" | returned "' . $currency . '")' );
            $order->add_note(WShop_Order_Note::Note_Type_Private, sprintf( __( 'Validation error: PayPal currencies do not match (code %s).', WSHOP ), $currency ));
            exit;
        }
    }
    
    /**
     * Check payment amount from IPN matches the order.
     *
     * @param WShop_Order $order  Order object.
     * @param int      $amount Amount to validate.
     */
    protected function validate_amount( $order, $amount ) {
        $api = WShop_Payment_Gateway_Paypal::instance();
        $exchange_rate = floatval($api->get_option('exchange_rate'));
        $order_total = round($order->get_total_amount(false)*$exchange_rate,2);
        
        if ( $order_total!=$amount ) {
            WShop_Log::error( 'Payment error: Amounts do not match (gross ' . $amount . ')' );
            $order->add_note(WShop_Order_Note::Note_Type_Private, sprintf( __( 'Validation error: PayPal amounts do not match (gross %s).', WSHOP ), $amount ) );
            exit;
        }
    }
    
    /**
     * Check receiver email from PayPal. If the receiver email in the IPN is different than what is stored in.
     * WooCommerce -> Settings -> Checkout -> PayPal, it will log an error about it.
     *
     * @param WShop_Order $order          Order object.
     * @param string   $receiver_email Email to validate.
     */
    protected function validate_receiver_email( $order, $receiver_email ) {
        $api = WShop_Payment_Gateway_Paypal::instance();
        if ( strcasecmp( trim( $receiver_email ), trim( $api->get_option('email') ) ) !== 0 ) {
            WShop_Log::error( "IPN Response is for another account: {$receiver_email}. Your email is {$this->receiver_email}" );
    
            $order->add_note(WShop_Order_Note::Note_Type_Private, sprintf( __( 'Validation error: PayPal IPN response from a different email address (%s).', WSHOP ), $receiver_email ));
            exit;
        }
    }
    
    /**
     * 
     * @param WShop_Order $order
     * @param array $posted
     */
    protected function payment_status_completed( $order, $posted ) {
        if ( $order->is_paid()) {
            WShop_Log::error( 'Aborting, Order #' . $order->id. ' is already complete.' );
            exit;
        }
    
        $this->validate_transaction_type( $posted['txn_type'] );
        $this->validate_currency( $order, $posted['mc_currency'] );
        $this->validate_amount( $order, $posted['mc_gross'] );
        $this->validate_receiver_email( $order, $posted['receiver_email'] );
     
        $metas = isset($order->metas)&&is_array($order->metas)?$order->metas:array();
        if ( ! empty( $posted['payment_type'] ) ) {
            $metas['payment_type']=stripslashes( $posted['payment_type'] );
        }
        if ( ! empty( $posted['txn_id'] ) ) {
            $metas['_transaction_id']=stripslashes( $posted['txn_id'] );
        }
        if ( ! empty( $posted['payment_status'] ) ) {
            $metas['_paypal_status']=stripslashes( $posted['payment_status'] );
        }
        if ( ! empty( $posted['mc_fee'] ) ) {
            $metas['_paypal_transaction_fee']=stripslashes( $posted['mc_fee'] );
        }
        if ( 'completed' === $posted['payment_status'] ) {
            $order->complete_payment( ! empty( $posted['txn_id'] ) ? stripslashes( $posted['txn_id'] ) : '',array(
                'metas'=>$metas
            ));
        } else {
            if ( 'authorization' === $posted['pending_reason'] ) {
                $order->save_changes();
                $order->add_note(WShop_Order_Note::Note_Type_Private,  __( 'Payment authorized. Change payment status to processing or complete to capture funds.', WSHOP ) );
                
            } else {
                $order->save_changes();
                $order->add_note(WShop_Order_Note::Note_Type_Private,  sprintf( __( 'Payment pending (%s).', WSHOP ), $posted['pending_reason'] ));
            }
        }
    }
    
    /**
     * Handle a pending payment.
     *
     * @param WShop_Order $order  Order object.
     * @param array    $posted Posted data.
     */
    protected function payment_status_pending( $order, $posted ) {
        $this->payment_status_completed( $order, $posted );
    }
    
    /**
     * Handle a failed payment.
     *
     * @param WShop_Order $order  Order object.
     * @param array    $posted Posted data.
     */
    protected function payment_status_failed( $order, $posted ) {
        /* translators: %s: payment status. */
        $order->add_note(WShop_Order_Note::Note_Type_Private,   sprintf( __( 'Payment %s via IPN.', WSHOP ), stripslashes( $posted['payment_status'] ) ) );
    }
    
    /**
     * Handle a denied payment.
     *
     * @param WShop_Order $order  Order object.
     * @param array    $posted Posted data.
     */
    protected function payment_status_denied( $order, $posted ) {
        $this->payment_status_failed( $order, $posted );
    }
    
    /**
     * Handle an expired payment.
     *
     * @param WShop_Order $order  Order object.
     * @param array    $posted Posted data.
     */
    protected function payment_status_expired( $order, $posted ) {
        $this->payment_status_failed( $order, $posted );
    }
    
    /**
     * Handle a voided payment.
     *
     * @param WShop_Order $order  Order object.
     * @param array    $posted Posted data.
     */
    protected function payment_status_voided( $order, $posted ) {
        $this->payment_status_failed( $order, $posted );
    }
    
    /**
     * When a user cancelled order is marked paid.
     *
     * @param WShop_Order $order  Order object.
     * @param array    $posted Posted data.
     */
    protected function payment_status_paid_cancelled_order( $order, $posted ) {
       $order->add_note(WShop_Order_Note::Note_Type_Private, sprintf( __( 'Order #%s has been marked paid by PayPal IPN, but was previously cancelled. Admin handling required.', WSHOP), $order->id ));
    }
    
    /**
     * Handle a refunded order.
     *
     * @param WShop_Order $order  Order object.
     * @param array    $posted Posted data.
     */
    protected function payment_status_refunded( $order, $posted ) {
         $order->add_note(WShop_Order_Note::Note_Type_Private, sprintf( __( 'Order #%1$s has been marked as refunded - PayPal reason code: %2$s', WSHOP ), $order->id, $posted['reason_code'] ));
    }
    
    /**
     * Handle a reversal.
     *
     * @param WShop_Order $order  Order object.
     * @param array    $posted Posted data.
     */
    protected function payment_status_reversed( $order, $posted ) {
        $order->add_note(WShop_Order_Note::Note_Type_Private, sprintf( __( 'Order #%1$s has been marked on-hold due to a reversal - PayPal reason code: %2$s', WSHOP ), $order->id, stripslashes( $posted['reason_code'] ) ) );
    }
    
    /**
     * Handle a cancelled reversal.
     *
     * @param WShop_Order $order  Order object.
     * @param array    $posted Posted data.
     */
    protected function payment_status_canceled_reversal( $order, $posted ) {
        $order->add_note(WShop_Order_Note::Note_Type_Private, sprintf( __( 'Order #%1$s has had a reversal cancelled. Please check the status of payment and update the order status accordingly here: %2$s', WSHOP ), $order->id, esc_url( $order->get_edit_link() ) ));
    }
    
    
    protected function validate_transaction( $validate_ipn ) {
        $validate_ipn['cmd'] = '_notify-validate';
        
        // Send back post vars to paypal.
        $params = array(
            'body'        => $validate_ipn,
            'timeout'     => 60,
            'httpversion' => '1.1',
            'compress'    => false,
            'decompress'  => false,
            'user-agent'  => 'WShop/' . WShop::instance()->version,
        );
        
        $api = WShop_Payment_Gateway_Paypal::instance();
        // Post back to get a response.
        $response = wp_safe_remote_post( 'yes'==$api->get_option('testmode')  ? 'https://www.sandbox.paypal.com/cgi-bin/webscr' : 'https://www.paypal.com/cgi-bin/webscr', $params );
        
        // Check to see if the request was valid.
        if ( ! is_wp_error( $response ) && $response['response']['code'] >= 200 && $response['response']['code'] < 300 && strstr( $response['body'], 'VERIFIED' ) ) {
            return true;
        }
        
        if ( is_wp_error( $response ) ) {
            WShop_Log::error( 'Error response: ' . $response->get_error_message() );
        }
        
        return false;
    }
}

return WShop_Add_On_Paypal::instance();
?>