<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

require_once 'class-wshop-payment-gateway-personal-pay.php';	   
/**
 * @author rain
 *
 */
class WShop_Add_On_Personal_Pay extends Abstract_WShop_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Personal_Pay
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Personal_Pay
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wshop_add_ons_personal_pay';
        $this->title='个人收款码';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url("admin.php?page=wshop_page_default&section=menu_default_checkout&sub=personal_pay")
            )
        );
    }

    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        add_filter('wshop_admin_menu_menu_default_checkout', function($menu){
            $menu[]= WShop_Payment_Gateway_Personal_Pay::instance();
            return $menu;
        },10,1);
        
        add_filter('wshop_payments', function($payment_gateways){
            $payment_gateways[] =WShop_Payment_Gateway_Personal_Pay::instance();
            return $payment_gateways;
        },10,1);
    }

    /**
     * 执行支付相关操作
     * @since 1.0.0
     */
    public function do_ajax(){
        $action ="wshop_{$this->id}";
        $datas=WShop_Async::instance()->shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null
        ), stripslashes_deep($_REQUEST));
    
        switch ($datas['tab']){
            case 'pay':
                $datas['order_id']=isset($_REQUEST['order_id'])?WShop_Helper_String::sanitize_key_ignorecase($_REQUEST['order_id']):'';
                if(!WShop::instance()->WP->ajax_validate($datas, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
                    WShop::instance()->WP->wp_die(WShop_Error::err_code(701));
                    exit;
                }
               

                $order_id =$datas['order_id'];
                $order = WShop::instance()->payment->get_order('id', $order_id);
                if(!$order){
                    WShop::instance()->WP->wp_die(WShop_Error::err_code(404));
                    exit;
                }
               
                if(!$order->can_pay()){
                    WShop::instance()->WP->wp_die(WShop_Error::error_custom(__('Current order is paid or expired!',WSHOP)));
                    exit;
                }
                
                try {
                   
                    //创建订单支付编号
                    $sn = $order->generate_sn();
                    if($sn instanceof WShop_Error){
                        throw new Exception($sn->errmsg);
                    }
                    ?>
                	<!DOCTYPE html>
                	<html>
                	<head>
                    <meta charset="utf-8">
                    <meta http-equiv="X-UA-Compatible" content="IE=edge">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
                    <meta name="keywords" content="">
                    <meta name="description" content="">   
                    <title>微信支付收银台</title>
                    <style>
                         *{margin:0;padding:0;}
                          body{padding-top: 50px; background: #f2f2f4;}
                         .clearfix:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; }
                        .clearfix { display: inline-block; }
                        * html .clearfix { height: 1%; }
                        .clearfix { display: block; }
                          .xh-title{height:35px;line-height:35px;text-align:center;font-size:30px;margin-bottom:20px;font-weight:300;}
                          .qrbox{width: 400px;                               
                             display: block;
                            margin: 0px auto;}
                          .qrbox .qrcon{
                            border-radius: 10px;
                            background: #fff;
                            overflow: visible;
                            text-align: center;
                            padding-top:25px;
                            color: #555;
                            box-shadow: 0 3px 3px 0 rgba(0, 0, 0, .05);
                            vertical-align: top;
                            -webkit-transition: all .2s linear;
                            transition: all .2s linear;
                          }
                            .qrbox  .qrcon .logo{width: 100%;}
                            .qrbox  .qrcon .title{font-size: 16px;margin: 10px auto;width: 100%;}
                            .qrbox .qrcon .price{font-size: 22px;margin: 0px auto;width: 100%;}
                            .qrbox  .qrcon .bottom{border-radius: 0 0 10px 10px;
                            width: 100%;
                            background: #32343d;
                            color: #f2f2f2;padding:15px 0px;text-align: center;font-size: 14px;}                          
                           .qrbox img{max-width: 100%;}
                           @media (max-width : 767px){
                        .qrbox{padding:20px;}
                            .qrbox{width: 85%;}   
                           
                           }
                           
                           @media (max-width : 320px){
                           body{padding-top:35px;}
                          }
                          @media ( min-width: 321px) and ( max-width:375px ){
                        body{padding-top:35px;}
                          }
                    </style>
                    </head>
                    
                    <body>
                     <div class="xh-title">微信支付收银台</div>
                      <div class="qrbox clearfix">                     
                         <div class="qrcon">
                           <h5><img src="<?php print WSHOP_URL;?>/assets/image/wechat/logo.png" alt=""></h5>
                             <div class="title"><?php print $order->get_title();?></div>
                             <div class="price"><?php echo $order->get_total_amount(true);?></div>
                             <div align="center">
                             	<img id="wechat_qrcode" style="width: 250px;height: 250px;padding:10px;" src="<?php echo WShop_Payment_Gateway_Personal_Pay::instance()->get_option('qrcode')?>"/>
                             </div>
                             <div class="bottom">
                                     	微信扫描二维码付款，付款后请联系站长确认收款
                             	
                             </div>
                         </div>
                                                 
                          </div>
                	</body>
                </html>
                	<?php    
                } catch (Exception $e) {
                    WShop_Log::error($e);
                    WShop::instance()->WP->wp_die($e);
                    exit;
                }
                exit;
        }
    }
}

return WShop_Add_On_Personal_Pay::instance();
?>