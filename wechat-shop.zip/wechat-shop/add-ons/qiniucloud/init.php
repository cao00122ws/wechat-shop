<?php
if (! defined('ABSPATH'))
    exit();
 // Exit if accessed directly

/**
 *
 * @author rain
 *        
 */
class WShop_Add_On_Qiniucloud extends Abstract_WShop_Add_Ons
{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Qiniucloud
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * 
     * @var string
     * @since 1.0.0
     */
    public $domain_url;

    public $domain_dir;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     *
     * @return WShop_Add_On_Qiniucloud
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct()
    {
        $this->id = 'wshop_add_ons_qiniucloud';
        $this->title = '七牛云存储';
        $this->description = '付费下载内容加密等功能';
        $this->version = '1.0.0';
        $this->min_core_version = '1.0.0';
        $this->author = __('xunhuweb', WSHOP);
        $this->author_uri = 'https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__);
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__);
        $this->setting_uris = array(
            'settings' => array(
                'title' => __('Settings', WSHOP),
                'url' => admin_url("admin.php?page=wshop_page_default&section=menu_default_basic&sub=wshop_add_ons_qiniucloud")
            )
        );
        $this->init_form_fields();
    }

    public function init_form_fields()
    {
        $fields = array(
            'accessKey' => array(
                'title' => 'AccessKey',
                'type' => 'text',
                'description'=>'登录七牛开发者自助平台，查看 <a href="https://portal.qiniu.com/user/key" target="_blank">Access Key 和 Secret Key</a>'
            ),
            'secretKey' => array(
               'title' => 'SecretKey',
                'type' => 'text',
            ),
            'bucket' => array(
               'title' => '存储空间',
                'type' => 'text',
                'description'=>'为了文件安全，请设置存储空间为私有'
            ),
            'domain' => array(
               'title' => '存储空间外链域名(不含http(s))',
                'type' => 'text',
                'placeholder'=>'pngp1sl8g.bkt.clouddn.com',
                'description'=>'注意域名不含http(s)'
            ),
            'upload_region' => array(
               'title' => '文件上传区域(含http(s))',
                'type' => 'text',
                'default'=>'http://up-z1.qiniup.com',
                'description'=>'注意域名含http(s)'
            )
            
        );
        
        $this->form_fields = apply_filters('wshop_pay_fields', $fields);
    }
    
    public function on_init(){
        add_filter('wshop_admin_menu_menu_default_basic', function($menus){
            $menus[]=WShop_Add_On_Qiniucloud::instance();
            return $menus;
        },10,1);
        add_filter('wshop_download_types', array($this,'wshop_download_types'),10,1);
    }
    
    public function do_ajax(){
        $action ="wshop_{$this->id}";
        $datas=WShop_Async::instance()->shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));
       
        switch ($datas['tab']){
            case 'remove_image':
                $datas['post_id'] = $_REQUEST['post_id'];
                if(!WShop::instance()->WP->ajax_validate($datas,$datas['hash'],true)){
                    echo WShop_Error::err_code(701)->to_json();
                    exit;
                }
                
                $post = get_post($datas['post_id']);
                if(!$post){
                    echo WShop_Error::error_custom('请求数据异常！')->to_json();
                    exit;
                }
                $download = new WShop_Download($post);
                if(!$download->is_load()){
                    echo WShop_Error::success()->to_json();
                    exit;
                }
                
                $downloads = $download->downloads?maybe_unserialize($download->downloads):null;
                $content = $downloads&&is_array($downloads)&&$downloads['type']=='qiniu'?json_decode($downloads['content'],true):null;
                if(!$content||!is_array($content)){
                    echo WShop_Error::success()->to_json();
                    exit;
                }
                
                require_once("qiniu/io.php");
                require_once("qiniu/rs.php");
                global $QINIU_UP_HOST;
                $QINIU_UP_HOST	=  $this->get_option('upload_region');
                $bucket = $this->get_option('bucket');
                $key1 = $content['key'];
                $accessKey = $this->get_option('accessKey');
                $secretKey = $this->get_option('secretKey');
                
                Qiniu_SetKeys($accessKey, $secretKey);
                $client = new Qiniu_MacHttpClient(null);
                
                $download->update(array(
                    'downloads'=>null
                ))->to_json();
                
                $err = Qiniu_RS_Delete($client, $bucket, $key1);
                if($err){
                    echo WShop_Error::error_custom($err->Err)->to_json();
                    exit;
                }
                
                echo WShop_Error::success()->to_json();
                exit;
            case 'upload_image':
                $datas['post_id'] = $_REQUEST['post_id'];
                if(!WShop::instance()->WP->ajax_validate($datas,$datas['hash'],true)){
                    echo WShop_Error::err_code(701)->to_json();
                    exit;
                }
                
                $post = get_post($datas['post_id']);
                if(!$post){
                    echo WShop_Error::error_custom('请求数据异常！')->to_json();
                    exit;
                }
                
                
                set_time_limit(30);
                 
                if ($_FILES ["file"] ["error"]) {
                    echo  WShop_Error::error_custom( $_FILES ["file"] ["error"])->to_json();
                    exit;
                }
                 
                if(empty($_FILES["file"]["name"])){
                    echo WShop_Error::error_custom(__('Invalid upload file name',WSHOP))->to_json();
                    exit;
                } 
                
                require_once("qiniu/io.php");
                require_once("qiniu/rs.php");
                global $QINIU_UP_HOST;
                $QINIU_UP_HOST	=  $this->get_option('upload_region');
                $bucket = $this->get_option('bucket');
                $key1 = date_i18n('Ymdhis').'-'.$_FILES["file"]["name"];
                $accessKey = $this->get_option('accessKey');
                $secretKey = $this->get_option('secretKey');
                	
                Qiniu_SetKeys($accessKey, $secretKey);
                $putPolicy = new Qiniu_RS_PutPolicy($bucket);
                
                $upToken = $putPolicy->Token(null);
                $putExtra = new Qiniu_PutExtra();
                $putExtra->Crc32 = 1;
                list($ret, $err) = Qiniu_PutFile($upToken, $key1, __file__, $putExtra);
               
                if($err){
                    echo WShop_Error::error_custom($err->Err)->to_json();
                    exit;
                }
                
                $download = new WShop_Download($post);
                if($download->is_load()){
                   $error = $download->update(array(
                        'downloads'=>maybe_serialize(array(
                            'type'=>'qiniu',
                            'content'=>json_encode(array(
                                'hash'=>$ret['hash'],
                                'key'=>$ret['key']
                            ))
                        ))
                    ));
                }else{
                    $download->post_ID = $post->ID;
                    $download->downloads=maybe_serialize(array(
                            'type'=>'qiniu',
                            'content'=>json_encode(array(
                                'hash'=>$ret['hash'],
                                'key'=>$ret['key']
                            ))
                        ));
                    $error = $download->insert();
                }
                if(!WShop_Error::is_valid($error)){
                    echo $error->to_json();exit;
                }
                
                echo WShop_Error::success($ret)->to_json();
                exit;
        }
    }
    
    /**
     * 
     * @param string $html
     * @param WShop_Download $download
     */
    public function wshop_download_types($fields){
        $fields['qiniu']=array(
            'title'=>'七牛云存储',
            'call'=>function($field,$download){
                    $file = $download->downloads['type']=='qiniu'? json_decode($download->downloads['content'],true):array();                   
                    if(!$file||!is_array($file)){
                        $file=array();
                    }
                    $input_id = "wshop_qiniu_file_uploader";
                    ?>
                     <style type="text/css">
                        .webuploader-container {
                        	position: relative;
                        }
                        .webuploader-element-invisible {
                        	position: absolute !important;
                        	clip: rect(1px 1px 1px 1px); /* IE6, IE7 */
                            clip: rect(1px,1px,1px,1px);
                        }
                        
                        .webuploader-pick {
                        	position: relative;
                        	display: inline-block;
                        	cursor: pointer;
                        	background: #337ab7;
                        	padding: 4px 12px;
                        	color: #fff;
                        	text-align: center;
                        	border-radius: 3px;
                        	overflow: hidden;
                        	margin-top:5px;
                        	
                        }
                        .webuploader-pick-hover {
                        	background: #00a2d4;
                        }
                        
                        .webuploader-pick-disable {
                        	opacity: 0.6;
                        	pointer-events:none;
                        }
                        
                       .uploader-container,.webuploader-element-invisible {
                            width: 400px;
                            height: 50px;
                            top: -10px;
                            left: -20px;
                        }
                        </style>
                    	<script type="text/javascript" src="<?php echo WSHOP_URL?>/assets/webuploader-0.1.7-alpha/webuploader.js"></script>
            			<input type="hidden" name="<?php echo $field?>" id="form-group-<?php echo $input_id?>-val" />
                        <div class="xh-form-group" id="form-group-<?php echo $input_id?>">
                            <div>
                            	<div id="image-<?php print $input_id;?>-review">
                            	<?php if($file){
                            	    echo $file['key'].' => '.$file['hash'];
                            	    ?>
                            	    <a onclick="window.removeWShopQiniuImage();" href="javascript:void(0);" style="margin-left:10px;">删除</a>
                            	    <?php 
                            	}?>
                            	
                            	</div>
                            	<div id="image-<?php print $input_id;?>-picker">上传文件</div>
                                <div>文件上传后，(为了文件安全)我们不会拷贝到web服务器内:请妥善保管文件</div>
                            </div>
                        </div>
                        <script type="text/javascript">
                        	(function($){
                        		if ( !WebUploader.Uploader.support() ) {
                        	       return;
                        	    }
                        		window.removeWShopQiniuImage = function(){
                            		if(!confirm('文件删除后无法还原，确定继续？')){return;}
                        			$('#wpbody-content').loading();
            						$.ajax({
            							url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$this->id}",'tab'=>"remove_image",'post_id'=>$download->post_ID),true,true)?>',
            							type:'post',
            							timeout:60*1000,
            							async:true,
            							cache:false,
            							dataType:'json',
            							complete:function(){
            								$('#wpbody-content').loading('hide');
            							},
            							success:function(e){
            								if(e.errcode!=0){
            									alert(e.errmsg);
            									return;
            								}
            								$('#image-<?php print $input_id;?>-review').html('');
            							},
            							error:function(e){
            								console.error(e.responseText);
            								alert('<?php echo esc_attr( 'System error while modifing order note!', WSHOP); ?>');
            							}
            						});
                            	};
                        			
            						
                        		var <?php print $input_id;?>_config ={
                        			swf:'<?php echo WSHOP_URL?>/assets/webuploader-0.1.7-alpha/Uploader.swf',
                        			server:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$this->id}",'tab'=>"upload_image",'post_id'=>$download->post_ID),true,true)?>',
                        			dnd:'#form-group-<?php echo $input_id?>',
                        			paste:document.body,
                        			pick:'#image-<?php print $input_id;?>-picker',
                        		    auto :true,
                        		    fileNumLimit:1			    
                        		};
                        
                        		     //do something
                        		var <?php print $input_id;?>_uploader = WebUploader.create(<?php print $input_id;?>_config);
                        		$('#image-wshop_qiniu_file_uploader-picker .webuploader-pick').click(function(){
            						$('#image-wshop_qiniu_file_uploader-picker .uploader-container :file').click();
                            	});
                        		// 文件上传失败，显示上传出错。
                        		<?php print $input_id;?>_uploader.on( 'uploadStart', function( file ) {
                        			$('#image-<?php print $input_id;?>-picker .webuploader-pick').text('<?php echo __('Uploading...',WSHOP)?>');
                        		});
                        		// 文件上传失败，显示上传出错。
                        		<?php print $input_id;?>_uploader.on( 'uploadError', function( file ,reason) {
                        			<?php print $input_id;?>_uploader.reset();
                        			alert('<?php echo WShop_Error::err_code(500)->errmsg?>');
                        		});
                        
                        		// 完成上传完了，成功或者失败，先删除进度条。
                        		<?php print $input_id;?>_uploader.on( 'uploadComplete', function( file ) {
                        			$('#image-<?php print $input_id;?>-picker .webuploader-pick').text('上传文件');
                        		});
                        		
                        		<?php print $input_id;?>_uploader.on( 'uploadSuccess', function( file ,response) {
                        			<?php print $input_id;?>_uploader.reset();
                        			
                        			if(!response||typeof response.errcode=='undefined'){
                        				alert('<?php echo WShop_Error::error_unknow()->errmsg?>');
                        				return;
                        			}
                        			
                        			if(response.errcode!=0){
                        				alert(response.errmsg);
                        				return;
                        			}
                        			$('#form-group-<?php echo $input_id?>-val').val(JSON.stringify(response.data));
                        			$('#image-<?php print $input_id;?>-review').html('<div>'+response.data.key+' => '+response.data.hash+' <a onclick="window.removeWShopQiniuImage();" href="javascript:void(0);" style="margin-left:10px;">删除</a></div>');
                        		});
                        	})(jQuery);
                        </script>
                    <?php 
            },
	         'render'=>function($download){
    	         echo WShop::instance()->WP->requires(WShop_Add_On_Qiniucloud::instance()->domain_dir, 'download/qiniu/content.php',array(
    	             'download'=>$download
    	         ));
	         }
        );
        return $fields;
    }
}

return WShop_Add_On_Qiniucloud::instance();
?>