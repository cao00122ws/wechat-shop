<?php
$data = WShop_Temp_Helper::clear('atts','templates');
$download = $data['download'];

$file = $download->downloads['type']=='qiniu'? json_decode($download->downloads['content'],true):array();
if(!$file||!$file['key']){
    ?><div>暂无下载文件...</div> <?php
   return;
}

$api = WShop_Add_On_Qiniucloud::instance();
require_once(WShop_Add_On_Qiniucloud::instance()->domain_dir."/qiniu/rs.php");
global $QINIU_UP_HOST;
$QINIU_UP_HOST	=  $api->get_option('upload_region');
$bucket = $api->get_option('bucket');

$key = $file['key'];
$domain = $api->get_option('domain');
$accessKey = $api->get_option('accessKey');
$secretKey = $api->get_option('secretKey');

Qiniu_SetKeys($accessKey, $secretKey);
$baseUrl = Qiniu_RS_MakeBaseUrl($domain, $key);
$getPolicy = new Qiniu_RS_GetPolicy();
$privateUrl = $getPolicy->MakeRequest($baseUrl, null);
?>
<div><a  href="<?php echo $privateUrl;?>" target="_blank"><?php echo $privateUrl;?></a></div>

<span style="position: absolute;top:15px;left:15px;font-size:90%;color:#90949c;">
文件地址
</span>
<span style="position: absolute;top:10px;right:10px;"><img style="width:22px;" src="<?php echo WSHOP_URL?>/assets/image/noshow.png" alt=""></span>

