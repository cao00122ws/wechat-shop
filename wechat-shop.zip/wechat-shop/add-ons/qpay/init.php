<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
	require_once 'abstract-xh-add-ons-api.php';	
require_once 'class-wshop-payment-gateway-qpay.php';	   
/**
 * @author rain
 *
 */
class WShop_Add_On_QPay extends Abstract_WShop_Add_Ons_QPay_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_QPay
     */
    private static $_instance = null;

    /**
     * 插件跟路径url
     * @var string
     * @since 1.0.0
     */
    public $domain_url;
    public $domain_dir;
    
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_QPay
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        parent::__construct();
        $this->id='wshop_add_ons_qpay';
        $this->title=__('QPay',WSHOP);
        $this->description='QQ钱包支付网关，支持扫码，公众号支付';
        $this->version='1.0.1';
        $this->min_core_version = '1.0.0';
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url("admin.php?page=wshop_page_default&section=menu_default_checkout&sub=qpay")
            )
        );
    }

    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Add_Ons::on_init()
     */
    public function on_init(){
        $this->m2();
    }
    
    public function on_after_init(){ 
        if(isset($_REQUEST['action'])&&$_REQUEST['action']=='__wshop_payment_qpay_callback__'){
            $request = shortcode_atts(array(
                'sn'=>null,
                'notice_str'=>null,
                'action'=>null,
                'hash'=>null
            ), stripslashes_deep($_REQUEST));
            
            if($request['hash']!=WShop_Helper::generate_hash($request, WShop::instance()->get_hash_key())){
                return;
            }
            
            $order = WShop::instance()->payment->get_order('sn', $request['sn']);
            if(!$order){
                return;
            }
            
            $api = WShop_Payment_Gateway_QPay::instance();
            $appid = $api->get_option('appid');
            $appsecret = $api->get_option('appsecret');
            $mchid = $api->get_option('mchid');
            $mchkey = $api->get_option('mchkey');
            
            try {
                $qpay_order = $this->query_qpay_order(array(
                    'out_trade_no'=> $request['sn'],
                    'appid'=>$appid,
                    'mch_id'=>$mchid,
                    'nonce_str'=>str_shuffle(time())
                ),$mchkey);
            
                if(isset($qpay_order['trade_state'])&&$qpay_order['trade_state']=='SUCCESS'){
                    $error = $order->complete_payment($qpay_order['transaction_id']);
                    if(WShop_Error::is_valid($error)){
                       wp_redirect($order->get_received_url());
                       exit;
                    }
            
                    WShop::instance()->WP->wp_die($error);
                    exit;
                }
            } catch (Exception $e) {
                WShop_Log::error($e);
                WShop::instance()->WP->wp_die($e);
                exit;
            }
            
            wp_redirect($order->get_received_url());
            exit;
        }
       
        
        $xml =isset($GLOBALS['HTTP_RAW_POST_DATA'])?$GLOBALS['HTTP_RAW_POST_DATA']:'';
        if(empty($xml)){
            $xml = file_get_contents("php://input");
        }
        
        if(empty($xml)){
            return;
        }
        
        //排除非xmlpost提交
        $xml = trim($xml);
        if(substr($xml, 0,5) !='<?xml'){
            return;
        }
      
        //排除非微信回调
        if(strpos($xml, 'transaction_id')===false
           ||strpos($xml, 'mch_id')===false){
            return;
        }
        
        $response =WShop_Helper_String::xml_to_obj($xml);
        if(!$response){
            return;
        }
       
        if(!isset($response['sign'])
            ||!isset($response['mch_id'])
            ||!isset($response['transaction_id'])
            ){  
            return;
        }
      
        if(!isset($response['device_info'])||$response['device_info']!='wshop_qpay'){
            return;
        }
       
        $sn = isset($response['out_trade_no'])?$response['out_trade_no']:null;
        $order = WShop::instance()->payment->get_order('sn', $sn);
        if(!$order){
            return;
        }
        
        $api = WShop_Payment_Gateway_QPay::instance();
        $appid = $api->get_option('appid');
        $appsecret = $api->get_option('appsecret');
        $mchid = $api->get_option('mchid');
        $mchkey = $api->get_option('mchkey');
        
        if($response['sign'] !== $this->generate_sign($response, $mchkey)){
            WShop_Log::error('invalid sign:'.print_r($response,true));
            return;
        }
        
        $transaction_id = $response["transaction_id"];
       
        try {
            $request = array(
                'transaction_id'=>$transaction_id,
                'appid'=>$appid,
                'mch_id'=>$mchid,
                'nonce_str'=>str_shuffle(time())
            );
            $qpay_order = $this->query_qpay_order($request,$mchkey);
        
            if(isset($qpay_order['trade_state'])&&$qpay_order['trade_state']=='SUCCESS'){
                $error = $order->complete_payment($transaction_id);
                if(WShop_Error::is_valid($error)){
                    echo '<xml>
                          <return_code><![CDATA[SUCCESS]]></return_code>
                          <return_msg><![CDATA[OK]]></return_msg>
                        </xml>';
                    exit;
                }
        
                throw new Exception($error->errmsg);
            }
        } catch (Exception $e) {
            WShop_Log::error($e);
            echo 'faild';
            exit;
        }
        
        echo '<xml>
              <return_code><![CDATA[SUCCESS]]></return_code>
              <return_msg><![CDATA[OK]]></return_msg>
            </xml>';
        exit;
        
    }
 
    /**
     * 执行支付相关操作
     * @since 1.0.0
     */
    public function do_ajax(){
       
        $action ="wshop_{$this->id}";
        $datas=WShop_Async::instance()->shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null
        ), stripslashes_deep($_REQUEST));
        
        switch ($datas['tab']){
            case 'inner':
                require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/qpay/inner.php');
                exit;
            case 'outer':
                require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/qpay/outer.php');
                exit;
            case 'pay':
                $datas['order_id']=isset($_REQUEST['order_id'])?WShop_Helper_String::sanitize_key_ignorecase($_REQUEST['order_id']):'';
                if(!WShop::instance()->WP->ajax_validate($datas, isset($_REQUEST['hash'])?$_REQUEST['hash']:null,true)){
                    WShop::instance()->WP->wp_die(WShop_Error::err_code(701));
                    exit;
                }
                
                $api = WShop_Add_On_QPay::instance();
                $payment_gateway = WShop_Payment_Gateway_QPay::instance();
                $appid = $payment_gateway->get_option('appid');
                if(empty($appid)){
                    //未填写APPID，那么直接扫码支付
                    require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/qpay/outer.php');
                    exit;
                }
                
                require WShop::instance()->WP->get_template($this->domain_dir, 'checkout/qpay/skip.php');
                exit;
               
        }
    }
 
    /**
     * 生成微信订单
     * @param array $request
     * @param string $mchkey
     * @return string
     */
    public function generate_qpay_order(array $request,$mchkey){
        return $this->post_xml("https://qpay.qq.com/cgi-bin/pay/qpay_unified_order.cgi", $request,$mchkey);
    }
    
    /**
     * 查询微信订单
     * @param array $request
     * @param string $mchkey
     */
    public function query_qpay_order(array $request,$mchkey){
        return $this->post_xml("https://qpay.qq.com/cgi-bin/pay/qpay_order_query.cgi", $request,$mchkey);
    }
  
    /**
     * 微信签名
     * @param array $parameter
     * @param string $mchkey
     * @return string
     */
    public function generate_sign(array $parameter,$mchkey){
        ksort($parameter);
        reset($parameter);
       
        $builder = '';
        $index=0;
        foreach ($parameter as $key=>$val){
            if($key==='sign'||$val===''||is_null($val) ||is_array($val)){
                continue;
            }
        
            if($index++!=0){
                $builder.='&';
            }
            $builder.="{$key}={$val}";
        }
        
        return strtoupper(md5($builder . "&key=".$mchkey));
    }
    
    /**
     * post 请求微信数据
     * @param unknown $url
     * @param array $request
     * @param string $mchkey
     * @throws Exception
     * @return string
     */
    public function post_xml($url,array $request,$mchkey){
        $request['sign'] =$this->generate_sign($request, $mchkey);
      
        $response = WShop_Helper_Http::http_post($url,WShop_Helper_String::obj_to_xml($request));
        if(!$response){
            throw new Exception($response);
        }
        
        $data = WShop_Helper_String::xml_to_obj($response);
        if(!$data){
            throw new Exception($response);
        }
        
        if($data['return_code']=='FAIL'){
             throw new Exception(print_r($data,true));
        }
        
        if($data['result_code']=='FAIL'){
            throw new Exception(print_r($data,true));
        }
        
        $sign = isset($data['sign'])?$data['sign']:null;       
        if($sign&&$sign !== $this->generate_sign($data, $mchkey)){
            throw new Exception('invalid sign'.$response);
        }
        
        return $data;
    }
    
    
}

return WShop_Add_On_QPay::instance();
?>