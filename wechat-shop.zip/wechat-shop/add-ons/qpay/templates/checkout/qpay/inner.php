<?php
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

    $order_id =isset($_GET['order_id'])?$_GET['order_id']:'';
    $order = WShop::instance()->payment->get_order('id', $order_id);
    if(!$order){
        WShop::instance()->WP->wp_die(WShop_Error::err_code(404));
        exit;
    }
    
    if(!$order->can_pay()){
        WShop::instance()->WP->wp_die(WShop_Error::error_custom(__('Current order is paid or expired!',WSHOP)));
        exit;
    }
    
    try {
    
        $api = WShop_Add_On_QPay::instance();
        $payment_gateway = WShop_Payment_Gateway_QPay::instance();
        $appid = $payment_gateway->get_option('appid');
        $mchid = $payment_gateway->get_option('mchid');
        $mchkey = $payment_gateway->get_option('mchkey');
    
        //创建订单支付编号
        $sn = $order->generate_sn();
        if($sn instanceof WShop_Error){
            throw new Exception($sn->errmsg);
        }
    
        $startTime = date_i18n('YmdHis' );
        $expiredTime = date('YmdHis',current_time( 'timestamp' )+10*60);
        //若过期时间不对，请检查时区
        $exchange_rate = round(floatval(WShop_Settings_Default_Basic_Default::instance()->get_option('exchange_rate')),3);
        if($exchange_rate<=0){
            $exchange_rate = 1;
        }
    
        $request = array(
            'appid'=>$appid,
            'mch_id'=>$mchid,
            'nonce_str'=>str_shuffle(time()),
            'body'=>mb_strimwidth($order->get_title(), 0, 32,'...','utf-8'),
            'out_trade_no'=>$sn,
            'fee_type'=>'CNY',
            'device_info'=>'wshop_qpay',
            'total_fee'=>round($order->get_total_amount()*100*$exchange_rate),
            'spbill_create_ip'=>WShop::instance()->WP->get_client_ip(),
            'time_start'=>$startTime,
            //'time_expire'=>$expiredTime,
            'trade_type'=>'JSAPI',
            'notify_url'=>home_url('/')
        );
         
        $qpay_order = $api->generate_qpay_order($request,$mchkey);
        ?>
        <html>
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>QQ钱包</title>
        <meta charset="utf-8">
        <script src="//open.mobile.qq.com/sdk/qqapi.js?_bid=152"></script>
        </head>
        <body>
        	
        <script type="text/javascript">
        if(mqq&& typeof mqq.isMobileQQ =='function'){
        	mqq.mqq.isMobileQQ(function(is_qq_app){
        		if(is_qq_app){
        			mqq.tenpay.pay({ 
        				tokenId: "<?php echo esc_js($qpay_order['prepay_id'])?>"
            			/*, pubAcc: "xxxx"
                		, pubAccHint: "xxxx"
                    	, appInfo: "appid#XXXXXXXXX|bargainor_id#XXXXXXXX|channel#wallet" */

    				}, function(result, resultCode){
						/*
    					-1: 未知错误 

    					0: 发货成功 

    					1: 下订单失败 

    					2: 支付失败 

    					3: 发货失败 

    					4: 网络错误 

    					5: 登录失败或无效 

    					6: 用户取消 

    					7: 用户关闭IAP支付 
						*/

						if(resultCode==0){
							location.href='<?php print esc_url($order->get_received_url());?>';
						}else{
							location.href='<?php print esc_url($order->get_back_url());?>';
						}
        			}); 
        		}else{
        			location.href='<?php echo esc_url(WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'outer','order_id'=>$order->id),true,true))?>';
        		}
        	});
        	return;
        }
        location.href='<?php echo esc_url(WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'outer','order_id'=>$order->id),true,true))?>';
        </script>
        </body>
        </html>
        <?php   
} catch (Exception $e) {
    WShop_Log::error($e);
    WShop::instance()->WP->wp_die($e);
    exit;
}
?>
