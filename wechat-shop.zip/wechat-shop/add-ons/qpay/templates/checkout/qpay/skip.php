<?php
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

$order_id =isset($_GET['order_id'])?$_GET['order_id']:'';
$order = WShop::instance()->payment->get_order('id', $order_id);
if(!$order){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404));
    exit;
}

if(!$order->can_pay()){
    WShop::instance()->WP->wp_die(WShop_Error::error_custom(__('Current order is paid or expired!',WSHOP)));
    exit;
}
$api = WShop_Add_On_QPay::instance();
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>QQ钱包</title>
<meta charset="utf-8">
<script src="//open.mobile.qq.com/sdk/qqapi.js?_bid=152"></script>
</head>
<body>
	
<script type="text/javascript">
(function(){
	if(mqq&& mqq.QQVersion!='0'){
		location.href='<?php echo esc_url(WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'inner','order_id'=>$order->id),true,true))?>';
	}else{
		location.href='<?php echo esc_url(WShop::instance()->ajax_url(array('action'=>"wshop_{$api->id}",'tab'=>'outer','order_id'=>$order->id),true,true))?>';
	}
})();
</script>
</body>
</html>
<?php 
exit;
