<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
require_once 'abstract-xh-sms-api.php';

/**
 * 阿里大于apis
 * @author ranj
 * @since 1.0.0
 */
class WShop_SMC_SMS_Alidayu extends Abstract_WShop_SMC_SMS_Api{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_SMC_SMS_Alidayu
     */
    private static $_instance = null;
    /**

     *
     * @since 1.0.0
     * @static
     * @return WShop_SMC_SMS_Alidayu
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    private function __construct(){
       $this->id='alidayu';
       $this->title='阿里大鱼(不推荐)';
       $this->init_form_fields();
    }
    
    public function init_form_fields(){
        $this->form_fields =array(
            'appkey' => array (
                'title' =>__('App Key',WSHOP),
                'type' => 'text'
            ),
            'appsecret' => array (
                'title' =>__('App Secret',WSHOP),
                'type' => 'text'
            ),
            'sign_name' => array (
                'title' => __('Sign Name',WSHOP),
                'type' => 'text'
            )
        );
    }
 
     /**
     * {@inheritDoc}
     * @see Abstract_WShop_SMC_SMS_Api::send()
     */
    public function send($msg_id,$mobile, $params){
        try {
            if(!defined('TOP_SDK_WORK_DIR')){
                require_once 'alidayu/TopSdk.php';
            }
            
            if(!preg_match('/^\d{11}$/',$mobile)){
                return WShop_Error::error_custom( __('Invalid Mobile!',WSHOP));
            }
            
            $api = WShop_Add_On_Shangrao_Marathon_COM::instance();
      
            $req = new AlibabaAliqinFcSmsNumSendRequest();
            $req->setSmsType("normal");
            $req->setSmsFreeSignName($api->get_option("{$this->id}_sign_name"));
            $req->setSmsParam(json_encode($params));
            $req->setRecNum($mobile);
            $req->setSmsTemplateCode($msg_id);
        
            $c = new TopClient($api->get_option("{$this->id}_appkey"),$api->get_option("{$this->id}_appsecret"));
            $resp = $c->execute($req);
            if($resp->code&&$resp->code!=0){
                throw new Exception(json_encode($resp));
            }	
        } catch (Exception $e) {
            try {
                if('yes'==WShop_Add_On_Shangrao_Marathon_COM::instance()->get_option('email_warning')){
                    @wp_mail(get_option('admin_email'), __('sms send failed',WSHOP), 'sms send failed,mobile:'.$mobile.',details:'.print_r($resp,true));
                }
            } catch (Exception $o) {
                //ignore
            }
            
            WSHOP_Log::ERROR('sms send failed,mobile:'.$mobile.',details:'.$e->getMessage());
            return WShop_Error::error_custom( __('Message is sending failed, please try again later!',WSHOP));
        }
       
        return WShop_Error::success();
    }
}
?>