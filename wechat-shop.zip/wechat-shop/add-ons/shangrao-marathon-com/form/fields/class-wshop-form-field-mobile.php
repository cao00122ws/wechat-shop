<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Form_Field_Mobile extends Abstract_WShop_Form_Field{
    public function __construct($obj=array()){
        parent::__construct($obj);  
        $this->field_type ="mobile";
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Form_Field::get_field_title()
     */
    public function get_field_title()
    {
        return __('Mobile',WSHOP);
    }
    
    /**
     * @return string  standard|advanced|...
     * @since 1.0.0
     */
    public function get_group()
    {
        return 'advanced';
    }
    
    /**
     * 编辑模式 html
     * @return NULL|string
     * @since 1.0.0
     */
    public function to_editable(){
        return WShop::instance()->WP->requires(
            WShop_Add_On_Shangrao_Marathon_COM::instance()->dir,
            "form/fields/{$this->field_type}/editable.php",
            array(
                'field'=>$this
            ));
    }
    
    /**
     * 获取输出html
     * @param string $context 当前表单会话ID
     * @return NULL|string
     * @since 1.0.0
     */
    public function to_html($context,$func_get_data=null){
         
        return WShop::instance()->WP->requires(
            WShop_Add_On_Shangrao_Marathon_COM::instance()->dir,
            "form/fields/{$this->field_type}/html.php",
            array(
                'field'=>$this,
                'context'=>$context,
                'val'=>call_user_func_array($func_get_data,array($this,isset($this->metas->default)?$this->metas->default:null))
            ));
    }
    

    /**
     * 验证并绑定表单数据
     * @param Abstract_WShop_Order $order
     * @since 1.0.0
     */
    public function validate_field($func_insert_data=null){
        $input_name =$this->get_input_name();
        $label =$this->get_input_label();
        $mobile = isset($_REQUEST[$input_name])?stripslashes($_REQUEST[$input_name]):null;
        if(isset($this->metas->required)&&$this->metas->required&&empty($mobile)){
            return WShop_Error::error_custom(sprintf(__("%s is required!",WSHOP),$label));
        }
    
        $error = apply_filters("wshop_form_validate_{$input_name}", WShop_Error::success(),$mobile,$this);
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
      
        if($this->is_mobile_valided(get_current_user_id(), $mobile)){
            $error = call_user_func_array($func_insert_data,array($this,$mobile));
            if(!WShop_Error::is_valid($error)){
                return $error;
            }
            
            $region = isset($_REQUEST[$input_name.'_region'])?$_REQUEST[$input_name.'_region']:'+86';
            $regions = Abstract_WShop_SMC_SMS_Api::get_mobile_codes();
            update_user_meta(get_current_user_id(),"xh_form_{$this->get_input_name()}_region",isset($regions[$region])?$region:'+86');
            update_user_meta(get_current_user_id(),"xh_form_{$this->get_input_name()}_valid",'yes');
            
            return array(
                'label'=>$label,
                'val'=>$mobile,
                'region'=>$region,
                'hidden'=>isset($this->metas->hidden_in_entry)?$this->metas->hidden_in_entry:false
            );
        }
        
        $api = WShop_Add_On_Shangrao_Marathon_COM::instance();
        $fields=$api->get_fields($input_name);
        $ignore_fields = apply_filters('wshop_mobile_fields_validate_ignore',array($input_name.'_v_img_code'));
        $userdata=array();
        foreach (array_merge($fields['mobile'],$fields['validate']) as $name=>$settings){
            if(in_array($name, $ignore_fields)){
                continue;
            }
        
            if(!isset($settings['validate'])||!is_callable($settings['validate'])){
                continue;
            }
        
            $userdata = call_user_func_array($settings['validate'],array($name,$userdata,$settings));
        
            if($userdata instanceof WShop_Error&& !WShop_Error::is_valid($userdata)){
                return $userdata;
            }
        }
        
        $userdata =apply_filters('wshop_mobile_login_vcode_validate', $userdata);
        if(!WShop_Error::is_valid($userdata)){
            return $userdata;
        }
        
        $error = call_user_func_array($func_insert_data,array($this,$mobile));
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        $regions = Abstract_WShop_SMC_SMS_Api::get_mobile_codes();
        $region = isset($_REQUEST[$input_name.'_region'])?$_REQUEST[$input_name.'_region']:'+86';
        update_user_meta(get_current_user_id(),"xh_form_{$this->get_input_name()}_region",isset($regions[$region])?$region:'+86');
        update_user_meta(get_current_user_id(),"xh_form_{$this->get_input_name()}_valid",'yes');
        return array(
            'label'=>$label,
            'val'=>$mobile,
            'region'=>$region,
            'hidden'=>isset($this->metas->hidden_in_entry)?$this->metas->hidden_in_entry:false
        );
    }
    

    public function is_mobile_valided($user_id,$mobile){
        if(empty($mobile)||$user_id<=0){
            return false;
        }
    
        $validated_mobile=(string)get_user_meta($user_id,"xh_form_{$this->get_input_name()}",true);
        if($validated_mobile==$mobile
            &&'yes'==((string)get_user_meta($user_id,"xh_form_{$this->get_input_name()}_valid",true))){
            return $validated_mobile;
        }
    
        //如果含手机登录插件
        if(class_exists('XH_Social')){
            $mobile_channel =XH_Social::instance()->channel->get_social_channel('social_mobile');
            if($mobile_channel){
                $ext_user = $mobile_channel->get_ext_user('mobile', $mobile);
                if($ext_user&&$ext_user->user_id==$user_id){
                    $validated_mobile=$mobile;
                    update_user_meta($user_id, "xh_form_{$this->get_input_name()}", $mobile);
                    update_user_meta($user_id, "xh_form_{$this->get_input_name()}_valid", 'yes');
                    return $validated_mobile;
                }
            }
        }
    
        return false;
    }
    
}
?>