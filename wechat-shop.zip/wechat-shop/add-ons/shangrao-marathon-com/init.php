<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

/**
 * 手机登录
 * 
 * @author ranj
 * @since 1.0.0
 */
class WShop_Add_On_Shangrao_Marathon_COM extends Abstract_WShop_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_Shangrao_Marathon_COM
     */
    private static $_instance = null;
    
    /**
     * 插件目录
     * @var string
     * @since 1.0.0
     */
    public $dir;
    
    /**

     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_Shangrao_Marathon_COM
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    protected function __construct(){
        $this->id='wshop_add_ons_shangrao_marathon_com';
        $this->title=__('ahangrao-marathon.com',WSHOP);
        $this->menu_title = '短信设置';
        $this->description='表单短信验证，短信消息提醒';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.3';
        $this->author=__('xunhuweb',WSHOP);
        $this->dir=  WShop_Helper_Uri::wp_dir(__FILE__);
        $this->plugin_uri='https://www.wpweixin.net';
        $this->author_uri='https://www.wpweixin.net'; 
        $this->init_form_fields();
        $this->setting_uris=array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url("admin.php?page=wshop_page_default&section=menu_default_basic&sub=wshop_add_ons_shangrao_marathon_com")
            )
        );
        $this->enabled ='yes'== $this->get_option('enabled');
    }

    public function on_load(){
        add_filter('wshop_form_fields', array($this,'wshop_form_fields'),10,1);
        add_action('wshop_order_order_ordered', array($this,'send_sms_msg'),10,2);
    }

    public function on_init(){
        add_filter('wshop_admin_menu_menu_default_basic', array($this,'add_channel_menus'),10,2);
    }
     
    /**
     * 
     * @param WShop_Error $success
     * @param WShop_Order $order
     */
    public function send_sms_msg($success,$order){
        $form_title = isset($order->metas['form']['title'])?$order->metas['form']['title']:null;
        $fields =isset($order->metas['form']['fields'])?$order->metas['form']['fields']:null;
        if(empty($form_title)||!$fields){
            return $success;
        }

        if(!isset($fields['send_sms_msg'])){
            return $success;
        }
        
        $mobile = isset($fields['mobile']['val'])?$fields['mobile']['val']:null;
        $region = isset($fields['mobile']['region'])?$fields['mobile']['region']:null;
        
        $sms_params_str =$this->get_option('bg_sms_params');
        $params=array();
        foreach (explode(',', $sms_params_str) as $p){
            switch($p){
                case 'item':
                    $params['item'] = $form_title;
                    break;
                default:
                    $params[$p] = isset($fields[$p]['val'])?$fields[$p]['val']:null;
                    break;
            }
        }
        
        if(defined('XH_MOBILE_TEST')&&XH_MOBILE_TEST){
            return WShop_Error::error_custom(print_r($params,true));
        }
        
        $sms_api = $this->get_sms_api();
        if(!$sms_api){
            return WShop_Error::error_custom(__('[system error]sms api is invalid!',WSHOP));
        }
        
        return $sms_api->send($this->get_option('bg_sms_id'),$mobile, $params,$region);
    }
    
    public function wshop_form_fields($fields){
        require_once 'form/fields/class-wshop-form-field-mobile.php';
        $fields[]=new WShop_Form_Field_Mobile();
        return $fields;
    }
    
    public function init_form_fields(){
        $this->form_fields =array(
            'disabled_captcha'=>array(
                'title'=>__('Disabled Captcha',WSHOP),
                'type'=>'checkbox',
                'label'=>__('Disable captcha verify when send sms code.',WSHOP),
                'default'=>'no'
            ),
            'email_warning'=>array(
                'title'=>__('Enabled Email Warning',WSHOP),
                'type'=>'checkbox',
                'label'=>__('Email warning when sms send failed(To: admin email).',WSHOP),
                'default'=>'yes'
            ),
            'subtitle_api'=>array(
                'title'=>__('SMS Servers',WSHOP),
                'type'=>'subtitle',
                'description'=>__('提供国内主流的短信服务商，阿里大鱼、网易等短信服务，短信服务商会不断增加也可定制',WSHOP)
            ),
            'api'=>array(
                'title' => __ ( 'SMS Server', WSHOP ),
                'type' => 'section',
                'options'=>array()
            )
        );
        
        
        $apis = $this->get_sms_apis();
         
        foreach ($apis as $api){
            $this->form_fields['api']['options'][$api->id]=$api->title;
        
            foreach ($api->form_fields as $key=>$fields){
                $fields['tr_css']="subsection section-api section-{$api->id}";
                $this->form_fields[$api->id.'_'.$key]=$fields;
            }
        }
         
        $this->form_fields['sms_v_title']=array(
            'title'=>'手机验证模板设置',
            'type'=>'subtitle',
            'description'=>__('以短信服务商系统设置的短信模板内容为准，这里仅提供参数',WSHOP)
        );
        
        $this->form_fields['login_sms_id']=array(
            'title'=>__('SMS ID',WSHOP),
            'type'=>'text',
            'description'=>__('填写短信平台登录验证模板ID(多个ID“,”分隔)',WSHOP)
        );
        
        $this->form_fields['login_sms_params']=array(
            'title'=>__('SMS Params',WSHOP),
            'type'=>'text',
            'default'=>'code',
            'description'=>__('设置短信内容参数，多个参数以英文逗号隔开(<a target="_blank" href="http://www.weixinsocial.com/blog/91.html#mobilesettings">详细设置</a>)。
                    <br/> 可选参数：
                    <br/>code:验证码
                    <br/>sitename(或product):网站名称
                    <br/>currenttime:当前时间',WSHOP)
        );
        

        $this->form_fields['sms_s_title']=array(
            'title'=>'报名成功短信模板设置',
            'type'=>'subtitle',
            'description'=>__('以短信服务商系统设置的短信模板内容为准，这里仅提供参数',WSHOP)
        );
        
        $this->form_fields['bg_sms_id']=array(
            'title'=>__('SMS ID',WSHOP),
            'type'=>'text',
            'description'=>__('填写短信平台登录验证模板ID(多个ID“,”分隔)',WSHOP)
        );
        
        $this->form_fields['bg_sms_params']=array(
            'title'=>__('SMS Params',WSHOP),
            'type'=>'text',
            'default'=>'name,item',
            'description'=>'设置短信内容参数，多个参数以英文逗号隔开(<a target="_blank" href="http://www.weixinsocial.com/blog/91.html#mobilesettings">详细设置</a>)。
                    <br/> 可选参数：
                    <br/>item:项目名称(表单标题)
                    <br/><除item字段>:表单的字段'
        );
    }

    public function do_ajax(){
        $action = "wshop_{$this->id}";
        $datas=shortcode_atts(array(
            'notice_str'=>null,
            'action'=>$action,
            $action=>null,
            'tab'=>null,
            'hash'=>null
        ), stripslashes_deep($_REQUEST));
        
        if(isset($_REQUEST['mobile_field_key'])){
            $datas['mobile_field_key'] = stripslashes($_REQUEST['mobile_field_key']);
        }
        
        $validate =WShop::instance()->WP->ajax_validate($datas,$datas['hash'],true);
        if(!$validate){
            echo (WShop_Error::err_code(701)->to_json());
            exit;
        }
        
        switch($datas['tab']){
            case 'mobile_login_vcode':
                $this->mobile_vcode($datas);
                exit;
        }
    }

    private function mobile_vcode($datas){
        $userdata = array();
        $field_mobile_key = $datas['mobile_field_key'];
        $fields=$this->get_fields($field_mobile_key);

        $include_fields = apply_filters('wshop_mobile_code_fields_validate',array($field_mobile_key,$field_mobile_key.'_v_img_code'));
        foreach (array_merge($fields['mobile'],$fields['validate']) as $name=>$settings){
            if(!in_array($name, $include_fields)){
                continue;
            }
        
            if(!isset($settings['validate'])||!is_callable($settings['validate'])){
                continue;
            }
        
            $userdata = call_user_func_array($settings['validate'],array($name,$userdata,$settings));
        
            if($userdata instanceof WShop_Error&& !WShop_Error::is_valid($userdata)){
                echo $userdata->to_json();
                exit;
            }
        }
        
        $userdata =apply_filters('wshop_mobile_login_vcode_validate', $userdata);
        if(!WShop_Error::is_valid($userdata)){
            echo $userdata->to_json();
            exit;
        }
        
        if(!isset($userdata[$field_mobile_key])||empty($userdata[$field_mobile_key])){
            echo WShop_Error::error_custom(__('mobile field is required!',WSHOP))->to_json();
            exit;
        }
        
        $region = isset($userdata['region'])?$userdata['region']:'';
        
        $time = intval(WShop::instance()->session->get('wshop_login_mobile_last_send_time',0));
        $now = time();
        
        if($time>$now){
            echo WShop_Error::error_custom(sprintf(__('Please wait for %s seconds!',WSHOP),$time-$now))->to_json();
            exit;
        }
       
        WShop::instance()->session->set('wshop_login_mobile_last_send_time',$now+60);
        
        $sms_api = $this->get_sms_api();
        if(!$sms_api){
            echo WShop_Error::error_custom(__('[system error]sms api is invalid!',WSHOP))->to_json();
            exit;
        }
       
        $code = substr(str_shuffle(time()), 0,6);
        WShop::instance()->session->set('wshop_mobile_validate_code',$code);
        
        $login_sms_params_str =$this->get_option('login_sms_params');
        $login_sms_params=null;
        if(!empty($login_sms_params_str)){
            $login_sms_params = explode(',', $login_sms_params_str);
        }
        
        $params = array();
        if(!$login_sms_params){return $params;}
        
        foreach ($login_sms_params as $param){
            switch ($param){
                case 'code':
                    $params['code']="$code";
                    break;
                case 'sitename':
                    $params['sitename']=get_option('blogname');
                    break;
                case 'product':
                    $params['product']=get_option('blogname');
                    break;
                case 'currenttime':
                    $params['currenttime']=date_i18n('Y-m-d H:i');
                    break;
                default:
                    $params = apply_filters('wshop_sms_login_params', $params,$this);
                    break;
            }
        }
        
        if(defined('XH_MOBILE_TEST')&&XH_MOBILE_TEST){
            echo WShop_Error::error_custom(print_r($params,true))->to_json();
            exit;
        }
       
        echo $sms_api->send($this->get_option('login_sms_id'),$userdata[$field_mobile_key], $params,$region)->to_json();
        exit;
    }

    public function clear_mobile_validate_code(){
        WShop::instance()->session->__unset('wshop_mobile_validate_code');
        WShop::instance()->session->__unset('wshop_login_mobile_last_send');
    }
    
    public function get_fields($mobile_field_name){
        $sms_api = $this->get_sms_api();
    
        $validate_fields = array();
        if('yes'!=$this->get_option('disabled_captcha')){
            $captcha_fields =WShop::instance()->WP->get_captcha_fields($mobile_field_name.'_v_img_code');
             
            $validate_fields=apply_filters('wshop_page_mobile_validate_fields',array_merge($validate_fields,$captcha_fields),2);
        }
    
        $validate_fields[$mobile_field_name.'_v_sms_code'] =array(
            'title'=>__('Sms captcha',WSHOP),
            'mobile_field_key'=>$mobile_field_name,
            'type'=>function ($form_id,$data_name,$settings){
                $html_name = $data_name;
                $html_id =isset($settings['id'])?$settings['id']:  $form_id."_".$data_name;
    
                ob_start();
                $api = WShop_Add_On_Shangrao_Marathon_COM::instance();
                $params = apply_filters('wshop_mobile_validation_request', array(
                    'action'=>"wshop_{$api->id}"  ,
                    'tab'=>'mobile_login_vcode',
                    'mobile_field_key'=>$settings['mobile_field_key'],
                    "wshop_{$api->id}"=>wp_create_nonce("wshop_{$api->id}"),
                    'notice_str'=>str_shuffle(time())
                ));
                $params['hash']=WShop_Helper::generate_hash($params, WShop::instance()->get_hash_key());
                ?>
                  <div class="xh-form-group">
                      <?php if(isset($settings['title'])&&!empty($settings['title'])){
                    	    ?><label><?php echo $settings['title']?></label><?php 
                       }?>
                       <div class="xh-input-group">
                           <input name="<?php echo esc_attr($html_name);?>" type="text" id="<?php echo esc_attr($html_id);?>" maxlength="6" class="form-control" placeholder="<?php echo __('sms captcha',WSHOP)?>">
                           <span class="xh-input-group-btn"><button type="button" style="min-width:96px;height:35px;line-height:35px;font-size:14px;padding:0;" class="xh-btn xh-btn-default" id="btn-code-<?php echo esc_attr($html_id);?>"><?php echo __('Send Code',WSHOP)?></button></span>
                       </div>
                   </div>	
                   <script type="text/javascript">
           			(function($){
           				if(!$){return;}
           
           				$('#btn-code-<?php echo esc_attr($html_id);?>').click(function(){
               				var $this = $(this);
           					var data =<?php echo json_encode($params);?>;
           					data.ajax={};
           					<?php WShop_Helper_Html_Form::generate_submit_data($form_id, 'data');?>    					
           					if($this.attr('disabled')){
           						return;
           					}
           					
           					$this.attr('disabled','disabled').text('<?php echo __('Processing...',WSHOP)?>');
           				
           					$.ajax({
           			            url: '<?php echo WShop::instance()->ajax_url()?>',
           			            type: 'post',
           			            timeout: 60 * 1000,
           			            async: true,
           			            cache: false,
           			            data: data,
           			            dataType: 'json',
           			            success: function(m) {
           			            	if(m.errcode!=0){
           				            	alert(m.errmsg);
           				            	$this.removeAttr('disabled').text('<?php echo __('Send Code',WSHOP)?>');
           				            	return;
           							}
           			            
           							var time = 60;
           							if(window.wshop_view_mobile_valid_interval){
           								clearInterval(window.wshop_view_mobile_valid_interval);
           							}
           							
           							window.wshop_view_mobile_valid_interval = setInterval(function(){
           								if(time<=0){
           									$this.removeAttr('disabled').text('<?php echo __('Send Code',WSHOP)?>');
           									if(window.wshop_view_mobile_valid_interval){
               									clearInterval(window.wshop_view_mobile_valid_interval);
                   							}
           									return;
           								}
           								time--;
           								$this.text('<?php echo __('Resend',WSHOP)?>('+time+')');
           							},1000);
           			            },error:function(e){
           			            	$this.removeAttr('disabled').text('<?php echo __('Send Code',WSHOP)?>');
           							console.error(e.responseText);
           				         }
           			         });
           				});
           			})(jQuery);
                   </script>
                   <?php 
                   WShop_Helper_Html_Form::generate_field_scripts($form_id, $html_name,$html_id);
                 
                   return ob_get_clean();
               },
                'validate'=>function($name,$datas,$settings){
                       $code_post =isset($_REQUEST[$name])?trim($_REQUEST[$name]):'';
                       if(empty($code_post)){
                           return WShop_Error::error_custom(__('sms captcha is required!',WSHOP));
                       }
                       
                       $code = WShop::instance()->session->get('wshop_mobile_validate_code');
                       if(empty($code)){
                           return WShop_Error::error_custom(__('please get the sms captcha again!',WSHOP));
                       }
                       
                       if(strcasecmp($code, $code_post) !==0){
                           return WShop_Error::error_custom(__('sms captcha is invalid!',WSHOP));
                       }
                       
                       return $datas;
                }
           );
            
            return array(
                'mobile'=>$sms_api->get_field_mobile($mobile_field_name),
                'validate'=>$validate_fields
            );
        }
   /**
    * 获取短信接口
    * @since 1.0.0
    * @return Abstract_WShop_SMC_SMS_Api[]
    */
   public function get_sms_apis(){
       require_once 'class-xh-sms-alidayu.php';
       require_once 'class-xh-sms-aliyun.php';
       require_once 'class-xh-sms-netease.php';
       require_once 'class-xh-sms-yunpian.php';
       require_once 'class-xh-sms-yunpian-internation.php';
       require_once 'class-xh-sms-qcloud.php';
       require_once 'class-xh-sms-qcloud-internation.php';
       
       return WShop_Helper_Array::where(apply_filters('wshop_sms_apis', array(
           WShop_SMC_SMS_Aliyun::instance(),
           WShop_SMC_SMS_Netease::instance(),
           WShop_SMC_SMS_Yunpian::instance(),
           WShop_SMC_SMS_Yunpian_Internation::instance(),
           WShop_SMC_SMS_QCloud::instance(),
           WShop_SMC_SMS_QCloud_Internation::instance(),
           WShop_SMC_SMS_Alidayu::instance(),
       )),function($m){
           return $m&&$m instanceof Abstract_WShop_SMC_SMS_Api;
       });
   }
   
   /**
    * 获取短信接口
    * @since 1.0.0
    * @return Abstract_WShop_SMC_SMS_Api
    */
   public function get_sms_api(){
       $api =$this->get_option('api');
       return WShop_Helper_Array::first_or_default($this->get_sms_apis(),function($m,$key){
           return !$key||$m->id==$key;
       },$api);
   }

    /**
     * 注册管理菜单
     * @param array $menus
     * @return array
     */
    public function add_channel_menus($menus){
        $menus[]=$this;
        return $menus;
    }
}

return WShop_Add_On_Shangrao_Marathon_COM::instance();
?>