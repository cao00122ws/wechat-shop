<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
$atts =WShop_Temp_Helper::clear('atts','templates');;
$field = $atts['field'];
$context = $atts['context'];

$api = WShop_Add_On_Shangrao_Marathon_COM::instance();
$field_id = esc_attr($field->id);
if(!$field->metas){$field->metas=new stdClass();}
$label = $field->get_input_label();
$description = isset($field->metas->description)?$field->metas->description:null;
$placeholder = isset($field->metas->placeholder)?$field->metas->placeholder:null;
$css = isset($field->metas->css)?$field->metas->css:null;
$style = isset($field->metas->style)?$field->metas->style:null;
$default =$atts['val'];
$required = isset($field->metas->required)?$field->metas->required:false;
$input_id = esc_attr($field->get_input_id($context));
$input_name =esc_attr($field->get_input_name());

$attr = isset($field->metas->attr)?$field->metas->attr:null;

$fields = $api->get_fields($input_name);

$fields['mobile'][$input_name]['id']=$input_id;
$fields['mobile'][$input_name]['css']=$css;
$fields['mobile'][$input_name]['style']=$style;
$fields['mobile'][$input_name]['default']=$default;
$fields['mobile'][$input_name]['required']=$required;
$fields['mobile'][$input_name]['description']=$description;
$fields['mobile'][$input_name]['title']=$label;
$fields['mobile'][$input_name]['custom_attributes']=array_merge( array(
    'placeholder'=>$placeholder
), wp_kses_hair_parse( $attr ));

echo WShop_Helper_Html_Form::generate_html($context, $fields['mobile']);
$validated_mobile=null;

$validated_mobile = $field->is_mobile_valided(get_current_user_id(),$default);

?>
<div id="field-mobile-validate-<?php echo $context?>" <?php echo $validated_mobile?'style="display:none"':'';?>>
	<?php 
	echo WShop_Helper_Html_Form::generate_html($context, $fields['validate']);
	?>
</div>
<script type="text/javascript">
	(function($){
		window.wshop_validated_mobile='<?php echo $validated_mobile;?>';
		$('#<?php echo $input_id?>').keyup(function(){
			var mobile = $.trim($(this).val());
			if(window.wshop_validated_mobile==mobile){
				$('#field-mobile-validate-<?php echo $context?>').hide();
			}else{
				$('#field-mobile-validate-<?php echo $context?>').show();
			}
		});
		$('#<?php echo $input_id?>').keyup();
	})(jQuery);
</script>
<?php 