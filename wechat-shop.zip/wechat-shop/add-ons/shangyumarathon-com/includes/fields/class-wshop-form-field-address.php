<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Form_Field_Address extends Abstract_WShop_Form_Field{
    public function __construct($obj=array()){
        parent::__construct($obj);  
        $this->field_type ="address";
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Form_Field::get_field_title()
     */
    public function get_field_title()
    {
        return '地址(三级联动)';
    }
    
    /**
     * @return string  standard|advanced|...
     * @since 1.0.0
     */
    public function get_group()
    {
        return 'advanced';
    }
    
    /**
     * 编辑模式 html
     * @return NULL|string
     * @since 1.0.0
     */
    public function to_editable(){
        return WShop::instance()->WP->requires(
            WShop_Add_On_shangyumarathon::instance()->domain_dir,
            "form/fields/{$this->field_type}/editable.php",
            array(
                'field'=>$this
            ));
    }
    
    /**
     * 验证并绑定表单数据
     * @param Abstract_WShop_Order $order
     * @since 1.0.0
     */
    public function validate_field($func_insert_data=null){
        $input_name =$this->get_input_name();
        $label =$this->get_input_label();
        
        $province = isset($_REQUEST["{$input_name}_province"])?stripslashes($_REQUEST["{$input_name}_province"]):null;
        $city = isset($_REQUEST["{$input_name}_city"])?stripslashes($_REQUEST["{$input_name}_city"]):null;
        $dic = isset($_REQUEST["{$input_name}_dic"])?stripslashes($_REQUEST["{$input_name}_dic"]):null;
        
        if(isset($this->metas->required)&&$this->metas->required){
            if(empty($province)){
                return WShop_Error::error_custom('请选择省份！');
            }
            
            if(empty($city)){
                return WShop_Error::error_custom('请选择城市！');
            }
            
            if(empty($dic)){
                return WShop_Error::error_custom('请选择地区！');
            }
        }
    
        $data = "{$province} {$city} {$dic}";
        $error = apply_filters("wshop_form_validate_{$input_name}", WShop_Error::success(),$data,$this);
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
    
        if(is_user_logged_in()){
            update_user_meta(get_current_user_id(),"xh_form_{$this->get_input_name()}_array",array(
                'province'=>$province,
                'city'=>$city,
                'dic'=>$dic,
            ));
        }
        
        $error = call_user_func_array($func_insert_data,array($this,$data));
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        return array(
            'label'=>$label,
            'val'=>$data,
            'hidden'=>isset($this->metas->hidden_in_entry)?$this->metas->hidden_in_entry:false
        );
    }
     
     
    /**
     * 获取输出html
     * @param string $context 当前表单会话ID
     * @return NULL|string
     * @since 1.0.0
     */
    public function to_html($context,$func_get_data=null){         
        return WShop::instance()->WP->requires(
            WShop_Add_On_shangyumarathon::instance()->domain_dir,
            "form/fields/{$this->field_type}/html.php",
            array(
                'field'=>$this,
                'context'=>$context,
                'val'=>is_user_logged_in()?get_user_meta(get_current_user_id(),"xh_form_{$this->get_input_name()}_array",true):null
            ));
    }
}
?>