<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Form_Field_IDCard extends Abstract_WShop_Form_Field{
    public function __construct($obj=array()){
        parent::__construct($obj);  
        $this->field_type ="idcard";
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Form_Field::get_field_title()
     */
    public function get_field_title()
    {
        return '证件';
    }
    
    /**
     * @return string  standard|advanced|...
     * @since 1.0.0
     */
    public function get_group()
    {
        return 'advanced';
    }
    
    /**
     * 编辑模式 html
     * @return NULL|string
     * @since 1.0.0
     */
    public function to_editable(){
        return WShop::instance()->WP->requires(
            WShop_Add_On_shangyumarathon::instance()->domain_dir,
            "form/fields/{$this->field_type}/editable.php",
            array(
                'field'=>$this
            ));
    }
    
    /**
     * 验证并绑定表单数据
     * @param Abstract_WShop_Order $order
     * @since 1.0.0
     */
    public function validate_field($func_insert_data=null){
        $input_name =$this->get_input_name();
        $label =$this->get_input_label();
        
        $data = isset($_REQUEST[$input_name])?stripslashes($_REQUEST[$input_name]):null;
        if(isset($this->metas->required)&&$this->metas->required&&empty($data)){
            return WShop_Error::error_custom(sprintf('请输入%s!',$label));
        }
    
        $type =  isset($_REQUEST["{$input_name}_type"])?stripslashes($_REQUEST["{$input_name}_type"]):null;        
        if(!empty($data)&&(empty($type)|| '身份证'==$type)){
            if(!class_exists('com\jdk5\blog\IDValidator\IDValidator')){
                require_once 'lib/IDValidator.php';
            }
            
            $v = com\jdk5\blog\IDValidator\IDValidator::getInstance();
            
            if(!$v->isValid($data)){
                return WShop_Error::error_custom(sprintf("请输入正确的%s!",$label));
            }
        }
        
        $error = apply_filters("wshop_form_validate_{$input_name}", WShop_Error::success(),array($data,$type),$this);
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        if(is_user_logged_in()){
            update_user_meta(get_current_user_id(),"xh_form_{$this->get_input_name()}_array",array(
                'type'=>$type,
                'data'=>$data
            ));
        }
        
        $data =empty($type)?$data:"{$type}:{$data}";
        
        $error = call_user_func_array($func_insert_data,array($this,$data));
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        return array(
            'label'=>$label,
            'val'=>$data,
            'hidden'=>isset($this->metas->hidden_in_entry)?$this->metas->hidden_in_entry:false
        );
    }
     
     
    /**
     * 获取输出html
     * @param string $context 当前表单会话ID
     * @return NULL|string
     * @since 1.0.0
     */
    public function to_html($context,$func_get_data=null){
         
        return WShop::instance()->WP->requires(
            WShop_Add_On_shangyumarathon::instance()->domain_dir,
            "form/fields/{$this->field_type}/html.php",
            array(
                'field'=>$this,
                'context'=>$context,
                'val'=>is_user_logged_in()?get_user_meta(get_current_user_id(),"xh_form_{$this->get_input_name()}_array",true):null
            ));
    }
}
?>