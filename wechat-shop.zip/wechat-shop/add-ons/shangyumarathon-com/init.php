<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
/**
 * @author rain
 *
 */
class WShop_Add_On_shangyumarathon extends Abstract_WShop_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Add_On_shangyumarathon
     */
    private static $_instance = null;
    public $domain_url;
    public $domain_dir;
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Add_On_shangyumarathon
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wshop_add_ons_shangyumarathon';
        $this->title='www.shangyumarathon.com';
        $this->description='身份证JS格式验证,报名数量,收货地址3级联动';
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';   
        $this->author=__('xunhuweb',WSHOP);
        $this->depends =array(
            'wshop_add_ons_form'=>array(
                'title'=>__('Forms',WSHOP)
            )
        );
        
        $this->author_uri='https://www.wpweixin.net';
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
    }

    public function on_install(){
        global $wpdb;
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_forms_product'
            and table_schema ='".DB_NAME."'
					and column_name ='enable_qty'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_forms_product` add column `enable_qty` varchar(8) NULL DEFAULT 'no';");
        }
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        $column =$wpdb->get_row(
            "select column_name
            from information_schema.columns
            where table_name='{$wpdb->prefix}wshop_forms_product'
            and table_schema ='".DB_NAME."'
					and column_name ='qty_min'
			limit 1;");
        
        if(!$column||empty($column->column_name)){
            $wpdb->query("alter table `{$wpdb->prefix}wshop_forms_product` add column `qty_min` int(11) NULL DEFAULT NULL;");
        }
        
        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
    }
    
    public function on_load(){
        add_filter('wshop_form_fields', array($this,'wshop_form_fields'),10,1);
        add_action('wshop_form_purchase_content_before_gateways', array($this,'wshop_form_purchase_content_before_gateways'),10,4);
        add_filter('wshop_forms_product_properties', array($this,'wshop_forms_product_properties'),10,1);
        add_filter('wshop_form_product_fields', array($this,'wshop_form_product_fields'),10,2);
        add_filter('wshop_form_created_order_add_to_cart', array($this,'wshop_form_created_order_add_to_cart'),10,5);
        
        add_filter('wsocial_mobile_form_fields', array($this,'wsocial_mobile_form_fields'),10,1);
        add_filter('wshop_order_order_ordered', array($this,'wshop_order_order_ordered'),10,2);
        
        add_filter('wshop_form_entry_columns', array($this,'wshop_form_entry_columns'),10,2);
        add_action( "manage_".WShop_Forms_Entry::POST_T."_posts_custom_column", array( $this, 'manage_enrtys_custom_column' ),11, 2 );
        
        add_filter('wshop_forms_entry_export_columns', function($c){
            $c[]='__qty__';
            return $c;
        },10,2);
        
        add_filter('wshop_forms_entry_export_first_line', function($c){
            $c[]='数量';
            return $c;
        },10,2);
        
        add_filter('wshop_form_entry_export_column', function($false,$column,$entry,$post,$form){
            if($column!='__qty__'){return $false;}
            $order = new WShop_Order($entry->order_id);
            if(!$order->is_load()){
                return $false;
            }
            
            $order_items = $order->get_order_items();
            $qty = 0;
            if($order_items){foreach($order_items as $order_item){
                $qty+=$order_item->qty;
            }}
            return $qty;
        },10,5);
        
        add_filter('wsocial_login_succeed', function($success,$wp_user){
            $api = XH_Social::instance()->channel->get_social_channel('social_mobile');
            if(!$api){
                return $success;
            }
            
            $ext_user = $api->get_ext_user_info_by_wp($wp_user->ID);
            if(!$ext_user){
                return new XH_Social_Error(8000,'',$api->generate_authorization_uri($wp_user->ID));
            }
            return $success;
        },10,2);
        
        add_filter('wsocial_old_user_logged_in_redirect_url', function($url,$wp_user){
            $api = XH_Social::instance()->channel->get_social_channel('social_mobile');
            if(!$api){
                return $url;
            }
            
            $ext_user = $api->get_ext_user_info_by_wp($wp_user->ID);
            if(!$ext_user){
                return $api->generate_authorization_uri($wp_user->ID);
            }
            return $url;
        },10,2);
    }
    
    public function manage_enrtys_custom_column($column,$post_ID){
        global $wp_query;
        global $current_wshop_entry;
        if(!$current_wshop_entry||$current_wshop_entry->post_ID!=$post_ID){
            $current_wshop_entry = new WShop_Forms_Entry($post_ID);
        }
        
        if(!$current_wshop_entry->is_load()){
            return;
        }
        
        if($column!='__qty__'){
            return;
        }
        
        $order = new WShop_Order($current_wshop_entry->order_id);
        if(!$order->is_load()){
            return;
        }
        
        $order_items = $order->get_order_items();
        $qty = 0;
        if($order_items){foreach($order_items as $order_item){
            $qty+=$order_item->qty;
        }}
        echo $qty;
    }
    
    public function wshop_form_entry_columns( $new_existing_columns,$current_wshop_form){
        $new_existing_columns['__qty__']='数量';
        return $new_existing_columns;
    }
    
    /**
     * 
     * @param WShop_Error $success
     * @param WShop_Order $order
     * @return XH_Social_Error
     */
    public function wshop_order_order_ordered($success,$order){
        if(!class_exists('XH_Social')){return $success;}
        $addon = XH_Social_Add_On_Social_Mobile::instance();
        $api = XH_Social::instance()->channel->get_social_channel('social_mobile');
        if(!$api){return $success;}
        
        $ext_user = $order->customer_id?$api->get_ext_user_info_by_wp($order->customer_id):null;
        if(!$ext_user){
            WShop_Log::debug("ext_user info not exists.customer id: {$order->customer_id}");
            return $success;
        }
        
        $sms_api = $addon->get_sms_api();
        if(!$sms_api){
            WShop_Log::debug("sms_api not exists.customer id: {$order->customer_id}");
            return $success;
        }
       
        $login_sms_params_str =$addon->get_option('order_success_sms_params');
        $login_sms_params=null;
        if(!empty($login_sms_params_str)){
            $login_sms_params = explode(',', $login_sms_params_str);
        }
        
        $user_ids =array(
            'id_1516856812',
            'id_1516856636',
            'id_1505183048',
            'id_1505175954'
        );
        
        $user_name = '用户';
        foreach ($user_ids as $user_id){
            if(isset($order->metas['form']['fields'][$user_id])){
                $user_name=$order->metas['form']['fields'][$user_id]['val'];
                break;
            }
        }
        
        $order_items = $order->get_order_items();
        if(count($order_items)==0){
            return $success;
        }
        
        $params = array();
        if(!$login_sms_params){return $params;}
        
        foreach ($login_sms_params as $param){
            switch ($param){
                case 'var1':
                    $params['var1']=$user_name;
                    break;
                case 'var2':
                    $params['var2']=$order_items[0]->get_title();
                    break;
                case 'sitename':
                    $params['sitename']=get_option('blogname');
                    break;
                case 'product':
                    $params['product']=get_option('blogname');
                    break;
                case 'currenttime':
                    $params['currenttime']=date_i18n('Y-m-d H:i');
                    break;
                default:
                    $params = apply_filters('wsocial_sms_order_success_params', $params,$this);
                    break;
            }
        }
        
        try {
            return $sms_api->send($addon->get_option('order_success_sms_id'),$ext_user['mobile'], $params);
        } catch (Exception $e) {
            WShop_Log::debug("sms send failed not exists.customer id: {$order->customer_id},".print_r($params,true));
            return WShop_Error::error_custom($e->getMessage());
        }
    }
    
    public function wsocial_mobile_form_fields($fields){
        $fields['order_success_sms_id']=array(
            'title'=>'(订单成功)短信ID',
            'type'=>'text',
            'description'=>__('填写短信平台登录验证模板ID(多个ID“,”分隔)',XH_SOCIAL)
        );
        
        $fields['order_success_sms_params']=array(
            'title'=>'(订单成功)短信参数',
            'type'=>'text',
            'default'=>'code',
            'description'=>__('设置短信内容参数，多个参数以英文逗号隔开(<a target="_blank" href="http://www.weixinsocial.com/blog/91.html#mobilesettings">详细设置</a>)。
                    <br/> 可选参数：
                    <br/>code:验证码
                    <br/>sitename(或product):网站名称
                    <br/>currenttime:当前时间',XH_SOCIAL)
        );
        
        return $fields;
    }
    
    public function wshop_form_product_fields($fields,$post){
        $fields['enable_qty'] =array(
            'title'=>'启用数量',
            'type'=>'checkbox'
        );
        $fields['qty_min'] =array(
            'title'=>'最少报名人数',
            'type'=>'text'
        );
        return $fields;
    }
    
    public function wshop_forms_product_properties($fields){
        $fields['enable_qty']='no';
        $fields['qty_min'] =null;
        return $fields;
    }
    
    /**
     * 
     * @param unknown $func
     * @param WShop_Shopping_Cart $cart
     * @param unknown $product
     * @param unknown $request
     */
    public function wshop_form_created_order_add_to_cart($func,$cart,$product,$form_product,$request){
        if(!$form_product||$form_product->get('enable_qty')!='yes'){
            return $func;
        }
        return function($cart,$product,$form_product,$request){
            $qty = isset($request['qty'])?intval($request['qty']):1;
            if($qty<1){$qty=1;}
            if($qty>999999){
                $qty=999999;
            }
            
            $qty_min = $form_product->get('qty_min');
            if(!is_null($qty_min)&&$qty_min!==''){
                $qty_min = intval($qty_min);
                
                if($qty<$qty_min){
                    $qty=$qty_min;
                }
            }
            
            return $cart->__add_to_cart($product->post_ID,$qty);
        };
    }
    
    public function wshop_form_purchase_content_before_gateways($form,$product,$form_product,$context){
        if('yes'!=$form_product->get('enable_qty')){
            return;
        }
        echo WShop::instance()->WP->requires(
            $this->domain_dir,
            "form/form-qty.php",
            array(
                'form'=>$form,
                'product'=>$product,
                'form_product'=>$form_product,
                'context'=>$context
            ));
    }
    
    public function wshop_form_fields($fields){
        require_once 'includes/fields/class-wshop-form-field-idcard.php';
        $fields[]=new WShop_Form_Field_IDCard();
        
        require_once 'includes/fields/class-wshop-form-field-address.php';
        $fields[]=new WShop_Form_Field_Address();
        
        return $fields;
    }
    
}

return WShop_Add_On_shangyumarathon::instance();
?>