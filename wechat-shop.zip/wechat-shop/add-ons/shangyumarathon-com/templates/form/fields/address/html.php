<?php 
if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
$atts =WShop_Temp_Helper::clear('atts','templates');;
$field = $atts['field'];
$context = $atts['context'];


$field_id = esc_attr($field->id);
if(!$field->metas){$field->metas=new stdClass();}
$label = $field->get_input_label();
$description = isset($field->metas->description)?$field->metas->description:null;
$placeholder = isset($field->metas->placeholder)?$field->metas->placeholder:null;
$css = isset($field->metas->css)?$field->metas->css:null;
$style = isset($field->metas->style)?$field->metas->style:null;
$default =$atts['val'];
$required = isset($field->metas->required)?$field->metas->required:false;
$input_id = esc_attr($field->get_input_id($context));
$input_name =esc_attr($field->get_input_name());
$attr = isset($field->metas->attr)?$field->metas->attr:null;

$datas = json_decode(require '_data.php',true);

$provinces = array();
foreach ($datas as $data){
    if(!empty($data['ShengJiName'])
        &&!empty($data['diji'])
        &&!empty($data['xianji'])){
        $provinces[$data['ShengJiName']][$data['diji']][]=$data['xianji'];
    }
}

?>

<div class="xh-form-group">
    <label class="<?php echo $required?"required":""?>"><?php echo $label;?></label>
    
    <div class="clearfix">
        <select <?php echo $attr;?>  class="form-control <?php echo esc_attr($css)?>" style="<?php echo esc_attr($style)?> ; width:33%;float:left;" name="<?php echo $input_name.'_province';?>"  id="<?php echo $input_id.'_province';?>">
    		<option value=''>省</option>
    		<?php 
    		  foreach ($provinces as $province =>$citys){
    		      ?>
    		      <option value="<?php echo esc_attr($province)?>" <?php echo $default&&is_array($default)&&isset($default['province'])&&$default['province']==$province?'selected':'';?>><?php echo esc_html($province)?></option>
    		      <?php 
    		  }
    		?>
    	</select>
        <select <?php echo $attr;?>  class="form-control <?php echo esc_attr($css)?>" style="<?php echo esc_attr($style)?>; width:33%;float:left;" name="<?php echo $input_name.'_city';?>"  id="<?php echo $input_id.'_city';?>">
       		
        </select>
        <select <?php echo $attr;?>  class="form-control <?php echo esc_attr($css)?>" style="<?php echo esc_attr($style)?>; width:33%;float:left;" name="<?php echo $input_name.'_dic';?>"  id="<?php echo $input_id.'_dic';?>">
        	
        </select>
    </div>
    <span class="xh-help-block"><?php echo $description?></span>
</div>
<script type="text/javascript">
		(function($){
			window.__wshop_form_address_<?php echo $context;?>={
				datas:<?php echo json_encode($provinces)?>
			};

			$('#<?php echo $input_id.'_province';?>').change(function(){
				var province = $('#<?php echo $input_id.'_province';?>').val();
				var city_options = '<option value="">市</option>';
				if(province.length!=0){
					var citys = window.__wshop_form_address_<?php echo $context;?>.datas[province];
					var default_city = '<?php echo $default&&is_array($default)&&isset($default['city'])?$default['city']:'';?>';
					$.each(citys,function(city,item){
						city_options+='<option value="'+city+'" '+(default_city==city?'selected':'')+'>'+city+'</option>';
					});
				}
				
				$('#<?php echo $input_id.'_city';?>').html(city_options);
				$('#<?php echo $input_id.'_city';?>').change();
			});

			$('#<?php echo $input_id.'_city';?>').change(function(){
				var province = $('#<?php echo $input_id.'_province';?>').val();
				var city = $('#<?php echo $input_id.'_city';?>').val();
				var dic_options = '<option value="">地区</option>';
				
				if(province.length!=0&&city.length!=0){
					var dics = window.__wshop_form_address_<?php echo $context;?>.datas[province][city];
					var default_dic = '<?php echo $default&&is_array($default)&&isset($default['dic'])?$default['dic']:'';?>';
					$.each(dics,function(key,dic){
						dic_options+='<option value="'+dic+'"  '+(default_dic==dic?'selected':'')+'>'+dic+'</option>';
					});
				}
				
				$('#<?php echo $input_id.'_dic';?>').html(dic_options);
			});

			$('#<?php echo $input_id.'_province';?>').change();
			$(document).bind('wshop_form_<?php echo $context;?>_submit',function(e,m){
				m.<?php echo $input_name?>_province=$('#<?php echo $input_id.'_province';?>').val();
				m.<?php echo $input_name?>_city=$('#<?php echo $input_id.'_city';?>').val();
				m.<?php echo $input_name?>_dic=$('#<?php echo $input_id.'_dic';?>').val();
			});
		})(jQuery);
</script>
<?php 