<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
$atts =WShop_Temp_Helper::clear('atts','templates');;
$form = $atts['form'];
$form_product = $atts['form_product'];
$context = $atts['context'];   

$qty_min = $form_product->get('qty_min');
if(!is_null($qty_min)&&$qty_min!==''){
    $qty_min = intval($qty_min);
}
?>
<div class="xh-form-group">
    <label>报名人数</label>
    <input  type="number" value="<?php echo $qty_min&&$qty_min>0?$qty_min:1;?>" class="form-control"  name="qty"  id="form-qty-<?php echo $context?>"/>
    <span class="xh-help-block"></span>
</div>
<script type="text/javascript">
	(function($){
		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,m){
			m.qty=$('#form-qty-<?php echo $context?>').val();
		});

		$(document).bind('wshop_<?php echo $context;?>_init_amount',function(e,m){
			var qty = parseInt($('#form-qty-<?php echo $context?>').val());
			if(isNaN(qty)||qty<=0){qty=1;}
			if(qty>999999){
				qty = 999999;
			}
			<?php 
			 if($qty_min){
			     ?>
			     var min_qty = <?php echo $qty_min;?>;
			     if(qty<min_qty){qty=min_qty;}
			     <?php 
			 }
			?>
			m.total_amount=m.total_amount*qty;
		});

		$('#form-qty-<?php echo $context?>').keyup(function(){
			$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
		}).change(function(){
			$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
		}).blur(function(){
			var qty = parseInt($('#form-qty-<?php echo $context?>').val());
			if(isNaN(qty)||qty<=0){qty=1;}
			if(qty>999999){
				qty = 999999;
			}

			<?php 
				 if($qty_min){
				     ?>
				     var min_qty = <?php echo $qty_min;?>;
				     if(qty<min_qty){qty=min_qty;}
				     <?php 
				 }
				?>
					
			$('#form-qty-<?php echo $context?>').val(qty);
		});
	})(jQuery);
</script>