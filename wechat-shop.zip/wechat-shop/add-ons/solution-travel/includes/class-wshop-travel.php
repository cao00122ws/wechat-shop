<?php 

if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly

class WShop_Travel extends WShop_Post_Object{
    public function __construct($obj=null){
        parent::__construct($obj);
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_travel';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_travel_properties', array(
            'post_ID'=>null,
            'child_free_amount'=>null
        ));
    }
}

class WShop_Travel_Item extends WShop_Post_Object{
    const POST_T='wshop_travel_item';
    public function __construct($obj=null){
        parent::__construct($obj);
    }
    
    /**
     * {@inheritDoc}
     * @see WShop_Object::get_table_name()
     */
    public function get_table_name()
    {
        // TODO Auto-generated method stub
        return 'wshop_travel_item';
    }

    /**
     * {@inheritDoc}
     * @see WShop_Object::get_propertys()
     */
    public function get_propertys()
    {
        return apply_filters('wshop_travel_item_properties', array(
            'post_ID'=>null,
            'date'=>null,
            'travel_post_ID'=>0
        ));
    }
}
class WShop_Travel_Model extends Abstract_WShop_Schema{
    /**
     * {@inheritDoc}
     * @see Abstract_XH_Model_Api::init()
     */
    public function init()
    {
        $collate=$this->get_collate();
        global $wpdb;
        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_travel` (
        	`post_ID` BIGINT(20) NOT NULL,
        	`child_free_amount` DECIMAL(18,2) NULL DEFAULT NULL,
        	PRIMARY KEY (`post_ID`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        $wpdb->query(
        "CREATE TABLE IF NOT EXISTS `{$wpdb->prefix}wshop_travel_item` (
        	`post_ID` BIGINT(20) NOT NULL,
        	`date` DATE NULL DEFAULT NULL,
        	`travel_post_ID` BIGINT(20) NULL DEFAULT NULL,
        	PRIMARY KEY (`post_ID`),
        	UNIQUE INDEX `ui_d_tpd` (`date`, `travel_post_ID`)
        )
        $collate;");

        if(!empty($wpdb->last_error)){
            WShop_Log::error($wpdb->last_error);
            throw new Exception($wpdb->last_error);
        }
        
        if($wpdb->get_var("show index from `{$wpdb->prefix}wshop_travel_item` where Column_name='date' and Key_name='ui_d_tpd'")!= "{$wpdb->prefix}wshop_travel_item"){
            $wpdb->query("ALTER TABLE `{$wpdb->prefix}wshop_travel_item` ADD UNIQUE INDEX `ui_d_tpd` (`date`, `travel_post_ID`);");
            if(!empty($wpdb->last_error)){
                WShop_Log::error($wpdb->last_error);
                throw new Exception($wpdb->last_error);
            }
        }
    }
}

class WShop_Travel_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Travel_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="travel";
        $this->title = __('Travel',WSHOP);
    }

    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
    public function init_form_fields(){
        global $post;
        $this->form_fields = apply_filters('wshop_travel_fields', array(
            'child_free_amount'=>array(
                'title'=>__('Child free amount',WSHOP),
                'type'=>'text',
                'default'=>0
            ),
            'travel_items'=>array(
                'title'=>__('Travel dates',WSHOP),
                'type'=>'custom',
                'func'=>function($key,$api,$data){
                    global $post;
                    $product = $post;
                    $addon = WShop_Modal_Solution_Travel::instance();
                    $field = $api->get_field_key ( $key );                   
                    ?>
                    <link href="<?php echo $addon->domain_url?>/assets/css/day.css" rel="stylesheet" type="text/css" />  
                    <style>
                        .form-table.pods-metabox.pods-admin td{width:90%}
                    </style>
                     <tr valign="top" class="<?php echo isset($data['tr_css'])?$data['tr_css']:''; ?>">
                        	
                        	<td colspan="2">
                            	<div id="calendar-container" style="min-width:800px;"></div>	 		
                        		<script type="text/javascript">
                            		(function($,undefined){
                            			window.wshop_calendar_view={
                                			_date:null,
                            				load:function(date){
                                				if(!date){
                                					date=this._date;
                                    			}else{
                                					this._date = date;
                                    			}
                                    			
                            					$('#calendar-container').loading('show');
                            					var data ={
                        							date:date
                            					};
                            					
                            					$.ajax({
                            						url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$addon->id}",'tab'=>'travel-list','travel_ID'=>$product->ID),true,true)?>',
                            						type:'post',
                            						timeout:60*1000,
                            						async:true,
                            						cache:false,
                            						data:data,
                            						dataType:'json',
                            						complete:function(){
                            							$('#calendar-container').loading('hide');
                            						},
                            						success:function(e){
                            							if(e.errcode!=0){
                            								alert(e.errmsg);
                            								return;
                            							}
                            							
                            							$('#calendar-container').html(e.data);;
                            							
														$('.wshop-month').change(function(){
															if($(this).attr('checked')){
																$('.wshop-calendar-week').attr('checked','checked');
															}else{
																$('.wshop-calendar-week:checked').removeAttr('checked');
															}

															$('.wshop-calendar-week').each(function(){
                            									if($(this).attr('checked')){
                            			    						$('.wshop-day-week-'+$(this).data('week')).addClass('selected');
                            									}else{
                            										$('.wshop-day-week-'+$(this).data('week')+'.selected').removeClass('selected');
                            									}
                            								});
                            								
															window.wshop_calendar_view.on_week_change();
														});

                            							$('.wshop-calendar-week').change(function(){
                            								if($('.wshop-calendar-week').not(':checked').length>0){
                            									$('.wshop-month:checked').removeAttr('checked');
                                							}else{
                                								$('.wshop-month').attr('checked','checked');
                                        					}

                            								if($(this).attr('checked')){
                        			    						$('.wshop-day-week-'+$(this).data('week')).addClass('selected');
                        									}else{
                        										$('.wshop-day-week-'+$(this).data('week')+'.selected').removeClass('selected');
                        									}
                        									
                            								window.wshop_calendar_view.on_week_change();
                            							});
                            							window.__ctrlKeying = false;
                            							$(window).keydown(function(e){
															if(e.ctrlKey){window.__ctrlKeying=true;}
                            							}).keyup(function(e){
                            								if(e.keyCode==17){
                            									window.__ctrlKeying=false;
                            								}
                                						});
                            							
                            							$('.wshop-calendar-day').click(function(){
															if(!window.__ctrlKeying){
																$('.wshop-calendar-day.selected').not(this).removeClass('selected');
															}
															
															if($(this).hasClass('selected')){
																$(this).removeClass('selected');
															}else{
																$(this).addClass('selected');
															}

															$('.wshop-calendar-week').each(function(){
																if($('.wshop-day-week-'+$(this).data('week')).not('.selected').length>0){
																	$(this).removeAttr('checked');
																}else{
																	$(this).attr('checked','checked');
																}
															});

															window.wshop_calendar_view.on_week_change();
                                						});
                            						},
                            						error:function(e){
                            							console.error(e.responseText);
                            							alert('<?php echo WShop_Error::err_code(701)->to_string(); ?>');
                            						}
                            					});
                            				}
                            			};
                            		
            							window.wshop_calendar_view.generate_inputs=function(price,inventory,sale_qty){
                							if(price===undefined){
                								price='';
                    						}

                							if(inventory===undefined){
                								inventory='';
                    						}

                							if(sale_qty===undefined){
                								sale_qty='';
                    						}
                    						
            								$('#wshop-contaiter-inputs').html(
            								'<table>\
            			        				<tr>\
            			        					<td>销售价格：</td><td><input id="wshop-calendar-price" class="wshop-calendar-input" type="text" value="'+price+'"/></td>\
            			        				</tr>\
            			        				<tr>\
            			        					<td>剩余库存：</td><td><input id="wshop-calendar-inventory" class="wshop-calendar-input" type="text" value="'+inventory+'"/></td>\
            			        				</tr>\
            			        				<tr>\
            			        					<td>已出售：</td><td><input id="wshop-calendar-sale_qty" class="wshop-calendar-input" type="text" value="'+sale_qty+'"/></td>\
            			        				</tr>\
                			        			<tr>\
													<td colspan="2"><button type="button" class="button" onclick="window.wshop_calendar_view.remove();">删除</button>\
		            			        			<button type="button" class="button button-primary" onclick="window.wshop_calendar_view.update();">更新</button></td>\
                			        			</tr>\
            			        			</table>');
            							};

            							window.wshop_calendar_view.remove=function(){
            								var $selected =$('.wshop-calendar-day.selected');
            								if($selected.length==0){return;}

            								var datas = [];
            								$selected.each(function(){
                								var id =$(this).data('id');
            									datas.push({
													id:id?id:null,
													date:$(this).data('date')
                								});
                							});
            								
            								$('#calendar-container').loading('show');
                        					
                        					var data ={
                        						dates:JSON.stringify(datas)
                        					};
                        					
                        					$.ajax({
                        						url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$addon->id}",'tab'=>'travel-remove','travel_ID'=>$product->ID),true,true)?>',
                        						type:'post',
                        						timeout:60*1000,
                        						async:true,
                        						cache:false,
                        						data:data,
                        						dataType:'json',
                        						complete:function(){
                        							$('#calendar-container').loading('hide');
                        						},
                        						success:function(e){
                        							if(e.errcode!=0){
                        								alert(e.errmsg);
                        								return;
                        							}

                        							window.wshop_calendar_view.load();
                            					},
                        						error:function(e){
                        							console.error(e.responseText);
                        							alert('<?php echo WShop_Error::err_code(701)->to_string(); ?>');
                        						}
                        					});
                						}

            							window.wshop_calendar_view.update=function(){
            								var $selected =$('.wshop-calendar-day.selected');
            								if($selected.length==0){return;}

            								var datas = [];
            								$selected.each(function(){
                								var id =$(this).data('id');
            									datas.push({
													id:id?id:null,
													date:$(this).data('date')
                								});
                							});
            								
            								$('#calendar-container').loading('show');
                        					
                        					var data ={
                                				inventory:$('#wshop-calendar-inventory').val(),
                                				price:$('#wshop-calendar-price').val(),
                                				sale_qty:$('#wshop-calendar-sale_qty').val(),
                        						dates:JSON.stringify(datas)
                        					};
                        					
                        					$.ajax({
                        						url:'<?php echo WShop::instance()->ajax_url(array('action'=>"wshop_{$addon->id}",'tab'=>'travel-update','travel_ID'=>$product->ID),true,true)?>',
                        						type:'post',
                        						timeout:60*1000,
                        						async:true,
                        						cache:false,
                        						data:data,
                        						dataType:'json',
                        						complete:function(){
                        							$('#calendar-container').loading('hide');
                        						},
                        						success:function(e){
                        							if(e.errcode!=0){
                        								alert(e.errmsg);
                        								return;
                        							}

                        							window.wshop_calendar_view.load();
                            					},
                        						error:function(e){
                        							console.error(e.responseText);
                        							alert('<?php echo WShop_Error::err_code(701)->to_string(); ?>');
                        						}
                        					});
                						}
            							
            							window.wshop_calendar_view.clear_inputs=function(){
            								$('#wshop-contaiter-inputs').empty();
            							};
            							
            							window.wshop_calendar_view.on_week_change=function(){
            								var $selected =$('.wshop-calendar-day.selected');
            								var selected_qty =$selected.length;
            								if(selected_qty==1){
                								
            									window.wshop_calendar_view.generate_inputs($selected.data('price'),$selected.data('inventory'),$selected.data('sale_qty'));
            								}else if(selected_qty>1){
            									window.wshop_calendar_view.generate_inputs('','','');
            								}else{
            									window.wshop_calendar_view.clear_inputs();
            								}
                						};
                						
                            			$(function(){
                            				window.wshop_calendar_view.load('<?php echo date_i18n('Y-m-01');?>');
                            			})
                            		})(jQuery);
                            	</script>
                            	<div class="description">提示：点击日期设置价格(按住Ctrl 可多选日期)</div>
                        	</td>
                        </tr>
                    
                    <?php
                }
            )
            
        ));
                
    }

    public function get_post_types()
    {
        return array(
            WShop_Modal_Solution_Travel::instance()->get_option('post_type')=>__('Travel',WSHOP)
        );
    }

    public function get_object($post){
        return new WShop_Travel($post);
    }
}
class WShop_Travel_Item_Fields extends Abstract_XH_WShop_Fields{

    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var Social
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * Ensures only one instance of Social is loaded or can be loaded.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Travel_Item_Fields - Main instance.
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * post 设置区域
     *
     * @param WShop_Payment_Api $payment
     * @since 1.0.0
     */
    protected function __construct(){
        parent::__construct();
        $this->id="travel_item";
        $this->title = __('Travel date',WSHOP);
    }

    public function admin_init(){
        parent::admin_init();
    
        foreach ($this->get_post_types() as $post_type=>$label){
            add_filter( "manage_{$post_type}_posts_columns", array($this,'manage_posts_columns'),11 ,1);
            add_action( "manage_{$post_type}_posts_custom_column", array( $this, 'manage_posts_custom_column' ),11, 2 );
        }
    }
  
    public function manage_posts_columns($existing_columns){
        if(!$existing_columns){$existing_columns=array();}
    
        $new_columns = array();
        foreach ($existing_columns as $key=>$v){
            $new_columns[$key]=$v;
            if($key=='title'){
                $new_columns['travel']=__('Travel',WSHOP);
            }
        }
    
        return $new_columns;
    }
    
    public function manage_posts_custom_column($column,$post_ID){
        global $current_travel_item;
        if(!$current_travel_item||$current_travel_item->post_ID!=$post_ID){
            $current_travel_item = new WShop_Travel_Item($post_ID);
        }
       
        if(!$current_travel_item->is_load()){
            return;
        }
    
        if($column=='travel'){
            $travel = $current_travel_item->get('travel_post_ID')?get_post($current_travel_item->get('travel_post_ID')):null;
            echo $travel?$travel->post_title:"";
        }
    }
        
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     * @since 1.0.0
     */
    public function init_form_fields(){
        global $post;
        $this->form_fields = apply_filters('wshop_travel_item_fields', array(
            'date'=>array(
                'title'=>__('Date',WSHOP),
                'required'=>true,
                'type'=>'datetime',
                'format_js'=>'yyyy-MM-dd',
                'format'=>'Y-m-d'
            ),
            'travel_post_ID'=>array(
                'title'=>__('Travel',WSHOP),
                'type'=>'select',
                'post_type'=>function(){
                    return WShop_Modal_Solution_Travel::instance()->get_option('post_type');
                }
            ),
        ),$post);
    }

    public function get_post_types()
    {
        return array(
            WShop_Travel_Item::POST_T=>__('Travel date',WSHOP)
        );
    }

    public function get_object($post){
        return new WShop_Travel_Item($post);
    }
}

?>