<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly
require_once 'includes/class-wshop-travel.php';
/**
 * @author rain
 *
 */
class WShop_Modal_Solution_Travel extends Abstract_WShop_Add_Ons{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Modal_Solution_Travel
     */
    private static $_instance = null;
    public $domain_dir;
    public $domain_url;
    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Modal_Solution_Travel
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='wshop_add_ons_solution_travel';
        $this->title=__('Solution - travel',WSHOP);
        $this->version='1.0.0';
        $this->min_core_version = '1.0.0';  
        $this->author=__('xunhuweb',WSHOP);
        $this->author_uri='https://www.wpweixin.net';
        $this->setting_uris = array(
            'settings'=>array(
                'title'=>__('Settings',WSHOP),
                'url'=>admin_url('admin.php?page=wshop_page_default&section=menu_default_modal&sub=wshop_add_ons_solution_travel')
            )
        );
        
        $this->init_form_fields();
        $this->domain_dir = WShop_Helper_Uri::wp_dir(__FILE__) ;
        $this->domain_url = WShop_Helper_Uri::wp_url(__FILE__) ;
    }

    /**
     * @since 1.0.0
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields(){
        $this->form_fields = array(
            'post_type'=>array(
                'title'=>__('Bind post type',WSHOP),
                'type'=>'select',
                'func'=>true,
                'options'=>array($this,'get_post_type_options')
            ),
            'page_checkout'=>array(
                'title'=>__('Checkout page',WSHOP),
                'description'=>null,
                'type'=>'select',
                'func'=>true,
                'default'=>null,
                'options'=>array($this,'get_page_options')
            ),
            'page_checkout_success'=>array(
                'title'=>__('Checkout success page',WSHOP),
                'description'=>null,
                'type'=>'select',
                'func'=>true,
                'default'=>null,
                'options'=>array($this,'get_page_options')
            ),
            'form_id' => array(
                'title'=>__('Checkout form',WSHOP),
                'type'=>'select',
                'func'=>true,
                'options'=>array($this,'get_form_options')
            )
        );
    }

    /**
     * @return string[]
     * @since 1.0.0
     */
    public function get_form_options(){
        $options = array(
            0=>__('Select...',WSHOP)
        );
        global $wpdb;
        $forms =$wpdb->get_results(
            "select *
            from {$wpdb->prefix}wshop_forms f
            inner join {$wpdb->prefix}posts p on p.ID =f.post_ID
            where p.post_status='publish';");
        if($forms){
            foreach ($forms as $form){
                $options[$form->post_ID]=$form->post_title;
            }
        }
    
        return $options;
    }
    public function on_install(){
        $api = new WShop_Travel_Model();
        $api->init();
        $this->init_page_checkout();
        $this->init_page_checkout_success();
    }
    
    public function on_load(){
        add_filter('wshop_wp_enqueue_scripts', array($this,'wshop_wp_enqueue_scripts'),10);
        add_filter('wshop_enable_inventory', array($this,'wshop_enable_inventory'),10,2);
        
        add_filter('wshop_create_order_travel_shopping', array($this,'wshop_create_order_travel_shopping'),10,3);
        add_filter('wshop_create_order_travel_shopping_func', array($this,'wshop_create_order_travel_shopping_func'),10,3);
        add_filter('wshop_page_templates', array($this,'wshop_page_templates'),10,1);
        add_filter('wshop_travel_shopping_order_item_creator', array($this,'wshop_travel_shopping_order_item_creator'),10,3);
        add_filter('wshop_order_travel_shopping_received_url', array($this,'wshop_order_travel_shopping_received_url'),10,2);
        
        //以下字段为 每个旅游项目，表单字段不一致
        add_filter('wshop_form_online_post_types', array($this,'wshop_form_online_post_types'),10,1);
        add_filter('wshop_enable_form_shortcodes_help', array($this,'wshop_enable_form_shortcodes_help'),10,2);
        
        add_filter('wshop_product_img', array($this,'wshop_product_img'),10,2);
        add_filter('wshop_product_link', array($this,'wshop_product_link'),10,2);
        add_action('wshop_order_view_admin_order_detail_general', array($this,'wshop_order_view_admin_order_detail_general'),10,1);
        
        add_action('wshop_order_email_sections', array($this,'wshop_order_email_sections'),10,1);
        add_filter('wshop_form_entry_columns', array($this,'wshop_form_entry_columns'),10,2);
        
        add_filter('wshop_form_entry_columns_html', array($this,'wshop_form_entry_columns_html'),10,3);
        
        add_filter('wshop_forms_entry_export_columns', array($this,'wshop_forms_entry_export_columns'),10,2);
        add_filter('wshop_forms_entry_export_first_line', array($this,'wshop_forms_entry_export_first_line'),10,4);
        add_filter('wshop_form_entry_export_column', array($this,'wshop_form_entry_export_column'),10,5);
    }
    
    
    
    public function wshop_form_entry_export_column($false,$column,$entry,$post,$form){
      if($column!='__start_date__'){return $false;}
        $order = new WShop_Order($entry->order_id);
        if(!$order->is_load()|| $order->obj_type!=WShop_Travel_Item::POST_T){
            return $false;
        }
        
        $items = $order->get_order_items();
        if($items){
            foreach ($items as $item){
                $travel_item = new WShop_Travel_Item($item->post_ID);
                if($travel_item->is_load()){
                    return $travel_item->date;
                }
            }
        }
        
        return $false;
    }
    public function wshop_forms_entry_export_first_line($first_line,$form){
        $first_line[] ='出发日期';
        return $first_line;
    }
    public function wshop_forms_entry_export_columns( $columns,$form){
        $columns[] ='__start_date__';
        return $columns;
    }
    
    public function wshop_form_entry_columns_html($false,$column, $current_wshop_entry){
        if($column!='__start_date__'){
            return $false;
        }
       
        $order = new WShop_Order($current_wshop_entry->order_id);
        if(!$order->is_load()|| $order->obj_type!=WShop_Travel_Item::POST_T){
            return $false;
        }
        
        $items = $order->get_order_items();
        if($items){
            foreach ($items as $item){
                $travel_item = new WShop_Travel_Item($item->post_ID);
                if($travel_item->is_load()){
                    return $travel_item->date;
                }
            }
        } 
        
        return $false;
    }
    
    public function wshop_form_entry_columns($new_existing_columns,$current_wshop_form){
        $new_existing_columns['__start_date__']='出发日期';
        return $new_existing_columns;
    }
    
    public  function wshop_order_email_sections($order){
        if($order->obj_type!=WShop_Travel_Item::POST_T){
            return;
        }
            
        ?>
        <h2 style='color: #96588a; display: block; font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif; font-size: 18px; font-weight: bold; line-height: 130%; margin: 16px 0 8px; text-align: left;'>其他信息</h2>
        <ul>
        <?php 
        $items = $order->get_order_items();
        if($items){
            foreach ($items as $item){
                $travel_item = new WShop_Travel_Item($item->post_ID);
                if($travel_item->is_load()){
                    ?><li><strong>出发日期：</strong> <span class="text" style='color: #3c3c3c; font-family: "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;'><?php echo $travel_item->date;?></span></li> <?php 
                }
            }
        } 
        ?>
        </ul>
        <?php 
    }
    
    /**
     * 
     * @param WShop_Order $order
     */
    public function wshop_order_view_admin_order_detail_general($order){
        if($order->obj_type!=WShop_Travel_Item::POST_T){
            return;
        }
        
        $items = $order->get_order_items();
        if($items){
            foreach ($items as $item){
                $travel_item = new WShop_Travel_Item($item->post_ID);
                if($travel_item->is_load()){
                    ?>
                    <p class="form-field form-field-wide wshop-order-status">
            			<label for="order_status">出发日期：<?php echo $travel_item->date;?> </label>
            		</p>
                    <?php 
                }
                
            }
        }
              
    }
    
    /**
     *
     * @param string $url
     * @param WShop_Product $product
     */
    public function wshop_product_link( $url,$product){
        if($product->get('post_type')!=WShop_Travel_Item::POST_T){return $url;}
        
        $travel_item = new WShop_Travel_Item($product->post_ID);
        if(!$travel_item->is_load()){
            return $url;
        }
        
        return get_permalink($travel_item->travel_post_ID);
    }
    /**
     * 
     * @param string $url
     * @param WShop_Product $product
     */
    public function wshop_product_img($url,$product){
        if($product->get('post_type')!=WShop_Travel_Item::POST_T){return $url;}
        
        $travel_item = new WShop_Travel_Item($product->post_ID);
        if(!$travel_item->is_load()){
            return $url;
        }
        
        $thumbnail_id = get_post_thumbnail_id($travel_item->travel_post_ID);
        if(!$thumbnail_id){
            $thumbnail_id= get_post_thumbnail_id(WShop_Settings_Default_Basic_Default::instance()->get_option('product_img_default',0));
        }
        
        $thumb = $thumbnail_id?wp_get_attachment_image_src($thumbnail_id, 'thumbnail'):null;
        return $thumb&&count($thumb)>0?$thumb[0]:WSHOP_URL.'/assets/image/default.png';
    }
    
    public function wshop_enable_form_shortcodes_help($true,$post){
        $_type =$this->get_option('post_type');
        if($post&&$post->post_type==$_type){
            return false;
        }
        
        return $true;
    }
    public function wshop_form_online_post_types($types){
        $new_types = array();
        $_type =$this->get_option('post_type');
        foreach ($types as $type){
            if($type==$_type){continue;}
            $new_types[]=$type;
        }
      
        return $new_types;
    }
    
    public function wshop_order_travel_shopping_received_url($url,$order){
        return $this->get_page_checkout_success_uri(WShop::instance()->generate_request_params(array(
            'oid'=>$order->id
        )));
    }
    
    public function wshop_page_templates($ms){
        $ms[$this->domain_dir]['travel/purchase.php']=__('WShop - travel',WSHOP);
        return $ms;
    }
    
    public function on_init(){
        add_filter('wshop_admin_menu_menu_default_modal',array($this,'wshop_admin_menu_menu_default_modal'),10,1);
        add_filter('wshop_obj_search_'.WShop_Travel_Item::POST_T, array($this,'travel_item_search'),10,3);
        if(is_admin()){
            add_action('restrict_manage_posts', array($this,'restrict_manage_posts'),10,2);
            add_action( 'pre_get_posts', array( $this, 'pre_get_posts' ) ,10,1);
        }
    }
    
    public function get_page_checkout_uri($params = array()){
        $page_id =  $this->get_option('page_checkout',0);
        return WShop_Helper_Uri::get_new_uri(get_page_link($page_id),$params);
    }
    
    public function get_page_checkout_success_uri($params = array()){
        $page_id =  $this->get_option('page_checkout_success',0);
        return WShop_Helper_Uri::get_new_uri(get_page_link($page_id),$params);
    }
    
    private function init_page_checkout(){
        $page_id =intval($this->get_option('page_checkout',0));
        $page=null;
        if($page_id>0){
            return true;
        }
    
        $page_id =wp_insert_post(array(
            'post_type'=>'page',
            'post_name'=>'travel-checkout',
            'post_title'=>__('WShop - travel checkout',WSHOP),
            'post_content'=>'[wshop_travel_checkout]',
            'post_status'=>'publish',
            'meta_input'=>array(
                '_wp_page_template'=>'travel/purchase.php'
            )
        ),true);
    
        if(is_wp_error($page_id)){
            WShop_Log::error($page_id);
            throw new Exception($page_id->get_error_message());
        }
    
        $this->update_option('page_checkout', $page_id,true);
        return true;
    }
    
    private function init_page_checkout_success(){
        $page_id =intval($this->get_option('page_checkout_success',0));
        $page=null;
        if($page_id>0){
            return true;
        }
    
        $page_id =wp_insert_post(array(
            'post_type'=>'page',
            'post_name'=>'travel-checkout-success',
            'post_title'=>__('WShop - travel checkout success',WSHOP),
            'post_content'=>'[wshop_travel_checkout_success]',
            'post_status'=>'publish',
            'meta_input'=>array(
                '_wp_page_template'=>'travel/purchase.php'
            )
        ),true);
    
        if(is_wp_error($page_id)){
            WShop_Log::error($page_id);
            throw new Exception($page_id->get_error_message());
        }
    
        $this->update_option('page_checkout_success', $page_id,true);
        return true;
    }
    
    
    public function add_shortcodes($shortcodes){
        $shortcodes['wshop_travel_content']=function($atts=array(),$content =null){
            return wshop_travel_content($atts,$content,false);
        };
        
        $shortcodes['wshop_travel_checkout']=function($atts = array(),$content =null){
             return WShop::instance()->WP->requires(WShop_Modal_Solution_Travel::instance()->domain_dir, 'travel/purchase-content.php');
        };
        
        $shortcodes['wshop_travel_checkout_success']=function($atts = array(),$content =null){
            return WShop::instance()->WP->requires(WShop_Modal_Solution_Travel::instance()->domain_dir, 'travel/purchase-success.php');
        };
        return $shortcodes;
    }
  
    public function wshop_travel_shopping_order_item_creator($func,$order,$shopping_cart_item){
        return function($order,$shopping_cart_item){
            $product =$shopping_cart_item['product'];
            $travel_item = new WShop_Travel_Item($product->post_ID);
            if(!$travel_item->is_load()){
                return WShop_Error::error_custom(__('Travel date is not found!',WSHOP));
            }
            
            $travel = new WShop_Travel($travel_item->travel_post_ID);
            if(!$travel->is_load()){
                return WShop_Error::error_custom(__('Travel is not found!',WSHOP));
            }
           // $product instanceof  WShop_Product;
            $metas = $shopping_cart_item['metas'];
            
            $adult_qty = isset($metas['adult_qty'])?absint($metas['adult_qty']):0;
            $child_qty = isset($metas['child_qty'])?absint($metas['child_qty']):0;
            if($adult_qty<=0&&$child_qty<=0){
                return WShop_Error::error_custom(__('Invalid quantity of persion!',WSHOP));
            }
            
            $price = $product->get_single_price(false);
            $inventory =$product->get_inventory();
            
            $subtotal_adult = $adult_qty*$price;
            $subtotal_child= ($price-round(floatval($travel->get('child_free_amount')),2))*$child_qty;
            if($subtotal_child<0){$subtotal_child=0;}
            
            
            if(!is_null($inventory)&&$inventory<($adult_qty+$child_qty)){
                return WShop_Error::error_custom(__('Product is understock!',WSHOP));
            }
            
            $order_item =new WShop_Order_Item();
            $order_item->price = $subtotal_adult+$subtotal_child;
            $order_item->qty =$shopping_cart_item['qty'];
            
            $order_item->inventory =$adult_qty+$child_qty;
            
            $order_item->post_ID = $product->post_ID;
            $order_item->metas =array(
                'title'=>$product->get_title()." - 成人x{$adult_qty},小孩x{$child_qty}",
                'img'=>$product->get_img(),
                'link'=>$product->get_link(),
                'post_type'=>$product->post->post_type
            );
            
            
            return $order_item;
        };
    }
    
    /**
     * 
     * @param unknown $func
     * @param WShop_Shopping_Cart $cart
     * @param array $request
     * @return function[]
     */
    public function wshop_create_order_travel_shopping($func,$cart,$request){
        return array(function($cart,$request){
            $cart->__empty_cart();
            
            $adult_qty = isset($request['adult_qty'])?absint($request['adult_qty']):0;
            $child_qty = isset($request['child_qty'])?absint($request['child_qty']):0;
            
            if($adult_qty<=0&&$child_qty<=0){
                return WShop_Error::error_custom(__('Invalid quantity of persion!',WSHOP));
            }
            
            $post_ID =isset($request['post_id'])?$request['post_id']:null;
            $travel_item = new WShop_Travel_Item($post_ID);
            if(!$travel_item->is_load()){
                return WShop_Error::error_custom(__('Travel date is not found!',WSHOP));
            }
            
            $product = new WShop_Product($post_ID);
            if(!$product->is_load()){
                return WShop_Error::error_custom(__('Product is invalid!',WSHOP));
            }
            
            $inventory = $product->get_inventory();
            if(!is_null($inventory)&&$inventory<($adult_qty+$child_qty)){
                return WShop_Error::error_custom(__('Product is understock!',WSHOP));
            }
            
            if(isset($request['payment_method'])&&!empty($request['payment_method'])){
                $cart->__set_payment_method($request['payment_method']);
                
                $form_product = new WShop_Forms_Product($travel_item->travel_post_ID);
                $form_id = $form_product->is_load()?$form_product->form_id:null;
                if($form_id){
                    $form =  WShop_Add_On_Modal_Forms_Payment::form_validate($cart,$form_id);
                    
                    if($form instanceof WShop_Error){
                        return $form;
                    }
                }
            }
            
            try {
                $cart->__add_to_cart($post_ID,1,null,array(
                    'adult_qty'=>$adult_qty,
                    'child_qty'=>$child_qty
                ));
            } catch (Exception $e) {
                $code =$e->getCode();
                return new WShop_Error($code==0?-1:$code,$e->getMessage());
            }
            
            $cart->__set_metas( array(
                'location'=>isset($request['location'])?$request['location']:null
            ));
            
            return $cart;
        });
    }
    
    public function wshop_create_order_travel_shopping_func($func,$cart,$request){
        return function($cart,$request){
            $payment_method = $cart->get_payment_method();
            if($payment_method){
                $order = $cart->create_order($request['section'],null,null,WShop_Order::Pending);
                if($order instanceof WShop_Error){
                    return $order;
                }
                 
                return WShop_Error::success(array(
                    'redirect_url'=>$order->get_pay_url()
                ));
            }else{
                
                return WShop_Error::success(array(
                    'redirect_url'=>WShop_Modal_Solution_Travel::instance()->get_page_checkout_uri()
                ));
            }
        };
    }
   
    public function wshop_wp_enqueue_scripts(){
       // wp_enqueue_style('travel-style',$this->domain_url."/assets/style.css",array(),$this->version);
    }
    
    /**
     * @param WP_Query $q
     */
    public function pre_get_posts($q ){
        remove_filter('pre_get_posts', array( $this, 'pre_get_posts' ) ,10);
        
        if ( ! $q->is_main_query() ) {
            return;
        }
        
        if(!is_admin()){
            return;
        }
        
        global $pagenow;
        if($pagenow!='edit.php'){
            return;
        }

        $post_type = $q->get('post_type');
        if($post_type!=WShop_Travel_Item::POST_T ){
            return;
        }
        
        $form_id = isset($_REQUEST['post_parent'])?intval($_REQUEST['post_parent']):0;
        global $current_wshop_travel,$wpdb;
        $post_type = $this->get_option('post_type');
        $current_wshop_travel = $wpdb->get_row(
            "select p.*
            from {$wpdb->prefix}posts p
            where p.post_status='publish'
                  and p.post_type='$post_type'
                  and ($form_id=0 or p.ID =$form_id)
            limit 1;");
        
        
        if($current_wshop_travel){
            $q->set( 'post_parent', $current_wshop_travel->ID);
        }
    }
    
    public function restrict_manage_posts($post_type,$which=0){
        if($which!='top'){
            return;
        }
    
        if($post_type!=WShop_Travel_Item::POST_T){
            return;
        }
        $post_type = $this->get_option('post_type');
        ?>
      <style type="text/css">.select2-container {width: 200px !important;}</style>
        <select name="post_parent" class="wshop-search" data-type='<?php echo $post_type ?>' data-sortable="true" data-placeholder="<?php echo __( 'Search for a travel&hellip;', WSHOP); ?>" data-allow_clear="true">
			<?php 
			 global $wpdb,$current_wshop_travel;
			 if($current_wshop_travel){
			     ?><option value="<?php echo $current_wshop_travel->ID?>" ><?php echo $current_wshop_travel->post_title;?></option><?php 
			 }
			?>
		</select>
        <?php 
    }
    public function wshop_admin_menu_menu_default_modal($menus){
        $menus[]=$this;
        return $menus;
    }
    
    public function travel_item_search($null,$type,$keywords){
        global $wpdb;
        $travel_ID = isset($_REQUEST['travel_ID'])?intval($_REQUEST['travel_ID']):0;
        $posts = $wpdb->get_results($wpdb->prepare(
            "select u.ID,
                    u.post_title,
                    p.sale_price,
                    p.inventory,
                    p.sale_qty,
                    p.sale_price
            from {$wpdb->prefix}posts u
            inner join {$wpdb->prefix}wshop_travel_item ti on ti.post_ID =u.ID
            inner join {$wpdb->prefix}wshop_product p on p.post_ID = u.ID
            where (%s='' or u.post_title like %s)
                    and u.post_type=%s
                    and u.post_status='publish'
                    and (ti.travel_post_ID is null or ti.travel_post_ID=0 or ti.travel_post_ID=$travel_ID)
            limit 10;",$keywords,"$keywords%", $type));
    
        $results = array();
        if($posts){
            foreach ($posts as $post){
                $post_title = mb_strimwidth($post->post_title,0,18,'...','utf-8');
                $results[]=array(
                    'id'=>$post->ID,
                    'text'=>"{$post_title} 售价：{$post->sale_price} 库存：{$post->inventory} 已售：{$post->sale_qty}"
                );
            }
        }
        
        return $results;
    }
    
    public function wshop_enable_inventory($false,$post){
        if($post&&$post->post_type==WShop_Travel_Item::POST_T){
            return true;
        }
        
        return $false;
    }
    
    public function register_fields(){
        WShop_Travel_Item_Fields::instance();
        WShop_Travel_Fields::instance();
    }
    
    public function register_post_types(){
        register_post_type( WShop_Travel_Item::POST_T,
            array(
                'labels' => array(
                    'name' => __('Travel date',WSHOP),
                    'singular_name' =>__('Travel date',WSHOP),
                    'add_new' => __('Add New',WSHOP),
                    'add_new_item' =>__('Add New Travel date',WSHOP),
                    'edit' =>  __('Edit',WSHOP),
                    'edit_item' => __('Edit Travel date',WSHOP),
                    'new_item' => __('New Travel date',WSHOP),
                    'view' => __('View',WSHOP),
                    'view_item' => __('View Travel date',WSHOP),
                    'search_items' => __('Search Travel date',WSHOP),
                    'not_found' => __('No Travel date found',WSHOP),
                    'not_found_in_trash' => __('No Travel date found in trash',WSHOP),
                    'parent' => __('Parent Travel date',WSHOP)
                ),
                //决定自定义文章类型在管理后台和前端的可见性
                'public' => false,
                'wshop_ignore'=>true,
                'wshop_include'=>true,
                'menu_position' => 15,
                'exclude_from_search '=>false,
                'publicly_queryable'=>false,
                'hierarchical'=>false,
                'supports' => array( 'title',/* 'editor', 'comments', 'thumbnail', 'excerpt','page-attributes'*/ ),
                //创建自定义分类。在这里没有定义
                //'taxonomies' => array( ),
                //启用自定义文章类型的存档功能
                'has_archive' => true
            ));
    }

    /**
     * 
     * @param WShop_Travel $travel
     * @param string $date
     */
    public function wshop_generate_travel_item($travel,$date,$price,$inventory,$sale_qty){
        $post_ID = wp_insert_post(array(
            'post_parent'=>$travel->post_ID,
            'post_title'=>"{$travel->post_title} ".$date,
            'post_status'=>'trash',
            'post_type'=>WShop_Travel_Item::POST_T
        ),true);
         
        if(is_wp_error($post_ID)){
            return WShop_Error::wp_error($post_ID);
        }
        
        $travel_item = new WShop_Travel_Item();
        $travel_item->post_ID = $post_ID;
        $travel_item->date =$date;
        $travel_item->travel_post_ID = $travel->post_ID;
        
        $error = $travel_item->insert();
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        $product = new WShop_Product();
        $product->post_ID = $post_ID;
        $product->sale_price = $price;
        $product->inventory = $inventory;
        $product->sale_qty = $sale_qty;
        
        $error = $product->insert();
        if(!WShop_Error::is_valid($error)){
            return $error;
        }
        
        $post_ID = wp_update_post(array(
            'ID'=>$post_ID,
            'post_status'=>'publish'
        ),true);
        if(is_wp_error($post_ID)){
            return WShop_Error::wp_error($post_ID);
        }
        
        return $post_ID;
    }
    
    public function do_ajax(){
        $tab = isset($_REQUEST['tab'])?$_REQUEST['tab']:null;
        $action = "wshop_{$this->id}";
        switch ($tab){
            case 'travel-update':
                $request=shortcode_atts(array(
                    'notice_str'=>null,
                    'action'=>$action,
                    $action=>null,
                    'tab'=>null,
                    'travel_ID'=>null,
                    'hash'=>null
                ), stripslashes_deep($_REQUEST));
            
                if(!WShop::instance()->WP->ajax_validate($request,$request['hash'],true)){
                    echo WShop_Error::err_code(701)->to_json();
                    exit;
                }
            
                $travel = new WShop_Travel($request['travel_ID']);
                if(!$travel->is_load()){
                    echo WShop_Error::err_code(404)->to_json();
                    exit;
                }
            
                $dates = isset($_REQUEST['dates'])?json_decode(stripslashes($_REQUEST['dates']),true):array();
                if(!$dates||count($dates)==0){
                    echo WShop_Error::success()->to_json();
                    exit;
                }
            
                $inventory = isset($_REQUEST['inventory'])?intval($_REQUEST['inventory']):0;
                $price = isset($_REQUEST['price'])?round(floatval($_REQUEST['price']),2):0;
                $sale_qty = isset($_REQUEST['sale_qty'])?intval($_REQUEST['sale_qty']):0;
               
                global $wpdb;
                foreach ($dates as $date){
                    $date =date('Y-m-d',strtotime($date['date']));
                    $travel_item = $wpdb->get_row(
                       "select *
                        from {$wpdb->prefix}wshop_travel_item ti
                        where ti.travel_post_ID={$travel->post_ID}
                              and ti.date='$date'
                        limit 1;");
                    
                    if(!$travel_item){
                        $post_ID = $this->wshop_generate_travel_item($travel,$date,$price,$inventory,$sale_qty);
                        if($post_ID instanceof WShop_Error){
                            echo $post_ID->to_json();exit;
                        }
                        
                        continue;
                    }
                    
                    $post = get_post($travel_item->post_ID);
                    if(!$post){
                        $wpdb->delete("{$wpdb->prefix}wshop_travel_item", array(
                            'post_ID'=>$travel_item->post_ID
                        ));
                        
                        if(!empty($wpdb->last_error)){
                            WShop_Error::error_custom($wpdb->last_error);
                            echo WShop_Error::error_custom($wpdb->last_error)->to_json();
                            exit;
                        }
                        
                        $post_ID = $this->wshop_generate_travel_item($travel,$date,$price,$inventory,$sale_qty);
                        if($post_ID instanceof WShop_Error){
                            echo $post_ID->to_json();exit;
                        }
                        
                        continue;
                    }
                    
                    $product = new WShop_Product($travel_item->post_ID);
                    $error=null;
                    if($product->is_load()){
                        $error = $product->update(array(
                            'inventory'=>$inventory,
                            'sale_price'=>$price,
                            'sale_qty'=>$sale_qty
                        ));
                    }else{
                        $product->post_ID = $travel_item->post_ID;
                        $product->inventory = $inventory;
                        $product->sale_price = $price;
                        $product->sale_qty = $sale_qty;
                        $error = $product->insert();
                    }
                    
                    if(!WShop_Error::is_valid($error)){
                        echo $error->to_json();
                        exit;
                    }
                   
                    if($post->post_status!='publish'){
                        $post_ID =wp_update_post(array(
                            'ID'=>$post->ID,
                            'status'=>'publish'
                        ),true);
                        
                        if(is_wp_error($post_ID)){
                            echo WShop_Error::wp_error($post_ID);
                            exit;
                        }
                    }
                }
            
                echo WShop_Error::success()->to_json();
                exit;
            case 'travel-remove':
                $request=shortcode_atts(array(
                    'notice_str'=>null,
                    'action'=>$action,
                    $action=>null,
                    'tab'=>null,
                    'travel_ID'=>null,
                    'hash'=>null
                ), stripslashes_deep($_REQUEST));
                
                if(!WShop::instance()->WP->ajax_validate($request,$request['hash'],true)){
                    echo WShop_Error::err_code(701)->to_json();
                    exit;
                }
                
                $travel = new WShop_Travel($request['travel_ID']);
                if(!$travel->is_load()){
                    echo WShop_Error::err_code(404)->to_json();
                    exit;
                }
                
                $dates = isset($_REQUEST['dates'])?json_decode(stripslashes($_REQUEST['dates']),true):array();
                if(!$dates||count($dates)==0){
                    echo WShop_Error::success()->to_json();
                    exit;
                }
              
                global $wpdb;
                foreach ($dates as $date){
                    $date =date('Y-m-d',strtotime($date['date']));
                    $travel_item = $wpdb->get_row(
                       "select * 
                        from {$wpdb->prefix}wshop_travel_item ti
                        where ti.travel_post_ID={$travel->post_ID}
                              and ti.date='$date'
                        limit 1;");
                    
                    if(!$travel_item){continue;}
                    
                    $post = get_post($travel_item->post_ID);
                    if($post){
                        $post_ID = wp_update_post(array(
                            'ID'=>$post->ID,
                            'status'=>'trash'
                        ),true);
                        if(is_wp_error($post_ID)){
                            echo WShop_Error::wp_error($post_ID)->to_json();
                            exit;
                        }
                    }
                    
                    $product = new WShop_Product($travel_item->post_ID);
                    if($product->is_load()){
                        $error = $product->remove();
                        if(!WShop_Error::is_valid($error)){
                            echo $error->to_json();
                            exit;
                        }
                    }
                    
                    $wpdb->delete("{$wpdb->prefix}wshop_travel_item", array(
                        'post_ID'=>$travel_item->post_ID
                    ));
                    
                    if(!empty($wpdb->last_error)){
                        WShop_Error::error_custom($wpdb->last_error);
                        echo WShop_Error::error_custom($wpdb->last_error)->to_json();
                        exit;
                    }
                }
                
                echo WShop_Error::success()->to_json();
                exit;
                
            case 'travel-list':
                $request=shortcode_atts(array(
                    'notice_str'=>null,
                    'action'=>$action,
                    $action=>null,
                    'tab'=>null,
                    'travel_ID'=>null,
                    'hash'=>null
                ), stripslashes_deep($_REQUEST));
                
                if(!WShop::instance()->WP->ajax_validate($request,$request['hash'],true)){
                    echo WShop_Error::err_code(701)->to_json();
                    exit;
                }
                
                $travel = new WShop_Travel($request['travel_ID']);
                if(!$travel->is_load()){
                    $travel->post_ID =$request['travel_ID'];
                    $error = $travel->insert();
                    if(!WShop_Error::is_valid($error)){
                        echo $error->to_json();exit;
                    }
                }
               
                echo WShop_Error::success($this->wshop_travel_generate_calendar_html(
                    isset($_REQUEST['date'])?strtotime($_REQUEST['date']):current_time( 'timestamp' ),
                    $travel->post_ID))->to_json();
                exit;
           
        }
    }
    
    /**
     * 
     * @param 日期时间 $date_of_time
     * @param unknown $travel_items
     * @param number $_index
     * @return string
     */
    function wshop_travel_generate_calendar_html($date_of_time,$travel_id){
        global $wpdb;
        
        $time = $date_of_time;
        $year = date('Y',$time);
        $month = date('m',$time);
        $start = "{$year}-{$month}-01";
        $end = date('Y-m-01',strtotime('+1 month', $time));
        
        $travel_items = $wpdb->get_results(
           "select *
            from {$wpdb->prefix}posts p
            inner join {$wpdb->prefix}wshop_travel_item ti on ti.post_ID = p.ID
            inner join {$wpdb->prefix}wshop_product pt on pt.post_ID = p.ID
            where ti.travel_post_ID ={$travel_id}
                  and p.post_status='publish'
                  and p.post_type='".WShop_Travel_Item::POST_T."'
                  and ti.date>='{$year}-{$month}-01'
                  and ti.date<'$end';");
        
        //这个月起始位置
        $start_of_month = date('w',strtotime($start));
        //一个月的天数
        $days_of_month = date('t',$time);
        
        $month_of_last= date('m',strtotime('-1 month', $time));
        $month_of_next= date('m',strtotime('+1 month', $time));
        
        ob_start();
        ?> 
        <table>
        <tr>
        	<td>
                <div class="schedule_wrap">
                <div class="schedule_title" style="text-align:center;line-height: 35px;">
                	<a href="javascript:void(0);" onclick="window.wshop_calendar_view.load('<?php echo date('Y-m-d',strtotime('-1 month', $time))?>');" style="float:left;margin-left:15px;">&lt; <?php echo $month_of_last?>月</a>
                	<span><label><input type="checkbox" class="wshop-month"/> <?php echo date('Y年m月',$time)?></label></span>
                    <a href="javascript:void(0);" onclick="window.wshop_calendar_view.load('<?php echo date('Y-m-d',strtotime('+1 month', $time))?>');" style="float:right;margin-right:15px;"><?php echo $month_of_next?>月 &gt;</a>
                </div>
                <div class="schedule_week">
                 	<ul style="margin:0;padding:0">
                        <li><label><input type="checkbox" class="wshop-calendar-week" data-week="0"/> 日</label></li>
                        <li><label><input type="checkbox" class="wshop-calendar-week" data-week="1"/> 一</label></li>
                        <li><label><input type="checkbox" class="wshop-calendar-week" data-week="2"/> 二</label></li>
                        <li><label><input type="checkbox" class="wshop-calendar-week" data-week="3"/> 三</label></li>
                        <li><label><input type="checkbox" class="wshop-calendar-week" data-week="4"/> 四</label></li>
                        <li><label><input type="checkbox" class="wshop-calendar-week" data-week="5"/> 五</label></li>
                        <li><label><input type="checkbox" class="wshop-calendar-week" data-week="6"/> 六</label></li>
                    </ul>
                </div>
                <ul>
                	 <li> 
                        <div class="schedule_day show" id="wshop-date-<?php echo $date_of_time?>"><ul><?php
                        $_now = date_i18n('Y-m-d');
                        for ($index=1;$index<=6;$index++){
                            for($week=0;$week<=6;$week++){
                                $position = 7*($index-1)+$week;
                                if($position>=$start_of_month&&$position<=($days_of_month+$start_of_month-1)){
                                    $day_now =($position-$start_of_month)+1;
                                    $date_now ="{$year}-{$month}-".($day_now<10?"0{$day_now}":$day_now);
                                    $travel_item =WShop_Helper_Array::first_or_default($travel_items,function($m,$date){
                                        return $m->date==$date;
                                    },$date_now);
                                   
                                    $week_of_day = date('w',strtotime($date_now));
                                    
                                    if($travel_item){
                                        $product = new WShop_Product($travel_item);
                                       ?>
                                        <li style="cursor:pointer;" class="wshop-calendar-day wshop-day-week-<?php echo $week_of_day?> <?php echo $date_now==$_now?'today':'';?>" data-date="<?php echo $date_now;?>" data-id="<?php echo $product->post_ID?>" data-sale_qty="<?php echo $product->get('sale_qty')?>" data-inventory="<?php echo $product->get_inventory()?>" data-price="<?php echo $product->get_single_price(false)?>" data-priceshow="<?php echo esc_attr($product->get_single_price(true))?>">
                                            <span class="date"><?php echo $day_now;?></span>
                                            <span class="stock">售出<?php echo $product->get('sale_qty');?> 余<?php echo $product->get_inventory();?></span>
                                     		<span class="price"><?php echo $product->get_single_price(true)?></span>
                                        </li>
                                       <?php  
                                    }else{
                                        ?>
                                        <li class="wshop-calendar-day wshop-day-week-<?php echo $week_of_day?> <?php echo $date_now==$_now?'today':'';?>"  data-date="<?php echo $date_now;?>" >
                                            <span class="date"><?php echo $day_now;?></span>
                                        </li>
                                       <?php  
                                    }
                                }else{
                                    ?>
                                    <li>
                                        <span class="date"></span>
                                    </li>
                                    <?php 
                                }
                            }
                        } 
                        
                		?></ul></div>
                 
                   		 </li>
                    </ul>
                    </div>
                   </td>
            		<td id="wshop-contaiter-inputs" style="background: #f8f8f8;vertical-align:top">
            			
            		</td>
        	</tr>
        </table>
        	<?php 
		return ob_get_clean();
    }
}

if(!function_exists('wshop_travel_content')){
    function wshop_travel_content($atts=array(),$content =null,$echo = true){
        if(!is_array($atts)){
            $atts = array();
        }
        
        if(!isset($atts['post_id'])||empty($atts['post_id'])){
            if(method_exists(WShop::instance()->WP, 'get_default_post')){
                $default_post = WShop::instance()->WP->get_default_post();
                $atts['post_id']=$default_post?$default_post->ID:0;
            }else{
                global $wp_query,$post;
                $default_post=$wp_query?$wp_query->post:null;
                if(!$default_post&&$post){
                    $default_post = $post;
                }
                $atts['post_id']=$default_post?$default_post->ID:0;
            }
        }
        
        if(!isset($atts['location'])||empty($atts['location'])){
            $atts['location'] =  WShop_Helper_Uri::get_location_uri();
        }
        
        if($echo){
            echo WShop::instance()->WP->requires(WShop_Modal_Solution_Travel::instance()->domain_dir, 'travel/product-content.php',array(
                'content'=>$content,
                'atts'=>$atts
            ));
        }else{
            return WShop::instance()->WP->requires(WShop_Modal_Solution_Travel::instance()->domain_dir, 'travel/product-content.php',array(
                'content'=>$content,
                'atts'=>$atts
            ));
        }
        
    }
}

return WShop_Modal_Solution_Travel::instance();
?>