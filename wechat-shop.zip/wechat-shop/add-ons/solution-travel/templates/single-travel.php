<?php get_header(); ?>
<div class="blank_x15"></div>
<?php if(have_posts()) :while(have_posts()) : the_post(); ?>
<div class="single_wrap">
    <div class="single_title">
    <ul class="left">
        <li class="title"><?php the_title(); ?></li>
        <li class="info"><i class="icon-calendar icon-1x"></i> 本活动最新一期将于：<?php echo pods_field_display( 'travel',$post->ID,'lately'); ?>&nbsp;&nbsp;&nbsp;&nbsp;<i class="icon-map-marker icon-1x"></i> <?php echo pods_field_display( 'travel',$post->ID,'city'); ?></li>
    </ul>
    <ul class="right"><div id="article_share"><div class="bdsharebuttonbox"><!--<a href="#" class="bds_more" data-cmd="more"></a>--><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_sqq" data-cmd="sqq" title="分享到QQ好友"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_copy" data-cmd="copy" title="分享到复制网址"></a></div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"32"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script></div></div></ul>
    </div>
</div>
<div class="blank_x15"></div>

<div class="single_wrap">
    <div class="single_foucs">
        <div class="left">
<!-- 代码 开始 -->
            <div id="playBox">
            <div class="pre"></div>
            <div class="next"></div>
            <div class="smalltitle">
                <ul>
                    <li class="thistitle"></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
                <ul class="oUlplay">
                    <li><img src="<?php echo pods_field_display( 'travel',$post->ID,'focus1'); ?>" /></a></li>
                    <li><img src="<?php echo pods_field_display( 'travel',$post->ID,'focus2'); ?>" /></a></li>
                    <li><img src="<?php echo pods_field_display( 'travel',$post->ID,'focus3'); ?>" /></a></li>
                    <li><img src="<?php echo pods_field_display( 'travel',$post->ID,'focus4'); ?>" /></a></li>
                    <li><img src="<?php echo pods_field_display( 'travel',$post->ID,'focus5'); ?>" /></a></li>
                </ul>
            </div>
<!-- 代码 结束 -->
        </div>
        <div class="right">
            <li class="price">¥ <span><?php echo pods_field_display( 'travel',$post->ID,'price'); ?></span> 壹人 <span class="info">起</span></li>
            <li class="list"><span><i class="icon-camera icon-1x"></i>&nbsp;活动主题：</span><?php echo pods_field_display( 'travel',$post->ID,'theme'); ?></li>
            <li class="list"><span><i class="icon-list-ul icon-1x"></i>&nbsp;活动天数：</span><?php echo pods_field_display( 'travel',$post->ID,'day'); ?></li>
            <li class="list"><span>&nbsp;<i class="icon-map-marker icon-1x"></i>&nbsp;集合地点：</span><?php echo pods_field_display( 'travel',$post->ID,'place'); ?></li>
            <li class="list"><span><i class="icon-flag icon-1x"></i>&nbsp;途经景点：</span><?php echo pods_field_display( 'travel',$post->ID,'scenic'); ?></li>
            <li class="list"><span>&nbsp;<i class="icon-plane icon-1x"></i>&nbsp;出行交通：</span><?php echo pods_field_display( 'travel',$post->ID,'traffic'); ?></li>
            <li class="list"><span><i class="icon-list-alt icon-1x"></i>&nbsp;报名方式：</span>在线咨询、电话咨询</li>
            <li class="list"><span>&nbsp;<i class="icon-usd icon-1x"></i>&nbsp;支付方式：</span>支付宝、微信、银行卡、线下</li>
        </div>
    </div>
</div>
<div class="blank_x15"></div>

<div class="single_reserve_wrap">
    <div class="single_reserve">
        <li class="text">选择出发时间：</li>
        <li class="select">
            <select>
                <?php echo pods_field_display( 'travel',$post->ID,'group'); ?>
            </select>
        </li>
        <li class="text">出行人数：</li>
        <li class="select"><input name="" type="text" /> 人</li>
        <li class="text">男：</li>
        <li class="select"><input name="" type="text" /> 人</li>
        <li class="text">女：</li>
        <li class="select"><input name="" type="text" /> 人</li>
        <li class="text">儿童：</li>
        <li class="select"><input name="" type="text" /> 人</li>
        <li class="consult"><a class="on" href="http://p.qiao.baidu.com/cps/chat?siteId=10865093&userId=22303378">在线咨询</a></li>
    </div>
</div>
<div class="blank_x15"></div>

<div class="single_mian_wrap">
    <div class="single_mian">
        <div class="left">
<!-- 行程介绍 -->
            <div class="article_trip_top"><a name="1F"></a></div>
            <div class="article_trip_title">
                <span class="on">活动亮点</span><span><a href="#2F">活动行程</a></span><span><a href="#3F">费用说明</a></span><span><a href="#4F">出行准备</a></span><span><a href="#5F">注意事项</a></span><span><a href="#6F">付款方式</a></span><span><a href="#7F">关于景点</a></span><span><a href="#8F">活动评论</a></span>
            </div>
            <div class="article_trip">
                <?php echo pods_field_display( 'travel',$post->ID,'highlights'); ?>
            </div>
<!-- 活动行程 -->
            <div class="article_space_y"><a name="2F"></a></div>
            <div class="article_trip_top"></div>
            <div class="article_trip_title">
                <span><a href="#1F">活动亮点</a></span><span class="on">活动行程</span><span><a href="#3F">费用说明</a></span><span><a href="#4F">出行准备</a></span><span><a href="#5F">注意事项</a></span><span><a href="#6F">付款方式</a></span><span><a href="#7F">关于景点</a></span><span><a href="#8F">活动评论</a></span>
            </div>
            <div class="article_trip">
                <?php the_content(); ?>
            </div>
<!-- 费用说明 -->
            <div class="article_space_y"><a name="3F"></a></div>
            <div class="article_trip_top"></div>
            <div class="article_trip_title">
                <span><a href="#1F">活动亮点</a></span><span><a href="#2F">活动行程</a></span><span class="on">费用说明</span><span><a href="#4F">出行准备</a></span><span><a href="#5F">注意事项</a></span><span><a href="#6F">付款方式</a></span><span><a href="#7F">关于景点</a></span><span><a href="#8F">活动评论</a></span>
            </div>
            <div class="article_trip">
                <?php echo pods_field_display( 'travel',$post->ID,'cost'); ?>
            </div>
<!-- 出行准备 -->
            <div class="article_space_y"><a name="4F"></a></div>
            <div class="article_trip_top"></div>
            <div class="article_trip_title">
                <span><a href="#1F">活动亮点</a></span><span><a href="#2F">活动行程</a></span><span><a href="#3F">费用说明</a></span><span class="on">出行准备</span><span><a href="#5F">注意事项</a></span><span><a href="#6F">付款方式</a></span><span><a href="#7F">关于景点</a></span><span><a href="#8F">活动评论</a></span>
            </div>
            <div class="article_trip">
				<p><b class="xiaobiao">个人装备</b></p>
				<p>1)各类有效证件：身份证、学生证、军官证、老年证、银行卡。</p>
				<p>2)背包：拉杆箱/大背包（平时放车上）；小背包（每天活动使用，存放相机，干粮水，药物等）；腰包（贵重物品随身带）</p>
				<p>3)衣服：冲锋衣，抓绒衣裤，保暖内衣，羽绒服（必选）。贴身快干衣。徒步鞋/运动鞋。*稻城地区全年气温偏低，昼夜温差大</p>
				<p>4)其他：护膝，手套，遮阳帽，太阳镜，雨衣，登山杖（可选），充气护颈枕，防晒霜（30+），唇膏，护肤霜，纸巾，洗漱用品，大号保温水壶，备用电池，充电器，头灯或者手电等个人用品。</p>
				<p><b class="xiaobiao">食品和水</b></p>
				<p>带适量备用食物，尽量高能消化快的。如巧克力，糖包，甘薯等碳水化合物。</p>
				<p>干果类：如腰果，杏仁，葡萄干等。水果：苹果、梨，番茄等。保温杯，随时能喝上热水补充能量，一定要有电解质饮料。</p>
				<p><b class="xiaobiao">预防高反</b></p>
				<p>当人到达一定的海拔高度后，身体为适应海拔而造成气压差，含氧少，空气干燥等变化，会产生头痛，气短，胸闷，厌食，发烧，头晕乏力等生理症状。</p>
				<p>应对方法：</p>
				<p>1）良好的心里素质，调整好心态，保持轻松愉悦心情，正视高反，可出发前一个月，口福红景天，西洋参泡水等。</p>
				<p>2）足量饮水，由于高原地带，空气干燥稀薄，人体水分流失加快，建议4-5L/天/人。</p>
				<p>3）保暖，随时增减衣服，千万不能感冒。</p>
				<p>4）合理膳食，多吃当地食物，高能高热量食物，多吃水果，不宜暴饮暴食。</p>
				<p>5）高原徒步，放慢节奏，勿跑勿跳，量力而行。</p>
            </div>
<!-- 注意事项 -->
            <div class="article_space_y"><a name="5F"></a></div>
            <div class="article_trip_top"></div>
            <div class="article_trip_title">
                <span><a href="#1F">活动亮点</a></span><span><a href="#2F">活动行程</a></span><span><a href="#3F">费用说明</a></span><span><a href="#4F">出行准备</a></span><span class="on">注意事项</span><span><a href="#6F">付款方式</a></span><span><a href="#7F">关于景点</a></span><span><a href="#8F">活动评论</a></span>
            </div>
            <div class="article_trip">
				<p>1、我们的活动不同于常规旅游团，重在全身心的体验，对参加队员的安全、环保及团队协作精神要求较高。</p>
				<p>2、西部地区旅行有很多您在繁华城市无法理解无法容忍的事：硬件方面是水、电、交通的问题，突然的停水停电经常发生，临时的交通管制也经常让我们措手不及；软件方面是当地人的服务意识方面的，许多不可思议的事情在慢节奏和原生态的西部都习以为常。</p>
				<p>3、我们希望您尊重原著文化、当地风俗以及他们的宗教信仰。接触另类生活人群和他们的文化时，尊重当地的文化和传统，与人平等相处才能发现一个完全不同的世界，减少旅游给当地文化和传统带来的影响。</p>
				<p>4、注重文明和环保：保持车内的卫生，不要车窗抛物，保护景区的环境，除了脚印什么也别留下，除了照片什么也别带走。</p>
				<p>5、我们所操作的路线多为深度游、摄影游、探险游路线，操作流程比较复杂，客观因素偶尔会影响计划实施。户外旅行的魅力也在于这种不确定性：有时候是毫无防备的惊喜，有时候是突如其来的困难。当发生困难导致活动无法继续的时候，领队或组织方有权利给出行程更改方案，由队员投票表决，少数服从多数。</p>
				<p>6、在不减少主要景点的前提下，组织方有权利根据天气、航班、交通、季节、旺季人潮等因素，调整游览景点的先后顺序。</p>
				<p>7、活动途中若因个人原因(如体力、疾病、私事等)退出，需签订离团协议，另产生的费用由自己承担。</p>
				<p>8、报名者必须是年龄在6~70岁之间的（6~16岁未成年人需有监护人陪同），身体健康、无任何急、慢性病，四肢健全、体力良好、吃苦耐劳、有极强的动手能力、有团队协作精神、心理健康的健康人士。</p>
				<p>9、如有传染性疾病、心脑血管疾病、严重呼吸系统疾病、精神病、严重贫血者、大中型手术恢复期患者、行动不便者、孕妇等不适宜出行者请勿报名。另希望您定期体检，出发前请咨询医生、凡隐瞒自己疾病产生严重后果的，责任自负。</p>
				<p>10、如果您在旅行过程中，出现任何接待质量方面的问题或担忧，请及时与领队或司机协调。如领队和司机的处理无法让您满意请及时拨打报名客服电话，我们会第一时间处理。如果在整个旅行过程中，您没有任何质量方面的反应，而在结束行程后提起投诉的话，我公司概不受理</p>				
            </div>
<!-- 付款方式 -->
            <div class="article_space_y"><a name="6F"></a></div>
            <div class="article_trip_top"></div>
            <div class="article_trip_title">
                <span><a href="#1F">活动亮点</a></span><span><a href="#2F">活动行程</a></span><span><a href="#3F">费用说明</a></span><span><a href="#4F">出行准备</a></span><span><a href="#5F">注意事项</a></span><span class="on">付款方式</span><span><a href="#7F">关于景点</a></span><span><a href="#8F">活动评论</a></span>
            </div>
            <div class="article_trip_yh">
                <h4>银行对私转帐：</h4>
                <ol>
                    <p><span class="yh">工商银行：</span><span class="yh">6212 **** 0202 6721 641</span><span class="name"></span><span class="yh">成都市青羊区青羊宫支行</span></p>
                    <p><span class="yh">中国邮政：</span><span class="yh">6221 **** 1000 2197 492</span><span class="name"></span><span class="yh">成都新都区斑竹园支行</span></p>
                </ol>             
                <h4>支付宝转帐：</h4>
                <ol>
                    <p><span class="yh">**@mail.com</span><span class="name"></span></p>
                </ol>
                <h4>俱乐部当面付款：</h4>
                <ol>
                    <p>地址：四川省成都市武候区红牌楼佳灵路20号 九峰大厦A座15楼08-10室</p>
                </ol>
                <p class="zy">请于汇款后第一时间以短信，微信或电话等方式通知我们查收，需提供姓名，参加哪一期，汇款到哪个银行，汇款金额。</p>
            </div> 
<!-- 关于景点 -->
            <div class="article_space_y"><a name="7F"></a></div>
            <div class="article_trip_top"></div>
            <div class="article_trip_title">
                <span><a href="#1F">活动亮点</a></span><span><a href="#2F">活动行程</a></span><span><a href="#3F">费用说明</a></span><span><a href="#4F">出行准备</a></span><span><a href="#5F">注意事项</a></span><span><a href="#6F">付款方式</a></span><span class="on">关于景点</span><span><a href="#8F">活动评论</a></span>
            </div>
            <div class="article_trip">
                <?php echo pods_field_display( 'travel',$post->ID,'view-gallery'); ?>
            </div>
<!-- 评论 -->
            <div class="article_space_y"><a name="8F"></a></div>
            <div class="article_trip_top"></div>
            <div class="article_trip_title">
                <span><a href="#1F">活动亮点</a></span><span><a href="#2F">活动行程</a></span><span><a href="#3F">费用说明</a></span><span><a href="#4F">出行准备</a></span><span><a href="#5F">注意事项</a></span><span><a href="#6F">付款方式</a></span><span><a href="#7F">关于景点</a></span><span class="on">活动评论</span>
            </div>
            <div class="article_trip">
                <div class="comments_framees">
                    <?php comments_template(); ?>
                </div>
            </div>
<?php endwhile;endif; ?>
<!-- end -->

    </div>
    <div class="jieri_main_right">
        <div class="jieri_custom"><a href="/custom"><img src="<?php bloginfo('template_url'); ?>/images/jieri/jieri_custom.jpg" /></a></div>
 <!-- 私人订制图片 -->  
        </div>
        <div class="right single_right">
            <div class="title">
                <h1>推荐活动</h1>
            </div>
            <div class="list">
<?php
wp_reset_query();
$args  = array(
'post_type'        => 'travel',
'caller_get_posts' => -1,
'showposts'        => 5,
'tax_query' => array(
	array(
		'taxonomy' => 'travel-category',
		'field'    => 'term_id',
		'terms'    => array( 17 )
	),
),
);
query_posts( $args );
?>
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
                <li class="pic"><a href="<?php the_permalink() ?>" title="<?php the_title() ?>" target="_blank"><?php if ( has_post_thumbnail() ) { ?><?php the_post_thumbnail(); ?><?php } else {?><img src="<?php bloginfo('template_url'); ?>/images/nopic.png" /><?php } ?></a></li>
                <li class="title"><a href="<?php the_permalink() ?>" title="<?php the_title() ?>"><?php the_title() ?></a></li>
                <li class="jiage"><span class="fuhao">&yen;</span ><?php echo pods_field_display( 'travel',$post->ID,'price'); ?></li>
<?php
endwhile;
endif;
wp_reset_query();
?>
            </div>
        </div>
    </div>
</div>
<div class="blank_x15"></div>
<?php get_footer(); ?>