<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
$data = WShop_Temp_Helper::clear('atts','templates');

$atts = $data['atts'];
$content = $data['content'];

$api = WShop_Modal_Solution_Travel::instance();
$post_id = isset($atts['post_id'])?$atts['post_id']:null;
if(!$post_id){
    return;
}

$travel = new WShop_Travel($post_id);
if(!$travel->is_load()){
    return;
}

$context = WShop_Helper::generate_unique_id();
$now = date_i18n('Y-m-d');
global $wpdb;
$travel_dates = $wpdb->get_results(
    "select ti.*,p.*,pr.*
     from {$wpdb->prefix}wshop_travel_item ti
     inner join {$wpdb->prefix}posts p on p.ID = ti.post_ID
     left join {$wpdb->prefix}wshop_product pr on pr.post_ID = p.ID
     where p.post_status='publish'
           and p.post_type='".WShop_Travel_Item::POST_T."'
           and ti.travel_post_ID ={$travel->post_ID}
           and ti.date>='{$now}'
           and (pr.inventory is null or pr.inventory>0) 
     order by ti.date asc;");

?><link href="<?php echo $api->domain_url?>/assets-m/style.css" rel="stylesheet" type="text/css" />
<div class="date-wrap">
    <div class="date">
        <div class="left">
            <ul class="wshop-travel-list">
            <?php 
            $weeks = array(
                0=>'周一',
                1=>'周二',
                2=>'周三',
                3=>'周四',
                4=>'周五',
                5=>'周六',
                6=>'周日',
            );
            if($travel_dates){
                foreach ($travel_dates as $date){
                    $product = new WShop_Product($date);
                    $travel_item = new WShop_Travel_Item($date);
                    $date_time =strtotime($travel_item->date);
                    ?>
                    <li class="wshop-travel-online"  data-id="<?php echo $product->post_ID?>">
                        <span class="day"><?php echo date('m-d',$date_time)?> <?php echo $weeks[date('w',$date_time)]?></span>
                        <span class="price"><?php echo $product->get_single_price(true)?></span>
                    </li>
                    <?php 
                }
            }?>
            </ul>
        </div>
        <div class="right">
           <ul> <li><a href="javascript:void(0);" onclick="window.wshop_toshare();">更多<br/>排期</a></li></ul>
        </div>
        
    </div>
</div>

<style type="text/css">
    .wshop-travel-list li.today .date{color:green;font-weight: bold}
</style>
<?php 
    if(!function_exists('wshop_travel_generate_calendar_html')){
        function wshop_travel_generate_calendar_html($date_of_time,$travel_items,$_index=0,&$products){
            $time = $date_of_time;
            $year = date('Y',$time);
            $month = date('m',$time);
           // $day = date('d',$time);
            //这个月起始位置
            $start_of_month = date('w',strtotime("$year-$month-01"));
            //一个月的天数
            $days_of_month = date('t',$time);
            
            $days_of_last_month= date('t',strtotime('-1 month', $time));
            ob_start();
            ?><div class="layer-month"><?php echo date('Y年m月',$time)?></div>
             <div class="layer-day">
             <ul class="wshop-travel-list"><?php 
            $_now = date_i18n('Y-m-d');
            for ($index=1;$index<=6;$index++){
                if($index!==1){
                    ?></ul><ul  class="wshop-travel-list"><?php
                }
                for($week=0;$week<=6;$week++){
                    $position = 7*($index-1)+$week;
                    if($position>=$start_of_month&&$position<=($days_of_month+$start_of_month-1)){
                        $day_now =($position-$start_of_month)+1;
                        $date_now ="{$year}-{$month}-".($day_now<10?"0{$day_now}":$day_now);
                        $travel_item =WShop_Helper_Array::first_or_default($travel_items,function($m,$date){
                            return $m->date==$date;
                        },$date_now);
                       
                        if($travel_item){
                            $product = new WShop_Product($travel_item);
                            $product->travel_date = strtotime("{$year}-{$month}-01");
                            $products[]=$product;
                           ?>
                            <li style="cursor:pointer;" id="wshop-day-<?php echo $product->post_ID?>" class="layer-day wshop-travel-online <?php echo $date_now==$_now?'today':'';?>" data-date="<?php echo $date_now;?>" data-id="<?php echo $product->post_ID?>" data-inventory="<?php echo $product->get_inventory()?>" data-price="<?php echo $product->get_single_price(false)?>" data-priceshow="<?php echo esc_attr($product->get_single_price(true))?>">
                                <span class="dates"><?php echo $day_now;?></span>
                         		<span class="price"><?php echo $product->get_single_price(true)?></span>
                            </li>
                           <?php  
                        }else{
                            ?>
                            <li class="<?php echo $date_now==$_now?'today':'';?>">
                                 <span class="dates"><?php echo $day_now;?></span>
                         		 <span class="price"></span>
                            </li>
                           <?php  
                        }
                    }else{
                        ?>
                        <li>
                             <span class="dates"></span>
                     		 <span class="price"></span>
                        </li>
                        <?php 
                    }
                }
            } 
            
    		?></ul>
    		</div><?php 
    		return ob_get_clean();
        }
    }
?>
<!--日历弹出层-->
<div class="date-layer">
    <div class="date-h3">
        <ul><li class="text">选择日期</li>
        <li class="close">X</li></ul>
    </div>
    <div class="layer-week">
        <ul>
            <li>日</li>
            <li>一</li>
            <li>二</li>
            <li>三</li>
            <li>四</li>
            <li>五</li>
            <li>六</li>
        </ul>
    </div>
    <div class="layer-month-wrap">
    <?php 
    $dates = array();
    if($travel_dates){
        foreach ($travel_dates as $date){
            $product = new WShop_Product($date);
            $travel_item = new WShop_Travel_Item($date);
    
            if(!$travel_item->date){continue;}
    
            $dates[strtotime(date('Y-m-01',strtotime($travel_item->date)))][]=$date;
        }
    }
    
    $index=0;
    $products = array();
    foreach ($dates as $date=>$items){
        echo wshop_travel_generate_calendar_html($date,$items,$index++,$products);
    }
    ?>
    </div>
</div>

<div class="bottom-service">
    <ul class="left">
        <li class="home"><span><i class="icon-home icon"></i></span><span>首页</span></li>
        <li class="tel"><span><i class="icon-phone icon"></i></span><span>电话咨询</span></li>
        <li class="sms"><span><i class="icon-comment icon"></i></span><span>在线咨询</span></li>
    </ul>
    <ul class="right">
    <?php 
    	echo WShop::instance()->WP->requires(WSHOP_DIR, '__purchase.php',array(
    	    'content'=>'立即预订',
    	    'class'=>'bnt',
    	    'location'=>WShop_Helper_Uri::get_location_uri(),
    	    'context'=>$context,
    	    'modal'=>'travel_shopping',
    	    'section'=>'travel_shopping'
    	));
    	?></ul>
</div>
<script type="text/javascript">
	(function($){
		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
			var $selected =$("ul.wshop-travel-list li.selected");
			if($selected.length==0){return;}
			
			data.post_id = $selected.data('id');
			data.adult_qty= 1;
			data.child_qty= 0;
    	});
    	
		$("ul.wshop-travel-list li.wshop-travel-online").click(function () {
			$("ul.wshop-travel-list li.selected").removeClass("selected");
			$(this).addClass("selected");
		});//点击选中
		$("ul.wshop-travel-list li.wshop-travel-online").first().click();
		$("ul.wshop-travel-list li").first().click();
		window.wshop_toshare=function(){
			$(".date-layer").addClass("am-modal-active");	
			if($(".layerbg").length>0){
				$(".layerbg").addClass("layerbg-active");
			}else{
				$("body").append('<div class="layerbg"></div>');
				$(".layerbg").addClass("layerbg-active");
			}
			$(".layerbg-active,.close").click(function(){
				$(".date-layer").removeClass("am-modal-active");	
				setTimeout(function(){
					$(".layerbg-active").removeClass("layerbg-active");	
					$(".layerbg").remove();	
				},300);
			})
		};
			
	})(jQuery);
</script>