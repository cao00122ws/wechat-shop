<?php 
if (! defined('ABSPATH')) {
    exit();
}

$context = WShop_Helper::generate_unique_id();
$api = WShop_Modal_Solution_Travel::instance();

$cart = WShop_Shopping_Cart::get_cart();
if($cart instanceof WShop_Error){
    WShop::instance()->WP->wp_die($cart,false,false);
    return;
}

$cart_items = $cart->get_items();
if($cart_items instanceof WShop_Error){
    WShop::instance()->WP->wp_die($cart_items,false,false);
    return;
}

if(count($cart_items)==0){
    WShop::instance()->WP->wp_die('未找到商品信息，请返回店铺重新下单！',false,false);
    return;
}

$cart_item=null;
foreach ($cart_items as $cart_item){
   break; 
}
$product = $cart_item['product'];

$travel_item = new WShop_Travel_Item($product->post_ID);
if(!$travel_item->is_load()){
    WShop::instance()->WP->wp_die('未找到商品信息，请返回店铺重新下单！',false,false);
    return;
}
$travel = new WShop_Travel($travel_item->travel_post_ID);
if(!$travel->is_load()){
    WShop::instance()->WP->wp_die('未找到商品信息，请返回店铺重新下单！',false,false);
    return;
}
$symbol = $product->get_currency_symbol();

$adult_qty = isset($cart_item['metas']['adult_qty'])?absint($cart_item['metas']['adult_qty']):0;
$child_qty = isset($cart_item['metas']['child_qty'])?absint($cart_item['metas']['child_qty']):0;

$now = date_i18n('Y-m-d');
global $wpdb;
$travel_dates = $wpdb->get_results(
   "select ti.*,p.*,pr.*
    from {$wpdb->prefix}wshop_travel_item ti
    inner join {$wpdb->prefix}posts p on p.ID = ti.post_ID
    inner join {$wpdb->prefix}wshop_product pr on pr.post_ID = p.ID
    where p.post_status='publish'
            and p.post_type='".WShop_Travel_Item::POST_T."'
            and ti.travel_post_ID ={$travel->post_ID}
            and ti.date>='{$now}'
            and (pr.inventory is null or pr.inventory>0) 
    order by ti.date asc;");
$weeks = array(
    0=>'周一',
    1=>'周二',
    2=>'周三',
    3=>'周四',
    4=>'周五',
    5=>'周六',
    6=>'周日',
);
?>
<link href="<?php echo $api->domain_url?>/assets-m/style.css" rel="stylesheet" type="text/css" /> 
<div class="order-tit-wrap">
    <div class="order-tit">
        <h1><?php echo get_the_title($travel->post)?></h1>
    </div>
</div>
<input type="hidden" id="wshop-travel-item" value="<?php echo $travel_item->post_ID;?>" data-inventory="<?php echo $product->get_inventory();?>" data-price="<?php echo $product->get_single_price(false)?>"/>
<div class="order-num-wrap">
    <div class="order-num">
        <ul>
            <li class="tit-time">出发日期：</li>
            <?php $date_time = strtotime($travel_item->date);?>
            <li class="info-time"><span id="show-travel-item"><?php echo date('Y-m-d',$date_time)?> <?php echo $weeks[date('w',$date_time)]?></span> <a href="javascript:void(0);" onclick="window.wshop_toshare();"><i class="icon-calendar icon"></i> 修改</a></li>
        </ul>
         <ul>
                <li class="tit">成人</li>
                <li class="info">
                    <span class="price" id="travel-date-adult-price"><?php 
                            $adult_amount =  $product->get_single_price(false);
                            echo "{$symbol}{$adult_amount}";
                    ?></span>
                    <span class="choice">
                        <div class="order-number">
                            <em class="jian"  id="wshop-adult-qty-cut">-</em>
                            <input type="tel" value="<?php echo $adult_qty;?>" class="num" id="wshop-adult-qty"/>
                            <em class="add"  id="wshop-adult-qty-add">+</em>
                        </div>
                    </span>
                </li>
               
            </ul>
            <ul>
                <li class="tit">儿童</li>
                <li class="info">
                    <span class="price" id="travel-date-child-price"><?php 
                    $price = $product->get_single_price(false);
                    $child_free_amount = round(floatval($travel->get('child_free_amount')),2);
                    
                    $child_amount = ($price-$child_free_amount)<0?0:round($price-$child_free_amount,2);
                    echo "{$symbol}{$child_amount}";
                ?></span>
                    <span class="choice">
                        <div class="order-number">
                            <em class="jian" id="wshop-child-qty-cut">-</em>
                            <input type="tel"  value="<?php echo $child_qty;?>" class="num" id="wshop-child-qty" />
                            <em class="add" id="wshop-child-qty-add">+</em>
                        </div>
                    </span>
                </li>
            </ul>
       
        <ul>
            <li class="remind">*请在出团日期前1天22点前预订*</li>
        </ul>
    </div>
</div>

<div class="order-contact-wrap">
    <div class="order-contact">
        <?php 
            $form_product = new WShop_Forms_Product($travel->post_ID);
            $form =$form_product->is_load()? new WShop_Forms($form_product->form_id):null;
            if($form&&$form->is_load()){
                ?>
                <style type="text/css">
                    .wshop-travel-form .form-control,.wshop-travel-form .xh-input-group {width:400px;}
					.xh-form .xh-form-group{height: 40px;}
					.xh-form label{float: left;}
					.wshop-travel-form .form-control, .wshop-travel-form .xh-input-group{float: right;}
                </style>
                <div class="title bak"><i class="fa fa-user-o"></i> 联系人信息 <span>（用于接收订单反馈）</span></div>                
                <div class="xh-form wshop-travel-form" style="max-width:550px;">
                	<?php  echo $form->to_html($context);?>
                </div>
                
                <?php 
            }
            ?>
    </div>
</div>

<div class="pay-mode-wrap">
    <div class="pay-mode">
        <div class="pay-mode-tit">支付信息</div>
        <div class="pay-money">订单结算总额：<span id="wshop-show-total">￥0.00</span></div>
       <?php 
        	   $gateways = WShop::instance()->payment->get_payment_gateways();
        	   if($gateways){
        	       ?>
        	       <ul>
        	       <?php 
        	       $index =0;
        	       foreach ($gateways as $gateway){
        	           ?><li><label style="margin-right:15px;"><input class="wshop-travel-<?php echo $context;?>-payment-method" type="radio" <?php echo $index++==0?'checked':'';?> name="payment-method-<?php echo $context?>" value="<?php echo esc_attr($gateway->id)?>" > <img src="<?php echo esc_attr($gateway->icon)?>" alt="<?php echo esc_attr($gateway->title);?>"></label></li><?php
        	       }
        	       ?>
        	       </ul>
        	       <script type="text/javascript">
                    	(function($){
                    		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
        						data.payment_method = $('.wshop-travel-<?php echo $context;?>-payment-method:checked').val();
                        	});
                    	})(jQuery);
                    </script>
        	       <?php 
        	   }
        	?>              
        <div class="pay-bnt">
			<style type="text/css">
                .order .contit ul.submit li .submit {
                    width: 120px;
                    height: 35px;
                    border: 0px;
                    background-color: #FF9600;
                    border-radius: 5px;
                    font: 500 16px/30px "\5FAE\8F6F\96C5\9ED1",Arial;
                    color: #fff;
                }
            </style>
			<?php 
        	echo WShop::instance()->WP->requires(WSHOP_DIR, '__purchase.php',array(
        	    'content'=>'提交订单',
        	    'class'=>'submit',
        	    'location'=>WShop_Helper_Uri::get_location_uri(),
        	    'context'=>$context,
        	    'modal'=>'travel_shopping',
        	));
        	?></div>
    </div>
</div>

<?php 
	echo WShop::instance()->WP->requires(WSHOP_DIR, 'page/checkout-order-pay-total-amount.php',array(
	    'context'=>$context
	));
   ?>
<script type="text/javascript">
	(function($){
		
		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
			data.post_id = $('#wshop-travel-item').val();
			data.adult_qty= parseInt($('#wshop-adult-qty').val());
			data.child_qty= parseInt($('#wshop-child-qty').val());
    	});

		$(document).bind('wshop_<?php echo $context;?>_init_amount_before',function(e,view){
			var $date =$('#wshop-travel-item');
			
			var price = parseFloat($date.data('price'));
			if(isNaN(price)){price=0;}
			
			var adult_qty= parseInt($('#wshop-adult-qty').val());
			if(isNaN(adult_qty)){adult_qty=0;}
			var child_qty= parseInt($('#wshop-child-qty').val());
			if(isNaN(child_qty)){child_qty=0;}

			var child_price = parseFloat(price)-<?php echo round(floatval($travel->get('child_free_amount')),2);?>;
			if(child_price<0){child_price=0;}
			
			view.total_amount+=parseFloat(price)*adult_qty+child_qty*child_price;
			$('#travel-date-adult-price').html(view.symbol+price.toFixed(2));
			$('#travel-date-child-price').html(view.symbol+child_price.toFixed(2));
    	});
		
		$(document).bind('wshop_<?php echo $context?>_show_amount',function(e,view){
			var total =view.total_amount;
			$('#wshop-show-total').html(view.symbol+total.toFixed(2))
		});
		window.wshop_on_adult_qty_change=function(changed){
			var $date =$('#wshop-travel-item');
			var qty = parseInt($('#wshop-adult-qty').val());
			if(isNaN(qty)||qty<0){qty=0;}

			var cqty = parseInt($('#wshop-child-qty').val());
			if(isNaN(cqty)||cqty<0){cqty=0;}

			var inventory = parseInt($date.data('inventory'));
			inventory = isNaN(inventory)?9999:inventory;
			if(isNaN(inventory)||inventory<0){
				inventory=0;
			}

			if(cqty>inventory){
				cqty=inventory;
				$('#wshop-child-qty').val(cqty);
			}
			
			if((qty+cqty)>inventory){
				qty=inventory-cqty;
				$('#wshop-adult-qty').val(qty);
			}

			var qty = changed+qty;
			if(qty<0){qty=0;}
			if(qty>(inventory-cqty)){
				qty=inventory-cqty;
			}

			$('#wshop-adult-qty').val(qty);
			$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
		}

		window.wshop_on_child_qty_change=function(changed){
			var $date =$('#wshop-travel-item');
			var qty = parseInt($('#wshop-adult-qty').val());
			if(isNaN(qty)||qty<0){qty=0;}

			var cqty = parseInt($('#wshop-child-qty').val());
			if(isNaN(cqty)||cqty<0){cqty=0;}

			var inventory = parseInt($date.data('inventory'));
			inventory = isNaN(inventory)?9999:inventory;
			if(isNaN(inventory)||inventory<0){
				inventory=0;
			}

			if(qty>inventory){
				qty=inventory;
				$('#wshop-adult-qty').val(qty);
			}
			
			if((qty+cqty)>inventory){
				cqty=inventory-qty;
				$('#wshop-child-qty').val(cqty);
			}

			var cqty = changed+cqty;
			if(cqty<0){cqty=0;}
			if(cqty>(inventory-qty)){
				cqty=inventory-qty;
			}

			$('#wshop-child-qty').val(cqty);
			$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
		};
		
		$('#wshop-adult-qty-cut').click(function(){
			window.wshop_on_adult_qty_change(-1);
		});
		$('#wshop-adult-qty-add').click(function(){
			window.wshop_on_adult_qty_change(1);
		});
		$('#wshop-adult-qty').keyup(function(){
			window.wshop_on_adult_qty_change(0);
		});

		//-----------------------------------------------------------------
		$('#wshop-child-qty-cut').click(function(){
			window.wshop_on_child_qty_change(-1);
		});
		$('#wshop-child-qty-add').click(function(){
			window.wshop_on_child_qty_change(1);
		});
		
		$('#wshop-child-qty').keyup(function(){
			window.wshop_on_child_qty_change(0);
		});
	})(jQuery);
</script>


<style type="text/css">
    .wshop-travel-list li.today .date{color:green;font-weight: bold}
</style>
<?php 
    if(!function_exists('wshop_travel_generate_calendar_html')){
        function wshop_travel_generate_calendar_html($date_of_time,$travel_items,$_index=0,&$products){
            $weeks = array(
                0=>'周一',
                1=>'周二',
                2=>'周三',
                3=>'周四',
                4=>'周五',
                5=>'周六',
                6=>'周日',
            );
            $time = $date_of_time;
            $year = date('Y',$time);
            $month = date('m',$time);
           // $day = date('d',$time);
            //这个月起始位置
            $start_of_month = date('w',strtotime("$year-$month-01"));
            //一个月的天数
            $days_of_month = date('t',$time);
            
            $days_of_last_month= date('t',strtotime('-1 month', $time));
            ob_start();
            ?><div class="layer-month"><?php echo date('Y年m月',$time)?></div>
             <div class="layer-day">
             <ul class="wshop-travel-list"><?php 
            $_now = date_i18n('Y-m-d');
            for ($index=1;$index<=6;$index++){
                if($index!==1){
                    ?></ul><ul  class="wshop-travel-list"><?php
                }
                for($week=0;$week<=6;$week++){
                    $position = 7*($index-1)+$week;
                    if($position>=$start_of_month&&$position<=($days_of_month+$start_of_month-1)){
                        $day_now =($position-$start_of_month)+1;
                        $date_now ="{$year}-{$month}-".($day_now<10?"0{$day_now}":$day_now);
                        $travel_item =WShop_Helper_Array::first_or_default($travel_items,function($m,$date){
                            return $m->date==$date;
                        },$date_now);
                       
                        if($travel_item){
                            $product = new WShop_Product($travel_item);
                            $product->travel_date = strtotime("{$year}-{$month}-01");
                            $products[]=$product;
                            $date_time =strtotime($travel_item->date); 
                           ?>
                            <li style="cursor:pointer;" id="wshop-day-<?php echo $product->post_ID?>" class="layer-day wshop-travel-online <?php echo $date_now==$_now?'today':'';?>" data-date="<?php echo $date_now;?>" data-id="<?php echo $product->post_ID?>" data-inventory="<?php echo $product->get_inventory()?>" data-price="<?php echo $product->get_single_price(false)?>" data-priceshow="<?php echo esc_attr($product->get_single_price(true))?>" data-title="<?php echo date('Y-m-d',$date_time)?> <?php echo $weeks[date('w',$date_time)]?>">
                                <span class="dates"><?php echo $day_now;?></span>
                         		<span class="price"><?php echo $product->get_single_price(true)?></span>
                            </li>
                           <?php  
                        }else{
                            ?>
                            <li class="<?php echo $date_now==$_now?'today':'';?>">
                                 <span class="dates"><?php echo $day_now;?></span>
                         		 <span class="price"></span>
                            </li>
                           <?php  
                        }
                    }else{
                        ?>
                        <li>
                             <span class="dates"></span>
                     		 <span class="price"></span>
                        </li>
                        <?php 
                    }
                }
            } 
            
    		?></ul>
    		</div><?php 
    		return ob_get_clean();
        }
    }
?>
<!--日历弹出层-->
<div class="date-layer">
    <div class="date-h3">
        <ul><li class="text">选择日期</li>
        <li class="close">X</li></ul>
    </div>
    <div class="layer-week">
        <ul>
            <li>日</li>
            <li>一</li>
            <li>二</li>
            <li>三</li>
            <li>四</li>
            <li>五</li>
            <li>六</li>
        </ul>
    </div>
    <div class="layer-month-wrap">
    <?php 
    $dates = array();
    if($travel_dates){
        foreach ($travel_dates as $date){
            $product = new WShop_Product($date);
            $travel_item = new WShop_Travel_Item($date);
    
            if(!$travel_item->date){continue;}
    
            $dates[strtotime(date('Y-m-01',strtotime($travel_item->date)))][]=$date;
        }
    }
    
    $index=0;
    $products = array();
    foreach ($dates as $date=>$items){
        echo wshop_travel_generate_calendar_html($date,$items,$index++,$products);
    }
    ?>
    </div>
</div>
<script type="text/javascript">
	(function($){
		$("ul.wshop-travel-list li.wshop-travel-online").click(function () {
			$("ul.wshop-travel-list li.selected").removeClass("selected");
			$(this).addClass("selected");

			$('#show-travel-item').html($(this).data('title'));
			$('#wshop-travel-item').val($(this).data('id'));
			$('#wshop-travel-item').data('price',$(this).data('price'));
			$('#wshop-travel-item').data('inventory',$(this).data('inventory'));
			
			$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
		});//点击选中

		$('#wshop-day-<?php echo $cart_item['product']?$cart_item['product']->post_ID:0;?>.wshop-travel-online').click();
		
		window.wshop_toshare=function(){
			$(".date-layer").addClass("am-modal-active");	
			if($(".layerbg").length>0){
				$(".layerbg").addClass("layerbg-active");
			}else{
				$("body").append('<div class="layerbg"></div>');
				$(".layerbg").addClass("layerbg-active");
			}
			$(".layerbg-active,.close").click(function(){
				$(".date-layer").removeClass("am-modal-active");	
				setTimeout(function(){
					$(".layerbg-active").removeClass("layerbg-active");	
					$(".layerbg").remove();	
				},300);
			})
		};
			
	})(jQuery);
</script>