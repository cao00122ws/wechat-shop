<?php 
if (! defined ( 'ABSPATH' ))
    exit (); // Exit if accessed directly
$data = WShop_Temp_Helper::clear('atts','templates');

$atts = $data['atts'];
$content = $data['content'];

$api = WShop_Modal_Solution_Travel::instance();
$post_id = isset($atts['post_id'])?$atts['post_id']:null;
if(!$post_id){
    return;
}
$travel = new WShop_Travel($post_id);
if(!$travel->is_load()){
    return;
}

$context = WShop_Helper::generate_unique_id();
$now = date_i18n('Y-m-d');
global $wpdb;
$travel_dates = $wpdb->get_results(
    "select ti.*,p.*,pr.*
     from {$wpdb->prefix}wshop_travel_item ti
     inner join {$wpdb->prefix}posts p on p.ID = ti.post_ID
     left join {$wpdb->prefix}wshop_product pr on pr.post_ID = p.ID
     where p.post_status='publish'
           and p.post_type='".WShop_Travel_Item::POST_T."'
           and ti.travel_post_ID ={$travel->post_ID}
           and ti.date>='{$now}'
           and (pr.inventory is null or pr.inventory>0) 
     order by ti.date asc;");
$min_price =0;
$dates = array();
if($travel_dates){
    foreach ($travel_dates as $date){
        $product = new WShop_Product($date);
        $travel_item = new WShop_Travel_Item($date);
        
        if(!$travel_item->date){continue;}
        
        $dates[strtotime(date('Y-m-01',strtotime($travel_item->date)))][]=$date;
        
        $sale_price = $product->get_single_price(false);
        if(!$min_price||$min_price>$sale_price){
            $min_price =$sale_price;
        }
    }
}
 
?><link href="<?php echo $api->domain_url?>/assets/style.css" rel="stylesheet" type="text/css" />
<div class="event_wrap">
    <div class="event">
        <div class="left">
            <div class="focus"> <?php echo get_the_post_thumbnail($travel->post,array(650, 410))?></div>
        </div>
        <div class="right">
            <div class="wrap">
                <div class="title">
                <ul>
                    <li class="price">
                        <span class="title">线路价格：</span> <span id="wshop-show-price"><span class="adult"><?php echo $min_price?></span> 元起</span>
                    </li>
                    <li>
                        <span class="title_spot">线路特色：</span><span class="tag">冰雪之旅</span><span class="tag">十里画廊</span><span class="tag">冰雪之旅</span><span class="tag">十里画廊</span><span class="tag">冰雪之旅</span><span class="tag">十里画廊</span>
                    </li>
                    </ul>
                </div>
            </div>
            <div class="info">
             <ul>
                <li><span>活动天数：</span>5天</li>
                <li><span>集合地点：</span>成都市金牛区羊犀立交地铁A出口</li>
                <li><span>服务理念：</span>我们只做真正的旅行，800员工为您倾情服务！</li>
                <li><span>活动优惠：</span><span class="sales"><i class="fa fa-cny fa"></i> 点评返现</span><span class="sales"><i class="fa fa-pencil fa"></i> 写游记有奖</span></li>
                <li><span>付款方式：</span><span class="pay"><i class="fa fa-weixin fa"></i> 微信</span><span class="pay"><i class="fa fa-yen fa"></i> 支付宝</span><span class="pay"><i class="fa fa-credit-card fa"></i> 银行汇款</span></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="event_blank"></div>

<div class="event_wrap">
    <div class="event_calendar">
        <div class="left">
            <div class="schedule_wrap">
                <div class="schedule_title">
                	<ul>
                		<?php 
                		 $index = 0;
                		  foreach ($dates as $date=>$items){
                		      ?> <li style="cursor:pointer;" id="wshop-date-title-<?php echo $date;?>" class="wshop-date <?php echo $index++===0?'on':''?>" data-date="<?php echo $date?>"><?php echo date('Y年m月',$date);?></li><?php 
                		  }
                		?>
                    </ul>
                </div>
                <style type="text/css">
                    .schedule_day{display:none;}
                    .schedule_day.show{display:block;}
                    .schedule_day li.today .date{color:green;font-weight: bold}
                </style>
                <?php 
                    if(!function_exists('wshop_travel_generate_calendar_html')){
                        function wshop_travel_generate_calendar_html($date_of_time,$travel_items,$_index=0,&$products){
                            $time = $date_of_time;
                            $year = date('Y',$time);
                            $month = date('m',$time);
                           // $day = date('d',$time);
                            //这个月起始位置
                            $start_of_month = date('w',strtotime("$year-$month-01"));
                            //一个月的天数
                            $days_of_month = date('t',$time);
                            
                            $days_of_last_month= date('t',strtotime('-1 month', $time));
                            ob_start();
                            ?> <div class="schedule_day <?php echo $_index===0?'show':'';?>" id="wshop-date-<?php echo $date_of_time?>"><ul><?php 
                            $_now = date_i18n('Y-m-d');
                            for ($index=1;$index<=6;$index++){
                                for($week=0;$week<=6;$week++){
                                    $position = 7*($index-1)+$week;
                                    if($position>=$start_of_month&&$position<=($days_of_month+$start_of_month-1)){
                                        $day_now =($position-$start_of_month)+1;
                                        $date_now ="{$year}-{$month}-".($day_now<10?"0{$day_now}":$day_now);
                                        $travel_item =WShop_Helper_Array::first_or_default($travel_items,function($m,$date){
                                            return $m->date==$date;
                                        },$date_now);
                                       
                                        if($travel_item){
                                            $product = new WShop_Product($travel_item);
                                            $product->travel_date = strtotime("{$year}-{$month}-01");
                                            $products[]=$product;
                                           ?>
                                            <li style="cursor:pointer;" id="wshop-day-<?php echo $product->post_ID?>" class="wshop-day-online <?php echo $date_now==$_now?'today':'';?>" data-date="<?php echo $date_now;?>" data-id="<?php echo $product->post_ID?>" data-inventory="<?php echo $product->get_inventory()?>" data-price="<?php echo $product->get_single_price(false)?>" data-priceshow="<?php echo esc_attr($product->get_single_price(true))?>">
                                                <span class="date"><?php echo $day_now;?></span>
                                                <span class="stock">余<?php echo $product->get_inventory();?></span>
                                         		<span class="price"><?php echo $product->get_single_price(true)?></span>
                                            </li>
                                           <?php  
                                        }else{
                                            ?>
                                            <li class="<?php echo $date_now==$_now?'today':'';?>">
                                                <span class="date"><?php echo $day_now;?></span>
                                            </li>
                                           <?php  
                                        }
                                    }else{
                                        ?>
                                        <li>
                                            <span class="date"></span>
                                        </li>
                                        <?php 
                                    }
                                }
                            } 
                            
                    		?></ul></div><?php 
                    		return ob_get_clean();
                        }
                    }
                ?>
                
                <div class="schedule_week">
                 	<ul>
                        <li>日</li>
                        <li>一</li>
                        <li>二</li>
                        <li>三</li>
                        <li>四</li>
                        <li>五</li>
                        <li>六</li>
                    </ul>
                </div>
                <ul>
               		 <li>
                        <?php 
                            $index = 0;
                            $products=array();
                            foreach ($dates as $date=>$items){
                                echo wshop_travel_generate_calendar_html($date,$items,$index++,$products);
                            }
                        ?>
                     </li>
                </ul>
                
            </div>
            <p>* 日历上显示的价格为当日最低成人优惠价，您可在下单时选择可用的优惠</p>
  			
        </div>
        <div class="right">
          <div class="reserve">
          	<ul>
                <li>
                    <span>出发时间：</span>
                    <select id="wshop-show-date">
                    	<?php foreach ($products as $product){
                    	    ?><option data-date="<?php echo $product->travel_date?>" value="<?php echo $product->post_ID;?>"><?php echo date('Y年m月d日',strtotime($product->date))?> （余<?php echo $product->get_inventory()?>） <?php echo $product->get_single_price(true)?></option><?php 
                    	}?>
                    </select>
                </li>
                <li>
                    <span>出游人数：</span>
                    <span class="info">成人</span>
                    <div class="gw_num">
                        <em class="jian" id="wshop-adult-qty-cut">-</em>
                        <input type="text" value="1" class="num" id="wshop-adult-qty"/>
                        <em class="add" id="wshop-adult-qty-add">+</em>
                    </div>
                    <span class="info">儿童</span>
                    <div class="gw_num">
                        <em class="jian" id="wshop-child-qty-cut">-</em>
                        <input type="text" value="0" class="num" id="wshop-child-qty"/>
                        <em class="add" id="wshop-child-qty-add">+</em>
                    </div>
                </li>
                <li class="links">
                	<?php 
                	echo WShop::instance()->WP->requires(WSHOP_DIR, '__purchase.php',array(
                	    'content'=>'立即预订',
                	    'class'=>'reserves',
                	    'location'=>WShop_Helper_Uri::get_location_uri(),
                	    'context'=>$context,
                	    'modal'=>'travel_shopping',
                	    'section'=>'travel_shopping'
                	));
                	?>
                    <a class="consult" href=""><i class="fa fa-user-circle-o fa-lg"></i> 在线咨询</a>
                </li>
                <li class="tel"><img src="<?php echo $api->domain_url?>/assets/images/zixun_tel.png" /></li>
                </ul>
                <?php 
            	echo WShop::instance()->WP->requires(WSHOP_DIR, 'page/checkout-order-pay-total-amount.php',array(
            	    'context'=>$context
            	));
            	?>
                <script type="text/javascript">
                
               		(function($){
						$('.wshop-date').click(function(){
							$('.wshop-date.on').removeClass('on');
							$(this).addClass('on');
							$('.schedule_day.show').removeClass('show');
							$('#wshop-date-'+$(this).data('date')).addClass('show');
						});

						$('.wshop-day-online').click(function(){
							$('.wshop-day-online.selected').removeClass('selected');
							var $this = $(this).addClass('selected');
							$('#wshop-show-date').val( $this.data('id'));
							
							window.wshop_on_adult_qty_change(0);
							window.wshop_on_child_qty_change(0);
						});

						$('#wshop-show-date').change(function(){
							$('#wshop-date-title-'+jQuery('#wshop-show-date option:selected').data('date')).click();
							$('#wshop-day-'+$(this).val()).click();
						});
						
						window.default_show_price = $('#wshop-show-price').html();

						$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
							var $product = $('.wshop-day-online.selected');
							if($product.length==0){
								return;
							}

							data.post_id = $product.data('id');
							data.adult_qty= parseInt($('#wshop-adult-qty').val());
							data.child_qty= parseInt($('#wshop-child-qty').val());
	                	});

						$(document).bind('wshop_<?php echo $context;?>_init_amount_before',function(e,data){
							var $product = $('.wshop-day-online.selected');
							if($product.length==0){
								return;
							}
							
							var price = $product.data('price');
							var adult_qty= parseInt($('#wshop-adult-qty').val());
							if(isNaN(adult_qty)){adult_qty=0;}
							var child_qty= parseInt($('#wshop-child-qty').val());
							if(isNaN(child_qty)){child_qty=0;}

							var child_price = parseFloat(price)-<?php echo round(floatval($travel->get('child_free_amount')),2);?>;
							if(child_price<0){child_price=0;}
							data.total_amount+=parseFloat(price)*adult_qty+child_qty*child_price;
	                	});
						
						$(document).bind('wshop_<?php echo $context?>_show_amount',function(e,view){
		    				var total =view.total_amount;
		    				if(total<=0){
		    					$('#wshop-show-price').html(window.default_show_price);
		    				}else{
		    					$('#wshop-show-price').html('<span class="adult">'+total.toFixed(2)+'</span> 元');
		    				}
		    			});
		    			
						window.wshop_on_adult_qty_change=function(changed){
							var qty = parseInt($('#wshop-adult-qty').val());
							if(isNaN(qty)||qty<0){qty=0;}

							var cqty = parseInt($('#wshop-child-qty').val());
							if(isNaN(cqty)||cqty<0){cqty=0;}

							var $product = $('.wshop-day-online.selected');
							if($product.length==0){return;}

							var inventory = parseInt($product.data('inventory'));
							if(isNaN(inventory)||inventory<0){
								inventory=0;
							}

							if(cqty>inventory){
								cqty=inventory;
								$('#wshop-child-qty').val(cqty);
							}
							
							if((qty+cqty)>inventory){
								qty=inventory-cqty;
								$('#wshop-adult-qty').val(qty);
							}

							var qty = changed+qty;
							if(qty<0){qty=0;}
							if(qty>(inventory-cqty)){
								qty=inventory-cqty;
							}

							$('#wshop-adult-qty').val(qty);
							$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
						}

						window.wshop_on_child_qty_change=function(changed){
							var qty = parseInt($('#wshop-adult-qty').val());
							if(isNaN(qty)||qty<0){qty=0;}

							var cqty = parseInt($('#wshop-child-qty').val());
							if(isNaN(cqty)||cqty<0){cqty=0;}

							var $product = $('.wshop-day-online.selected');
							if($product.length==0){return;}

							var inventory = parseInt($product.data('inventory'));
							if(isNaN(inventory)||inventory<0){
								inventory=0;
							}

							if(qty>inventory){
								qty=inventory;
								$('#wshop-adult-qty').val(qty);
							}
							
							if((qty+cqty)>inventory){
								cqty=inventory-qty;
								$('#wshop-child-qty').val(cqty);
							}

							var cqty = changed+cqty;
							if(cqty<0){cqty=0;}
							if(cqty>(inventory-qty)){
								cqty=inventory-qty;
							}

							$('#wshop-child-qty').val(cqty);
							$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
						};
						
						$('#wshop-adult-qty-cut').click(function(){
							window.wshop_on_adult_qty_change(-1);
						});
						$('#wshop-adult-qty-add').click(function(){
							window.wshop_on_adult_qty_change(1);
						});
						$('#wshop-adult-qty').keyup(function(){
							window.wshop_on_adult_qty_change(0);
						});

						//-----------------------------------------------------------------
						$('#wshop-child-qty-cut').click(function(){
							window.wshop_on_child_qty_change(-1);
						});
						$('#wshop-child-qty-add').click(function(){
							window.wshop_on_child_qty_change(1);
						});
						
						$('#wshop-child-qty').keyup(function(){
							window.wshop_on_child_qty_change(0);
						});

						$('.wshop-day-online').first().click();
					})(jQuery);
                </script>
            </div>
        </div>
    </div>
</div>