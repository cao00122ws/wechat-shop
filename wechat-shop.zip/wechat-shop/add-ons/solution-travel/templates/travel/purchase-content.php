<?php 
if (! defined('ABSPATH')) {
    exit();
}

$context = WShop_Helper::generate_unique_id();
$api = WShop_Modal_Solution_Travel::instance();

$cart = WShop_Shopping_Cart::get_cart();
if($cart instanceof WShop_Error){
    WShop::instance()->WP->wp_die($cart,false,false);
    return;
}

$cart_items = $cart->get_items();
if($cart_items instanceof WShop_Error){
    WShop::instance()->WP->wp_die($cart_items,false,false);
    return;
}

if(count($cart_items)==0){
    WShop::instance()->WP->wp_die('未找到商品信息，请返回店铺重新下单！',false,false);
    return;
}

$cart_item=null;
foreach ($cart_items as $cart_item){
   break; 
}
$product = $cart_item['product'];

$travel_item = new WShop_Travel_Item($product->post_ID);
if(!$travel_item->is_load()){
    WShop::instance()->WP->wp_die('未找到商品信息，请返回店铺重新下单！',false,false);
    return;
}
$travel = new WShop_Travel($travel_item->travel_post_ID);
if(!$travel->is_load()){
    WShop::instance()->WP->wp_die('未找到商品信息，请返回店铺重新下单！',false,false);
    return;
}
$symbol = $product->get_currency_symbol();

$adult_qty = isset($cart_item['metas']['adult_qty'])?absint($cart_item['metas']['adult_qty']):0;
$child_qty = isset($cart_item['metas']['child_qty'])?absint($cart_item['metas']['child_qty']):0;

$now = date_i18n('Y-m-d');
global $wpdb;
$travel_dates = $wpdb->get_results(
   "select ti.*,p.*,pr.*
    from {$wpdb->prefix}wshop_travel_item ti
    inner join {$wpdb->prefix}posts p on p.ID = ti.post_ID
    inner join {$wpdb->prefix}wshop_product pr on pr.post_ID = p.ID
    where p.post_status='publish'
            and p.post_type='".WShop_Travel_Item::POST_T."'
            and ti.travel_post_ID ={$travel->post_ID}
            and ti.date>='{$now}'
            and (pr.inventory is null or pr.inventory>0) 
    order by ti.date asc;");
?>
<link href="<?php echo $api->domain_url?>/assets/style.css" rel="stylesheet" type="text/css" /> 
<div class="order_wrap">
    <div class="order">
        <div class="title"><i class="fa fa-file-text-o fa"></i> 预订信息</div>
        <div class="info_wrap pcinfo">
            <div class="left"> <?php echo get_the_post_thumbnail($travel->post,array(280, 180))?></div>
            <div class="right">
            	<ul>
                <li><span>产品名称：</span><a href="<?php the_permalink($travel->post)?>"><?php echo get_the_title($travel->post)?></a></li>
                <li><span>活动天数：</span>5天</li>
                <li><span>集合地点：</span>成都市金牛区羊犀立交地铁A出口</li>
                <li><span>出发时间：</span>
                    <select id="wshop-show-date">
                    	<?php if($travel_dates){
                    	    foreach ($travel_dates as $date){
                    	        $_product = new WShop_Product($date);
                    	        if(!$_product->is_load()){continue;}
                    	        ?><option data-date="<?php echo date('Y年m月d日',strtotime($date->date))?>" data-inventory="<?php echo $_product->get_inventory();?>" data-price="<?php echo $_product->get_single_price(false)?>" data-showprice="<?php echo $_product->get_single_price(true)?>" value="<?php echo $_product->post_ID?>" <?php echo $_product->post_ID==$product->post_ID?'selected':'';?>><?php echo date('Y年m月d日',strtotime($_product->date))?> （余<?php echo $_product->get_inventory()?>） <?php echo $_product->get_single_price(true)?></option><?php 
                    	    }
                    	}?>
                    </select> 
                </li>
                </ul>
            </div>
        </div>
        <div class="table">
            <ul class="tit">
                <li>类型</li>
                <li>日期</li>
                <li>单价</li>
                <li>数量</li>
                <li>金额</li>
            </ul>
            <ul class="con">
                <li>成人</li>
                <li id="travel-date-adult-day"><?php echo $travel_item->date?></li>
                <li id="travel-date-adult-price"><?php 
                        $adult_amount =  $product->get_single_price(false);
                        echo "{$symbol}{$adult_amount}";
                ?></li>
                <li>
                    <div class="order_num">
                        <em class="jian" id="wshop-adult-qty-cut">-</em>
                        <input type="text" value="<?php echo $adult_qty;?>" class="num" id="wshop-adult-qty"/>
                        <em class="add" id="wshop-adult-qty-add">+</em>
                    </div>
                </li>
                <li><span id="wshop-subtotal-adult"><?php
                $adult_subtotal = $adult_amount*$adult_qty;
                echo "{$symbol}{$adult_subtotal}";
                ?></span></li>
            </ul>
            <ul class="con">
                <li>儿童</li>
                <li id="travel-date-child-day"><?php echo $travel_item->date?></li>
                <li id="travel-date-child-price"><?php 
                    $price = $product->get_single_price(false);
                    $child_free_amount = round(floatval($travel->get('child_free_amount')),2);
                    
                    $child_amount = ($price-$child_free_amount)<0?0:round($price-$child_free_amount,2);
                    echo "{$symbol}{$child_amount}";
                ?></li>
                <li>
                    <div class="order_num">
                        <em class="jian" id="wshop-child-qty-cut">-</em>
                        <input type="text" value="<?php echo $child_qty;?>" class="num" id="wshop-child-qty"/>
                        <em class="add" id="wshop-child-qty-add">+</em>
                    </div>
                </li>
                <li>
                    <span id="wshop-subtotal-child"><?php
                    $child_subtotal = $child_amount*$child_qty;
                    echo "{$symbol}{$child_subtotal}";
                    ?></span>
                </li>
            </ul>
        </div>
         <?php 
        	echo WShop::instance()->WP->requires(WSHOP_DIR, 'page/checkout-order-pay-total-amount.php',array(
        	    'context'=>$context
        	));
    	   ?>
        <script type="text/javascript">
			(function($){
				$('#wshop-show-date').change(function(){
					$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
				});
				
				$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
					data.post_id = $('#wshop-show-date').val();
					data.adult_qty= parseInt($('#wshop-adult-qty').val());
					data.child_qty= parseInt($('#wshop-child-qty').val());
            	});

				$(document).bind('wshop_<?php echo $context;?>_init_amount_before',function(e,view){
					var $date =$('#wshop-show-date option:selected');
					
					var price = parseFloat($date.data('price'));
					if(isNaN(price)){price=0;}
					
					var adult_qty= parseInt($('#wshop-adult-qty').val());
					if(isNaN(adult_qty)){adult_qty=0;}
					var child_qty= parseInt($('#wshop-child-qty').val());
					if(isNaN(child_qty)){child_qty=0;}

					var child_price = parseFloat(price)-<?php echo round(floatval($travel->get('child_free_amount')),2);?>;
					if(child_price<0){child_price=0;}
					
					view.total_amount+=parseFloat(price)*adult_qty+child_qty*child_price;
					
					$('#travel-date-adult-day').text($date.data('date'));
					$('#travel-date-child-day').text($date.data('date'));
					
					$('#travel-date-adult-price').html(view.symbol+price.toFixed(2));
					$('#travel-date-child-price').html(view.symbol+child_price.toFixed(2));
					
					$('#wshop-subtotal-adult').html(view.symbol+(adult_qty*price).toFixed(2));
					$('#wshop-subtotal-child').html(view.symbol+(child_qty*child_price).toFixed(2));
            	});
				
				$(document).bind('wshop_<?php echo $context?>_show_amount',function(e,view){
    				var total =view.total_amount;
    				$('#wshop-show-total').html(view.symbol+total.toFixed(2))
    			});
				window.wshop_on_adult_qty_change=function(changed){
					var qty = parseInt($('#wshop-adult-qty').val());
					if(isNaN(qty)||qty<0){qty=0;}

					var cqty = parseInt($('#wshop-child-qty').val());
					if(isNaN(cqty)||cqty<0){cqty=0;}

					var inventory = parseInt($('#wshop-show-date option:selected').data('inventory'));
					inventory = isNaN(inventory)?9999:inventory;
					if(isNaN(inventory)||inventory<0){
						inventory=0;
					}

					if(cqty>inventory){
						cqty=inventory;
						$('#wshop-child-qty').val(cqty);
					}
					
					if((qty+cqty)>inventory){
						qty=inventory-cqty;
						$('#wshop-adult-qty').val(qty);
					}

					var qty = changed+qty;
					if(qty<0){qty=0;}
					if(qty>(inventory-cqty)){
						qty=inventory-cqty;
					}

					$('#wshop-adult-qty').val(qty);
					$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
				}

				window.wshop_on_child_qty_change=function(changed){
					var qty = parseInt($('#wshop-adult-qty').val());
					if(isNaN(qty)||qty<0){qty=0;}

					var cqty = parseInt($('#wshop-child-qty').val());
					if(isNaN(cqty)||cqty<0){cqty=0;}

					var inventory = parseInt($('#wshop-show-date option:selected').data('inventory'));
					inventory = isNaN(inventory)?9999:inventory;
					if(isNaN(inventory)||inventory<0){
						inventory=0;
					}

					if(qty>inventory){
						qty=inventory;
						$('#wshop-adult-qty').val(qty);
					}
					
					if((qty+cqty)>inventory){
						cqty=inventory-qty;
						$('#wshop-child-qty').val(cqty);
					}

					var cqty = changed+cqty;
					if(cqty<0){cqty=0;}
					if(cqty>(inventory-qty)){
						cqty=inventory-qty;
					}

					$('#wshop-child-qty').val(cqty);
					$(document).trigger('wshop_<?php echo $context?>_on_amount_change');
				};
				
				$('#wshop-adult-qty-cut').click(function(){
					window.wshop_on_adult_qty_change(-1);
				});
				$('#wshop-adult-qty-add').click(function(){
					window.wshop_on_adult_qty_change(1);
				});
				$('#wshop-adult-qty').keyup(function(){
					window.wshop_on_adult_qty_change(0);
				});

				//-----------------------------------------------------------------
				$('#wshop-child-qty-cut').click(function(){
					window.wshop_on_child_qty_change(-1);
				});
				$('#wshop-child-qty-add').click(function(){
					window.wshop_on_child_qty_change(1);
				});
				
				$('#wshop-child-qty').keyup(function(){
					window.wshop_on_child_qty_change(0);
				});
			})(jQuery);
        </script>
        
        
        <div class="contit">
            <?php 
            $form_product = new WShop_Forms_Product($travel->post_ID);
            $form =$form_product->is_load()? new WShop_Forms($form_product->form_id):null;
            if($form&&$form->is_load()){
                ?>
                <style type="text/css">
                    .wshop-travel-form .form-control,.wshop-travel-form .xh-input-group {width:400px;}
					.xh-form .xh-form-group{height: 40px;}
					.xh-form label{float: left;}
					.wshop-travel-form .form-control, .wshop-travel-form .xh-input-group{float: right;}
                </style>
                <div class="title bak"><i class="fa fa-user-o"></i> 联系人信息 <span>（用于接收订单反馈）</span></div>                
                <div class="xh-form wshop-travel-form" style="max-width:550px;">
                	<?php  echo $form->to_html($context);?>
                </div>
                
                <?php 
            }
            ?>
        	<div class="title bak"><i class="fa fa-credit-card"></i> 支付方式 <span></span></div>  
        	<?php 
        	   $gateways = WShop::instance()->payment->get_payment_gateways();
        	   if($gateways){
        	       ?>
        	       <ul>
        	       <?php 
        	       $index =0;
        	       foreach ($gateways as $gateway){
        	           ?><li><label style="margin-right:15px;"><input class="wshop-travel-<?php echo $context;?>-payment-method" type="radio" <?php echo $index++==0?'checked':'';?> name="payment-method-<?php echo $context?>" value="<?php echo esc_attr($gateway->id)?>" > <img src="<?php echo esc_attr($gateway->icon)?>" alt="<?php echo esc_attr($gateway->title);?>"></label></li><?php
        	       }
        	       ?>
        	       </ul>
        	       <script type="text/javascript">
                    	(function($){
                    		$(document).bind('wshop_form_<?php echo $context?>_submit',function(e,data){
        						data.payment_method = $('.wshop-travel-<?php echo $context;?>-payment-method:checked').val();
                        	});
                    	})(jQuery);
                    </script>
        	       <?php 
        	   }
        	?>              
            <ul class="submit">
                <li>订单结算总额：<span id="wshop-show-total">￥0.00</span></li>
                <li>
                	<style type="text/css">
                        .order .contit ul.submit li .submit {
                            width: 120px;
                            height: 35px;
                            border: 0px;
                            background-color: #FF9600;
                            border-radius: 5px;
                            font: 500 16px/30px "\5FAE\8F6F\96C5\9ED1",Arial;
                            color: #fff;
                        }
                    </style>
                	<?php 
                	echo WShop::instance()->WP->requires(WSHOP_DIR, '__purchase.php',array(
                	    'content'=>'提交订单',
                	    'class'=>'submit',
                	    'location'=>WShop_Helper_Uri::get_location_uri(),
                	    'context'=>$context,
                	    'modal'=>'travel_shopping',
                	));
                	?>
                </li>
          </ul>
        </div>
    </div>
</div>