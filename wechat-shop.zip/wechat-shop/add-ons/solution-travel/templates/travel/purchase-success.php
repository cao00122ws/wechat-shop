<?php 
if (! defined('ABSPATH')) {
    exit();
}
$request = shortcode_atts(array(
    'oid'=>0,
    'hash'=>null,
    'notice_str'=>null
), stripslashes_deep($_REQUEST));
if(!WShop::instance()->WP->ajax_validate($request, $request['hash'])){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
    return;
}

$order = new WShop_Order($request['oid']);
if(!$order->is_load()){
    WShop::instance()->WP->wp_die(WShop_Error::err_code(404),false,false);
    return;
}
?>
<div class="order_wrap">
    <div class="success_wrap">
    	<?php if($order->is_paid()){
    	    ?>
    	     <div class="success">
                <h1><i class="fa fa-check-circle fa-lg"></i> 预定成功，等待确认...</h1>
                <ul>
                    <li>订单详情已发送至您的邮箱；</li>
                    <li>请保持您的电话畅通，我们的工作人员将尽快确认并联系您！</li>
                    <li>
                        <a href="<?php echo $order->get_review_url();?>">查看订单</a>
                        <a href="/">返回首页</a>
                    </li>
                </ul>
            </div>
    	    <?php 
    	}else{
    	    ?>
    	     <div class="failed">
                <h1><i class="fa fa-check-circle fa-lg"></i> 订购失败</h1>
                <ul>
                    <li>如有疑问，请咨询在线客服！</li>
                    <li><a href="<?php echo $order->get_review_url();?>">查看订单</a><a href="/">返回首页</a></li>
                </ul>
            </div>
    	    <?php 
    	}?>
       
    </div>

</div>