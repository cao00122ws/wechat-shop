<?php 
/*
 Template Name: WShop - Checkout
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
get_header();
	    while ( have_posts() ) : 
	       the_post();
	       the_content();
		// End the loop.
		endwhile;
get_footer();