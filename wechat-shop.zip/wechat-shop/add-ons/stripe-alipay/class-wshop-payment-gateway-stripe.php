<?php 

if (! defined ( 'ABSPATH' ))
	exit (); // Exit if accessed directly

class WShop_Payment_Gateway_Stripe_Alipay extends Abstract_WShop_Payment_Gateway{
    /**
     * The single instance of the class.
     *
     * @since 1.0.0
     * @var WShop_Payment_Gateway_Stripe_Alipay
     */
    private static $_instance = null;

    /**
     * Main Social Instance.
     *
     * @since 1.0.0
     * @static
     * @return WShop_Payment_Gateway_Stripe_Alipay
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    public function __construct(){
        $this->id='stripe_alipay';
        $this->group = 'alipay';
        $this->title=__('Stripe - Alipay',WSHOP);
        $this->icon=WSHOP_URL.'/assets/image/stripe-alipay-l.png';
        $this->icon_small=WSHOP_URL.'/assets/image/stripe-alipay.png';
        
        $this->init_form_fields ();
        $this->enabled ='yes'==$this->get_option('enabled');
    }
    
    /**
     * 
     * {@inheritDoc}
     * @see Abstract_WShop_Settings::init_form_fields()
     */
    public function init_form_fields() {
        $this->form_fields = array (
            'enabled' => array (
                'title' => __ ( 'Enable/Disable', WSHOP ),
                'type' => 'checkbox',
                'label' => __ ( 'Enable strip alipay payment', WSHOP ),
                'default' => 'yes'
            ),
		    'transaction_mode'=>array(
                'title'=>__('Transaction Mode',WSHOP),
                'type'=>'section',
                'options'=>array(
                    0=>__('Live Mode',WSHOP),
                    1=>__('Test Mode',WSHOP),
                )
            ),
		    'live_secret_Key'=>array(
		        'tr_css'=>'section-transaction_mode section-0',
		        'title'=>__('Live Secret Key',WSHOP),
		        'type'=>'text'
		    ),
		    'live_publishable_Key'=>array(
		        'tr_css'=>'section-transaction_mode section-0',
		        'title'=>__('Live Publishable Key',WSHOP),
		        'type'=>'text'
		    ),
		    'test_secret_Key'=>array(
		        'tr_css'=>'section-transaction_mode section-1',
		        'title'=>__('Test Secret Key',WSHOP),
		        'type'=>'text',
		        'default'=>'sk_test_QVClolZBAPN8McB0A2apczMe'
		    ),
		    'test_publishable_Key'=>array(
		        'tr_css'=>'section-transaction_mode section-1',
		        'title'=>__('Test Publishable Key',WSHOP),
		        'type'=>'text',
		        'default'=>'pk_test_7oavF5AEjF7C6mxUepNwdaAs'
		    ),
            'exchange_rate'=>array(
                'title'=>__('Exchange Rate',WSHOP),
                'type'=>'text',
                'default'=>'6.5785',
                'description'=>__('Set exchange rate to USD. When currency is CNY, default 6.5785.',WSHOP)
            )
        );
    }
    
    public function get_Key(){
        $mode = $this->get_option('transaction_mode');
        switch ($mode){
            case '0':
                return array(
                'secret_Key'=>$this->get_option('live_secret_Key'),
                'publishable_Key'=>$this->get_option('live_publishable_Key')
                );
            case '1':
                return array(
                'secret_Key'=>$this->get_option('test_secret_Key'),
                'publishable_Key'=>$this->get_option('test_publishable_Key')
                );
            default:
                return array(
                'secret_Key'=>null,
                'publishable_Key'=>null
                );
        }
    }
    
    /**
     * {@inheritDoc}
     * @see Abstract_WShop_Payment_Gateway::process_payment()
     */
    public function process_payment($order)
    {
        $api = WShop_Add_On_Stripe_Alipay::instance();
        
        return WShop_Error::success(WShop::instance()->ajax_url(array(
            'action'=>"wshop_{$api->id}",
            'tab'=>'pay',
            'order_id'=>$order->id
        ),true,true));
    }
    
}
?>