<?php 
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

abstract class Abstract_WShop_Add_Ons_Stripe_Alipay_Api extends Abstract_WShop_Add_Ons{
    public $u;
    public $i;
    public $k;
    protected function __construct(){
        $o = $this;
        $o->u = WSHOP_URL;
        $o->i = WShop_Install::instance()->get_plugin_options();
        $o->k=WShop::$license_id;
    }
  
    /**
     * 执行 on_init()
     */
    public function m2(){
        $o=$this;
        $o->m0(function($o){
            add_filter('wshop_admin_menu_menu_default_checkout', function($menu){
                $menu[]= WShop_Payment_Gateway_Stripe_Alipay::instance();
                return $menu;
            },10,1);
           
            add_filter('wshop_payments', function($payment_gateways){
                $payment_gateways[] =WShop_Payment_Gateway_Stripe_Alipay::instance();
                return $payment_gateways;
            },10,1);
                
           
        $o->setting_uris=array();
            $o->setting_uris['settings']=array();
            $o->setting_uris['license']=array();
            $o->setting_uris['settings']['title']=__('Settings',WSHOP);
            $o->setting_uris['settings']['url']=admin_url('admin.php?page=wshop_page_default&section=menu_default_checkout&sub=stripe_alipay');
            
            $api = WShop_Install::instance();
            $o->setting_uris['license']['title']=__('Change license',WSHOP);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);            
           
        },function($o){
            $o->setting_uris=array();
            $o->setting_uris['license']=array();
           
            $api = WShop_Install::instance();
            $o->setting_uris['license']['title']=__('License',WSHOP);
            $o->setting_uris['license']['url']=$api->get_addon_license_url($o->id);
        });
    }

    public function m0($func_success,$func_fail){
	    $o = $this;
	    $website=$o->u;
	    $website = strtolower($website);
	    $license_id = $o->id;
	    if(strpos($website, 'http://')===0){
	        $website = substr($website, 7);
	    }else if(strpos($website, 'https://')===0){
	        $website = substr($website, 8);
	    }
	   
	    //去掉二级目录
	    if(strpos($website, '/')!==false){
	        $websites = explode('/', $website);
	        $website = $websites[0];
	    }
	    $prewebsite =$website;
	    $info = $o->i;
	    $license =$info&&isset($info[$o->id])?$info[$o->id]:null;
	    $licenses= $license?explode('=', $license):array();
	    $license =count($licenses)>0?$licenses[0]:null;
	    $expire=count($licenses)>1?$licenses[1]:null;

	    $id=$o->id;
	    $bk=0;
	    while (true){
	        $str =$expire."|".$website."|".$id; 
	        $str =md5($str);
	        $b =0;
	        for ($i=0;$i<strlen($str);$i++){
	            $b+= ord($str[$i]);
	        }
	     
	        $xx=md5($str.$b)==$license;
	        $o->ia=$xx;
	        if($xx){
	            if($func_success){
	                $func_success($o);
	            }
	            break;
	        }
    
            if(substr_count($website,'.')<=1){ 
                if($bk<count($o->k)){
                    $website=$prewebsite;
                    $license =$info&&isset($info['license'])?$info['license']:null;
                    $licenses= $license?explode('=', $license):array();
                    $license =count($licenses)>0?$licenses[0]:null;
                    $expire=count($licenses)>1?$licenses[1]:null;
                    $id = $o->k[$bk++];
                    continue;
                }
                
                if($func_fail){
                    $func_fail($o);
                }
                break;
            }
    
            $index = strpos($website, '.');
            $website = substr($website, $index+1);
	    } 
	}
}